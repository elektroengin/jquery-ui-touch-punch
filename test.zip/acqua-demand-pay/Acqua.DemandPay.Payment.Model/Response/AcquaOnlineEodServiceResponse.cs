﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Model.Response
{
    public class AcquaOnlineEodServiceResponse
    {
        public string F37 {  get; set; }
        public string F38 { get; set; }
        public string F42 { get; set; }
        public string ResponseCode {  get; set; }
        public string ResponseMessage { get; set; }   
        public int ServiceOperation { get; set; }
    }
}
