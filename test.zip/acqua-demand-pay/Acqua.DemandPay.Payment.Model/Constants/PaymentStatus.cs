﻿namespace Acqua.DeamndPay.Payment.Model.Constants
{
    public class PaymentStatus
    {
        /// <summary>
        /// Ödeme İste talebi Ödemeler biriminden ilk gönderildiğinde ve POS_INFO'dan üyeişyeri numarası ve etkinlik kontorlünden geçtikten sonra ki ilk statüdür.
        /// </summary>
        public const string PN = "PN";
        /// <summary>
        /// Ödemeler, işlemi sorgulamak için geldiğinde (sorgu servisi aşaması) kayıt mevcutsa, statü VR'ye (verified) çekilmelidir.
        /// </summary>
        public const string VR = "VR";
        /// <summary>
        /// Ödemeler, işlem validasyonu için geldikleri zaman, kayıt VL'ye (validated) çekilmelidir.
        /// </summary>
        public const string VL = "VL";
        /// <summary>
        /// işlem validasyon ardından Günsonuna (End of Day) gönderildiği zaman, statü ED'ye çekilmelidir.
        /// </summary>
        public const string ED = "ED";
        /// <summary>
        /// Ödeme iste işlemi günsonundan olumlu olacak geldiği zaman ve otorizasyon için POSMRC.POS_TRNX_INFO ve POS_TRNX_DETAIL_INFO'ya eklendiği zaman, OK statüsüne çekilmelidir.
        /// </summary>
        public const string OK = "OK";
        /// <summary>
        /// akışın herhangi bir aşamasında, sistem kaynaklı (timeout veya error kodları) veya harici bir hata alındığı zman statü ER'ye (error) çekilmelidir.
        /// </summary>
        public const string ER = "ER";
        /// <summary>
        /// Ödeme İste işleminin validasyon veya Günsonu'ndan gelen red cevabı durumlarında, işlem statüsü NO'ya çekilmelidir.
        /// </summary>
        public const string NO = "NO";
        /// <summary>
        /// Ödeme İste İşlemi, başarılı olarak iade edildiyse, iade edilen işleme ait statü değeri RF'e çekilmelidir.
        /// </summary>
        public const string RF = "RF";
        /// <summary>
        /// Ödeme İste işlemi günsonu veya timeout konularından kaynaklı olarak reverse edildiyse, işleme ait statü değeri RV'ye çekilmelidir.
        /// </summary>
        public const string RV = "RV";
    }
}
