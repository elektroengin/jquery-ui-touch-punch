﻿namespace Acqua.DemandPay.Payment.Model.Enum
{
    public enum BusinessExceptionCodes
    {
        /// <summary>
        /// Başarılı
        /// </summary>
        Success = 0,

        /// <summary>
        /// Zorunlu alan hatası  
        /// </summary>
        ValidationError = 1,

        /// <summary>
        /// Format/uzunluk hatası 
        /// </summary>
        FormatError = 2,

        /// <summary>
        /// Tanımsız değer hatası 
        /// </summary>
        UnnounValueError = 3,

        /// <summary>
        /// Bölüm bulunamadı
        /// </summary>
        MerchantSeqRelationNotFound = 4,

        /// <summary>
        /// Bölüm bulunamadı
        /// </summary>
        SeqNoNotFound = 5,

        /// <summary>
        /// Üye işyeri fraud sebebiyle kapatılmıştır.
        /// </summary>
        MerchantClosedByFraudStar = 6,

        /// <summary>
        /// SL007 Üye işyeri statüsü bulunamadı
        /// </summary>
        StatusNotFound = 7,

        /// <summary>
        /// üye işyeri bulunamadı
        /// </summary>
        MerchantNotFound = 8,
        /// <summary>
        /// işlem bulunamadı
        /// </summary>
        TransactionInfoFound = 9,
        /// <summary>
        /// Komisyon bulunamadı
        /// </summary>
        LoyaltyComissionInfoFound = 10,
        /// <summary>
        /// işlem daha önce iptal edilmiştir.
        /// </summary>
        TransactionAlreadyCanceled = 11,
        /// <summary>
        /// transaction bulunamadı
        /// </summary>
        TransactionNotFound = 12,
        /// <summary>
        /// terminal bulunamadı
        /// </summary>
        TerminalNotFound = 13,

        /// <summary>
        ///  komisyon bulunamadı.
        /// </summary>
        ComissionInfoFound = 14,

        /// <summary>
        /// üye işyeri aktif değildir.
        /// </summary>
        MerchantNotAuthorize = 15,

        /// <summary>
        /// -MCC bulunamadı
        /// </summary>
        MccNotFound = 16,

        /// <summary>
        /// Bilinmeyen hata 
        /// </summary>
        AnUnexpectedErrorOccurred = 999,

        
        ReferenceNumberCannotBeNull = 17,                       
        AnErrorOccurredWhileSavingData = 18,
        MerchantNumberCannotBeNull = 19,
        TransactionTypeCannotBeNull = 20,
        TerminalIdCannotBeNull = 21,
        TransactionCurrencyCannotBeNull = 22,                
        AmountCanNotBeNull = 23,
        MrcADPRefNoCanNotBeNull = 24,
        MerchantAccHoldCanNotBeNull = 25,
        MerchantLoyaltyInfNotFound = 26,
        MerchantSeqRelInfNotFound = 27,
        ExpiredDateContNotBeNull = 28,
        MerchantAccIBANCanNotBeNull = 29,
        MerchantAccIBANBeValidIban = 30,
        CustomerAccIBANConNotBeNull = 31,
        CustomerAccIBANBeValidIban = 32,
        CustomerAccHoldCanNotBeNull = 33,
        DelayPayFlagCanNotBeNull = 34,
        PartialFlagCanNotBeNull = 35,
        EarlyPayFlagCanNotBeNull = 36,
        TransactionTypeCanNotBeNull = 37,
        CreateWorkplaceDetailInfoRecordDataNotFound = 38,
        InvalidTransactionType = 39,
        ExpiredDateExpireError = 40,
        AlreadyCreateWorkplaceInfoRecord = 41,
        QueryIdCannotBeNull = 42,
        PaymentIdCanNotBeNull = 43,
        FastDescriptionCanNotBeNull = 44,
        ValidDateCanNotBeNull = 45,
        InvalidIsSuspension = 46,
        DemandPayTrnxInfoDetailDataNotFound = 47,
        InformIbanToMerchantAccIBANBeValidIban = 48,
        PaymentTypeCanNotBeNull = 49,        
        OriginalTransactionNotFound = 50,
        DemandPayNotPermissions = 51,
        AlreadySuccessDermandPayment = 52
    }
}
