﻿namespace Acqua.DemandPay.Payment.Model.Request
{
    public class CreateWorkplaceInfoRecordRequest
    {
        //public string Token { get; set; }
        //public long ProcessDate { get; set; }
        //public long ProcessTime { get; set; }
        public string TransactionType { get; set; }
        //public string Rrn { get; set; }
        public string MerchantNumber { get; set; }
        public string TerminalNumber { get; set; }
        public string MrcADPRefNo { get; set; }
        //public string AdpTrnxCode { get; set; }
        public string ExpiredDate { get; set; }
        //public string CurrCode { get; set; }
        public string Amount { get; set; }
        public string MerchantAccHold { get; set; }
        public string MerchantAccIBAN { get; set; }
        public string CustomerAccHold { get; set; }
        public string CustomerAccIBAN { get; set; }
        //public short IsConsumed { get; set; }
        //public short DelayPayFlag { get; set; }
        //public short PartialPayFlag { get; set; }
        //public short EarlyPayFlag { get; set; }
        //public string ResultStatus { get; set; }
        //public DateTime? RespDate { get; set; }
    }
}
