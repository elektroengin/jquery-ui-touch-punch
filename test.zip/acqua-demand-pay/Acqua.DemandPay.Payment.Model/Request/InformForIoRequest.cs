﻿namespace Acqua.DemandPay.Payment.Model.Request
{
    public class InformForIoRequest
    {        
        public string MerchantNumber { get; set; }
        public string MrcADPRefNo { get; set; }
        public string ReferenceNumber { get; set; }
        public string PaymentType { get; set; }
        public string ValidDate { get; set; }
        public string QueryId { get; set; }
        public string PaymentId { get; set; }     
        public string Iban { get; set; }
        public string IsSuspension { get; set; }
        public string FastDescription { get; set; }
    }
}
