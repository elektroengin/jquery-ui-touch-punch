using Serilog.Sinks.File.Archive;
using System.IO.Compression;

namespace Acqua.DemandPay.Payment
{
    
        public class SerilogHooks
    {
            public static ArchiveHooks MyArchiveHooks => new ArchiveHooks(CompressionLevel.NoCompression, $"C:\\Loglar\\Acqua.DemandPay.Payment\\Trace\\archive");

            public static ArchiveHooks MyArchiveHooksError => new ArchiveHooks(CompressionLevel.NoCompression, $"C:\\Loglar\\Acqua.DemandPay.Payment\\Error\\archive");


            public static ArchiveHooks MyArchiveContainerHooks => new ArchiveHooks(CompressionLevel.NoCompression, "/app/logs/Trace/archive");

            public static ArchiveHooks MyArchiveContainerHooksError => new ArchiveHooks(CompressionLevel.NoCompression, "/app/logs/Error/archive");
        }
    
}

