﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.Validator;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Core.Validation;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using corf.Core.Messaging;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Safir.Online.Authorizer.Domain.model.Transaction.ProcessPosMessage;
using Safir.Online.Authorizer.Interface;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Executers
{
    public class CreateWorkplaceInfoRecordExecuter : BaseExecuter
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly ITransactionService _transactionService;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        //private readonly IMerchantService _merchantService;
        //private readonly ITerminalService _terminalService;
        //private readonly IMerchantLoyaltyInfoService _merchantLoyaltyInfoService;
        //private readonly IMerchantCommissionInfoService _merchantCommissionInfoService;
        //private readonly IMerchantSeqRelService _merchantSeqRelService;

        public CreateWorkplaceInfoRecordExecuter(ILogger<CreateWorkplaceInfoRecordExecuter> logger,
             IDemandPayPaymentService demandPayPaymentService,
             ITransactionService transactionService,
             //IMerchantService merchantService,
             //ITerminalService terminalService,
             //IMerchantLoyaltyInfoService merchantLoyaltyInfoService,
             //IMerchantSeqRelService merchantSeqRelService,
             //IMerchantCommissionInfoService merchantCommissionInfoService,
             IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger, demandPayPaymentConfiguration)
        {
            _demandPayPaymentService = demandPayPaymentService;
            _transactionService = transactionService;
            //_merchantService = merchantService;
            //_terminalService = terminalService;
            //_merchantLoyaltyInfoService = merchantLoyaltyInfoService;
            //_merchantCommissionInfoService = merchantCommissionInfoService;
            //_merchantSeqRelService = merchantSeqRelService;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            Logger.LogInformation(message.Unique, $"Incoming Message", $"{message.InnerMessage}");

            CreateWorkplaceInfoRecordRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoRecordRequest>(message.InnerMessage);

            Logger.LogInformation($"{message.Unique} - Data successfully deserialized");
            Logger.LogInformation($"{message.Unique} - deserialized message {JsonConvert.SerializeObject(request)}");

            var response = CreateWorkplaceInfoResponse("000");

            try
            {
                InsertDemandPayPaymentTrnx(request, message.Unique, response);
            }
            catch (Exception ex)
            {
                response = CreateWorkplaceInfoResponse("020");
                Logger.LogError(ex, $"{message.Unique} - General Error Exception Message :{ex.Message}");
            }

            message.InnerMessage = JsonConvert.SerializeObject(response);
            return await Task.FromResult(message);
        }

        /// <summary>
        /// Validate method wruns before execution
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>,

        public override MessageValidationResult Validate(InternalMessage message)
        {
            CreateWorkplaceInfoRecordResponse createWorkplaceInfoRecordResponse = new CreateWorkplaceInfoRecordResponse();
            CreateWorkplaceInfoRecordRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoRecordRequest>(message.InnerMessage);

            #region Validasyon

            try
            {                
                ValidationTool.FluentValidate(typeof(CreateWorkplaceInfoRecordRequestValidator), request);

                ValidationTool.FluentValidate(typeof(TRIbanValidator), request);

                var demandPayTrnx = _demandPayPaymentService.GetDemandPayTrnxInfoDetail(request.MerchantNumber, request.MrcADPRefNo, "000").Result;

                if (demandPayTrnx != null && demandPayTrnx.ResultStatus == "000")
                {
                    throw new BusinessException(BusinessExceptionCodes.AlreadyCreateWorkplaceInfoRecord.GetHashCode());
                }

                var processPosMessageRequest = new ProcessPosMessageRequest()
                {
                    Amount = Convert.ToDecimal(request.Amount) / 100,
                    CurrencyCode = 949,
                    DebitCreditInd = "D",
                    IsFinancial = true,
                    MerchantNumber = decimal.Parse(request.MerchantNumber),
                    Pcode = int.Parse(request.TransactionType) == (int)TransactionType.Fast ? int.Parse(request.TransactionType) == (int)TransactionType.Fast ? long.Parse("109700")
                    : long.Parse("109751") : int.Parse(request.TransactionType) == (int)TransactionType.Fast ? long.Parse("109701") : long.Parse("109702"), // FAST EFT Satis = 109700, FAST EFT Iade = 109751, FAST Havale Satis = 109701, FAST Havale Iade = 109702
                    SeqNo = 1,
                    UseDefaultSeqNo = false,
                    Source = int.Parse(request.TransactionType) == (int)TransactionType.Havale ? "O" : "D",
                    TerminalType = "POS",
                    MxmMobilePaymentType = null,
                    TerminalNumber = request.TerminalNumber,
                    Mti = 200
                };

                var posMessageResponse = _transactionService.ProcessPosMessage(processPosMessageRequest, message.Unique);

                #region Safir.Authorization kontolünden eklendi kapatıldı
                /*
                var merchantEntity = _merchantService.GetMerchantInfo(request.MerchantNumber);

                if (merchantEntity == null)
                {
                    throw new BusinessException(BusinessExceptionCodes.MerchantNotFound.GetHashCode());
                }

                var merchantStatusInfoEntity = _merchantService.GetMerchantStatusInfo(merchantEntity);

                if (merchantStatusInfoEntity == null)
                {
                    throw new BusinessException((int)BusinessExceptionCodes.StatusNotFound, "Üye işyeri statüsü bulunamadı!");
                }

                if (merchantStatusInfoEntity.Condition != ConstantValues.MRC_STATUS.O.ToString())
                {
                    throw new BusinessException((int)BusinessExceptionCodes.MrcStatIsNotOpen, "Üye işyeri statüsü kapalı!");
                }

                var terminalEntity = _terminalService.GetTerminalByTerminalNumber(request.TerminalNumber);

                if (terminalEntity == null || (terminalEntity.TermType != "VP"))
                {
                    throw new BusinessException(BusinessExceptionCodes.TerminalNotFound.GetHashCode(), "Terminal Bulunamadı!");
                }

                var merchantSeqRelEntity = _merchantSeqRelService.GetMerchantSeqRel(request.MerchantNumber, 1);
                if (merchantSeqRelEntity == null)
                {
                    throw new BusinessException(BusinessExceptionCodes.MerchantSeqRelInfNotFound.GetHashCode(), "Üye işyerinin bölüm tanımı Bulunamadı!");
                }

                if (request.TransactionType == TransactionType.Havale.ToString())
                {
                    var merchantLoyaltyInfoEntity = _merchantLoyaltyInfoService.GetPosMessageCommission(merchantSeqRelEntity.LoyalityGroupCode, "P30", Convert.ToDecimal(request.Amount) / 10, 949);
                    if (merchantLoyaltyInfoEntity == null)
                    {
                        throw new BusinessException(BusinessExceptionCodes.MerchantLoyaltyInfNotFound.GetHashCode(), "Havale Mali koşul tanımı Bulunamadı!");
                    }
                }
                else if (request.TransactionType == TransactionType.Fast.ToString())
                {
                    var merchantCommissionInfoEntity = _merchantCommissionInfoService.GetPosMessageCommission(merchantSeqRelEntity.CommissionGroupCode, "P31", Convert.ToDecimal(request.Amount) / 10, 949);

                    if (merchantCommissionInfoEntity == null)
                    {
                        throw new BusinessException(BusinessExceptionCodes.MerchantCommissionInfNotFound.GetHashCode(), "Mali koşul tanımı Bulunamadı!");
                    }
                }
                else
                {
                    throw new BusinessException(BusinessExceptionCodes.InvalidTransactionType.GetHashCode(), "TransactionType Havale:0 Fast:1 değerleri dışındadır!");
                }
                */
                #endregion


                return new MessageValidationResult { Succeed = true, PayLoad = message };

            }
            catch (ValidationException validationException)
            {
                Logger.LogError(validationException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{validationException.Message}");

                createWorkplaceInfoRecordResponse = CreateWorkplaceInfoResponse(validationException.Errors.ToList().First().ErrorCode.PadLeft(3, '0'));

                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);


                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (BusinessException businessException)
            {
                Logger.LogError(businessException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{businessException.Message}");

                createWorkplaceInfoRecordResponse = CreateWorkplaceInfoResponse(businessException.Message);
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);

                if (!string.IsNullOrEmpty(businessException.MessageDetail))
                {
                    createWorkplaceInfoRecordResponse = CreateWorkplaceInfoResponse(businessException.Message);
                    message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);
                }

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, $"{message.Unique} - Oracle hata oluştu! :{exception.Message}");

                if (exception.Message.Length == 3)
                {
                    createWorkplaceInfoRecordResponse = CreateWorkplaceInfoResponse(exception.Message.ToString());
                }
                else
                {
                    createWorkplaceInfoRecordResponse = CreateWorkplaceInfoResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString());
                }

                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            finally
            {
                if (createWorkplaceInfoRecordResponse != null && !string.IsNullOrEmpty(createWorkplaceInfoRecordResponse.ResultCode))
                {
                    InsertDemandPayPaymentTrnx(request, message.Unique, createWorkplaceInfoRecordResponse);
                }
            }

            #endregion
        }

        private CreateWorkplaceInfoRecordResponse CreateWorkplaceInfoResponse(string responseCode)
        {
            var message = _demandPayPaymentConfiguration.ResponseCodeList.SingleOrDefault(x => x.Code == responseCode);

            CreateWorkplaceInfoRecordResponse qrTransactionQueryResponse = new CreateWorkplaceInfoRecordResponse
            {
                IsSuccess = responseCode == "000",
                ResultCode = responseCode,
                ResultDescription = message.Message,
                ResultDate = DateTime.Now
            };

            return qrTransactionQueryResponse;
        }

        private async void InsertDemandPayPaymentTrnx(CreateWorkplaceInfoRecordRequest data, string unique, CreateWorkplaceInfoRecordResponse response)
        {
            try
            {
                DemandPayTrnxInfo entity = new DemandPayTrnxInfo()
                {
                    ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ADPTrnxId = "ADP" + data.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
                    MrcADPRefNo = data.MrcADPRefNo,
                    MerchantNumber = Convert.ToInt64(data.MerchantNumber),
                    TransactionType = Convert.ToInt16(data.TransactionType),
                    Amount = Convert.ToDecimal(data.Amount) / 100,
                    CurrCode = 949,
                    ExpiredDate = DateTime.ParseExact(data.ExpiredDate, "yyyyMMddHHmmss", null),
                    DelayPayFlag = 0,//data.DelayPayFlag,
                    EarlyPayFlag = 0,//data.EarlyPayFlag,
                    PartialPayFlag = 0,//data.PartialPayFlag,
                    IsConsumed = 0,
                    MerchantAccHold = data.MerchantAccHold,
                    MerchantAccIBAN = data.MerchantAccIBAN,
                    CustomerAccHold = data.CustomerAccHold,
                    CustomerAccIBAN = data.CustomerAccIBAN,
                    Rrn = "_",
                    EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ServiceOperation = (int)ServiceOperation.CreateWorkplaceInfoRecord,
                    ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                    ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                    DemandPaymentRequest = JsonConvert.SerializeObject(data, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                    DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore })
                };

                Logger.LogInformation($"{unique} - Inserted successfully.Entity  :{JsonConvert.SerializeObject(entity)}");

                await _demandPayPaymentService.Create(entity);

                Logger.LogInformation($"{unique} - Inserted successfully.");
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"{unique} - An error occured while inserting data Exception Message :{JsonConvert.SerializeObject(ex)}");
            }
        }
    }
}
