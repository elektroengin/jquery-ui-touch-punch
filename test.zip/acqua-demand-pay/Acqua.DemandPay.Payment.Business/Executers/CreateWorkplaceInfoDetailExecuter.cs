﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Executers
{
    public class CreateWorkplaceInfoDetailExecuter : BaseExecuter
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;

        public CreateWorkplaceInfoDetailExecuter(ILogger<CreateWorkplaceInfoDetailExecuter> logger,
             IDemandPayPaymentService demandPayPaymentService,
             IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger, demandPayPaymentConfiguration)
        {
            _demandPayPaymentService = demandPayPaymentService;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            CreateWorkplaceInfoDetailResponse response = new CreateWorkplaceInfoDetailResponse();

            try
            {
                Logger.LogInformation(message.Unique, $"CreateWorkplaceInfoDetailExecuter Incoming Message", $"{message.InnerMessage}");

                CreateWorkplaceInfoDetailRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoDetailRequest>(message.InnerMessage);
                Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter Data successfully deserialized");
                Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter deserialized message {JsonConvert.SerializeObject(request)}");

                var getDemandPayTrnxInfoDetail = await _demandPayPaymentService.GetDemandPayTrnxInfoDetail(request.MerchantNumber, request.MrcADPRefNo, String.Empty);

                if (getDemandPayTrnxInfoDetail != null)
                {
                    response.DemandPayTrnxInfo = getDemandPayTrnxInfoDetail;
                    response.IsSuccess = true;
                    response.ResultCode = "000";
                    response.ResultDescription = "Başarılı";
                    response.ResultDate = DateTime.Now;

                    CreateWorkplaceInfoRecordRequest createWorkplaceInfoRecordRequest = new CreateWorkplaceInfoRecordRequest();
                    createWorkplaceInfoRecordRequest.MerchantNumber = request.MerchantNumber;
                    createWorkplaceInfoRecordRequest.MrcADPRefNo = getDemandPayTrnxInfoDetail.MrcADPRefNo;

                    try
                    {
                        InsertDemandPayPaymentTrnx(request, message.Unique, response);
                    }
                    catch (Exception ex)
                    {
                        response = CreateWorkplaceInfoResponse("020");
                        Logger.LogError(ex, $"{message.Unique} - General Error Exception Message :{ex.Message}");
                    }

                }
                else
                {
                    response.ResultCode = "085";
                    response.ResultDescription = "Sorgulama servisinde Kayıt bulunamadı.";
                    response.ResultDate = DateTime.Now;
                }

            }
            catch (Exception ex)
            {
                response.ResultCode = "020";
                response.ResultDescription = "Beklenmeyen bir hata oluştu.";
                response.ResultDate = DateTime.Now;
                Logger.LogError(ex, $"{message.Unique} - CreateWorkplaceInfoDetailExecuter General Error Exception Message :{ex.Message}");
            }

            Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter Processed successfully. Response Data :{JsonConvert.SerializeObject(response)}");

            message.InnerMessage = JsonConvert.SerializeObject(response);
            return await Task.FromResult(message);
        }

        public override MessageValidationResult Validate(InternalMessage message)
        {
            CreateWorkplaceInfoDetailResponse createWorkplaceInfoDetailResponse = new CreateWorkplaceInfoDetailResponse();

            try
            {
                CreateWorkplaceInfoDetailRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoDetailRequest>(message.InnerMessage);

                if (request == null || String.IsNullOrEmpty(request.MrcADPRefNo))
                {
                    throw new BusinessException(BusinessExceptionCodes.MrcADPRefNoCanNotBeNull.GetHashCode());
                }
                else if (String.IsNullOrEmpty(request.MerchantNumber))
                {
                    throw new BusinessException(BusinessExceptionCodes.MerchantNumberCannotBeNull.GetHashCode());
                }

                return new MessageValidationResult { Succeed = true, PayLoad = message };

            }
            catch (BusinessException businessException)
            {
                Logger.LogError(businessException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{businessException.Message}");

                createWorkplaceInfoDetailResponse = CreateWorkplaceInfoDetailResponse(businessException.Message, EvaluateResponseMessage(businessException.Message));
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);

                if (!string.IsNullOrEmpty(businessException.MessageDetail))
                {
                    createWorkplaceInfoDetailResponse = CreateWorkplaceInfoDetailResponse(businessException.Message, EvaluateResponseMessage(businessException.Message, businessException.MessageDetail));
                    message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);
                }

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, $"{message.Unique} - Oracle hata oluştu! :{exception.Message}");

                createWorkplaceInfoDetailResponse = CreateWorkplaceInfoDetailResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString(), EvaluateResponseMessage(exception.Message));
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
        }

        private CreateWorkplaceInfoDetailResponse CreateWorkplaceInfoDetailResponse(string responseCode, string responseMessage)
        {
            CreateWorkplaceInfoDetailResponse qrTransactionQueryResponse = new CreateWorkplaceInfoDetailResponse
            {                
                ResultDescription = responseMessage,
                ResultDate = DateTime.Now,
                ResultCode = responseCode
            };

            return qrTransactionQueryResponse;
        }

        private async void InsertDemandPayPaymentTrnx(CreateWorkplaceInfoDetailRequest data, string unique, CreateWorkplaceInfoDetailResponse response)
        {
            try
            {
                DemandPayTrnxInfo entity = new DemandPayTrnxInfo()
                {
                    ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ADPTrnxId = "ADP" + data.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
                    MrcADPRefNo = data.MrcADPRefNo,
                    MerchantNumber = Convert.ToInt64(data.MerchantNumber),
                    ExpiredDate = DateTime.Now,
                    Rrn = "_",
                    EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ServiceOperation = (int)ServiceOperation.GetOdemeIsteDetail,
                    ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                    ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                    DemandPaymentRequest = JsonConvert.SerializeObject(data, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                    DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore })
                };

                Logger.LogInformation($"{unique} - Inserted successfully.Entity  :{JsonConvert.SerializeObject(entity)}");

                await _demandPayPaymentService.Create(entity);

                Logger.LogInformation($"{unique} - Inserted successfully.");
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"{unique} - An error occured while inserting data Exception Message :{JsonConvert.SerializeObject(ex)}");
            }
        }

        private CreateWorkplaceInfoDetailResponse CreateWorkplaceInfoResponse(string responseCode)
        {
            var message = _demandPayPaymentConfiguration.ResponseCodeList.SingleOrDefault(x => x.Code == responseCode);

            CreateWorkplaceInfoDetailResponse qrTransactionQueryResponse = new CreateWorkplaceInfoDetailResponse
            {
                IsSuccess = responseCode == "000",
                ResultCode = responseCode,
                ResultDescription = message.Message,
                ResultDate = DateTime.Now
            };

            return qrTransactionQueryResponse;
        }
    }
}
