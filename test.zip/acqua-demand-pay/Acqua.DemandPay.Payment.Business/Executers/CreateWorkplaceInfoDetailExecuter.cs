﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.Factories;
using Acqua.DemandPay.Payment.Business.Mappers;
using Acqua.DemandPay.Payment.Business.ServiceValidation;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using Azure.Core;
using corf.Core.Messaging;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Executers
{
    public class CreateWorkplaceInfoDetailExecuter : BaseExecuter
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly IWorkplaceValidationService _validationService;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        private readonly IResponseFactory _responseFactory;
        private readonly IDemandPayEntityMapper _demandPayEntityMapper;

        public CreateWorkplaceInfoDetailExecuter(ILogger<CreateWorkplaceInfoDetailExecuter> logger,
             IDemandPayPaymentService demandPayPaymentService,
             IWorkplaceValidationService validationService,
             IResponseFactory responseFactory,
             IDemandPayEntityMapper demandPayEntityMapper,
             IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger, demandPayPaymentConfiguration)
        {
            _demandPayPaymentService = demandPayPaymentService;
            _validationService = validationService;
            _responseFactory = responseFactory;
            _demandPayEntityMapper = demandPayEntityMapper;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            CreateWorkplaceInfoDetailResponse response = new CreateWorkplaceInfoDetailResponse();
            CreateWorkplaceInfoDetailRequest request = null;

            try
            {
                Logger.LogInformation(message.Unique, $"CreateWorkplaceInfoDetailExecuter Incoming Message", $"{message.InnerMessage}");

                request = JsonConvert.DeserializeObject<CreateWorkplaceInfoDetailRequest>(message.InnerMessage);
                Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter Data successfully deserialized");
                Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter deserialized message {JsonConvert.SerializeObject(request)}");

                var getDemandPayTrnxInfoDetail = await _demandPayPaymentService.GetDemandPayTrnxInfoDetail(request.MerchantNumber, request.MrcADPRefNo, String.Empty);

                if (getDemandPayTrnxInfoDetail != null)
                {
                    response = _responseFactory.CreateWorkplaceInfoDetailResponse("000", "Başarılı");
                    response.DemandPayTrnxInfo = getDemandPayTrnxInfoDetail;


                    CreateWorkplaceInfoRecordRequest createWorkplaceInfoRecordRequest = new CreateWorkplaceInfoRecordRequest();
                    createWorkplaceInfoRecordRequest.MerchantNumber = request.MerchantNumber;
                    createWorkplaceInfoRecordRequest.MrcADPRefNo = getDemandPayTrnxInfoDetail.MrcADPRefNo;

                    request.TransactionType = getDemandPayTrnxInfoDetail.TransactionType.ToString();
                    request.TerminalNumber = getDemandPayTrnxInfoDetail.TerminalNumber.ToString();

                    var entity = _demandPayEntityMapper.MapEntity(request, response, message.Unique);
                    Logger.LogInformation($"{message.Unique} - Entity prepared for insertion. ADPTrnxId: {entity.ADPTrnxId}");

                    await _demandPayPaymentService.Create(entity);
                }
                else
                {
                    response = _responseFactory.CreateWorkplaceInfoDetailResponse("038", "Sorgulama servisinde Kayıt bulunamadı.");

                    //Kayıt bulunamadığında da veritabanına kaydet
                    await SaveErrorDatabase(request, response, new Exception("Record Not Found"), message.Unique, _demandPayEntityMapper, _demandPayPaymentService);
                }
            }
            catch (Exception ex)
            {
                response = _responseFactory.CreateWorkplaceInfoDetailResponse("020", "Beklenmeyen bir hata oluştu");
                Logger.LogError(ex, $"{message.Unique} - CreateWorkplaceInfoDetailExecuter General Error Exception Message :{ex.Message}");

                //Hata alması durumunda veritabanına kaydet
                if (request != null)
                {
                    await SaveErrorDatabase(request, response, ex, message.Unique, _demandPayEntityMapper, _demandPayPaymentService);
                }
            }

            Logger.LogInformation($"{message.Unique} - CreateWorkplaceInfoDetailExecuter Processed successfully. Response Data :{JsonConvert.SerializeObject(response)}");

            message.InnerMessage = JsonConvert.SerializeObject(response);
            return await Task.FromResult(message);
        }

        public override MessageValidationResult Validate(InternalMessage message)
        {
            CreateWorkplaceInfoDetailResponse createWorkplaceInfoDetailResponse = new CreateWorkplaceInfoDetailResponse();
            CreateWorkplaceInfoDetailRequest request = null;
            try
            {
                request = JsonConvert.DeserializeObject<CreateWorkplaceInfoDetailRequest>(message.InnerMessage);

                _validationService.ValidationCreateWorkplaceInfoDetail(request);

                return new MessageValidationResult { Succeed = true, PayLoad = message };

            }
            catch (ValidationException validationException)
            {
                Logger.LogError(validationException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{validationException.Message}");

                var errorCode = validationException.Errors.ToList().FirstOrDefault().ErrorCode ?? "999";
                createWorkplaceInfoDetailResponse = _responseFactory.CreateWorkplaceInfoDetailResponse(errorCode.PadLeft(3, '0'), EvaluateResponseMessage(validationException.Errors.ToList().FirstOrDefault()));

                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (BusinessException businessException)
            {
                Logger.LogError(businessException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{businessException.Message}");

                createWorkplaceInfoDetailResponse = _responseFactory.CreateWorkplaceInfoDetailResponse(businessException.Message, EvaluateResponseMessage(businessException.Message));
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);

                if (!string.IsNullOrEmpty(businessException.MessageDetail))
                {
                    createWorkplaceInfoDetailResponse = _responseFactory.CreateWorkplaceInfoDetailResponse(businessException.Message, EvaluateResponseMessage(businessException.Message, businessException.MessageDetail));
                    message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);
                }

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, $"{message.Unique} - Oracle hata oluştu! :{exception.Message}");

                createWorkplaceInfoDetailResponse = _responseFactory.CreateWorkplaceInfoDetailResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString(), EvaluateResponseMessage(exception.Message));
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoDetailResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            finally
            {
                try
                {
                    if (createWorkplaceInfoDetailResponse != null && !string.IsNullOrEmpty(createWorkplaceInfoDetailResponse.ResultCode))
                    {
                        var entity = _demandPayEntityMapper.MapEntity(request, createWorkplaceInfoDetailResponse, message.Unique);
                        _demandPayPaymentService.Create(entity).GetAwaiter().GetResult();
                        Logger.LogInformation($"{message.Unique} - Validation error saved to database");
                    }                    
                }
                catch (Exception dbEx)
                {
                    Logger.LogError($"{message.Unique} - Failed to save validation error");
                }
            }
        }

        //private async Task InsertDemandPayPaymentTrnx(CreateWorkplaceInfoDetailRequest data, string unique, CreateWorkplaceInfoDetailResponse response)
        //{
        //    try
        //    {
        //        DemandPayTrnxInfo entity = new DemandPayTrnxInfo()
        //        {
        //            ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //            ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //            ADPTrnxId = "ADP" + data.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
        //            TransactionType = short.Parse(data.TransactionType),
        //            TerminalNumber = data.TerminalNumber,
        //            MrcADPRefNo = data.MrcADPRefNo,
        //            MerchantNumber = Convert.ToInt64(data.MerchantNumber),
        //            ExpiredDate = DateTime.Now,
        //            Rrn = "_",
        //            EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //            EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //            ServiceOperation = (int)ServiceOperation.GetOdemeIsteDetail,
        //            ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
        //            ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
        //            DemandPaymentRequest = JsonConvert.SerializeObject(data, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //            DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //            QueryId = "_",
        //            PaymentId = "_",
        //            FastDescription = "_",
        //            PaymentType = "_",
        //            IsReversal = 0,
        //            PosTrnxInfo = "_",
        //            PosTrnxDetailInfo = "_"
        //        };

        //        //Logger.LogInformation($"{unique} - Inserted successfully.Entity  :{JsonConvert.SerializeObject(entity)}");
        //        Logger.LogInformation($"{unique} Entity prepared for insertion ADPTrnxId:{entity.ADPTrnxId}");

        //        await _demandPayPaymentService.Create(entity);

        //        Logger.LogInformation($"{unique} - Inserted successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogError(ex, $"{unique} - An error occured while inserting data. Error type :{ex.GetType().Name}");
        //        //Logger.LogError(ex, $"{unique} - An error occured while inserting data Exception Message :{JsonConvert.SerializeObject(ex)}");
        //    }
        //}
    }
}
