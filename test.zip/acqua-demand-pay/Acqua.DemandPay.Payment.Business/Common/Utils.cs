﻿using System;

namespace Acqua.DemandPay.Payment.Business.Common
{
    public class Utils
    {
       public static decimal ConvertFormattedAmount(string amount)
        {
            try
            {
                var tl = amount.Substring(0, 10);

                var kurus = amount.Substring(10, 2);

                var tlKurus = tl + "," + kurus;

                var formatted = decimal.Parse(tlKurus);

                return formatted;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

            }
        }
    }
}
