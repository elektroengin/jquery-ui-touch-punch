﻿using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Model.Enum;
using corf.Core.Commands;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Linq;


namespace Acqua.DemandPay.Payment.Business.Common
{
    public abstract class BaseExecuter : BusinessCommand
    {
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;

        public BaseExecuter(ILogger logger, IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger)
        {
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public string EvaluateResponseMessage(Exception exception)
        {
            if (exception is ValidationException)
            {
                var errorCode = ((ValidationException)exception).Errors.FirstOrDefault();
                if (errorCode != null)
                {
                    return GetResponseMessage(errorCode.ErrorCode);
                }
                else
                {
                    return GetResponseMessage("999");
                }
            }
            else if (exception is BusinessException)
            {
                return GetResponseMessage(exception.Message);
            }
            else
            {
                return GetResponseMessage(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString());
            }
        }

        public string EvaluateResponseMessage(ValidationFailure fail)
        {
            //validationException.Errors.ToList().First().ErrorMessage
            if (!int.TryParse(fail.ErrorCode, out int result))
            {
                return "Bilinmeyen bir hata oluştu";
            }

            return string.Format("{0} {1}", _demandPayPaymentConfiguration.ResponseCodeList?.SingleOrDefault(x => Convert.ToInt32(x.Code) == result)?.Message, fail.PropertyName);
        }

        public string EvaluateResponseMessage(string responseCode)
        {
            return GetResponseMessage(responseCode);
        }

        public string EvaluateResponseMessage(string responseCode, string messageDetail)
        {
            if (!int.TryParse(responseCode, out int result))
            {
                return "Bilinmeyen bir hata oluştu";
            }

            return string.Format("{0} {1}", _demandPayPaymentConfiguration.ResponseCodeList?.SingleOrDefault(x => Convert.ToInt32(x.Code) == result)?.Message, messageDetail);
        }

        private string GetResponseMessage(string responseCode)
        {
            if (!int.TryParse(responseCode, out int result))
            {
                return "Bilinmeyen bir hata oluştu";
            }

            return _demandPayPaymentConfiguration.ResponseCodeList?.SingleOrDefault(x => Convert.ToInt32(x.Code) == result)?.Message;
        }
    }
}
