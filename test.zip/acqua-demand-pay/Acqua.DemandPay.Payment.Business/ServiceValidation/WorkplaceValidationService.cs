﻿using Acqua.DemandPay.Payment.Business.Validator;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Core.Validation;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Repository.Oracle.Services;
using Acqua.DemandPay.Payment.Repository.Services;
using Safir.Online.Authorizer.Domain.model.Transaction.ProcessPosMessage;
using Safir.Online.Authorizer.Interface;
using Safir.Online.Entity;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.ServiceValidation
{
    public class WorkplaceValidationService : IWorkplaceValidationService
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly ITransactionService _transactionService;
        private readonly MerchantTerminalProcessor _merchantTerminalProcessor;

        public WorkplaceValidationService(IDemandPayPaymentService demandPayPaymentService, 
            ITransactionService transactionService,
            MerchantTerminalProcessor merchantTerminalProcessor)
        {
            _demandPayPaymentService = demandPayPaymentService ?? throw new ArgumentException(nameof(demandPayPaymentService));
            _transactionService = transactionService ?? throw new ArgumentException(nameof(transactionService));
            _merchantTerminalProcessor = merchantTerminalProcessor;
        }
        public void ValidationCreateWorkplaceInfoRecord(CreateWorkplaceInfoRecordRequest request, string uniqueId)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            ValidationTool.FluentValidate(typeof(CreateWorkplaceInfoRecordRequestValidator), request);

            //IBAN validasyonu
            ValidationTool.FluentValidate(typeof(TRIbanValidator), request);

            //Ödeme İste SanalPos terminal kontrolü
            var terminalInfo = _merchantTerminalProcessor.GetDemanPayTerminal(request.TerminalNumber);

            //Ödeme İste yetki kontrolü
            var merchantInfo = _merchantTerminalProcessor.GetMerchantInfo(request.MerchantNumber);

            if (merchantInfo != null && !string.IsNullOrEmpty(merchantInfo.Permissions))
            {
                char[] yetki = merchantInfo.Permissions.ToCharArray();

                if (yetki == null || yetki[10] == 'N')
                {
                    throw new BusinessException(BusinessExceptionCodes.DemandPayNotPermissions.GetHashCode());
                }                
            }

            var demandPayTrnx = _demandPayPaymentService.GetDemandPayTrnxInfoDetail(request.MerchantNumber, request.MrcADPRefNo, "000").GetAwaiter().GetResult();

            if (demandPayTrnx != null && demandPayTrnx.ResultStatus == "000")
            {
                throw new BusinessException(BusinessExceptionCodes.AlreadyCreateWorkplaceInfoRecord.GetHashCode());
            }

            var processPosMessageRequest = new ProcessPosMessageRequest()
            {
                Amount = Convert.ToDecimal(request.Amount) / 100,
                CurrencyCode = 949,
                DebitCreditInd = "D",
                IsFinancial = true,
                MerchantNumber = decimal.Parse(request.MerchantNumber),
                Pcode = int.Parse(request.TransactionType) == (int)TransactionType.Fast ? int.Parse(request.TransactionType) == (int)TransactionType.Fast ? long.Parse("109700")
                : long.Parse("109751") : int.Parse(request.TransactionType) == (int)TransactionType.Fast ? long.Parse("109701") : long.Parse("109702"), // FAST EFT Satis = 109700, FAST EFT Iade = 109751, FAST Havale Satis = 109701, FAST Havale Iade = 109702
                SeqNo = 1,
                UseDefaultSeqNo = false,
                Source = int.Parse(request.TransactionType) == (int)TransactionType.Havale ? "O" : "D",
                TerminalType = "POS",
                MxmMobilePaymentType = null,
                TerminalNumber = request.TerminalNumber,
                Mti = 200
            };

            try
            {
                var posMessageResponse = _transactionService.ProcessPosMessage(processPosMessageRequest, uniqueId);
            }
            catch (TaskCanceledException ex)
            {
                throw new BusinessException(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode());
            }
            catch (TimeoutException ex)
            {
                throw new BusinessException(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode());
            }
            catch (OperationCanceledException ex)
            {
                throw new BusinessException(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode());
            }
            catch (Exception ex)
            {
                throw new BusinessException(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode());
            }            
        }

        public void ValidationCreateWorkplaceInfoDetail(CreateWorkplaceInfoDetailRequest request)
        {
            if (request == null || String.IsNullOrEmpty(request.MrcADPRefNo))
            {
                throw new BusinessException(BusinessExceptionCodes.MrcADPRefNoCanNotBeNull.GetHashCode());
            }
            
            if (String.IsNullOrEmpty(request.MerchantNumber))
            {
                throw new BusinessException(BusinessExceptionCodes.MerchantNumberCannotBeNull.GetHashCode());
            }
        }
      
        public void ValidateInformIo(InformForIoRequest request)
        {
            ValidationTool.FluentValidate(typeof(InformForIoValidator), request);

            var getSucceedTransactionByInform = _demandPayPaymentService.GetSucceedTransactionByInform(request).GetAwaiter().GetResult();

            if (getSucceedTransactionByInform != null)
            {
                throw new BusinessException(BusinessExceptionCodes.AlreadySuccessDermandPayment.GetHashCode());
            }
        }     
    }
}
