﻿using Acqua.DemandPay.Payment.Model.Request;

namespace Acqua.DemandPay.Payment.Business.ServiceValidation
{
    public interface IWorkplaceValidationService
    {
        void ValidationCreateWorkplaceInfoRecord(CreateWorkplaceInfoRecordRequest request, string uniqueId);
        void ValidationCreateWorkplaceInfoDetail(CreateWorkplaceInfoDetailRequest request);
        void ValidateInformIo(InformForIoRequest request);
    }
}
