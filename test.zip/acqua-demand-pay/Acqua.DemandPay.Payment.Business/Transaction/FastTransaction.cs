﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.ServiceCallers;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Safir.Online.Authorizer.Domain.DomainService;
using Safir.Online.Authorizer.Domain.model.Transaction.ProcessPosMessage;
using Safir.Online.Authorizer.Interface;
using Safir.Online.Entity;
using Safir.Online.Repository;
using System;
using System.Threading.Tasks;
using static Grpc.Core.Metadata;

namespace Acqua.DemandPay.Payment.Business.Transaction
{
    public class FastTransaction
    {
        private readonly ITransactionService _transactionService;
        private readonly OtherServices _otherServices;
        private readonly IOnlineUnitOfWork _onlineUnitOfWork;
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly AcquaOnlineEodProcessService _acquaOnlineEodService;
        private readonly ILogAdapter _logger;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;

        public FastTransaction(ITransactionService transactionService,
            IDemandPayPaymentService demandPayPaymentService,
            AcquaOnlineEodProcessService acquaOnlineEodService,
            OtherServices otherServices,
            IOnlineUnitOfWork onlineUnitOfWork,
            ILogAdapter logger, IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration)
        {
            _transactionService = transactionService;
            _otherServices = otherServices;
            _acquaOnlineEodService = acquaOnlineEodService;
            _onlineUnitOfWork = onlineUnitOfWork;
            _logger = logger;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
            _demandPayPaymentService = demandPayPaymentService;
        }

        public async Task<PosTrnxInfoResponse> AddFastTransaction(DemandPayTrnxInfo demandDetails, string unique, bool isPayment = false)
        {
            PosTrnxInfo posTrnxInfo;
            PosTrnxInfoResponse posTrnxInfoResponse = new PosTrnxInfoResponse();

            try
            {
                _logger.LogInformation(unique + " AddFastTransaction");

                string origF37 = "_";
                string referenceNumber = string.Empty;
                string trnxType = "N";

                if (demandDetails.PaymentType == "Cancel")
                {
                    referenceNumber = demandDetails.Rrn;
                    //trnxType = "V";
                }
                else
                {
                    referenceNumber = _otherServices.GenerateRRN();

                    if (demandDetails.PaymentType == "Refund")
                    {
                        origF37 = demandDetails.Rrn;
                    }
                }                    

                string pCode = string.Empty;

                var source = demandDetails.TransactionType == (int)TransactionType.Havale ? "O" : "D";

                var terminalNumber = demandDetails.TerminalNumber;

                //ToDo: Refund eklenecek

                if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Sale")
                {
                    pCode = "109700";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Refund")
                {
                    pCode = "109750";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Cancel")
                {
                    pCode = "109700";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Sale")
                {
                    pCode = "109701";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Refund")
                {
                    pCode = "109702";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Cancel")
                {
                    pCode = "109701";
                }

                //// FAST EFT Satis = 109700, FAST EFT Iade = 109750, FAST Havale Satis = 109701, FAST Havale Iade = 109702

                var processPosMessageRequest = new ProcessPosMessageRequest()
                {
                    Amount = demandDetails.Amount,
                    CurrencyCode = long.Parse("949"),
                    DebitCreditInd = "D",
                    IsFinancial = true,
                    MerchantNumber = demandDetails.MerchantNumber,
                    Pcode = long.Parse(pCode),
                    SeqNo = 1,
                    UseDefaultSeqNo = false,
                    Source = source,
                    TerminalType = "POS",
                    MxmMobilePaymentType = null,
                    TerminalNumber = terminalNumber,
                    Mti = demandDetails.IsReversal == (int)Answer.Yes ? 400 : 200
                };

                var processPosMessageResponse = _transactionService.ProcessPosMessage(processPosMessageRequest, unique);                

                if (demandDetails.PaymentType == "Sale")
                {
                    origF37 = "_";
                }

                posTrnxInfo = new PosTrnxInfo()
                {
                    InsCode = "1",
                    F42 = processPosMessageRequest.MerchantNumber,
                    TermId = processPosMessageRequest.TerminalNumber,
                    BatchNo = processPosMessageResponse.Terminal_BatchNo,
                    MsgType = demandDetails.IsReversal == (int)Answer.Yes ? 400 : 200,
                    TrnxCode = processPosMessageResponse.PcodeTrnxRel_TrnxCode,
                    TrnxSubCode = processPosMessageResponse.PcodeTrnxRel_TrnxSubCode,
                    F2 = "1111111111111111",
                    F3 = processPosMessageRequest.Pcode,
                    F4 = processPosMessageRequest.Amount,
                    OutF4 = processPosMessageRequest.Amount,
                    OutF6 = processPosMessageRequest.Amount,
                    F11 = 0,
                    SeqNo = long.Parse(referenceNumber.Substring(6, 6)),
                    SequenceNo = 1, //Bölüm Bilgisi
                    F37 = referenceNumber,
                    MrcLoyaltyGroupCommId = source == "O" ? Utils.ConvertToDecimal(processPosMessageResponse.LoyaltyCommissionInfo_CommId) : -1,
                    MrcLoyaltyGroupCode = source == "O" ? Utils.ConvertToDecimal(processPosMessageResponse.LoyaltyCommissionInfo_GroupCode) : -1,
                    MrcCommId = source == "D" ? Utils.ConvertToDecimal(processPosMessageResponse.ComissionInfo_CommId) : -1,
                    MrcCommGroupCode = source == "D" ? Utils.ConvertToDecimal(processPosMessageResponse.ComissionInfo_GroupCode) : -1,
                    TrnxType = demandDetails.IsReversal == (int)Answer.Yes ? "R" : trnxType, //satış ve iade için N, iptal için V, reversal için R olmalıdır  //2792
                    TrnxSign = processPosMessageResponse.TrnxSign,
                    Status = "N",
                    OrigF37 = origF37,
                    //OrigF37 = !string.IsNullOrEmpty(demandDetails.ORIGINAL_SALES_RRN) ? _repository.GetQrDetailsByRRN(new BkmQrTrnx() { RRN = qrDetails.ORIGINAL_SALES_RRN, ACQUIRER_ID = _bkmQrConfiguration.TrQrConfiguration.KarekodUreticiKodu }, _logger, unique).QR_REFERENCE_NUMBER : "_", 
                    ReverseFlag = "_",
                    VoidFlag = "_",
                    AutoRefundFlag = "_",
                    RefundedAmnt = 0,
                    F39Auth = "_",
                    F39 = "00",
                    AcqTrnxGroupCode = processPosMessageResponse.AcqTrnxGroupCode,
                    TermType = processPosMessageResponse.TermType,
                    ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    SourceOrigFui = "SFSTR",
                    SourceFui = "SFSTR",
                    Dest = "FS",
                    DestFui = "SFST",
                    DestOrigFui = "FS",
                    Source = source,
                    Mcc = processPosMessageResponse.Mcc,
                    PosTermCap = "8",
                    TrnxSource = "P",
                    ProcessIdClr = 25,
                    Brand = "F",
                    DebitCreditInd = "D",
                    MrcMaximumFlag = processPosMessageResponse.MaximumFlag,
                    TrnxGroupCode = processPosMessageResponse.TrnxGroupCode,
                    //IssBankCode = Utils.ConvertToDecimal(demandDetails.ACQUIRER_ID.Substring(2, 2)),
                    F49 = processPosMessageRequest.CurrencyCode,
                    OutF49 = processPosMessageRequest.CurrencyCode,
                    SuppliesCode = -1,
                    SubscriberNo = "_",
                    FraudFlag = "N",
                    TargetCardId = "_",
                    Version = "_",
                    //FastTransactionId = demandDetails.PAYMENT_METHOD == (int)PaymentMethod.FAST ? Utils.CreateRelatedFastMessage(qrDetails) : "_",
                    OrigTrnxApproved = demandDetails.IsReversal == (int)Answer.Yes ? "Y" : "N",
                    F22PosEntryMode = 3,
                    F22PinEntryMode = 0
                };

                var posTrnxDetailInfo = new PosTrnxDetailInfo()
                {
                    F37 = referenceNumber,
                    EodType = "S", //Synchronous = "S", Asynchronous = "A"
                    TrnxType = posTrnxInfo.TrnxType,
                    ProcessDate = posTrnxInfo.ProcessDate,
                    BatchSource = source,
                    ThyDuIban = demandDetails.MerchantAccIBAN,
                    IsFastTrnx = "Y"
                };

                //ToDo : Tek noktada toplantı burası kritik

                await _demandPayPaymentService.Create(demandDetails);

                using (var scope = _onlineUnitOfWork.BeginScope())
                {
                    _onlineUnitOfWork.NonTrackingContainer.PosTrnxInfoRepository.Create(posTrnxInfo);
                    _onlineUnitOfWork.NonTrackingContainer.PosTrnxDetailInfoRepository.Create(posTrnxDetailInfo);
                    _onlineUnitOfWork.Save(scope.ScopedContextId);
                }

                FraudStarIntegration(posTrnxInfo, posTrnxDetailInfo, demandDetails);

                //Günsonu Servisi
                var acquaOnlineEodServiceResponse = AcquaOnlineEodServiceIntefration(posTrnxInfo, demandDetails);

                //NULL kontrolü eklenecek
                if (acquaOnlineEodServiceResponse != null)
                {
                    posTrnxInfoResponse.ServiceType = "EOD";
                    posTrnxInfoResponse.ResponseCode = acquaOnlineEodServiceResponse.ResponseCode;
                    posTrnxInfoResponse.ResponseMessage = acquaOnlineEodServiceResponse.ResponseMessage;
                    posTrnxInfoResponse.ServiceOperation = (int)ServiceOperation.EodSuspan;
                }
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Timeout: Request cancelled after timeout periaod", ex);
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (TimeoutException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Timeout excepiton", ex);
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Operation Cancelled", ex);
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (Exception ex)
            {
                _logger.LogError(unique + " FastTransaction Exception: ", ex);

                posTrnxInfo = new PosTrnxInfo() { F39 = "SF" };
            }

            posTrnxInfoResponse.PosTrnxInfo = posTrnxInfo;

            return await Task.FromResult(posTrnxInfoResponse);
        }

        private void FraudStarIntegration(PosTrnxInfo posTrnxInfo, PosTrnxDetailInfo posTrnxDetailInfo, DemandPayTrnxInfo demandPayTrnxInfos)
        {
            Utils.ConvertToNull<PosTrnxInfo>(posTrnxInfo);

            Utils.ConvertToNull<PosTrnxDetailInfo>(posTrnxDetailInfo);

            demandPayTrnxInfos.Rrn = posTrnxInfo.F37;

            demandPayTrnxInfos.PosTrnxInfo = JsonConvert.SerializeObject(posTrnxInfo, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            demandPayTrnxInfos.PosTrnxDetailInfo = JsonConvert.SerializeObject(posTrnxDetailInfo, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            //SORU-1: IsConsumed iptal ve iade de başarılı ise setlenecekmi
            //SORU-2: Günsonu servisinden sonra hata dönerse IsConsumed ne değeri ile setlenecek
            //SORU-3: Satış işlemi başarılı günsonu servisinden hata aldı satış işlemine iptal gönderilecek (yada reversal mı yapılacak)
            //        IsConsumed ne olacak? 
            //SORU-4: Merchant tablosuna Permissions string alanı eklenecek
            if (posTrnxInfo.F39 == "00")
            {
                demandPayTrnxInfos.IsConsumed = 1;
            }

            if (demandPayTrnxInfos.PaymentType.ToLower() == "refund" || demandPayTrnxInfos.PaymentType.ToLower() == "cancel")
            {
                demandPayTrnxInfos.RefundInformPosTime = DateTime.Now;
            }

            var result = _demandPayPaymentService.UpdateDemandPayToPosTrnxAndDetails(demandPayTrnxInfos);
        }

        public AcquaOnlineEodServiceResponse AcquaOnlineEodServiceIntefration(PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandDetails)
        {
            AcquaOnlineEodServiceResponse acquaOnlineEodServiceResponse = new AcquaOnlineEodServiceResponse();
            //Günsonu servisi Süspan
            AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest = new AcquaOnlineEodServiceRequest();
            acquaOnlineEodServiceRequest.System_Entry_Date = posTrnxInfo.ProcessDate.ToString();
            acquaOnlineEodServiceRequest.Trnx_Code = posTrnxInfo.TrnxCode;
            acquaOnlineEodServiceRequest.F42 = posTrnxInfo.F42.ToString();
            acquaOnlineEodServiceRequest.F37 = posTrnxInfo.F37;

            acquaOnlineEodServiceResponse = _acquaOnlineEodService.Process(acquaOnlineEodServiceRequest, posTrnxInfo, demandDetails);


            //if (acquaOnlineEodServiceResponse.ResponseCode == "00000")
            //{
            //    SaveEodSuspanLogSave(posTrnxInfo, demandDetails, acquaOnlineEodServiceRequest, acquaOnlineEodServiceResponse);
            //}

            return acquaOnlineEodServiceResponse;
        }

        //public async Task SaveEodSuspanLogSave(PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandPayTrnxInfo, AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest,AcquaOnlineEodServiceResponse response)
        //{
        //    var errorEntity = new DemandPayTrnxInfo()
        //    {
        //        ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //        ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //        ADPTrnxId = "ADP" + demandPayTrnxInfo.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
        //        MrcADPRefNo = demandPayTrnxInfo.MrcADPRefNo,
        //        MerchantNumber = Convert.ToInt64(demandPayTrnxInfo.MerchantNumber),
        //        TerminalNumber = posTrnxInfo.TermId,
        //        TransactionType = demandPayTrnxInfo?.TransactionType ?? 0,
        //        Amount = posTrnxInfo.F4,
        //        CurrCode = 949,
        //        ExpiredDate = demandPayTrnxInfo?.ExpiredDate ?? DateTime.Now,
        //        DelayPayFlag = 0,
        //        EarlyPayFlag = 0,
        //        PartialPayFlag = 0,
        //        IsSuspension = 0,
        //        MerchantAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
        //        MerchantAccIBAN = demandPayTrnxInfo?.MerchantAccIBAN,
        //        CustomerAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
        //        CustomerAccIBAN = demandPayTrnxInfo?.CustomerAccIBAN ?? "_",
        //        Rrn = "_",
        //        EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //        EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //        ServiceOperation = (int)ServiceOperation.EodSuspan,
        //        ResultStatus = !string.IsNullOrEmpty(response.ResponseCode) ? response.ResponseCode : "_",
        //        ResultDescription = $"Error: {response.ResponseMessage}",
        //        DemandPaymentRequest = JsonConvert.SerializeObject(acquaOnlineEodServiceRequest, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //        DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //        QueryId = demandPayTrnxInfo.QueryId ?? "_",
        //        PaymentId = demandPayTrnxInfo.PaymentId ?? "_",
        //        FastDescription = demandPayTrnxInfo.FastDescription ?? $"Hata - Ref:{posTrnxInfo.F37}",
        //        PaymentType = demandPayTrnxInfo.PaymentType ?? "unknown",
        //        IsReversal = 0,
        //        Orig_Rrn = "_"
        //    };

        //    await _demandPayPaymentService.Create(errorEntity);
        //}
    }
}
