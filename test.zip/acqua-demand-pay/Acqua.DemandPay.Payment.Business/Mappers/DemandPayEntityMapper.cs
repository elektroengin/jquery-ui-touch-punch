﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Newtonsoft.Json;
using System;

namespace Acqua.DemandPay.Payment.Business.Mappers
{
    public class DemandPayEntityMapper : IDemandPayEntityMapper
    {
        public DemandPayTrnxInfo MapEntity(CreateWorkplaceInfoRecordRequest request, CreateWorkplaceInfoRecordResponse response, string unique)
        {
            return new DemandPayTrnxInfo()
            {
                ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
                MrcADPRefNo = request.MrcADPRefNo,
                MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                TerminalNumber = request.TerminalNumber,
                TransactionType = Convert.ToInt16(request.TransactionType),
                Amount = Convert.ToDecimal(request.Amount) / 100,
                CurrCode = 949,
                ExpiredDate = DateTime.ParseExact(request.ExpiredDate, "yyyyMMddHHmmss", null),
                DelayPayFlag = 0,//data.DelayPayFlag,
                EarlyPayFlag = 0,//data.EarlyPayFlag,
                PartialPayFlag = 0,//data.PartialPayFlag,
                IsSuspension = 0,
                MerchantAccHold = request.MerchantAccHold,
                MerchantAccIBAN = request.MerchantAccIBAN,
                CustomerAccHold = request.CustomerAccHold,
                CustomerAccIBAN = request.CustomerAccIBAN,
                Rrn = "_",
                EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ServiceOperation = (int)ServiceOperation.CreateWorkplaceInfoRecord,
                ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                QueryId = "_",
                PaymentId = "_",
                FastDescription = "_",
                PaymentType = "_",
                IsReversal = 0,
                PosTrnxInfo = "_",
                PosTrnxDetailInfo = "_",
                IsConsumed = 0,
                Orig_Rrn = "_" 
            };
        }

        public DemandPayTrnxInfo MapEntity(CreateWorkplaceInfoDetailRequest request, CreateWorkplaceInfoDetailResponse response, string unique)
        {
            var demandPaymentTrnx = new DemandPayTrnxInfo();

            demandPaymentTrnx.ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd"));
            demandPaymentTrnx.ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss"));
            demandPaymentTrnx.MrcADPRefNo = request.MrcADPRefNo;
            demandPaymentTrnx.ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss");
            demandPaymentTrnx.MerchantNumber = Convert.ToInt64(request.MerchantNumber);
            demandPaymentTrnx.TerminalNumber = request.TerminalNumber ?? "_";
            demandPaymentTrnx.TransactionType = request.TransactionType != null ? short.Parse(request.TransactionType) : short.Parse("0");
            demandPaymentTrnx.ExpiredDate = DateTime.Now;
            demandPaymentTrnx.Amount = 0;
            demandPaymentTrnx.Rrn = "_";
            demandPaymentTrnx.DelayPayFlag = 0;
            demandPaymentTrnx.EarlyPayFlag = 0;
            demandPaymentTrnx.PartialPayFlag = 0;
            demandPaymentTrnx.EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd"));
            demandPaymentTrnx.EntryTime = long.Parse(DateTime.Now.ToString("HHmmss"));
            demandPaymentTrnx.ServiceOperation = (int)ServiceOperation.GetOdemeIsteDetail;
            demandPaymentTrnx.ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_";
            demandPaymentTrnx.ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_";
            demandPaymentTrnx.DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            demandPaymentTrnx.DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            demandPaymentTrnx.QueryId = "_";
            demandPaymentTrnx.PaymentId = "_";
            demandPaymentTrnx.FastDescription = "_";
            demandPaymentTrnx.PaymentType = "_";
            demandPaymentTrnx.IsReversal = 0;
            demandPaymentTrnx.PosTrnxInfo = "_";
            demandPaymentTrnx.PosTrnxDetailInfo = "_";
            demandPaymentTrnx.IsConsumed = 0;
            demandPaymentTrnx.Orig_Rrn = "_";

            return demandPaymentTrnx;

            //return new DemandPayTrnxInfo()
            //{
            //    ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
            //    ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
            //    MrcADPRefNo = request.MrcADPRefNo,
            //    ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss"),
            //    MerchantNumber = Convert.ToInt64(request.MerchantNumber),
            //    TerminalNumber = request.TerminalNumber ?? "_",
            //    TransactionType =  request.TransactionType == null ? short.Parse(request.TransactionType) : short.Parse("0"),                                        
            //    ExpiredDate = DateTime.Now,
            //    Rrn = "_",
            //    DelayPayFlag = 0,//data.DelayPayFlag,
            //    EarlyPayFlag = 0,//data.EarlyPayFlag,
            //    PartialPayFlag = 0,//data.PartialPayFlag,
            //    EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
            //    EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
            //    ServiceOperation = (int)ServiceOperation.GetOdemeIsteDetail,
            //    ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
            //    ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
            //    DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
            //    DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
            //    QueryId = "_",
            //    PaymentId = "_",
            //    FastDescription = "_",
            //    PaymentType = "_",
            //    IsReversal = 0,
            //    PosTrnxInfo = "_",
            //    PosTrnxDetailInfo = "_",
            //    IsConsumed = 0
            //};
        }
    }
}
