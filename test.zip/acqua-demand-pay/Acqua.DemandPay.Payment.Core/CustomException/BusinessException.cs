﻿namespace Acqua.DemandPay.Payment.Core.CustomException
{
    public class BusinessException : Exception
    {
        public string MessageDetail { get; set; }

        public BusinessException(int message) : base(message.ToString().PadLeft(3, '0'))
        {

        }

        public BusinessException(int message, string messageDetail) : base(message.ToString().PadLeft(3, '0'))
        {
            this.MessageDetail = messageDetail;
        }
    }
}
