﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace Acqua.DemandPay.Payment.Core.CustomException
{
    public abstract class RestValidationException : ValidationException
    {
        public string Code { get; }
        public HttpStatusCode HttpStatusCode { get; set; }

        public RestValidationException(string code, string message, Exception innerException = null) : base(message, innerException)
        {
            this.Code = code;
        }
    }
}
