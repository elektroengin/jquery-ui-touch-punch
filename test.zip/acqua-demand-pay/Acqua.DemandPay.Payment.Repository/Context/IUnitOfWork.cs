﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Context
{
    public interface IUnitOfWork<TContext> where TContext : DbContext
    {
        Task<int> CommitAsync();
        string GetContextId();
    }
}
