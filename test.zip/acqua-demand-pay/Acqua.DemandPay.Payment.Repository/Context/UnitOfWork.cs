﻿using Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Context
{
    public abstract class UnitOfWork<TContext> : IUnitOfWork<TContext> where TContext : DbContext
    {
        private readonly IDbContextAccessor<TContext> _accessor;
        private readonly ILogAdapter _logger;

        public UnitOfWork(IDbContextAccessor<TContext> accessor, ILogAdapter logger)
        {
            _accessor = accessor;
            _logger = logger;
        }

        public async Task<int> CommitAsync()
        {
            return await _accessor.Context.SaveChangesAsync();
        }


        public string GetContextId()
        {
            return _accessor.Context.ContextId.ToString();
        }

    }
}
