﻿using Logging;

namespace Acqua.DemandPay.Payment.Repository.Context
{
    public class DemandPayUnitOfWork : UnitOfWork<DemandPayDbContext>, IDemandPayUnitOfWork
    {
        public DemandPayUnitOfWork(IDbContextAccessor<DemandPayDbContext> accessor, ILogAdapter logger) : base(accessor, logger)
        {
        }
    }
}
