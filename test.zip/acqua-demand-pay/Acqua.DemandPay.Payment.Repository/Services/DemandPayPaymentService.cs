﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Repository.Context;
using Acqua.DemandPay.Payment.Repository.EfCoreRepository;
using Logging;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Services
{
    public class DemandPayPaymentService : IDemandPayPaymentService
    {
        private IDemandPayPaymentRepository _demandPayPaymentRepository;
        private readonly ILogAdapter _logger;                
        private readonly IDemandPayUnitOfWork _unitOfWork;
        
        public DemandPayPaymentService(IDemandPayUnitOfWork unitOfWork, IDemandPayPaymentRepository demandPayPaymentRepository, ILogAdapter logger)
        {            
            this._demandPayPaymentRepository = demandPayPaymentRepository;
            this._unitOfWork = unitOfWork;
            _logger = logger;
        }
        public async Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string mrcADPRefNo, string responseCode)
        {
            var query = await _demandPayPaymentRepository.GetDemandPayTrnxInfoDetail(merchantNumber, mrcADPRefNo, responseCode);

            return query;
        }

        public async Task Create(DemandPayTrnxInfo entity)
        {
            _logger.LogInformation("DbContextId:", null, _unitOfWork.GetContextId());
            await _demandPayPaymentRepository.InsertAsync(entity);
            await _unitOfWork.CommitAsync();
        }

        public async Task<bool> SaveChange(DemandPayTrnxInfo marketPlacePaymentTrnx)
        {
            try
            {
                _logger.LogInformation("SaveChange");
                await _demandPayPaymentRepository.UpdateAsync(marketPlacePaymentTrnx);
                await _unitOfWork.CommitAsync();
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }
    }
}
