﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Services
{
    public interface IDemandPayPaymentService
    {
        Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string mrcADPRefNo,string responseCode);
        Task<int> UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo);
        Task<DemandPayTrnxInfo> GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo);
        Task<DemandPayTrnxInfo> GetSucceedTransactionByInform(InformForIoRequest request);
        Task Create(DemandPayTrnxInfo entity);
        Task<bool> SaveChange(DemandPayTrnxInfo demandPayTrnxInfo);
    }
}
