﻿using Acqua.DeamndPay.Payment.Model.Entity;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Services
{
    public interface IDemandPayPaymentService
    {
        Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string mrcADPRefNo,string responseCode);
        Task Create(DemandPayTrnxInfo entity);
        Task<bool> SaveChange(DemandPayTrnxInfo demandPayTrnxInfo);
    }
}
