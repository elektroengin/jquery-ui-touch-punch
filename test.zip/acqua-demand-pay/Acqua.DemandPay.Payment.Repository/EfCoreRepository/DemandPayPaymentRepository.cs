﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Repository.Context;
using Logging;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public class DemandPayPaymentRepository : BaseRepository<DemandPayTrnxInfo, DemandPayDbContext>, IDemandPayPaymentRepository
    {
        private readonly ILogAdapter _logger;
        public IRepository<DemandPayDbContext, DemandPayTrnxInfo> DemandPayTrnxInfo { get; private set; }

        public DemandPayPaymentRepository(IDbContextAccessor<DemandPayDbContext> accessor, ILogAdapter logger,
            IRepository<DemandPayDbContext, DemandPayTrnxInfo> DemandPayTrnxInfo) : base(accessor)
        {
            _logger = logger;
            this.DemandPayTrnxInfo = DemandPayTrnxInfo;
        }

        public async Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode)
        {
            if (string.IsNullOrEmpty(responseCode))
            {
                return await (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                              where
                              item.MerchantNumber == Convert.ToInt64(merchantNumber) 
                              && item.MrcADPRefNo == MrcADPRefNo 
                              && item.ServiceOperation == (int)ServiceOperation.CreateWorkplaceInfoRecord
                              select
                              item).OrderByDescending(m => m.ProcessDate).ThenByDescending(m => m.ProcessTime).FirstOrDefaultAsync();
            }
            else
            {
                return await (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                              where
                              item.MrcADPRefNo == MrcADPRefNo && item.ResultStatus == responseCode
                              select
                              item).FirstOrDefaultAsync();
            }
            
        }
    }
}