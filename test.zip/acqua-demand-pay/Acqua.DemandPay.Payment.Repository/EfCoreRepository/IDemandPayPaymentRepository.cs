﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Repository.Context;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public interface IDemandPayPaymentRepository : IBaseRepository<DemandPayTrnxInfo, DemandPayDbContext>
    {
        Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode);
        Task<int> UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo);
        Task<DemandPayTrnxInfo> GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo);
        Task<DemandPayTrnxInfo> GetSucceedTransactionByInform(InformForIoRequest request);
    }
}

