﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Repository.Context;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public interface IDemandPayPaymentRepository : IBaseRepository<DemandPayTrnxInfo, DemandPayDbContext>
    {
        Task<DemandPayTrnxInfo> GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode);
    }
}
