﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository
{
    public interface IRepository<TDbContext, TEntity> where TDbContext : DbContext where TEntity : class
    {
        Task AddAsync(TEntity entity);
        IQueryable<TEntity> Query();
        IQueryable<TEntity> QueryAsNoTracking();
    }
}
