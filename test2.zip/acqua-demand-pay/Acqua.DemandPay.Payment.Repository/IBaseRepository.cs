﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository
{
    public interface IBaseRepository<TEntity, TContext> where TEntity : class where TContext : DbContext
    {
        Task<EntityEntry<TEntity>> InsertAsync(TEntity entity);
        //Task<bool> Any(string sql);
        Task<EntityEntry<TEntity>> UpdateAsync(TEntity entity);

    }
}
