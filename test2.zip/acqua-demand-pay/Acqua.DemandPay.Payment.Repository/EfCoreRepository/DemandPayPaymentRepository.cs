﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Repository.Context;
using Logging;
using Microsoft.Diagnostics.Tracing.Parsers.Clr;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public class DemandPayPaymentRepository : BaseRepository<DemandPayTrnxInfo, DemandPayDbContext>, IDemandPayPaymentRepository
    {
        private readonly ILogAdapter _logger;
        public IRepository<DemandPayDbContext, DemandPayTrnxInfo> DemandPayTrnxInfo { get; private set; }
        private readonly DemandPayDbContext _demandPayDbContext;
        public DemandPayPaymentRepository(IDbContextAccessor<DemandPayDbContext> accessor,
            DemandPayDbContext demandPayDbContext,
            ILogAdapter logger,
            IRepository<DemandPayDbContext, DemandPayTrnxInfo> DemandPayTrnxInfo) : base(accessor)
        {
            _demandPayDbContext = demandPayDbContext;
            _logger = logger;
            this.DemandPayTrnxInfo = DemandPayTrnxInfo;
        }

        public DemandPayTrnxInfo GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode)
        {
            if (string.IsNullOrEmpty(responseCode))
            {
                return (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                        where
                        item.MerchantNumber == Convert.ToInt64(merchantNumber)
                        && item.MrcADPRefNo == MrcADPRefNo
                        && item.ServiceOperation == (int)ServiceOperation.CreateWorkplaceInfoRecord
                        select
                        item).OrderByDescending(m => m.ProcessDate).ThenByDescending(m => m.ProcessTime).FirstOrDefault();
            }
            else
            {
                return (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                        where
                        item.MerchantNumber == long.Parse(merchantNumber)
                        && item.MrcADPRefNo == MrcADPRefNo
                        && item.ResultStatus == responseCode
                        && item.ServiceOperation == (int)ServiceOperation.CreateWorkplaceInfoRecord
                        select
                        item).FirstOrDefault();
            }
        }

        //ToDo: Satış işlemi başarılı ise kaydı getir 
        //Tekrar gönderdiğinde hata ver
        //İptal-İade-Reversal nasıl olacak
        public DemandPayTrnxInfo GetSucceedTransactionByInform(InformForIoRequest request)
        {
            return (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                    where
                    item.MerchantNumber == Convert.ToInt64(request.MerchantNumber)
                    && item.MrcADPRefNo == request.MrcADPRefNo
                    && item.ServiceOperation == (int)ServiceOperation.InformForOi
                    && item.IsConsumed == 1
                    && item.ResultStatus == "000"
                    && item.PaymentType == request.PaymentType
                    select
                    item).OrderByDescending(m => m.ProcessDate).ThenByDescending(m => m.ProcessTime).FirstOrDefault();
        }

        public DemandPayTrnxInfo GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo)
        {
            return (from item in DemandPayTrnxInfo.QueryAsNoTracking()
                    where
                    item.MerchantNumber == Convert.ToInt64(merchantNumber)
                    && item.MrcADPRefNo == mrcADPRefNo
                    && item.Rrn == referenceNumber
                    && item.PaymentType == "Sale"
                    && item.ServiceOperation == (int)ServiceOperation.InformForOi
                    select item
                          ).OrderByDescending(m => m.ProcessDate).ThenByDescending(m => m.ProcessTime).FirstOrDefault();
        }

        public int UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo)
        {
            return _demandPayDbContext.demandPayTrnxInfo.Where(x => x.ADPTrnxId == demandPayTrnxInfo.ADPTrnxId
            && x.MerchantNumber == demandPayTrnxInfo.MerchantNumber)
                .ExecuteUpdate(setters => setters
                .SetProperty(x => x.PosTrnxInfo, demandPayTrnxInfo.PosTrnxInfo)
                .SetProperty(x => x.PosTrnxDetailInfo, demandPayTrnxInfo.PosTrnxDetailInfo)
                .SetProperty(x => x.RefundInformPosTime, demandPayTrnxInfo.RefundInformPosTime)
                .SetProperty(x => x.IsConsumed, demandPayTrnxInfo.IsConsumed)
                .SetProperty(x => x.Rrn, demandPayTrnxInfo.Rrn));


        }
    }
}