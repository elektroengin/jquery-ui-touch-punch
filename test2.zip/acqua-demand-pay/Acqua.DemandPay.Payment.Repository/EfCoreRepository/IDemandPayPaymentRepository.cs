﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Repository.Context;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public interface IDemandPayPaymentRepository : IBaseRepository<DemandPayTrnxInfo, DemandPayDbContext>
    {
        DemandPayTrnxInfo GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode);
        int UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo);
        DemandPayTrnxInfo GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo);
        DemandPayTrnxInfo GetSucceedTransactionByInform(InformForIoRequest request);
    }
}

