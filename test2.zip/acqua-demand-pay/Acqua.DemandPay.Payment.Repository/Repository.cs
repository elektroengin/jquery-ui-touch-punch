﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository
{
    public class Repository<TDbContext, TEntity> : IRepository<TDbContext, TEntity> where TDbContext : DbContext where TEntity : class
    {
        protected readonly TDbContext dbContext;

        public Repository(TDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task AddAsync(TEntity entity)
        {
            await dbContext.Set<TEntity>().AddAsync(entity);
        }

        public IQueryable<TEntity> Query()
        {
            return dbContext.Set<TEntity>().AsQueryable<TEntity>();
        }

        public IQueryable<TEntity> QueryAsNoTracking()
        {
            return dbContext.Set<TEntity>().AsNoTracking().AsQueryable();
        }
    }
}
