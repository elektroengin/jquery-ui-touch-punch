﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Services
{
    public interface IDemandPayPaymentService
    {
        DemandPayTrnxInfo GetDemandPayTrnxInfoDetail(string merchantNumber, string mrcADPRefNo,string responseCode);
        int UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo);
        DemandPayTrnxInfo GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo);
        DemandPayTrnxInfo GetSucceedTransactionByInform(InformForIoRequest request);
        Task Create(DemandPayTrnxInfo entity);
        Task<bool> SaveChange(DemandPayTrnxInfo demandPayTrnxInfo);
    }
}
