﻿using Acqua.DemandPay.Payment.Repository.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository
{
    public class BaseRepository<TEntity, TContext> : IBaseRepository<TEntity, TContext> where TEntity : class where TContext : DbContext
    {
        protected IDbContextAccessor<TContext> Accessor { get; set; }

        public BaseRepository(IDbContextAccessor<TContext> accessor) => Accessor = accessor;

        public async virtual Task<EntityEntry<TEntity>> InsertAsync(TEntity entity)
        {
            return await Accessor.Context.Set<TEntity>().AddAsync(entity);
        }

        //public async Task<bool> Any(string sql)
        //{
        //    var isAny = false;

        //    try
        //    {
        //        isAny = Accessor.Context.Set<TEntity>().FromSqlRaw(sql).Any();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //    finally
        //    {

        //    }

        //    return await Task.FromResult(isAny);
        //}

        public async virtual Task<EntityEntry<TEntity>> UpdateAsync(TEntity entity)
        {
            Accessor.Context.ChangeTracker.Clear();

            return Accessor.Context.Set<TEntity>().Update(entity);
        }
    }
}
