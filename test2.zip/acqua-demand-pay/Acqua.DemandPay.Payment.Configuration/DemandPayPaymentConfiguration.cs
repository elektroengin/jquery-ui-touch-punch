﻿using Newtonsoft.Json.Linq;

namespace Acqua.DemandPay.Payment.Configuration
{
    public class DemandPayPaymentConfiguration
    {
        public string ConnectionString { get; set; }
        //public string OnlineConnectionString { get; set; }
        public bool LogSql { get; set; }
        public int ExpireTime { get; set; }
        public IAmTokenEntites ApiPlatformAccessTokenService { get; set; }
        public List<ResponseCodeElement> ResponseCodeList { get; set; }
        public JObject AcquaOnlineEodService { get; set; }
    }
}
