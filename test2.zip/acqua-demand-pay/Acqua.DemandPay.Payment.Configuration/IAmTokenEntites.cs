﻿namespace Acqua.DemandPay.Payment.Configuration
{
    public class IAmTokenEntites
    {
        public string PetraServiceUrl { get; set; }
        public string Referer { get; set; }
        public string Origin { get; set; }
        public string IamAccessTokenServiceUrl { get; set; }
        public string Cookie { get; set; }
        public string IamParameters { get; set; }
        public string IamPassword { get; set; }
    }
}
