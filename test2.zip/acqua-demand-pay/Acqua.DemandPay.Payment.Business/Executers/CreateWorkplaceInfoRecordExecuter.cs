﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.Factories;
using Acqua.DemandPay.Payment.Business.Mappers;
using Acqua.DemandPay.Payment.Business.ServiceValidation;
using Acqua.DemandPay.Payment.Business.Validator;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Core.Validation;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using corf.Core.Messaging;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Safir.Online.Authorizer.Domain.model.Transaction.ProcessPosMessage;
using Safir.Online.Authorizer.Interface;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Executers
{
    public class CreateWorkplaceInfoRecordExecuter : BaseExecuter
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly ITransactionService _transactionService;
        private readonly IWorkplaceValidationService _validationService;
        private readonly IResponseFactory _responseFactory;
        private readonly IDemandPayEntityMapper _demandPayEntityMapper;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        //private readonly IMerchantService _merchantService;
        //private readonly ITerminalService _terminalService;
        //private readonly IMerchantLoyaltyInfoService _merchantLoyaltyInfoService;
        //private readonly IMerchantCommissionInfoService _merchantCommissionInfoService;
        //private readonly IMerchantSeqRelService _merchantSeqRelService;

        public CreateWorkplaceInfoRecordExecuter(ILogger<CreateWorkplaceInfoRecordExecuter> logger,
             IDemandPayPaymentService demandPayPaymentService,
             ITransactionService transactionService,
             IWorkplaceValidationService validationService,
             IResponseFactory responseFactory,
             IDemandPayEntityMapper demandPayEntityMapper,
             IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger, demandPayPaymentConfiguration)
        {
            _demandPayPaymentService = demandPayPaymentService;
            _transactionService = transactionService;
            _validationService = validationService;
            _responseFactory = responseFactory;
            _demandPayEntityMapper = demandPayEntityMapper;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            Logger.LogInformation(message.Unique, $"Incoming Message", $"{message.InnerMessage}");

            CreateWorkplaceInfoRecordRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoRecordRequest>(message.InnerMessage);

            Logger.LogInformation($"{message.Unique} - Data successfully deserialized");
            Logger.LogInformation($"{message.Unique} - deserialized message {JsonConvert.SerializeObject(request)}");

            var response = _responseFactory.CreateWorkplaceInfoRecordResponse("000");

            try
            {
                var entity = _demandPayEntityMapper.MapEntity(request, response, message.Unique);

                Logger.LogInformation($"{message.Unique} Entity prepared for insertion ADPTrnxId:{entity.ADPTrnxId}");

                await _demandPayPaymentService.Create(entity);

                Logger.LogInformation($"{message.Unique} - Inserted successfully.");
            }
            catch (Exception ex)
            {
                response = _responseFactory.CreateWorkplaceInfoRecordResponse("020");
                Logger.LogError(ex, $"{message.Unique} - General Error Exception Message :{ex.Message}");

                //Hata durumunu veritabanına kaydet
                await SaveErrorDatabase(request, response, ex, message.Unique, _demandPayEntityMapper, _demandPayPaymentService);
            }

            message.InnerMessage = JsonConvert.SerializeObject(response);
            return await Task.FromResult(message);
        }

        /// <summary>
        /// Validate method wruns before execution
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>,

        public override MessageValidationResult Validate(InternalMessage message)
        {
            CreateWorkplaceInfoRecordResponse createWorkplaceInfoRecordResponse = new CreateWorkplaceInfoRecordResponse();
            CreateWorkplaceInfoRecordRequest request = JsonConvert.DeserializeObject<CreateWorkplaceInfoRecordRequest>(message.InnerMessage);

            #region Validasyon

            try
            {
                _validationService.ValidationCreateWorkplaceInfoRecord(request,message.Unique);

                return new MessageValidationResult { Succeed = true, PayLoad = message };

            }
            catch (ValidationException validationException)
            {
                Logger.LogError(validationException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{validationException.Message}");

                createWorkplaceInfoRecordResponse = _responseFactory.CreateWorkplaceInfoRecordResponse(validationException.Errors.ToList().First().ErrorCode.PadLeft(3, '0'));

                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);


                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (BusinessException businessException)
            {
                Logger.LogError(businessException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{businessException.Message}");

                createWorkplaceInfoRecordResponse = _responseFactory.CreateWorkplaceInfoRecordResponse(businessException.Message);
                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);

                if (!string.IsNullOrEmpty(businessException.MessageDetail))
                {
                    createWorkplaceInfoRecordResponse = _responseFactory.CreateWorkplaceInfoRecordResponse(businessException.Message);
                    message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);
                }

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, $"{message.Unique} - Oracle hata oluştu! :{exception.Message}");

                if (exception.Message.Length == 3)
                {
                    createWorkplaceInfoRecordResponse = _responseFactory.CreateWorkplaceInfoRecordResponse(exception.Message.ToString());
                }
                else
                {
                    createWorkplaceInfoRecordResponse = _responseFactory.CreateWorkplaceInfoRecordResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString());
                }

                message.InnerMessage = JsonConvert.SerializeObject(createWorkplaceInfoRecordResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            finally
            {
                if (createWorkplaceInfoRecordResponse != null && !string.IsNullOrEmpty(createWorkplaceInfoRecordResponse.ResultCode))
                {
                    var entity = _demandPayEntityMapper.MapEntity(request, createWorkplaceInfoRecordResponse, message.Unique);
                    _demandPayPaymentService.Create(entity).GetAwaiter().GetResult();   
                }
            }

            #endregion
        }               
    }
}
