﻿using Acqua.DemandPay.Payment.Model.Response;

namespace Acqua.DemandPay.Payment.Business.Factories
{
    public interface IResponseFactory
    {
        CreateWorkplaceInfoRecordResponse CreateWorkplaceInfoRecordResponse(string responseCode);
        CreateWorkplaceInfoDetailResponse CreateWorkplaceInfoDetailResponse(string responseCode, string responseMessage);
        InformForIoResponse CreateInformForIoResponse(string responseCode, string responseMessage);
    }
}
