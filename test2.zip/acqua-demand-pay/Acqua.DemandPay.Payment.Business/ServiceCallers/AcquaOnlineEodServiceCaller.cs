﻿using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using corf.Communication.ServiceCaller;
using Microsoft.Extensions.Logging;

namespace Acqua.DemandPay.Payment.Business.ServiceCallers
{
    public class AcquaOnlineEodServiceCaller : GenericServiceCaller<AcquaOnlineEodServiceRequest, AcquaOnlineEodServiceResponse>
    {
        DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        public AcquaOnlineEodServiceCaller(DemandPayPaymentConfiguration demandPayPaymentConfiguration, ILogger<AcquaOnlineEodServiceCaller> logger)
        {
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration;

            this.Initialize(_demandPayPaymentConfiguration.AcquaOnlineEodService, logger);
        }
    }
}