﻿using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using FluentValidation;
using System;
using System.Globalization;

namespace Acqua.DemandPay.Payment.Business.Validator
{
    public class CreateWorkplaceInfoRecordRequestValidator : AbstractValidator<CreateWorkplaceInfoRecordRequest>
    {
        public CreateWorkplaceInfoRecordRequestValidator()
        {            
            CascadeMode = CascadeMode.StopOnFirstFailure;

            RuleFor(m => m.MerchantNumber).NotEmpty().WithErrorCode(BusinessExceptionCodes.MerchantNumberCannotBeNull.GetHashCode().ToString());
            RuleFor(m => m.TerminalNumber).NotEmpty().WithErrorCode(BusinessExceptionCodes.TerminalIdCannotBeNull.GetHashCode().ToString());
            RuleFor(m => m.Amount).NotEmpty().WithErrorCode(BusinessExceptionCodes.AmountCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.Amount).Must(ValidTryParseInt).WithErrorCode(BusinessExceptionCodes.FormatError.GetHashCode().ToString());
            RuleFor(m => m.MrcADPRefNo).NotEmpty().WithErrorCode(BusinessExceptionCodes.MrcADPRefNoCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.MerchantAccHold).NotEmpty().WithErrorCode(BusinessExceptionCodes.MerchantAccHoldCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.CustomerAccHold).NotEmpty().WithErrorCode(BusinessExceptionCodes.CustomerAccHoldCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.ExpiredDate).NotEmpty().WithErrorCode(BusinessExceptionCodes.ExpiredDateContNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.ExpiredDate).Length(14).WithErrorCode(BusinessExceptionCodes.FormatError.GetHashCode().ToString());
            RuleFor(m => m.ExpiredDate).Must(ValidTryParseDateTime).WithErrorCode(BusinessExceptionCodes.FormatError.GetHashCode().ToString());
            RuleFor(m => m.ExpiredDate).Must(ValidGreaterThanNow).WithErrorCode(BusinessExceptionCodes.ExpiredDateExpireError.GetHashCode().ToString());
            //RuleFor(m => m.DelayPayFlag).NotNull().Must(v=> v == 0 || v == 1).WithErrorCode(BusinessExceptionCodes.DelayPayFlagCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.TransactionType).NotNull().Must(v => v == "0" || v == "1").WithErrorCode(BusinessExceptionCodes.InvalidTransactionType.GetHashCode().ToString());
        }
        private bool ValidTryParseInt(string value)
        {
            return value != null && int.TryParse(value, out int outValue);
        }

        private bool ValidTryParseDateTime(string value)
        {
            return DateTime.TryParseExact(value, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
        }

        private bool ValidGreaterThanNow(string value)
        {
            if (!DateTime.TryParseExact(value, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsed))
                return false;

            return parsed > DateTime.Now;
        }

    }
}
