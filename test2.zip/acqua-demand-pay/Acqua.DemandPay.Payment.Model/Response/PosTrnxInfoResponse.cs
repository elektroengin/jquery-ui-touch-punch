﻿using Safir.Online.Entity;

namespace Acqua.DemandPay.Payment.Model.Response
{
    public class PosTrnxInfoResponse
    {
        public PosTrnxInfo PosTrnxInfo { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseMessage { get; set; }
        public string ServiceType { get; set; }
        public int ServiceOperation { get; set; }
    }
}
