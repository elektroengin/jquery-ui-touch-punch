﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Model.Enum
{
    public static class DemandPaymentConstants
    {
        public static class TransactionCodes
        {
            public const string Sale = "05";
            public const string Refund = "06";
            public const string Cancel = "25";
        }

        public static class TransactionDescriptions
        {
            public const string Sale = "Peşin Satış";
            public const string Refund = "Iade";
            public const string Cancel = "Iptal";
            public const string Reversal = "Otomatik Iptal";            
        }
    }
}
