﻿using System.Text.Json.Serialization;

namespace Acqua.DemandPay.Payment.Model.Request
{
    public class CreateWorkplaceInfoDetailRequest
    {
        public string MerchantNumber { get; set; }
        public string MrcADPRefNo { get; set; }
        [JsonIgnore]
        public string TransactionType { get; set; }
        [JsonIgnore]
        public string TerminalNumber { get; set; }
    }
}
