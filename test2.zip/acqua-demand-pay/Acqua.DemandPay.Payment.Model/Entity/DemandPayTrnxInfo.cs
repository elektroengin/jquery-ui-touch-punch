﻿using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace Acqua.DeamndPay.Payment.Model.Entity
{
    [Table("DEMAND_PAY_TRNX_INFO", Schema = "dbo")]
    public class DemandPayTrnxInfo
    {
        /// <summary>
        /// işlemin geliş tarihi
        /// </summary>
        public long ProcessDate { get; set; }
        /// <summary>
        /// işlemin geliş zamanı
        /// </summary>
        public long ProcessTime { get; set; }
        /// <summary>
        /// işlemin onay aldığı zaman banka tarafından üretilen referans numarası
        /// </summary>        
        [JsonIgnore]
        public string Rrn { get; set; }
        /// <summary>
        /// 0: Havele 1: Fast 
        /// </summary>
        public short TransactionType { get; set; }
        /// <summary>
        /// işyerinin Safir tarafındaki üyeişyeri numarası (MRC_NO) değeridir. - Alfanumerik (max 64), "600123435". 
        /// </summary>
        public long MerchantNumber { get; set; }
        
        /// <summary>
        /// Terminal Numarası
        /// </summary>
        public string TerminalNumber { get; set; }

        /// <summary>
        /// index değeri görev gören "Ödeme İste" talep kodudur, otomatik olarak, "[ADP]+[MERC_NO]+[SYSDATE]" değerleri append edilerek oluşturulmalıdır.
        /// </summary>
        public string ADPTrnxId { get; set; }
        /// <summary>
        /// İşyeri Ödeme İste referans numarası 
        /// </summary>
        public string MrcADPRefNo { get; set; }
        /// <summary>
        /// index değeri görev gören "Ödeme İste" talep kodudur
        /// </summary>
        //public string AdpTrnxCode { get; set; }
        /// <summary>
        /// Ödeme İste talebinin son geçerlilik tarih değeridi
        /// </summary>
        public DateTime ExpiredDate { get; set; }
        /// <summary>
        /// Ödeme İste işlemleri için kaydedilen para birimi alanıdır. Her işlem için default olarak "949"la doldurulması gerekir.
        /// </summary>
        public int CurrCode { get; set; }
        /// <summary>
        /// Ödenecek tutar 
        /// </summary>
        public decimal Amount { get; set; }
        /// <summary>
        /// Alacaklının hesap ismi
        /// </summary>
        public string MerchantAccHold { get; set; }
        /// <summary>
        /// Alacaklının IBAN numarası 
        /// </summary>
        public string MerchantAccIBAN { get; set; }
        /// <summary>
        /// Borçlunun hesap ismi 
        /// </summary>
        public string CustomerAccHold { get; set; }
        /// <summary>
        /// Borçlunun IBAN numarası 
        /// </summary>
        public string CustomerAccIBAN { get; set; }
        /// <summary>
        /// Gecikmeli Ödeme İşlem flag'idir
        /// </summary>
        [JsonIgnore]
        public short DelayPayFlag { get; set; }
        /// <summary>
        /// Kısmı Ödeme İşlem flag'idir
        /// </summary>
        [JsonIgnore]
        public short PartialPayFlag { get; set; }
        /// <summary>
        /// Erken Ödeme İşlem flag'idir
        /// </summary>
        [JsonIgnore]
        public short EarlyPayFlag { get; set; }
        /// <summary>
        /// 0 Başarızı 1: Başarılı -1: Gelmemiş
        /// </summary>
        [JsonIgnore]
        public short IsSuspension { get; set; }

        public string ResultStatus { get; set; }
        public string ResultDescription { get; set; }
        [JsonIgnore]
        public long EntryDate { get; set; }
        [JsonIgnore]
        public long EntryTime { get; set; }
        [JsonIgnore]
        public long UpdateDate { get; set; }
        [JsonIgnore]
        public long UpdateTime { get; set; }
        [JsonIgnore]
        public string DemandPaymentRequest { get; set; }
        [JsonIgnore]
        public string DemandPaymentResponse { get; set; }
        [JsonIgnore]
        public int ServiceOperation {  get; set; }
        /// <summary>
        /// BKM validasyon sorgu numarasıdır
        /// </summary>
        [JsonIgnore]
        public string QueryId { get; set; }
        /// <summary>
        /// Ödemeler biriminden iletilen bir ödeme bilgisidir
        /// </summary>
        [JsonIgnore]
        public string PaymentId { get; set; }
        /// <summary>
        /// Ödemeler birimi tarafından gönderilen validasyon servis requestinde gönderilecek "FAST_DESCRIPTION" parametresindeki, FAST açıklama metni bilgisi söz konusu alana eklenmelidir.
        /// </summary>
        [JsonIgnore]
        public string FastDescription { get; set; }
        [JsonIgnore]
        public string PaymentType { get; set; }
        [JsonIgnore]
        public int IsReversal { get; set; }
        [JsonIgnore]
        public string PosTrnxInfo { get; set; }
        [JsonIgnore]
        public string PosTrnxDetailInfo { get; set; }
        [JsonIgnore]
        public DateTime? RefundInformPosTime { get; set; }
        [JsonIgnore]
        public int IsConsumed { get; set; }
        /// <summary>
        /// işlemin onay aldığı RRN iade edilmesi durumundaki orijinal rrn
        /// </summary>        
        [JsonIgnore]
        public string Orig_Rrn { get; set; }
    }
}
