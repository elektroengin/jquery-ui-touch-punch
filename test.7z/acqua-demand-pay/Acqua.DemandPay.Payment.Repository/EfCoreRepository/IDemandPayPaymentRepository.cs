﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Repository.Context;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.EfCoreRepository
{
    public interface IDemandPayPaymentRepository : IBaseRepository<DemandPayTrnxInfo, DemandPayDbContext>
    {
        /// <summary>
        /// MerchantNumber ve MrcADPREfNo'ya göre Ödeme iste detay bilgisini getirir.
        /// CreateWorkplaceInfoRecord kaydını response olarak döner
        /// </summary>
        /// <param name="merchantNumber"></param>
        /// <param name="MrcADPRefNo"></param>
        /// <param name="responseCode"></param>
        /// <returns></returns>
        DemandPayTrnxInfo GetDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo, string responseCode);
        bool AnyDemandPayTrnxInfoDetail(string merchantNumber, string MrcADPRefNo);
        Task<int> UpdateDemandPayToPosTrnxAndDetails(DemandPayTrnxInfo demandPayTrnxInfo);
        Task<DemandPayTrnxInfo> GetOriginalTransactionByReferenceNumber(string referenceNumber, string merchantNumber, string mrcADPRefNo);
        Task<DemandPayTrnxInfo> GetSucceedTransactionByInform(InformForIoRequest request);
        /// <summary>
        /// Reversal işlemi için uygun sale işlemini getirir
        /// Sadece günsonu (EodSuspan) yapılmamış ve otoriasyonda hata almış işlemler için reversal döner.
        /// </summary>
        /// <param name="merchantNumber"></param>
        /// <param name="mrcADPRefNo"></param>
        /// <returns></returns>
        Task<DemandPayTrnxInfo> GetSaleTransactionForReversal(string merchantNumber, string mrcADPRefNo);
    }
}

