﻿using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Models;
using Acqua.DemandPay.Payment.Repository.Oracle.Entities;
using Logging;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Diagnostics;
using Dapper;

namespace Acqua.DemandPay.Payment.Repository.Oracle
{
    public class OracleRepository
    {
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        private ILogAdapter _logger;

        public OracleRepository(DemandPayPaymentConfiguration demandPayPaymentConfiguration, ILogAdapter logger)
        {
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration;
            _logger = logger;
        }

        public MrcAccInfoOutput GetMrcAccountNumber(MrcAccInfo mrcAccInfo, ILogAdapter logger, string unique)
        {            
            var stackTrace = new StackTrace();

            var mrcAccInfoOutput = new MrcAccInfoOutput();

            try
            {
                using (IDbConnection db = new OracleConnection(_demandPayPaymentConfiguration.ConnectionStringBatch))
                {
                    MerchantFindAcc merchantFindAcc = new MerchantFindAcc();
                    merchantFindAcc.InsCode = mrcAccInfo.InsCode;
                    merchantFindAcc.MerchantNumber = mrcAccInfo.MrcNo;
                    merchantFindAcc.AccType = mrcAccInfo.AccType;
                    merchantFindAcc.SeqNo = mrcAccInfo.SeqNo;
                    merchantFindAcc.CurrencyCode = mrcAccInfo.CurrCode;
                    merchantFindAcc.CommissionId = mrcAccInfo.CommId;

                    var procedure = "POSMRC.PCKG_EOD_COMMON.SP_MRC_FIND_ACC";

                    db.Execute(procedure, merchantFindAcc.GetDynamicParameters(), commandType: CommandType.StoredProcedure);

                    mrcAccInfoOutput.AccNo = merchantFindAcc.AccNo;
                    mrcAccInfoOutput.Suffix = merchantFindAcc.Suffix;
                    mrcAccInfoOutput.ErrorCode = merchantFindAcc.ErrorCode;
                    mrcAccInfoOutput.ErrorDescription = merchantFindAcc.ErrorDescription;

                    return mrcAccInfoOutput;
                }
            }
            finally
            {        
                logger.LogInformation(unique + " " + stackTrace.GetFrame(0).GetMethod().Name);
            }
        }

    }
}
