﻿using Acqua.DemandPay.Payment.Model.Enum;
using Logging;
using Safir.Authorizer.Helper;
using Safir.Online.Entity;
using Safir.Online.Repository;
using System;
using System.Linq;

namespace Acqua.DemandPay.Payment.Repository.Oracle.Services
{
    public class MerchantTerminalProcessor
    {
        private IOnlineUnitOfWork onlineUOW;
        private ILogAdapter logger;

        public MerchantTerminalProcessor(ILogAdapter logger, IOnlineUnitOfWork uow)
        {
            this.onlineUOW = uow;
            this.logger = logger;
        }

        public Terminal GetDemanPayTerminal(string terminalNumber)
        {
            var demandTerm = this.onlineUOW.NonTrackingContainer.TerminalRepository.Get(x => x.TermId == terminalNumber &&
              x.IsValid.Trim() == "Y" && x.Brand == "Z" && x.TermType == "VP").FirstOrDefault();

            if (demandTerm == null)
            {
                throw new BusinessException((int)BusinessExceptionCodes.TerminalNotFound, "Üye işyernine ait bir Ödeme iste sanalpos Terminal bulunamadı");
            }
            return demandTerm;
        }

        public Merchant GetMerchantInfo(string merchantNumber)
        {
            var demandMerchant = this.onlineUOW.NonTrackingContainer.MerchantRepository.Get(x => x.MerchantNumber == Convert.ToInt64(merchantNumber) &&
              x.IsValid.Trim() == "Y").FirstOrDefault();

            if (demandMerchant == null)
            {
                throw new BusinessException((int)BusinessExceptionCodes.MerchantNotFound, "Üye işyeri bulunamadı");
            }
            return demandMerchant;
        }
    }
}
