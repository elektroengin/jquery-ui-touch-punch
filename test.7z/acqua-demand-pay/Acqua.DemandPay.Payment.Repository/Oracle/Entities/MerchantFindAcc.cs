﻿using Acqua.DemandPay.Payment.Repository.Oracle.Data;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace Acqua.DemandPay.Payment.Repository.Oracle.Entities
{
    public class MerchantFindAcc : OracleParametersContainer
    {

        [OraParameter("PI_INS_CODE", 1, OracleDbType.NVarchar2, ParameterDirection.Input)]
        public char InsCode { get { return GetValue<char>("PI_INS_CODE"); } set { SetValue("PI_INS_CODE", value); } }

        [OraParameter("PI_MRC_NO", 12, OracleDbType.Double, ParameterDirection.Input)]
        public double MerchantNumber { get { return GetValue<double>("PI_MRC_NO"); } set { SetValue("PI_MRC_NO", value); } }

        [OraParameter("PI_ACC_TYPE", 1, OracleDbType.NVarchar2, ParameterDirection.Input)]
        public char AccType { get { return GetValue<char>("PI_ACC_TYPE"); } set { SetValue("PI_ACC_TYPE", value); } }

        [OraParameter("PI_SEQ_NO", 3, OracleDbType.Double, ParameterDirection.Input)]
        public double SeqNo { get { return GetValue<int>("PI_SEQ_NO"); } set { SetValue("PI_SEQ_NO", value); } }

        [OraParameter("PI_CURR_CODE", 3, OracleDbType.Double, ParameterDirection.Input)]
        public double CurrencyCode { get { return GetValue<int>("PI_CURR_CODE"); } set { SetValue("PI_CURR_CODE", value); } }

        [OraParameter("PI_COMM_ID", 16, OracleDbType.Double, ParameterDirection.Input)]
        public double CommissionId { get { return GetValue<int>("PI_COMM_ID"); } set { SetValue("PI_COMM_ID", value); } }

        [OraParameter("PO_ACC_NO", 100, OracleDbType.Varchar2, ParameterDirection.Output)]
        public string AccNo { get { return GetValue<string>("PO_ACC_NO"); } set { SetValue("PO_ACC_NO", value); } }

        [OraParameter("PO_SUFFIX", 100, OracleDbType.Varchar2, ParameterDirection.Output)]
        public string Suffix { get { return GetValue<string>("PO_SUFFIX"); } set { SetValue("PO_SUFFIX", value); } }

        [OraParameter("PO_ERROR_CODE", 5, OracleDbType.Varchar2, ParameterDirection.Output)]
        public string ErrorCode { get { return GetValue<string>("PO_ERROR_CODE"); } set { SetValue("PO_ERROR_CODE", value); } }

        [OraParameter("PO_ERROR_DESC", 255, OracleDbType.Varchar2, ParameterDirection.Output)]
        public string ErrorDescription { get { return GetValue<string>("PO_ERROR_DESC"); } set { SetValue("PO_ERROR_DESC", value); } }
    }
}
