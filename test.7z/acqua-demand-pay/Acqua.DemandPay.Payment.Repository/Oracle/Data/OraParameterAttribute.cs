﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

namespace Acqua.DemandPay.Payment.Repository.Oracle.Data
{
    public class OraParameterAttribute : Attribute
    {
        public string Name { get; private set; }
        public int Size { get; private set; }
        public OracleDbType OracleDbType { get; private set; }
        public ParameterDirection Direction { get; private set; } = ParameterDirection.Input;
        public OraParameterAttribute(string name, int size, OracleDbType oracleDbType)
        {
            Name = name;
            Size = size;
            OracleDbType = oracleDbType;
        }

        public OraParameterAttribute(string name, int size, OracleDbType oracleDbType, ParameterDirection direction) : this(name, size, oracleDbType)
        {
            Direction = direction;
        }
    }
}
