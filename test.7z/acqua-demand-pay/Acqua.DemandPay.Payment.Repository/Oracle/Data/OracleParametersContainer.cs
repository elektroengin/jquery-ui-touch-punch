﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using static Dapper.SqlMapper;

namespace Acqua.DemandPay.Payment.Repository.Oracle.Data
{
    public abstract class OracleParametersContainer
    {
        private static readonly ConcurrentDictionary<string, Dictionary<string, OraParameterAttribute>> StaticAttributes
            = new ConcurrentDictionary<string, Dictionary<string, OraParameterAttribute>>();
        private readonly string _key;
        public Dictionary<string, OracleParameter> FieldValues { get; private set; } = new Dictionary<string, OracleParameter>();

        protected OracleParametersContainer()
        {
            _key = GetType().ToString();
            CreateMap();
        }

        private void CreateMap()
        {
            if (StaticAttributes.ContainsKey(_key) == false)
            {
                Dictionary<string, OraParameterAttribute> fieldMaps = new Dictionary<string, OraParameterAttribute>();

                foreach (PropertyInfo prop in GetType().GetProperties())
                {
                    object[] attrs = prop.GetCustomAttributes(typeof(OraParameterAttribute), true);

                    if (attrs != null && attrs.Length > 0)
                    {
                        OraParameterAttribute attribute = (OraParameterAttribute)attrs[0];

                        fieldMaps.Add($"{attribute.Name}", attribute);
                    }
                }

                StaticAttributes.TryAdd(_key, fieldMaps);
            }

            if (FieldValues.Count == 0)
            {
                CreateFieldValues();
            }
        }

        private void CreateFieldValues()
        {
            foreach (KeyValuePair<string, OraParameterAttribute> prop in StaticAttributes[_key])
            {
                OracleParameter parameter = new OracleParameter();
                parameter.ParameterName = prop.Value.Name;
                parameter.OracleDbType = prop.Value.OracleDbType;
                parameter.Size = prop.Value.Size;
                parameter.Direction = prop.Value.Direction;
                FieldValues.Add(prop.Key, parameter);
            }
        }

        public void SetValue<T>(string key, T value)
        {
            FieldValues[key].Value = value;
        }

        public T GetValue<T>(string key)
        {
            return (T)Convert.ChangeType(FieldValues[key].Value.ToString(), typeof(T));
        }

        public IDynamicParameters GetDynamicParameters()
        {
            DapperOracleCommandParameters parameters = new DapperOracleCommandParameters();

            foreach (KeyValuePair<string, OracleParameter> parameter in FieldValues)
            {
                parameters.Add(parameter.Value);
            }

            return parameters;
        }

        public class DapperOracleCommandParameters : List<OracleParameter>, IDynamicParameters
        {
            public void AddParameters(IDbCommand command, Identity identity)
            {
                foreach (var parameter in this)
                {
                    command.Parameters.Add(parameter);
                }
            }
        }
    }
}
