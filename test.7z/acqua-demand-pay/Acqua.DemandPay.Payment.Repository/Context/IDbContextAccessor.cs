﻿using Microsoft.EntityFrameworkCore;


namespace Acqua.DemandPay.Payment.Repository.Context
{
    public interface IDbContextAccessor<TContext> where TContext : DbContext
    {
        public TContext Context { get; }
    }
}
