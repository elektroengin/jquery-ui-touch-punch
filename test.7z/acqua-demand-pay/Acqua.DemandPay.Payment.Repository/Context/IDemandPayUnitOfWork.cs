﻿namespace Acqua.DemandPay.Payment.Repository.Context
{
    public interface IDemandPayUnitOfWork : IUnitOfWork<DemandPayDbContext>
    {      
    }
}
