﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NLog.Extensions.Logging;

namespace Acqua.DemandPay.Payment.Repository.Context
{
    public class DemandPayDbContext : DbContext
    {
        private readonly DemandPayPaymentConfiguration _configuration;
        private readonly ILoggerFactory loggerFactory = LoggerFactory.Create(builder => { builder.AddNLog(); });

        public DemandPayDbContext(IOptions<DemandPayPaymentConfiguration> configuration)
        {
            _configuration = configuration.Value;
        }

        public DbSet<DemandPayTrnxInfo> demandPayTrnxInfo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_configuration.ConnectionString);
            optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

#if DEBUG
            optionsBuilder.EnableSensitiveDataLogging()
                             .EnableDetailedErrors();
#endif
           optionsBuilder.UseLoggerFactory(loggerFactory);

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DemandPayTrnxInfo>().HasKey(key => new { key.ADPTrnxId });
        }
    }
}
