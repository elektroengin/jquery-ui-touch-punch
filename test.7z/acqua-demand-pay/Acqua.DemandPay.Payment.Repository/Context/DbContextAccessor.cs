﻿
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Repository.Context
{
    public class DbContextAccessor<TContext> : IDbContextAccessor<TContext> where TContext : DbContext
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly TContext _context;

        public DbContextAccessor(IHttpContextAccessor httpContextAccessor, TContext context)
        {
            _httpContextAccessor = httpContextAccessor;
            _context = context;
        }
        public TContext Context => _context;
    }
}
