﻿using Acqua.DemandPay.Payment.Repository.Context;
using Microsoft.Extensions.DependencyInjection;

namespace Acqua.DemandPay.Payment.Repository
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddDataAccess(this IServiceCollection collection)
        {
            collection.AddDbContext<DemandPayDbContext>(ServiceLifetime.Scoped);
            return collection;
        }
    }
}
