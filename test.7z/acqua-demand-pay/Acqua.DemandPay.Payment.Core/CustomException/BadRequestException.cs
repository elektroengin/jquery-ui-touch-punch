﻿using System;
using System.Net;

namespace Acqua.DemandPay.Payment.Core.CustomException
{
    public class BadRequestException : RestValidationException
    {
        public BadRequestException(string code, string message, Exception innerException = null) : base(code, message, innerException)
        {
            HttpStatusCode = HttpStatusCode.BadRequest;
        }
    }
}
