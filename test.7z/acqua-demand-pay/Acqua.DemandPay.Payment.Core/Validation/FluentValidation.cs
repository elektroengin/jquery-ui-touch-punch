﻿using FluentValidation;

namespace Acqua.DemandPay.Payment.Core.Validation
{
    public static class ValidationTool
    {
        public static void FluentValidate(Type validatorType, object entity)
        {
            var validator = (IValidator)Activator.CreateInstance(validatorType);
            var context = new ValidationContext<object>(entity);
            var result = validator.Validate(context);

            if (result.Errors.Count > 0)
            {
                throw new ValidationException(result.Errors);
            }

        }
    }
}