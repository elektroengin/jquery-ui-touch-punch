﻿namespace Acqua.DemandPay.Payment.Model.Models
{
    public class MrcAccInfo
    {
        public char InsCode { get; set; }
        public long MrcNo { get; set; }
        public char AccType { get; set; }
        public int SeqNo { get; set; }
        public int CurrCode { get; set; }
        public int CommId { get; set; }
    }
}
