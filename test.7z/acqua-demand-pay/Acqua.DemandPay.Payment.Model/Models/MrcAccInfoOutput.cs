﻿namespace Acqua.DemandPay.Payment.Model.Models
{
    public class MrcAccInfoOutput
    {
        public string AccNo { get; set; }
        public string Suffix { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
    }
}
