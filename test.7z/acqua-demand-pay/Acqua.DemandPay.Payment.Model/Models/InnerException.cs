﻿namespace Acqua.DemandPay.Payment.Model.Models
{
    public class InnerException
    {
        public Detail Detail { get; set; }
    }

    public class Detail
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string SIID { get; set; }
    }
}
