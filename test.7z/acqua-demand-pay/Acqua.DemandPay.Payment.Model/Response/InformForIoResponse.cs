﻿using Acqua.DeamndPay.Payment.Model.Response;

namespace Acqua.DemandPay.Payment.Model.Response
{
    public class InformForIoResponse : BaseResponse
    {
        public string ReferenceNumber { get; set; }
        //public string AuthCode { get; set; }
    }
}
