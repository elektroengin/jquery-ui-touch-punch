﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DeamndPay.Payment.Model.Response;

namespace Acqua.DemandPay.Payment.Model.Response
{
    public class CreateWorkplaceInfoDetailResponse : BaseResponse
    {
        public DemandPayTrnxInfo DemandPayTrnxInfo { get; set; }
    }
}
