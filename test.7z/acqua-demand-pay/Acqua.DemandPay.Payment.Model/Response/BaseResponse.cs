﻿namespace Acqua.DeamndPay.Payment.Model.Response
{
    public class BaseResponse
    {
        public BaseResponse()
        {
            IsSuccess = false;
            ResultCode = string.Empty;            
            ResultDescription = string.Empty;            
        }
        public bool IsSuccess { get; set; }
        public string ResultCode { get; set; }        
        public string ResultDescription { get; set; }
        public DateTime ResultDate { get; set; }
    }
}
