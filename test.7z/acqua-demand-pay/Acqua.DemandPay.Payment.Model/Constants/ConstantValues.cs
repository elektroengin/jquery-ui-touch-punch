﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Model.Constants
{
    public class ConstantValues
    {
        public enum MRC_STATUS
        {

            /// <summary>
            /// Open
            /// </summary>
            O,
            /// <summary>
            /// Closed
            /// </summary>
            C,
            /// <summary>
            /// Inactive
            /// </summary>
            I,
            /// <summary>
            /// BKM
            /// </summary>
            B,
            /// <summary>
            /// 
            /// </summary>
            H,
            /// <summary>
            /// 
            /// </summary>
            T
        }

        public enum ACQTRNX
        {
            POS = 1,
            CRT = 2,
            PDT = 3,
            SAB = 4,
            PNT = 5,
            VPOS = 6
        }

        public const string MRC_STAT_CODE_FRAUD = "50";
        public const string MRC_STAT_CODE_SUCCESS = "00";
    }
}
