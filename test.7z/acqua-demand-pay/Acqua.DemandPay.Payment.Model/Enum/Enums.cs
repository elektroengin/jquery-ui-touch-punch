﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Model.Enum
{
    public enum IslemTipi
    {
        Sale = 1,
        Refund = 2,
        Reversal = 3,
        ReversalRefund = 4
    }

    public enum ParaBirimi
    {
        TRY = 949,
        USD = 840,
        EUR = 978
    }

    public enum TransactionType
    {
        Fast = 1,
        Havale = 2
    }

    public enum ServiceOperation
    {
        CreateWorkplaceInfoRecord = 1,
        GetOdemeIsteDetail = 2,
        InformForOi = 3,
        EodSuspan = 4,
        InformCancel = 5,
        InformRefund = 6
    }

    public enum ProcessingCodes
    {
        TerminalQrBuilder = 109000,
        QueryPaymentMethodInfo = 109100,
        QuerySalesPaymentMethod = 109101,
        TerminalQrCancellationBuilder = 109200,
        TerminalQrRefundBuilder = 109300,
        CheckAchAvailability = 109400,
        QrConfirmationInformDB = 109500,
        QueryQrStatus = 109600,
        PosApprovalStatus = 109800,
        RefundByReference = 109801,
        FastAdvice = 109802,
        QueryRefundStatus = 109900
    }

    public enum Answer
    {
        Unkownn = -1,
        Yes = 1,
        No = 0
    }
    public enum PaymentTypeEnum
    {
        Sale,
        Cancel,
        Refund,
        Reversal
    }
}
