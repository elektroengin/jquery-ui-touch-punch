﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Model.Enum
{
    public static class DemandPaymentConstants
    {
        public static class TransactionCodes
        {
            public const string Sale = "05";
            public const string Refund = "06";
            public const string Cancel = "25";
        }

        public static class TransactionDescriptions
        {
            public const string Sale = "Peşin Satış";
            public const string Refund = "Iade";
            public const string Cancel = "Iptal";
            public const string Reversal = "Otomatik Iptal";            
        }

        public static Dictionary<string, bool> GetRetriableErrorCodes()
        {
            try
            {
                return new Dictionary<string, bool> {
                    { "PYMNT-46003", true },
                    { "PYMNT-46054", true },
                    { "PYMNT-46055", true },
                    { "PYMNT-46008", true },
                    { "PYMNT-45029", true },
                    { "PYMNT-45060", true },
                    { "PYMNT-45078", true },
                    { "PYMNT-45063", true },
                    { "PYMNT-45065", true },
                    { "PYMNT-45066", true },
                    { "PYMNT-45009", true },
                    { "PYMNT-45010", true },
                    { "PYMNT-45043", true },
                    { "PYMNT-45042", true },
                    { "PYMNT-47000", false },
                    { "SFR-PYMNT-99998", false },
                    { "SFR-PYMNT-99999", false } };
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

            }
        }
    }
}
