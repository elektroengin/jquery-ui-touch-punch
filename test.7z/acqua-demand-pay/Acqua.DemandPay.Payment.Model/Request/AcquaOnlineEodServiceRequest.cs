﻿namespace Acqua.DemandPay.Payment.Model.Request
{
    public class AcquaOnlineEodServiceRequest
    {
        public string System_Entry_Date { get; set; }
        public string Trnx_Code { get; set; }
        public string F37 { get; set; }
        public string F42 { get; set; }
    }
}
