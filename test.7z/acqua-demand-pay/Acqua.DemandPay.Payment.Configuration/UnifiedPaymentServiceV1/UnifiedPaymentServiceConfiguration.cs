﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1
{
    public class UnifiedPaymentServiceConfiguration
    {
        public string EndPointAddress { get; set; }
        public string ConsumerContextNameSpace { get; set; }
        public UnifiedPaymentConsumerContext ConsumerContext { get; set; }
        public IdempotencyContext IdempotencyContext { get; set; }
        public string SecurityContextNameSpace { get; set; }
        public Security Security { get; set; }
        public string SecurityTokenNameSpace { get; set; }
    }
}
