﻿using Acqua.DemandPay.Payment.Configuration.General;
using System.Xml.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1
{
    [Serializable]
    public class UnifiedPaymentConsumerContext : ContextBase
    {
        private XmlSerializerNamespaces xmlns;

        [XmlNamespaceDeclarations]
        public XmlSerializerNamespaces Xmlns
        {
            get
            {
                if (xmlns == null)
                {
                    xmlns = new XmlSerializerNamespaces();
                    xmlns.Add("headerv1", "http://isbank.com/Technical/EA/Header/Schema/V1");
                }
                return xmlns;
            }
            set { xmlns = value; }
        }

        [XmlAttribute(Namespace = "http://www.w3.org/2001/XMLSchema-instance")]
        public string type = "BatchContextType";

        [XmlElement(ElementName = "jobName", Order = 7)]
        public string JobName { get; set; }


    }
}
