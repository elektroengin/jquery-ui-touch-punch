﻿using Acqua.DemandPay.Payment.Configuration.General;
using System.Runtime.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1
{
    [Serializable]
    public class Security
    {
        [DataMember]
        public UsernameToken UsernameToken { get; set; }

        public string SecurityToken { get; set; }
    }
}
