﻿using System.Xml.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1
{
    [Serializable]
    public class IdempotencyContext
    {
        [XmlElement(ElementName = "idempotencyKey", Order = 0)]
        public string IdempotencyKey { get; set; }
    }
}
