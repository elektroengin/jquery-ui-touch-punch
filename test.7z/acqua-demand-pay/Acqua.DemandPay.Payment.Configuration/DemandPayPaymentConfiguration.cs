﻿using Acqua.DemandPay.Payment.Configuration.Mby;
using Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1;
using Newtonsoft.Json.Linq;

namespace Acqua.DemandPay.Payment.Configuration
{
    public class DemandPayPaymentConfiguration
    {
        public string ConnectionString { get; set; }
        public string ConnectionStringBatch { get; set; }        
        public bool LogSql { get; set; }
        public int ExpireTime { get; set; }
        public IAmTokenEntites ApiPlatformAccessTokenService { get; set; }
        public List<ResponseCodeElement> ResponseCodeList { get; set; }
        public JObject AcquaOnlineEodService { get; set; }
        public UnifiedPaymentServiceConfiguration unifiedPaymentServiceConfiguration { get; set; }
        public MbyServiceConfiguration MbyServiceConfiguration { get; set; }        
    }
}
