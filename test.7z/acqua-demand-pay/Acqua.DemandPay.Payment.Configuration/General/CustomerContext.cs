﻿using System.Xml.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.General
{
    [Serializable]
    public class CustomerContext
    {
        [XmlElement(ElementName = "customer")]
        public Customer Customer { get; set; }
    }
}
