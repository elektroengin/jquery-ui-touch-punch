﻿using System.Xml.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.General
{
    [Serializable]
    public class Customer
    {
        [XmlElement(ElementName = "customerNumber", Order = 0)]
        public string CustomerNumber { get; set; }
        [XmlElement(ElementName = "citizenId", Order = 1)]
        public string CitizenId { get; set; }
        [XmlElement(ElementName = "name", Order = 2)]
        public string Name { get; set; }
        [XmlElement(ElementName = "surname", Order = 3)]
        public string Surname { get; set; }
        [XmlElement(ElementName = "taxId", Order = 4)]
        public string TaxId { get; set; }

    }
}
