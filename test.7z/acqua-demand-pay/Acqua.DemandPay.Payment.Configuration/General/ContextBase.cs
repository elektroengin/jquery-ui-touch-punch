﻿using System.Xml.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.General
{
    public class ContextBase
    {
        [XmlElement(ElementName = "lang", Order = 0)]
        public string Lang { get; set; }
        [XmlElement(ElementName = "consumerCode", Order = 1)]
        public string ConsumerCode { get; set; }
        [XmlElement(ElementName = "channelCode", Order = 2)]
        public string ChannelCode { get; set; }
        [XmlElement(ElementName = "customerContext", Order = 3)]
        public CustomerContext CustomerContext { get; set; }
        [XmlElement(ElementName = "ipAddress", Order = 4)]
        public string IpAddress { get; set; }
        [XmlElement(ElementName = "workstationName", Order = 5)]
        public string WorkStationName { get; set; }
        [XmlElement(ElementName = "organizationUnitCode", Order = 6)]
        public string OrganizationUnitCode { get; set; }
    }
}
