﻿using System.Runtime.Serialization;

namespace Acqua.DemandPay.Payment.Configuration.General
{
    public class UsernameToken
    {
        [DataMember]
        public string Username { get; set; }
        [DataMember]
        public string Password { get; set; }
    }
}
