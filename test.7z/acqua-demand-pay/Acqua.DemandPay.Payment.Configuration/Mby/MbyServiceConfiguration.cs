﻿using Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1;

namespace Acqua.DemandPay.Payment.Configuration.Mby
{
    public class MbyServiceConfiguration
    {
        public string EndPointAddress { get; set; }
        public string ConsumerContextNameSpace { get; set; }
        public MbyConsumerContext ConsumerContext { get; set; }
        public string SecurityContextNameSpace { get; set; }
        public Security Security { get; set; }
        public string SecurityTokenNameSpace { get; set; }
    }
}
