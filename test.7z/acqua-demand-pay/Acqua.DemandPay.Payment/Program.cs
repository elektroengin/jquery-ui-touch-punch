﻿using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.Executers;
using Acqua.DemandPay.Payment.Business.ExternalServices;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby;
using Acqua.DemandPay.Payment.Business.Factories;
using Acqua.DemandPay.Payment.Business.Mappers;
using Acqua.DemandPay.Payment.Business.ServiceCallers;
using Acqua.DemandPay.Payment.Business.ServiceValidation;
using Acqua.DemandPay.Payment.Business.Transaction;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Repository;
using Acqua.DemandPay.Payment.Repository.Context;
using Acqua.DemandPay.Payment.Repository.EfCoreRepository;
using Acqua.DemandPay.Payment.Repository.Oracle;
using Acqua.DemandPay.Payment.Repository.Oracle.Services;
using Acqua.DemandPay.Payment.Repository.Services;
using corf.Core.Hosting;
using corf.Routing;
using Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using Safir.Authorizer.LogicalValidator;
using Safir.Online.Authorizer;
using Safir.Online.Authorizer.Configuration;
using Safir.Online.Authorizer.Domain;
using Safir.Online.Authorizer.Domain.DomainService;
using Safir.Online.Authorizer.Interface;
using Safir.Online.Repository;
using Safir.Online.Repository.Infrastructure.Configuration;
using Safir.Online.Repository.Repositories;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Acqua.DemandPay.Payment
{
    class Program
    {
        #region Definitions
        private static string enviroment
        {
            get
            {
                return System.Diagnostics.Debugger.IsAttached ? ".development" : string.Empty;
            }
        }

        private static string executablePath
        {
            get
            {
                if (!System.Diagnostics.Debugger.IsAttached && RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    return Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                return Environment.CurrentDirectory;
            }
        }

        static void CreateLogConfiguration(IHostBuilder hostBuilder, IGenericHostContainer genericHostContainer)
        {
            /*
            --------------------------- NLog --------------------------------
            //Use Nlog.json file to customize your logging

            genericHostContainer.AddConfigurationFile("nlog.json");
            hostBuilder = hostBuilder.UseNLog(new NLogAspNetCoreOptions()
            {
                LoggingConfigurationSectionName = "NLog"
            });
            --------------------------- NLog -------------------------------- 
            */

            //Serilog
            //Use serilog.json file to customize your logging

            hostBuilder = hostBuilder.UseSerilog((context, services, configuration) => configuration
                   .ReadFrom.Configuration(context.Configuration)
                   .ReadFrom.Services(services)
                   .Enrich.FromLogContext());


        }

        #endregion

        static void Main(string[] args)
        {
            #region Json Settings

            var jsonSerializerSettings = new JsonSerializerSettings()
            {
                ContractResolver = new DefaultContractResolver
                {
                    NamingStrategy = new CamelCaseNamingStrategy()
                },
                Converters = new List<JsonConverter> { new StringEnumConverter() },
                NullValueHandling = NullValueHandling.Ignore,
                Formatting = Formatting.Indented,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            };

            #endregion
            try
            {
                GenericHostContainer.Instance.ExternalDescriptors.AddDataAccess();

                GenericHostContainer.Instance
                        .AddConfigurationFile("serilog.json")
                        .AddConfigurationFile($"appsettings{enviroment}.json")
                        .AddConfigurationFile($"demandpaysettings{enviroment}.json")
                        .AddConfigMapFile($"config/appsettings.ConfigMap{enviroment}.json")
                        .AddSecretFile($"secret/appsettings.Secret{enviroment}.json")
                        .AddConfigurationFile("nlog.json")
                        .AddShutdownControlFile("shutdownSignalReceived")
                        .SetConfiguration(executablePath)
                        .AddSingleton(jsonSerializerSettings)
                        .AddSingleton<ILogAdapter, NLogAdapter>()
                        .AddScoped<CreateWorkplaceInfoRecordExecuter>()
                        .AddScoped<CreateWorkplaceInfoDetailExecuter>()
                        .AddScoped<InformForIoExecuter>()                        
                        .AddScoped<AcquaOnlineEodProcessService>()
                        .AddScoped<AcquaOnlineEodServiceCaller>()
                        .AddScoped<MerchantTerminalProcessor>()
                        .AddSingleton<FastTransaction>()
                        .AddSingleton<MbyServiceOperator>()
                        .AddSingleton<OracleRepository>()
                        .AddSingleton<DemandPayUtils>()
                        .AddScoped<UnifiedPaymentServiceAccess>()
                        .AddScoped<IResponseFactory, ResponseFactory>()
                        .AddScoped<IWorkplaceValidationService, WorkplaceValidationService>()
                        .AddScoped<IDemandPayEntityMapper, DemandPayEntityMapper>()
                        .AddScoped<IDemandPayPaymentService, DemandPayPaymentService>()
                        .AddScoped<IDemandPayPaymentRepository, DemandPayPaymentRepository>()
                        .AddScoped<IDemandPayUnitOfWork, DemandPayUnitOfWork>()
                        .AddScoped(typeof(Acqua.DemandPay.Payment.Repository.IRepository<,>), typeof(Acqua.DemandPay.Payment.Repository.Repository<,>))
                        .AddScoped<IHttpContextAccessor, HttpContextAccessor>()
                        .AddScoped(typeof(IDbContextAccessor<>), typeof(DbContextAccessor<>))
                        .Configure<DemandPayPaymentConfiguration>("demandpay-payment-configuration")
                        .ConfigureSection<DemandPayPaymentConfiguration>("demandpay-payment-configuration")
                        //.ConfigureSection<DemandPayPaymentConfiguration>("demandpay-payment-settings")
                        .Configure<LogConfiguration>("log-configuration")
                        .CreateBuilder(args, CreateLogConfiguration);
                GenericHostContainer.Instance.AddOnlineDb();
                GenericHostContainer.Instance.AddAuthorizerServices();
                GenericHostContainer.Instance.RunAsService();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message} {Environment.NewLine} {ex.StackTrace}");
            }

            Console.ReadLine();
        }
    }
}
