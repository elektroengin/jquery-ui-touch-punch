﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Safir.Online.Entity;
using System;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.ServiceCallers
{
    public class AcquaOnlineEodProcessService
    {
        AcquaOnlineEodServiceCaller _acquaOnlineEodServiceCaller;
        private ILogger logger;
        private readonly IDemandPayPaymentService _demandPayPaymentService;

        public AcquaOnlineEodProcessService(ILogger<AcquaOnlineEodProcessService> logger,
            IDemandPayPaymentService demandPayPaymentService,
            AcquaOnlineEodServiceCaller acquaOnlineEodServiceCaller)
        {
            this.logger = logger;
            this._acquaOnlineEodServiceCaller = acquaOnlineEodServiceCaller;
            this._demandPayPaymentService = demandPayPaymentService;
        }

        public async Task<AcquaOnlineEodServiceResponse> Process(AcquaOnlineEodServiceRequest request, PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandPayTrnxInfo)
        {
            AcquaOnlineEodServiceResponse acquaOnlineEodServiceResponse = new AcquaOnlineEodServiceResponse();
            //AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest = JsonConvert.DeserializeObject<AcquaOnlineEodServiceRequest>(message);

            this.logger.LogInformation("AcquaOnlineEodService - AcquaOnlineEodServiceRequest" + JsonConvert.SerializeObject(request, Formatting.Indented));
            var response = await _acquaOnlineEodServiceCaller.Call(request);           

            //ToDo: Response NULL kontrolü eklenecek ve NULL ise reversal işlemi yapıalcak

            if (response != null)
            {
                acquaOnlineEodServiceResponse.ResponseCode = response.Response.ResponseCode;
                acquaOnlineEodServiceResponse.ResponseMessage = acquaOnlineEodServiceResponse.ResponseCode == "00000" ? "İşlem Başarılı" : response.Response.ResponseMessage;
                acquaOnlineEodServiceResponse.F38 = response.Response.F38;
                acquaOnlineEodServiceResponse.ServiceOperation = (int)ServiceOperation.EodSuspan;
            }
            else
            {
                //response null gelebiliyor mutlaka bu akışı düşün
                acquaOnlineEodServiceResponse.ResponseCode = "SG";
                acquaOnlineEodServiceResponse.ResponseMessage = (response != null && response.Response != null) ?  $"Günsonu Servisinden hata alındı.{response.Response.ResponseMessage}" : "The request was canceled due to the configured HttpClient.Timeout of 10 seconds elapsing.";
                acquaOnlineEodServiceResponse.F38 = "_";
                acquaOnlineEodServiceResponse.ServiceOperation = (int)ServiceOperation.EodSuspan;
            }

            await SaveEodSuspanLogSave(posTrnxInfo, demandPayTrnxInfo, request, acquaOnlineEodServiceResponse);

            return acquaOnlineEodServiceResponse;

        }

        public async Task SaveEodSuspanLogSave(PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandPayTrnxInfo, AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest, AcquaOnlineEodServiceResponse response)
        {
            var errorEntity = new DemandPayTrnxInfo()
            {
                ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ADPTrnxId = "ADP" + demandPayTrnxInfo.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                MrcADPRefNo = demandPayTrnxInfo.MrcADPRefNo,
                MerchantNumber = Convert.ToInt64(demandPayTrnxInfo.MerchantNumber),
                TerminalNumber = posTrnxInfo.TermId,
                TransactionType = demandPayTrnxInfo?.TransactionType ?? 0,
                Amount = posTrnxInfo.F4,
                CurrCode = 949,
                ExpiredDate = demandPayTrnxInfo?.ExpiredDate ?? DateTime.Now,
                DelayPayFlag = 0,
                EarlyPayFlag = 0,
                PartialPayFlag = 0,
                IsSuspension = 0,
                MerchantAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
                MerchantAccIBAN = demandPayTrnxInfo?.MerchantAccIBAN,
                CustomerAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
                CustomerAccIBAN = demandPayTrnxInfo?.CustomerAccIBAN ?? "_",
                Rrn = "_",
                EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ServiceOperation = (int)ServiceOperation.EodSuspan,
                ResultStatus = !string.IsNullOrEmpty(response.ResponseCode) ? response.ResponseCode : "_",
                ResultDescription = $"{response.ResponseMessage}",
                DemandPaymentRequest = JsonConvert.SerializeObject(acquaOnlineEodServiceRequest, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                QueryId = demandPayTrnxInfo.QueryId ?? "_",
                PaymentId = demandPayTrnxInfo.PaymentId ?? "_",
                FastDescription = demandPayTrnxInfo.FastDescription ?? $"Hata - Ref:{posTrnxInfo.F37}",
                PaymentType = demandPayTrnxInfo.PaymentType ?? "unknown",
                IsReversal = 0,
                Orig_Rrn = "_"
            };

             await _demandPayPaymentService.Create(errorEntity);
        }
    }
}
