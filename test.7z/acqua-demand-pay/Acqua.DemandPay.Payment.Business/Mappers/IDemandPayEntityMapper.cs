﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;

namespace Acqua.DemandPay.Payment.Business.Mappers
{
    public interface IDemandPayEntityMapper
    {
        DemandPayTrnxInfo MapEntity(CreateWorkplaceInfoRecordRequest request, CreateWorkplaceInfoRecordResponse response, string unique);
        DemandPayTrnxInfo MapEntity(CreateWorkplaceInfoDetailRequest request, CreateWorkplaceInfoDetailResponse response, string unique);
        //DemandPayTrnxInfo MapEntity(InformForIoRequest request, InformForIoResponse response, string unique);
    }
}
