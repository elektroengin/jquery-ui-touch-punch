﻿namespace Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts
{
    public class RetrieveAccountInfoResponse
    {
        public string ResultCode { get; set; }
        public string ResultDescription { get; set; }
        public string Iban { get; set; }
        public string Balance { get; set; }
        public string AccountName { get; set; }
        public long AccountId { get; set; }
        public string CustomerNumber { get; set; }
    }
}
