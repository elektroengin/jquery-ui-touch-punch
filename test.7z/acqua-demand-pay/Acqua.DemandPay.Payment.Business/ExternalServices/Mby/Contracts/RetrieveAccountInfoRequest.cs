﻿namespace Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts
{
    public class RetrieveAccountInfoRequest
    {
        public AccountIdentityInfo[] Account { get; set; }
        public AccountOptionsInfo Options { get; set; }

    }

    public class AccountIdentityInfo
    {
        public AccountKeyInfo Item { get; set; }
    }

    public class AccountKeyInfo
    {
        public int BranchCode;

        public int Number;

        public ReferenceDataType Type;
    }

    public class ReferenceDataType
    {
        public string Code;
    }

    public class AccountOptionsInfo
    {
        public bool ShowBalance { get; set; }
        public bool ShowBalanceSpecified { get; set; }
        public bool ShowCustomerRelation { get; set; }
        public bool ShowAccountRelation { get; set; }
        public bool ShowCustomerRelationSpecified { get; set; }
        public bool ShowAccountRelationSpecified { get; set; }
        public bool ShowTermInfo { get; set; }

    }
}
