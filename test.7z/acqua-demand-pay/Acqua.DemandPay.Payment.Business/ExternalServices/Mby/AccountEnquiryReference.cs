﻿namespace Acqua.DemandPay.Payment.Business.ExternalServices.Mby
{
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/Technical/EA/Fault/Schema/V1")]
    public partial class SystemFaultType : BaseFaultType
    {
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(BusinessFaultType))]
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(SystemFaultType))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/Technical/EA/Fault/Schema/V1")]
    public partial class BaseFaultType
    {

        private string codeField;

        private int screenCodeField;

        private bool screenCodeFieldSpecified;

        private string descriptionField;

        private string detailField;

        private string sIIDField;

        private string actorField;

        private string sourceField;

        private string[] parametersField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public string code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int screenCode
        {
            get
            {
                return this.screenCodeField;
            }
            set
            {
                this.screenCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool screenCodeSpecified
        {
            get
            {
                return this.screenCodeFieldSpecified;
            }
            set
            {
                this.screenCodeFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public string detail
        {
            get
            {
                return this.detailField;
            }
            set
            {
                this.detailField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public string SIID
        {
            get
            {
                return this.sIIDField;
            }
            set
            {
                this.sIIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public string actor
        {
            get
            {
                return this.actorField;
            }
            set
            {
                this.actorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public string source
        {
            get
            {
                return this.sourceField;
            }
            set
            {
                this.sourceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("parameters", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public string[] parameters
        {
            get
            {
                return this.parametersField;
            }
            set
            {
                this.parametersField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class ActivityOperation
    {

        private string groupField;

        private string transactionCodeField;

        private string mainTransactionCodeField;

        private string swiftCodeField;

        private string eventCodeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public string group
        {
            get
            {
                return this.groupField;
            }
            set
            {
                this.groupField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string transactionCode
        {
            get
            {
                return this.transactionCodeField;
            }
            set
            {
                this.transactionCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string mainTransactionCode
        {
            get
            {
                return this.mainTransactionCodeField;
            }
            set
            {
                this.mainTransactionCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public string swiftCode
        {
            get
            {
                return this.swiftCodeField;
            }
            set
            {
                this.swiftCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public string eventCode
        {
            get
            {
                return this.eventCodeField;
            }
            set
            {
                this.eventCodeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class Invoice
    {

        private short invoiceBranchField;

        private bool invoiceBranchFieldSpecified;

        private int invoiceNumberField;

        private bool invoiceNumberFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public short invoiceBranch
        {
            get
            {
                return this.invoiceBranchField;
            }
            set
            {
                this.invoiceBranchField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool invoiceBranchSpecified
        {
            get
            {
                return this.invoiceBranchFieldSpecified;
            }
            set
            {
                this.invoiceBranchFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int invoiceNumber
        {
            get
            {
                return this.invoiceNumberField;
            }
            set
            {
                this.invoiceNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool invoiceNumberSpecified
        {
            get
            {
                return this.invoiceNumberFieldSpecified;
            }
            set
            {
                this.invoiceNumberFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class Context
    {

        private int employeeIdField;

        private bool employeeIdFieldSpecified;

        private string consumerCodeField;

        private int branchCodeField;

        private bool branchCodeFieldSpecified;

        private int tellerIdField;

        private bool tellerIdFieldSpecified;

        private int customerNumberField;

        private bool customerNumberFieldSpecified;

        private int sequenceNoField;

        private bool sequenceNoFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int employeeId
        {
            get
            {
                return this.employeeIdField;
            }
            set
            {
                this.employeeIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool employeeIdSpecified
        {
            get
            {
                return this.employeeIdFieldSpecified;
            }
            set
            {
                this.employeeIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string consumerCode
        {
            get
            {
                return this.consumerCodeField;
            }
            set
            {
                this.consumerCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public int branchCode
        {
            get
            {
                return this.branchCodeField;
            }
            set
            {
                this.branchCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool branchCodeSpecified
        {
            get
            {
                return this.branchCodeFieldSpecified;
            }
            set
            {
                this.branchCodeFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public int tellerId
        {
            get
            {
                return this.tellerIdField;
            }
            set
            {
                this.tellerIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool tellerIdSpecified
        {
            get
            {
                return this.tellerIdFieldSpecified;
            }
            set
            {
                this.tellerIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public int customerNumber
        {
            get
            {
                return this.customerNumberField;
            }
            set
            {
                this.customerNumberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool customerNumberSpecified
        {
            get
            {
                return this.customerNumberFieldSpecified;
            }
            set
            {
                this.customerNumberFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public int sequenceNo
        {
            get
            {
                return this.sequenceNoField;
            }
            set
            {
                this.sequenceNoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool sequenceNoSpecified
        {
            get
            {
                return this.sequenceNoFieldSpecified;
            }
            set
            {
                this.sequenceNoFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class FxRate
    {

        private ReferenceDataType typeField;

        private decimal valueField;

        private bool valueFieldSpecified;

        private string provisionIdField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public ReferenceDataType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public decimal value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool valueSpecified
        {
            get
            {
                return this.valueFieldSpecified;
            }
            set
            {
                this.valueFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string provisionId
        {
            get
            {
                return this.provisionIdField;
            }
            set
            {
                this.provisionIdField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/Technical/EA/RefData/Schema/V1")]
    public partial class ReferenceDataType
    {

        private string codeField;

        private string categoryField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public string code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string category
        {
            get
            {
                return this.categoryField;
            }
            set
            {
                this.categoryField = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(AccountActivityDetail))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class AccountActivity
    {

        private long idField;

        private bool idFieldSpecified;

        private string referenceIdField;

        private System.DateTime timestampField;

        private bool timestampFieldSpecified;

        private short timestampMicrosField;

        private bool timestampMicrosFieldSpecified;

        private System.DateTime valueDateField;

        private bool valueDateFieldSpecified;

        private ReferenceDataType typeField;

        private decimal amountField;

        private bool amountFieldSpecified;

        private decimal balanceField;

        private bool balanceFieldSpecified;

        private decimal netBalanceField;

        private bool netBalanceFieldSpecified;

        private decimal overdraftBalanceField;

        private bool overdraftBalanceFieldSpecified;

        private long otherAccountIdField;

        private bool otherAccountIdFieldSpecified;

        private string internalReferenceIdField;

        private string externalReferenceIdField;

        private ReferenceDataType currencyCodeField;

        private FxRate fxRateField;

        private string descriptionField;

        private string customerDescriptionField;

        private string channelCodeField;

        private string todField;

        private Context contextField;

        private Invoice invoiceField;

        private ActivityOperation operationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public long id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool idSpecified
        {
            get
            {
                return this.idFieldSpecified;
            }
            set
            {
                this.idFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string referenceId
        {
            get
            {
                return this.referenceIdField;
            }
            set
            {
                this.referenceIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public System.DateTime timestamp
        {
            get
            {
                return this.timestampField;
            }
            set
            {
                this.timestampField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool timestampSpecified
        {
            get
            {
                return this.timestampFieldSpecified;
            }
            set
            {
                this.timestampFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public short timestampMicros
        {
            get
            {
                return this.timestampMicrosField;
            }
            set
            {
                this.timestampMicrosField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool timestampMicrosSpecified
        {
            get
            {
                return this.timestampMicrosFieldSpecified;
            }
            set
            {
                this.timestampMicrosFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 4)]
        public System.DateTime valueDate
        {
            get
            {
                return this.valueDateField;
            }
            set
            {
                this.valueDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool valueDateSpecified
        {
            get
            {
                return this.valueDateFieldSpecified;
            }
            set
            {
                this.valueDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public ReferenceDataType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public decimal amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool amountSpecified
        {
            get
            {
                return this.amountFieldSpecified;
            }
            set
            {
                this.amountFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public decimal balance
        {
            get
            {
                return this.balanceField;
            }
            set
            {
                this.balanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool balanceSpecified
        {
            get
            {
                return this.balanceFieldSpecified;
            }
            set
            {
                this.balanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public decimal netBalance
        {
            get
            {
                return this.netBalanceField;
            }
            set
            {
                this.netBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool netBalanceSpecified
        {
            get
            {
                return this.netBalanceFieldSpecified;
            }
            set
            {
                this.netBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public decimal overdraftBalance
        {
            get
            {
                return this.overdraftBalanceField;
            }
            set
            {
                this.overdraftBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool overdraftBalanceSpecified
        {
            get
            {
                return this.overdraftBalanceFieldSpecified;
            }
            set
            {
                this.overdraftBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 10)]
        public long otherAccountId
        {
            get
            {
                return this.otherAccountIdField;
            }
            set
            {
                this.otherAccountIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool otherAccountIdSpecified
        {
            get
            {
                return this.otherAccountIdFieldSpecified;
            }
            set
            {
                this.otherAccountIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 11)]
        public string internalReferenceId
        {
            get
            {
                return this.internalReferenceIdField;
            }
            set
            {
                this.internalReferenceIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 12)]
        public string externalReferenceId
        {
            get
            {
                return this.externalReferenceIdField;
            }
            set
            {
                this.externalReferenceIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 13)]
        public ReferenceDataType currencyCode
        {
            get
            {
                return this.currencyCodeField;
            }
            set
            {
                this.currencyCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 14)]
        public FxRate fxRate
        {
            get
            {
                return this.fxRateField;
            }
            set
            {
                this.fxRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 15)]
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 16)]
        public string customerDescription
        {
            get
            {
                return this.customerDescriptionField;
            }
            set
            {
                this.customerDescriptionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 17)]
        public string channelCode
        {
            get
            {
                return this.channelCodeField;
            }
            set
            {
                this.channelCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 18)]
        public string tod
        {
            get
            {
                return this.todField;
            }
            set
            {
                this.todField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 19)]
        public Context context
        {
            get
            {
                return this.contextField;
            }
            set
            {
                this.contextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 20)]
        public Invoice invoice
        {
            get
            {
                return this.invoiceField;
            }
            set
            {
                this.invoiceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 21)]
        public ActivityOperation operation
        {
            get
            {
                return this.operationField;
            }
            set
            {
                this.operationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class AccountActivityDetail : AccountActivity
    {

        private string accountIbanField;

        private string accountNameField;

        private string otherAccountIbanField;

        private string otherAccountNameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public string accountIban
        {
            get
            {
                return this.accountIbanField;
            }
            set
            {
                this.accountIbanField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string accountName
        {
            get
            {
                return this.accountNameField;
            }
            set
            {
                this.accountNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string otherAccountIban
        {
            get
            {
                return this.otherAccountIbanField;
            }
            set
            {
                this.otherAccountIbanField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public string otherAccountName
        {
            get
            {
                return this.otherAccountNameField;
            }
            set
            {
                this.otherAccountNameField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveActivitiesResponse
    {

        private RetrieveActivitiesResponseRetrieveActivitiesResponseDTO retrieveActivitiesResponseDTOField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public RetrieveActivitiesResponseRetrieveActivitiesResponseDTO RetrieveActivitiesResponseDTO
        {
            get
            {
                return this.retrieveActivitiesResponseDTOField;
            }
            set
            {
                this.retrieveActivitiesResponseDTOField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveActivitiesResponseRetrieveActivitiesResponseDTO
    {

        private AccountActivity[] activitiesField;

        private int totalResultSizeField;

        private bool totalResultSizeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("activities", Order = 0)]
        public AccountActivity[] activities
        {
            get
            {
                return this.activitiesField;
            }
            set
            {
                this.activitiesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public int totalResultSize
        {
            get
            {
                return this.totalResultSizeField;
            }
            set
            {
                this.totalResultSizeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool totalResultSizeSpecified
        {
            get
            {
                return this.totalResultSizeFieldSpecified;
            }
            set
            {
                this.totalResultSizeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlIncludeAttribute(typeof(ActivityResultOptionsWithOffset))]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class ActivityResultOptions
    {

        private bool showContextField;

        private bool showContextFieldSpecified;

        private bool showOtherAccountField;

        private bool showOtherAccountFieldSpecified;

        private bool showReferenceField;

        private bool showReferenceFieldSpecified;

        private bool showFxRateField;

        private bool showFxRateFieldSpecified;

        private bool showInvoiceField;

        private bool showInvoiceFieldSpecified;

        private int pageSizeField;

        private bool pageSizeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public bool showContext
        {
            get
            {
                return this.showContextField;
            }
            set
            {
                this.showContextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showContextSpecified
        {
            get
            {
                return this.showContextFieldSpecified;
            }
            set
            {
                this.showContextFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public bool showOtherAccount
        {
            get
            {
                return this.showOtherAccountField;
            }
            set
            {
                this.showOtherAccountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showOtherAccountSpecified
        {
            get
            {
                return this.showOtherAccountFieldSpecified;
            }
            set
            {
                this.showOtherAccountFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public bool showReference
        {
            get
            {
                return this.showReferenceField;
            }
            set
            {
                this.showReferenceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showReferenceSpecified
        {
            get
            {
                return this.showReferenceFieldSpecified;
            }
            set
            {
                this.showReferenceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public bool showFxRate
        {
            get
            {
                return this.showFxRateField;
            }
            set
            {
                this.showFxRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showFxRateSpecified
        {
            get
            {
                return this.showFxRateFieldSpecified;
            }
            set
            {
                this.showFxRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public bool showInvoice
        {
            get
            {
                return this.showInvoiceField;
            }
            set
            {
                this.showInvoiceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showInvoiceSpecified
        {
            get
            {
                return this.showInvoiceFieldSpecified;
            }
            set
            {
                this.showInvoiceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public int pageSize
        {
            get
            {
                return this.pageSizeField;
            }
            set
            {
                this.pageSizeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool pageSizeSpecified
        {
            get
            {
                return this.pageSizeFieldSpecified;
            }
            set
            {
                this.pageSizeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class ActivityResultOptionsWithOffset : ActivityResultOptions
    {

        private int offsetField;

        private bool offsetFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int offset
        {
            get
            {
                return this.offsetField;
            }
            set
            {
                this.offsetField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool offsetSpecified
        {
            get
            {
                return this.offsetFieldSpecified;
            }
            set
            {
                this.offsetFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class ActivityCriteria
    {

        private System.DateTime beginTimeField;

        private bool beginTimeFieldSpecified;

        private short beginTimeMicrosField;

        private bool beginTimeMicrosFieldSpecified;

        private System.DateTime endTimeField;

        private bool endTimeFieldSpecified;

        private decimal minAmountField;

        private bool minAmountFieldSpecified;

        private decimal maxAmountField;

        private bool maxAmountFieldSpecified;

        private ReferenceDataType financialTypeField;

        private string descField;

        private ReferenceDataType channelField;

        private ReferenceDataType[] operationTypeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public System.DateTime beginTime
        {
            get
            {
                return this.beginTimeField;
            }
            set
            {
                this.beginTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool beginTimeSpecified
        {
            get
            {
                return this.beginTimeFieldSpecified;
            }
            set
            {
                this.beginTimeFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public short beginTimeMicros
        {
            get
            {
                return this.beginTimeMicrosField;
            }
            set
            {
                this.beginTimeMicrosField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool beginTimeMicrosSpecified
        {
            get
            {
                return this.beginTimeMicrosFieldSpecified;
            }
            set
            {
                this.beginTimeMicrosFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public System.DateTime endTime
        {
            get
            {
                return this.endTimeField;
            }
            set
            {
                this.endTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool endTimeSpecified
        {
            get
            {
                return this.endTimeFieldSpecified;
            }
            set
            {
                this.endTimeFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public decimal minAmount
        {
            get
            {
                return this.minAmountField;
            }
            set
            {
                this.minAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool minAmountSpecified
        {
            get
            {
                return this.minAmountFieldSpecified;
            }
            set
            {
                this.minAmountFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public decimal maxAmount
        {
            get
            {
                return this.maxAmountField;
            }
            set
            {
                this.maxAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool maxAmountSpecified
        {
            get
            {
                return this.maxAmountFieldSpecified;
            }
            set
            {
                this.maxAmountFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public ReferenceDataType financialType
        {
            get
            {
                return this.financialTypeField;
            }
            set
            {
                this.financialTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public string desc
        {
            get
            {
                return this.descField;
            }
            set
            {
                this.descField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public ReferenceDataType channel
        {
            get
            {
                return this.channelField;
            }
            set
            {
                this.channelField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("operationType", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public ReferenceDataType[] operationType
        {
            get
            {
                return this.operationTypeField;
            }
            set
            {
                this.operationTypeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class AccountKey
    {

        private ReferenceDataType typeField;

        private int branchCodeField;

        private int numberField;

        private string additionalKeyField;

        private string ibanField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public ReferenceDataType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int branchCode
        {
            get
            {
                return this.branchCodeField;
            }
            set
            {
                this.branchCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public int number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public string additionalKey
        {
            get
            {
                return this.additionalKeyField;
            }
            set
            {
                this.additionalKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public string iban
        {
            get
            {
                return this.ibanField;
            }
            set
            {
                this.ibanField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class AccountId
    {

        private object itemField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accountKey", typeof(AccountKey), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        [System.Xml.Serialization.XmlElementAttribute("id", typeof(long), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public object Item
        {
            get
            {
                return this.itemField;
            }
            set
            {
                this.itemField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Schema/V3")]
    public partial class ActivitiesRequest
    {

        private AccountId accountIdField;

        private ActivityCriteria criteriaField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public AccountId accountId
        {
            get
            {
                return this.accountIdField;
            }
            set
            {
                this.accountIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public ActivityCriteria criteria
        {
            get
            {
                return this.criteriaField;
            }
            set
            {
                this.criteriaField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveActivities
    {

        private ActivitiesRequest activityRequestField;

        private ActivityResultOptions optionsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public ActivitiesRequest activityRequest
        {
            get
            {
                return this.activityRequestField;
            }
            set
            {
                this.activityRequestField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public ActivityResultOptions options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/Technical/EA/Fault/Schema/V1")]
    public partial class BusinessFaultType : BaseFaultType
    {
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", ConfigurationName = "AccountEnquiryServiceV3x0")]
    public interface AccountEnquiryServiceV3x0
    {

        [System.ServiceModel.OperationContractAttribute(Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveActiv" +
            "ities", ReplyAction = "*")]
        [System.ServiceModel.FaultContractAttribute(typeof(SystemFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveActiv" +
            "ities", Name = "SystemFault")]
        [System.ServiceModel.FaultContractAttribute(typeof(BusinessFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveActiv" +
            "ities", Name = "BusinessFault")]
        [System.ServiceModel.XmlSerializerFormatAttribute(SupportFaults = true)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseFaultType))]
        System.Threading.Tasks.Task<retrieveActivitiesResponse1> retrieveActivitiesAsync(retrieveActivitiesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveLastA" +
            "ctivities", ReplyAction = "*")]
        [System.ServiceModel.FaultContractAttribute(typeof(SystemFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveLastA" +
            "ctivities", Name = "SystemFault")]
        [System.ServiceModel.FaultContractAttribute(typeof(BusinessFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveLastA" +
            "ctivities", Name = "BusinessFault")]
        [System.ServiceModel.XmlSerializerFormatAttribute(SupportFaults = true)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseFaultType))]
        System.Threading.Tasks.Task<retrieveLastActivitiesResponse1> retrieveLastActivitiesAsync(retrieveLastActivitiesRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveAccou" +
            "ntInfo", ReplyAction = "*")]
        [System.ServiceModel.FaultContractAttribute(typeof(SystemFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveAccou" +
            "ntInfo", Name = "SystemFault")]
        [System.ServiceModel.FaultContractAttribute(typeof(BusinessFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveAccou" +
            "ntInfo", Name = "BusinessFault")]
        [System.ServiceModel.XmlSerializerFormatAttribute(SupportFaults = true)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseFaultType))]
        System.Threading.Tasks.Task<retrieveAccountInfoResponse1> retrieveAccountInfoAsync(retrieveAccountInfoRequest request);

        [System.ServiceModel.OperationContractAttribute(Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveCusto" +
            "merAccounts", ReplyAction = "*")]
        [System.ServiceModel.FaultContractAttribute(typeof(SystemFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveCusto" +
            "merAccounts", Name = "SystemFault")]
        [System.ServiceModel.FaultContractAttribute(typeof(BusinessFaultType), Action = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3/retrieveCusto" +
            "merAccounts", Name = "BusinessFault")]
        [System.ServiceModel.XmlSerializerFormatAttribute(SupportFaults = true)]
        [System.ServiceModel.ServiceKnownTypeAttribute(typeof(BaseFaultType))]
        System.Threading.Tasks.Task<retrieveCustomerAccountsResponse1> retrieveCustomerAccountsAsync(retrieveCustomerAccountsRequest request);
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveActivitiesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveActivities retrieveActivities;

        public retrieveActivitiesRequest()
        {
        }

        public retrieveActivitiesRequest(RetrieveActivities retrieveActivities)
        {
            this.retrieveActivities = retrieveActivities;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveActivitiesResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveActivitiesResponse retrieveActivitiesResponse;

        public retrieveActivitiesResponse1()
        {
        }

        public retrieveActivitiesResponse1(RetrieveActivitiesResponse retrieveActivitiesResponse)
        {
            this.retrieveActivitiesResponse = retrieveActivitiesResponse;
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveLastActivities
    {

        private AccountId accountIdField;

        private ActivityResultOptions optionsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public AccountId accountId
        {
            get
            {
                return this.accountIdField;
            }
            set
            {
                this.accountIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public ActivityResultOptions options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveLastActivitiesResponse
    {

        private AccountActivity[] retrieveLastActivitiesResponseDTOField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 0)]
        [System.Xml.Serialization.XmlArrayItemAttribute("activities", IsNullable = false)]
        public AccountActivity[] RetrieveLastActivitiesResponseDTO
        {
            get
            {
                return this.retrieveLastActivitiesResponseDTOField;
            }
            set
            {
                this.retrieveLastActivitiesResponseDTOField = value;
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveLastActivitiesRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveLastActivities retrieveLastActivities;

        public retrieveLastActivitiesRequest()
        {
        }

        public retrieveLastActivitiesRequest(RetrieveLastActivities retrieveLastActivities)
        {
            this.retrieveLastActivities = retrieveLastActivities;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveLastActivitiesResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveLastActivitiesResponse retrieveLastActivitiesResponse;

        public retrieveLastActivitiesResponse1()
        {
        }

        public retrieveLastActivitiesResponse1(RetrieveLastActivitiesResponse retrieveLastActivitiesResponse)
        {
            this.retrieveLastActivitiesResponse = retrieveLastActivitiesResponse;
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveAccountInfo
    {

        private AccountIdentityInfo[] accountField;

        private AccountOptionsInfo optionsField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("account", Order = 0)]
        public AccountIdentityInfo[] account
        {
            get
            {
                return this.accountField;
            }
            set
            {
                this.accountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public AccountOptionsInfo options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountIdentityInfo
    {

        private object itemField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accountKey", typeof(AccountKeyInfo), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        [System.Xml.Serialization.XmlElementAttribute("iban", typeof(string), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        [System.Xml.Serialization.XmlElementAttribute("id", typeof(long), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public object Item
        {
            get
            {
                return this.itemField;
            }
            set
            {
                this.itemField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountKeyInfo
    {

        private ReferenceDataType typeField;

        private int branchCodeField;

        private int numberField;

        private string additionalKeyField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public ReferenceDataType type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int branchCode
        {
            get
            {
                return this.branchCodeField;
            }
            set
            {
                this.branchCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public int number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public string additionalKey
        {
            get
            {
                return this.additionalKeyField;
            }
            set
            {
                this.additionalKeyField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountOptionsInfo
    {

        private bool showCustomerRelationField;

        private bool showCustomerRelationFieldSpecified;

        private bool showAccountRelationField;

        private bool showAccountRelationFieldSpecified;

        private bool showRelatedAccountInfoField;

        private bool showRelatedAccountInfoFieldSpecified;

        private bool showBalanceField;

        private bool showBalanceFieldSpecified;

        private bool showInterestInfoField;

        private bool showInterestInfoFieldSpecified;

        private bool showTermInfoField;

        private bool showTermInfoFieldSpecified;

        private bool showAvailableBalanceInfoField;

        private bool showAvailableBalanceInfoFieldSpecified;

        private bool showPassbookInfoField;

        private bool showPassbookInfoFieldSpecified;

        private bool showTransferredInfoField;

        private bool showTransferredInfoFieldSpecified;

        private bool showOfsaaCodeField;

        private bool showOfsaaCodeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public bool showCustomerRelation
        {
            get
            {
                return this.showCustomerRelationField;
            }
            set
            {
                this.showCustomerRelationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showCustomerRelationSpecified
        {
            get
            {
                return this.showCustomerRelationFieldSpecified;
            }
            set
            {
                this.showCustomerRelationFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public bool showAccountRelation
        {
            get
            {
                return this.showAccountRelationField;
            }
            set
            {
                this.showAccountRelationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showAccountRelationSpecified
        {
            get
            {
                return this.showAccountRelationFieldSpecified;
            }
            set
            {
                this.showAccountRelationFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public bool showRelatedAccountInfo
        {
            get
            {
                return this.showRelatedAccountInfoField;
            }
            set
            {
                this.showRelatedAccountInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showRelatedAccountInfoSpecified
        {
            get
            {
                return this.showRelatedAccountInfoFieldSpecified;
            }
            set
            {
                this.showRelatedAccountInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public bool showBalance
        {
            get
            {
                return this.showBalanceField;
            }
            set
            {
                this.showBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showBalanceSpecified
        {
            get
            {
                return this.showBalanceFieldSpecified;
            }
            set
            {
                this.showBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public bool showInterestInfo
        {
            get
            {
                return this.showInterestInfoField;
            }
            set
            {
                this.showInterestInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showInterestInfoSpecified
        {
            get
            {
                return this.showInterestInfoFieldSpecified;
            }
            set
            {
                this.showInterestInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public bool showTermInfo
        {
            get
            {
                return this.showTermInfoField;
            }
            set
            {
                this.showTermInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showTermInfoSpecified
        {
            get
            {
                return this.showTermInfoFieldSpecified;
            }
            set
            {
                this.showTermInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public bool showAvailableBalanceInfo
        {
            get
            {
                return this.showAvailableBalanceInfoField;
            }
            set
            {
                this.showAvailableBalanceInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showAvailableBalanceInfoSpecified
        {
            get
            {
                return this.showAvailableBalanceInfoFieldSpecified;
            }
            set
            {
                this.showAvailableBalanceInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public bool showPassbookInfo
        {
            get
            {
                return this.showPassbookInfoField;
            }
            set
            {
                this.showPassbookInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showPassbookInfoSpecified
        {
            get
            {
                return this.showPassbookInfoFieldSpecified;
            }
            set
            {
                this.showPassbookInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public bool showTransferredInfo
        {
            get
            {
                return this.showTransferredInfoField;
            }
            set
            {
                this.showTransferredInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showTransferredInfoSpecified
        {
            get
            {
                return this.showTransferredInfoFieldSpecified;
            }
            set
            {
                this.showTransferredInfoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public bool showOfsaaCode
        {
            get
            {
                return this.showOfsaaCodeField;
            }
            set
            {
                this.showOfsaaCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool showOfsaaCodeSpecified
        {
            get
            {
                return this.showOfsaaCodeFieldSpecified;
            }
            set
            {
                this.showOfsaaCodeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveAccountInfoResponse
    {

        private BaseAccount[] retrieveAccountInfoResponseDTOField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayAttribute(Order = 0)]
        [System.Xml.Serialization.XmlArrayItemAttribute("accounts", IsNullable = false)]
        public BaseAccount[] RetrieveAccountInfoResponseDTO
        {
            get
            {
                return this.retrieveAccountInfoResponseDTOField;
            }
            set
            {
                this.retrieveAccountInfoResponseDTOField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class BaseAccount
    {

        private IdInfo idInfoField;

        private int productCodeField;

        private bool productCodeFieldSpecified;

        private ReferenceDataType accountStatusReasonField;

        private ReferenceDataType accountStatusField;

        private bool secretField;

        private bool secretFieldSpecified;

        private HolderInfo[] holdersField;

        private BalanceInfo balanceField;

        private AvailableBalanceOfDayInfo[] availableBalanceOfDayField;

        private AccountMetadataInfo accountMetadataField;

        private TermInfo termField;

        private InterestInfo interestField;

        private ReferenceDataType dormantStatusField;

        private AccountRelationInfo[] accountRelationsField;

        private PassbookInfo passbookField;

        private TransferredAccountInfo[] transferredAccountsField;

        private AdditionalInfo additionalInfoField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public IdInfo idInfo
        {
            get
            {
                return this.idInfoField;
            }
            set
            {
                this.idInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int productCode
        {
            get
            {
                return this.productCodeField;
            }
            set
            {
                this.productCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool productCodeSpecified
        {
            get
            {
                return this.productCodeFieldSpecified;
            }
            set
            {
                this.productCodeFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public ReferenceDataType accountStatusReason
        {
            get
            {
                return this.accountStatusReasonField;
            }
            set
            {
                this.accountStatusReasonField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public ReferenceDataType accountStatus
        {
            get
            {
                return this.accountStatusField;
            }
            set
            {
                this.accountStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public bool secret
        {
            get
            {
                return this.secretField;
            }
            set
            {
                this.secretField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool secretSpecified
        {
            get
            {
                return this.secretFieldSpecified;
            }
            set
            {
                this.secretFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("holders", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public HolderInfo[] holders
        {
            get
            {
                return this.holdersField;
            }
            set
            {
                this.holdersField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public BalanceInfo balance
        {
            get
            {
                return this.balanceField;
            }
            set
            {
                this.balanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("availableBalanceOfDay", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public AvailableBalanceOfDayInfo[] availableBalanceOfDay
        {
            get
            {
                return this.availableBalanceOfDayField;
            }
            set
            {
                this.availableBalanceOfDayField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public AccountMetadataInfo accountMetadata
        {
            get
            {
                return this.accountMetadataField;
            }
            set
            {
                this.accountMetadataField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public TermInfo term
        {
            get
            {
                return this.termField;
            }
            set
            {
                this.termField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 10)]
        public InterestInfo interest
        {
            get
            {
                return this.interestField;
            }
            set
            {
                this.interestField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 11)]
        public ReferenceDataType dormantStatus
        {
            get
            {
                return this.dormantStatusField;
            }
            set
            {
                this.dormantStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accountRelations", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 12)]
        public AccountRelationInfo[] accountRelations
        {
            get
            {
                return this.accountRelationsField;
            }
            set
            {
                this.accountRelationsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 13)]
        public PassbookInfo passbook
        {
            get
            {
                return this.passbookField;
            }
            set
            {
                this.passbookField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("transferredAccounts", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 14)]
        public TransferredAccountInfo[] transferredAccounts
        {
            get
            {
                return this.transferredAccountsField;
            }
            set
            {
                this.transferredAccountsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 15)]
        public AdditionalInfo additionalInfo
        {
            get
            {
                return this.additionalInfoField;
            }
            set
            {
                this.additionalInfoField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class IdInfo
    {

        private long idField;

        private bool idFieldSpecified;

        private AccountKeyInfo accountKeyField;

        private string ibanField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public long id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool idSpecified
        {
            get
            {
                return this.idFieldSpecified;
            }
            set
            {
                this.idFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public AccountKeyInfo accountKey
        {
            get
            {
                return this.accountKeyField;
            }
            set
            {
                this.accountKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string iban
        {
            get
            {
                return this.ibanField;
            }
            set
            {
                this.ibanField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class HolderInfo
    {

        private int customerNoField;

        private bool customerNoFieldSpecified;

        private long relationIdField;

        private bool relationIdFieldSpecified;

        private ReferenceDataType customerStatusField;

        private ReferenceDataType approvalStatusField;

        private ReferenceDataType customerRoleField;

        private ReferenceDataType arrangementTypeField;

        private System.DateTime relStartField;

        private bool relStartFieldSpecified;

        private System.DateTime relEndField;

        private bool relEndFieldSpecified;

        private string aliasField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int customerNo
        {
            get
            {
                return this.customerNoField;
            }
            set
            {
                this.customerNoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool customerNoSpecified
        {
            get
            {
                return this.customerNoFieldSpecified;
            }
            set
            {
                this.customerNoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public long relationId
        {
            get
            {
                return this.relationIdField;
            }
            set
            {
                this.relationIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relationIdSpecified
        {
            get
            {
                return this.relationIdFieldSpecified;
            }
            set
            {
                this.relationIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public ReferenceDataType customerStatus
        {
            get
            {
                return this.customerStatusField;
            }
            set
            {
                this.customerStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public ReferenceDataType approvalStatus
        {
            get
            {
                return this.approvalStatusField;
            }
            set
            {
                this.approvalStatusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public ReferenceDataType customerRole
        {
            get
            {
                return this.customerRoleField;
            }
            set
            {
                this.customerRoleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public ReferenceDataType arrangementType
        {
            get
            {
                return this.arrangementTypeField;
            }
            set
            {
                this.arrangementTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 6)]
        public System.DateTime relStart
        {
            get
            {
                return this.relStartField;
            }
            set
            {
                this.relStartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relStartSpecified
        {
            get
            {
                return this.relStartFieldSpecified;
            }
            set
            {
                this.relStartFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 7)]
        public System.DateTime relEnd
        {
            get
            {
                return this.relEndField;
            }
            set
            {
                this.relEndField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relEndSpecified
        {
            get
            {
                return this.relEndFieldSpecified;
            }
            set
            {
                this.relEndFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public string alias
        {
            get
            {
                return this.aliasField;
            }
            set
            {
                this.aliasField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class BalanceInfo
    {

        private decimal balanceField;

        private bool balanceFieldSpecified;

        private ReferenceDataType currencyField;

        private decimal creditBalanceField;

        private bool creditBalanceFieldSpecified;

        private decimal creditLimitField;

        private bool creditLimitFieldSpecified;

        private decimal blockageAmountField;

        private bool blockageAmountFieldSpecified;

        private int ledgerIndexField;

        private bool ledgerIndexFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public decimal balance
        {
            get
            {
                return this.balanceField;
            }
            set
            {
                this.balanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool balanceSpecified
        {
            get
            {
                return this.balanceFieldSpecified;
            }
            set
            {
                this.balanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public ReferenceDataType currency
        {
            get
            {
                return this.currencyField;
            }
            set
            {
                this.currencyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public decimal creditBalance
        {
            get
            {
                return this.creditBalanceField;
            }
            set
            {
                this.creditBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool creditBalanceSpecified
        {
            get
            {
                return this.creditBalanceFieldSpecified;
            }
            set
            {
                this.creditBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public decimal creditLimit
        {
            get
            {
                return this.creditLimitField;
            }
            set
            {
                this.creditLimitField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool creditLimitSpecified
        {
            get
            {
                return this.creditLimitFieldSpecified;
            }
            set
            {
                this.creditLimitFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public decimal blockageAmount
        {
            get
            {
                return this.blockageAmountField;
            }
            set
            {
                this.blockageAmountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool blockageAmountSpecified
        {
            get
            {
                return this.blockageAmountFieldSpecified;
            }
            set
            {
                this.blockageAmountFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public int ledgerIndex
        {
            get
            {
                return this.ledgerIndexField;
            }
            set
            {
                this.ledgerIndexField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool ledgerIndexSpecified
        {
            get
            {
                return this.ledgerIndexFieldSpecified;
            }
            set
            {
                this.ledgerIndexFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AvailableBalanceOfDayInfo
    {

        private System.DateTime dateField;

        private bool dateFieldSpecified;

        private decimal debitBalanceField;

        private bool debitBalanceFieldSpecified;

        private decimal creditBalanceField;

        private bool creditBalanceFieldSpecified;

        private decimal midBalanceField;

        private bool midBalanceFieldSpecified;

        private ReferenceDataType accountStatusReasonField;

        private TermInfo termField;

        private decimal interestRateField;

        private bool interestRateFieldSpecified;

        private decimal additionalInterestRateField;

        private bool additionalInterestRateFieldSpecified;

        private decimal availableLimitField;

        private bool availableLimitFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 0)]
        public System.DateTime date
        {
            get
            {
                return this.dateField;
            }
            set
            {
                this.dateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool dateSpecified
        {
            get
            {
                return this.dateFieldSpecified;
            }
            set
            {
                this.dateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public decimal debitBalance
        {
            get
            {
                return this.debitBalanceField;
            }
            set
            {
                this.debitBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool debitBalanceSpecified
        {
            get
            {
                return this.debitBalanceFieldSpecified;
            }
            set
            {
                this.debitBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public decimal creditBalance
        {
            get
            {
                return this.creditBalanceField;
            }
            set
            {
                this.creditBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool creditBalanceSpecified
        {
            get
            {
                return this.creditBalanceFieldSpecified;
            }
            set
            {
                this.creditBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public decimal midBalance
        {
            get
            {
                return this.midBalanceField;
            }
            set
            {
                this.midBalanceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool midBalanceSpecified
        {
            get
            {
                return this.midBalanceFieldSpecified;
            }
            set
            {
                this.midBalanceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public ReferenceDataType accountStatusReason
        {
            get
            {
                return this.accountStatusReasonField;
            }
            set
            {
                this.accountStatusReasonField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public TermInfo term
        {
            get
            {
                return this.termField;
            }
            set
            {
                this.termField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public decimal interestRate
        {
            get
            {
                return this.interestRateField;
            }
            set
            {
                this.interestRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool interestRateSpecified
        {
            get
            {
                return this.interestRateFieldSpecified;
            }
            set
            {
                this.interestRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public decimal additionalInterestRate
        {
            get
            {
                return this.additionalInterestRateField;
            }
            set
            {
                this.additionalInterestRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool additionalInterestRateSpecified
        {
            get
            {
                return this.additionalInterestRateFieldSpecified;
            }
            set
            {
                this.additionalInterestRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public decimal availableLimit
        {
            get
            {
                return this.availableLimitField;
            }
            set
            {
                this.availableLimitField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool availableLimitSpecified
        {
            get
            {
                return this.availableLimitFieldSpecified;
            }
            set
            {
                this.availableLimitFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class TermInfo
    {

        private System.DateTime termStartField;

        private bool termStartFieldSpecified;

        private System.DateTime termEndField;

        private bool termEndFieldSpecified;

        private ReferenceDataType statusField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 0)]
        public System.DateTime termStart
        {
            get
            {
                return this.termStartField;
            }
            set
            {
                this.termStartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool termStartSpecified
        {
            get
            {
                return this.termStartFieldSpecified;
            }
            set
            {
                this.termStartFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 1)]
        public System.DateTime termEnd
        {
            get
            {
                return this.termEndField;
            }
            set
            {
                this.termEndField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool termEndSpecified
        {
            get
            {
                return this.termEndFieldSpecified;
            }
            set
            {
                this.termEndFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public ReferenceDataType status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountMetadataInfo
    {

        private System.DateTime openingDateField;

        private bool openingDateFieldSpecified;

        private int openingUserIdField;

        private bool openingUserIdFieldSpecified;

        private string openingChannelField;

        private System.DateTime closingDateField;

        private bool closingDateFieldSpecified;

        private int closingUserIdField;

        private bool closingUserIdFieldSpecified;

        private string closingChannelField;

        private System.DateTime lastTrxDateField;

        private bool lastTrxDateFieldSpecified;

        private System.DateTime expireDateField;

        private bool expireDateFieldSpecified;

        private string nameField;

        private ReferenceDataType baseLocationField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 0)]
        public System.DateTime openingDate
        {
            get
            {
                return this.openingDateField;
            }
            set
            {
                this.openingDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool openingDateSpecified
        {
            get
            {
                return this.openingDateFieldSpecified;
            }
            set
            {
                this.openingDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int openingUserId
        {
            get
            {
                return this.openingUserIdField;
            }
            set
            {
                this.openingUserIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool openingUserIdSpecified
        {
            get
            {
                return this.openingUserIdFieldSpecified;
            }
            set
            {
                this.openingUserIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public string openingChannel
        {
            get
            {
                return this.openingChannelField;
            }
            set
            {
                this.openingChannelField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 3)]
        public System.DateTime closingDate
        {
            get
            {
                return this.closingDateField;
            }
            set
            {
                this.closingDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool closingDateSpecified
        {
            get
            {
                return this.closingDateFieldSpecified;
            }
            set
            {
                this.closingDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public int closingUserId
        {
            get
            {
                return this.closingUserIdField;
            }
            set
            {
                this.closingUserIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool closingUserIdSpecified
        {
            get
            {
                return this.closingUserIdFieldSpecified;
            }
            set
            {
                this.closingUserIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public string closingChannel
        {
            get
            {
                return this.closingChannelField;
            }
            set
            {
                this.closingChannelField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 6)]
        public System.DateTime lastTrxDate
        {
            get
            {
                return this.lastTrxDateField;
            }
            set
            {
                this.lastTrxDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool lastTrxDateSpecified
        {
            get
            {
                return this.lastTrxDateFieldSpecified;
            }
            set
            {
                this.lastTrxDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public System.DateTime expireDate
        {
            get
            {
                return this.expireDateField;
            }
            set
            {
                this.expireDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool expireDateSpecified
        {
            get
            {
                return this.expireDateFieldSpecified;
            }
            set
            {
                this.expireDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public ReferenceDataType baseLocation
        {
            get
            {
                return this.baseLocationField;
            }
            set
            {
                this.baseLocationField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class InterestInfo
    {

        private decimal interestRateField;

        private bool interestRateFieldSpecified;

        private decimal announcedRateField;

        private bool announcedRateFieldSpecified;

        private decimal additionalInterestRateField;

        private bool additionalInterestRateFieldSpecified;

        private decimal ftfRateField;

        private bool ftfRateFieldSpecified;

        private decimal minusMargeRateField;

        private bool minusMargeRateFieldSpecified;

        private decimal spreadField;

        private bool spreadFieldSpecified;

        private decimal baseRateField;

        private bool baseRateFieldSpecified;

        private decimal banksShareField;

        private bool banksShareFieldSpecified;

        private decimal defaultRateField;

        private bool defaultRateFieldSpecified;

        private decimal underAnnounceField;

        private bool underAnnounceFieldSpecified;

        private decimal eftWithCommissionField;

        private bool eftWithCommissionFieldSpecified;

        private decimal eftWithoutCommissionField;

        private bool eftWithoutCommissionFieldSpecified;

        private decimal commissionRateField;

        private bool commissionRateFieldSpecified;

        private decimal contractRateField;

        private bool contractRateFieldSpecified;

        private decimal totalInterestRateField;

        private bool totalInterestRateFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public decimal interestRate
        {
            get
            {
                return this.interestRateField;
            }
            set
            {
                this.interestRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool interestRateSpecified
        {
            get
            {
                return this.interestRateFieldSpecified;
            }
            set
            {
                this.interestRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public decimal announcedRate
        {
            get
            {
                return this.announcedRateField;
            }
            set
            {
                this.announcedRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool announcedRateSpecified
        {
            get
            {
                return this.announcedRateFieldSpecified;
            }
            set
            {
                this.announcedRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public decimal additionalInterestRate
        {
            get
            {
                return this.additionalInterestRateField;
            }
            set
            {
                this.additionalInterestRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool additionalInterestRateSpecified
        {
            get
            {
                return this.additionalInterestRateFieldSpecified;
            }
            set
            {
                this.additionalInterestRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public decimal ftfRate
        {
            get
            {
                return this.ftfRateField;
            }
            set
            {
                this.ftfRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool ftfRateSpecified
        {
            get
            {
                return this.ftfRateFieldSpecified;
            }
            set
            {
                this.ftfRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public decimal minusMargeRate
        {
            get
            {
                return this.minusMargeRateField;
            }
            set
            {
                this.minusMargeRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool minusMargeRateSpecified
        {
            get
            {
                return this.minusMargeRateFieldSpecified;
            }
            set
            {
                this.minusMargeRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public decimal spread
        {
            get
            {
                return this.spreadField;
            }
            set
            {
                this.spreadField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool spreadSpecified
        {
            get
            {
                return this.spreadFieldSpecified;
            }
            set
            {
                this.spreadFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public decimal baseRate
        {
            get
            {
                return this.baseRateField;
            }
            set
            {
                this.baseRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool baseRateSpecified
        {
            get
            {
                return this.baseRateFieldSpecified;
            }
            set
            {
                this.baseRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 7)]
        public decimal banksShare
        {
            get
            {
                return this.banksShareField;
            }
            set
            {
                this.banksShareField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool banksShareSpecified
        {
            get
            {
                return this.banksShareFieldSpecified;
            }
            set
            {
                this.banksShareFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public decimal defaultRate
        {
            get
            {
                return this.defaultRateField;
            }
            set
            {
                this.defaultRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool defaultRateSpecified
        {
            get
            {
                return this.defaultRateFieldSpecified;
            }
            set
            {
                this.defaultRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public decimal underAnnounce
        {
            get
            {
                return this.underAnnounceField;
            }
            set
            {
                this.underAnnounceField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool underAnnounceSpecified
        {
            get
            {
                return this.underAnnounceFieldSpecified;
            }
            set
            {
                this.underAnnounceFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 10)]
        public decimal eftWithCommission
        {
            get
            {
                return this.eftWithCommissionField;
            }
            set
            {
                this.eftWithCommissionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool eftWithCommissionSpecified
        {
            get
            {
                return this.eftWithCommissionFieldSpecified;
            }
            set
            {
                this.eftWithCommissionFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 11)]
        public decimal eftWithoutCommission
        {
            get
            {
                return this.eftWithoutCommissionField;
            }
            set
            {
                this.eftWithoutCommissionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool eftWithoutCommissionSpecified
        {
            get
            {
                return this.eftWithoutCommissionFieldSpecified;
            }
            set
            {
                this.eftWithoutCommissionFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 12)]
        public decimal commissionRate
        {
            get
            {
                return this.commissionRateField;
            }
            set
            {
                this.commissionRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool commissionRateSpecified
        {
            get
            {
                return this.commissionRateFieldSpecified;
            }
            set
            {
                this.commissionRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 13)]
        public decimal contractRate
        {
            get
            {
                return this.contractRateField;
            }
            set
            {
                this.contractRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool contractRateSpecified
        {
            get
            {
                return this.contractRateFieldSpecified;
            }
            set
            {
                this.contractRateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 14)]
        public decimal totalInterestRate
        {
            get
            {
                return this.totalInterestRateField;
            }
            set
            {
                this.totalInterestRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool totalInterestRateSpecified
        {
            get
            {
                return this.totalInterestRateFieldSpecified;
            }
            set
            {
                this.totalInterestRateFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountRelationInfo
    {

        private ReferenceDataType arrangementTypeField;

        private long relatedAccountIdField;

        private bool relatedAccountIdFieldSpecified;

        private IdInfo relatedAccountInfoField;

        private ReferenceDataType relArrangementTypeField;

        private ReferenceDataType relationTypeField;

        private ReferenceDataType statusField;

        private System.DateTime relStartField;

        private bool relStartFieldSpecified;

        private System.DateTime relEndField;

        private bool relEndFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public ReferenceDataType arrangementType
        {
            get
            {
                return this.arrangementTypeField;
            }
            set
            {
                this.arrangementTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public long relatedAccountId
        {
            get
            {
                return this.relatedAccountIdField;
            }
            set
            {
                this.relatedAccountIdField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relatedAccountIdSpecified
        {
            get
            {
                return this.relatedAccountIdFieldSpecified;
            }
            set
            {
                this.relatedAccountIdFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public IdInfo relatedAccountInfo
        {
            get
            {
                return this.relatedAccountInfoField;
            }
            set
            {
                this.relatedAccountInfoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public ReferenceDataType relArrangementType
        {
            get
            {
                return this.relArrangementTypeField;
            }
            set
            {
                this.relArrangementTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public ReferenceDataType relationType
        {
            get
            {
                return this.relationTypeField;
            }
            set
            {
                this.relationTypeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public ReferenceDataType status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 6)]
        public System.DateTime relStart
        {
            get
            {
                return this.relStartField;
            }
            set
            {
                this.relStartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relStartSpecified
        {
            get
            {
                return this.relStartFieldSpecified;
            }
            set
            {
                this.relStartFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 7)]
        public System.DateTime relEnd
        {
            get
            {
                return this.relEndField;
            }
            set
            {
                this.relEndField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool relEndSpecified
        {
            get
            {
                return this.relEndFieldSpecified;
            }
            set
            {
                this.relEndFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class PassbookInfo
    {

        private int passbookNoField;

        private bool passbookNoFieldSpecified;

        private System.DateTime lastTrxTimeField;

        private bool lastTrxTimeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int passbookNo
        {
            get
            {
                return this.passbookNoField;
            }
            set
            {
                this.passbookNoField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool passbookNoSpecified
        {
            get
            {
                return this.passbookNoFieldSpecified;
            }
            set
            {
                this.passbookNoFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public System.DateTime lastTrxTime
        {
            get
            {
                return this.lastTrxTimeField;
            }
            set
            {
                this.lastTrxTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool lastTrxTimeSpecified
        {
            get
            {
                return this.lastTrxTimeFieldSpecified;
            }
            set
            {
                this.lastTrxTimeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class TransferredAccountInfo
    {

        private AccountKeyInfo accountKeyField;

        private string ibanField;

        private System.DateTime expireTimeField;

        private bool expireTimeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public AccountKeyInfo accountKey
        {
            get
            {
                return this.accountKeyField;
            }
            set
            {
                this.accountKeyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public string iban
        {
            get
            {
                return this.ibanField;
            }
            set
            {
                this.ibanField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 2)]
        public System.DateTime expireTime
        {
            get
            {
                return this.expireTimeField;
            }
            set
            {
                this.expireTimeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool expireTimeSpecified
        {
            get
            {
                return this.expireTimeFieldSpecified;
            }
            set
            {
                this.expireTimeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AdditionalInfo
    {

        private int ofsaaCodeField;

        private bool ofsaaCodeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int ofsaaCode
        {
            get
            {
                return this.ofsaaCodeField;
            }
            set
            {
                this.ofsaaCodeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool ofsaaCodeSpecified
        {
            get
            {
                return this.ofsaaCodeFieldSpecified;
            }
            set
            {
                this.ofsaaCodeFieldSpecified = value;
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveAccountInfoRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveAccountInfo retrieveAccountInfo;

        public retrieveAccountInfoRequest()
        {
        }

        public retrieveAccountInfoRequest(RetrieveAccountInfo retrieveAccountInfo)
        {
            this.retrieveAccountInfo = retrieveAccountInfo;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveAccountInfoResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveAccountInfoResponse retrieveAccountInfoResponse;

        public retrieveAccountInfoResponse1()
        {
        }

        public retrieveAccountInfoResponse1(RetrieveAccountInfoResponse retrieveAccountInfoResponse)
        {
            this.retrieveAccountInfoResponse = retrieveAccountInfoResponse;
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveCustomerAccounts
    {

        private int customerField;

        private AccountCriteriaInfo criteriaField;

        private AccountOptionsInfo optionsField;

        private PaginationInfo paginationField;

        private SortInfo sortField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public int customer
        {
            get
            {
                return this.customerField;
            }
            set
            {
                this.customerField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public AccountCriteriaInfo criteria
        {
            get
            {
                return this.criteriaField;
            }
            set
            {
                this.criteriaField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 2)]
        public AccountOptionsInfo options
        {
            get
            {
                return this.optionsField;
            }
            set
            {
                this.optionsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 3)]
        public PaginationInfo pagination
        {
            get
            {
                return this.paginationField;
            }
            set
            {
                this.paginationField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 4)]
        public SortInfo sort
        {
            get
            {
                return this.sortField;
            }
            set
            {
                this.sortField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class AccountCriteriaInfo
    {

        private object[] itemsField;

        private ReferenceDataType[] items1Field;

        private Items1ChoiceType[] items1ElementNameField;

        private int[] branchCodeListField;

        private ReferenceDataType[] customerRoleListField;

        private ReferenceDataType[] approvalStatusListField;

        private ReferenceDataType[] currencyListField;

        private System.DateTime openingDateField;

        private bool openingDateFieldSpecified;

        private DateRangeInfo termStartingRangeField;

        private DateRangeInfo termEndingRangeField;

        private ReferenceDataType commercialListingTypeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accountTypeList", typeof(ReferenceDataType), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        [System.Xml.Serialization.XmlElementAttribute("productCodeList", typeof(int), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public object[] Items
        {
            get
            {
                return this.itemsField;
            }
            set
            {
                this.itemsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accountStatus", typeof(ReferenceDataType), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        [System.Xml.Serialization.XmlElementAttribute("statusReasonList", typeof(ReferenceDataType), Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("Items1ElementName")]
        public ReferenceDataType[] Items1
        {
            get
            {
                return this.items1Field;
            }
            set
            {
                this.items1Field = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Items1ElementName", Order = 2)]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public Items1ChoiceType[] Items1ElementName
        {
            get
            {
                return this.items1ElementNameField;
            }
            set
            {
                this.items1ElementNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("branchCodeList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 3)]
        public int[] branchCodeList
        {
            get
            {
                return this.branchCodeListField;
            }
            set
            {
                this.branchCodeListField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("customerRoleList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 4)]
        public ReferenceDataType[] customerRoleList
        {
            get
            {
                return this.customerRoleListField;
            }
            set
            {
                this.customerRoleListField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("approvalStatusList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 5)]
        public ReferenceDataType[] approvalStatusList
        {
            get
            {
                return this.approvalStatusListField;
            }
            set
            {
                this.approvalStatusListField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("currencyList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 6)]
        public ReferenceDataType[] currencyList
        {
            get
            {
                return this.currencyListField;
            }
            set
            {
                this.currencyListField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 7)]
        public System.DateTime openingDate
        {
            get
            {
                return this.openingDateField;
            }
            set
            {
                this.openingDateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool openingDateSpecified
        {
            get
            {
                return this.openingDateFieldSpecified;
            }
            set
            {
                this.openingDateFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 8)]
        public DateRangeInfo termStartingRange
        {
            get
            {
                return this.termStartingRangeField;
            }
            set
            {
                this.termStartingRangeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 9)]
        public DateRangeInfo termEndingRange
        {
            get
            {
                return this.termEndingRangeField;
            }
            set
            {
                this.termEndingRangeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 10)]
        public ReferenceDataType commercialListingType
        {
            get
            {
                return this.commercialListingTypeField;
            }
            set
            {
                this.commercialListingTypeField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1", IncludeInSchema = false)]
    public enum Items1ChoiceType
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute(":accountStatus")]
        accountStatus,

        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute(":statusReasonList")]
        statusReasonList,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class DateRangeInfo
    {

        private System.DateTime startingField;

        private System.DateTime endingField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 0)]
        public System.DateTime starting
        {
            get
            {
                return this.startingField;
            }
            set
            {
                this.startingField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "date", Order = 1)]
        public System.DateTime ending
        {
            get
            {
                return this.endingField;
            }
            set
            {
                this.endingField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class PaginationInfo
    {

        private int pageStartField;

        private int pageEndField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public int pageStart
        {
            get
            {
                return this.pageStartField;
            }
            set
            {
                this.pageStartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public int pageEnd
        {
            get
            {
                return this.pageEndField;
            }
            set
            {
                this.pageEndField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public partial class SortInfo
    {

        private SortBy byField;

        private SortDirection directionField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public SortBy by
        {
            get
            {
                return this.byField;
            }
            set
            {
                this.byField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        public SortDirection direction
        {
            get
            {
                return this.directionField;
            }
            set
            {
                this.directionField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public enum SortBy
    {

        /// <remarks/>
        CUSTOMER_ROLE,

        /// <remarks/>
        ACCOUNT_NO,

        /// <remarks/>
        BRANCH,

        /// <remarks/>
        ACCOUNT_STATUS,

        /// <remarks/>
        PRODUCT_CODE,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/Account/Schema/V1")]
    public enum SortDirection
    {

        /// <remarks/>
        ASC,

        /// <remarks/>
        DESC,
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveCustomerAccountsResponse
    {

        private RetrieveCustomerAccountsResponseRetrieveCustomerAccountsResponseDTO retrieveCustomerAccountsResponseDTOField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 0)]
        public RetrieveCustomerAccountsResponseRetrieveCustomerAccountsResponseDTO RetrieveCustomerAccountsResponseDTO
        {
            get
            {
                return this.retrieveCustomerAccountsResponseDTOField;
            }
            set
            {
                this.retrieveCustomerAccountsResponseDTOField = value;
            }
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3")]
    public partial class RetrieveCustomerAccountsResponseRetrieveCustomerAccountsResponseDTO
    {

        private BaseAccount[] accountsField;

        private int totalCountField;

        private bool totalCountFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("accounts", Order = 0)]
        public BaseAccount[] accounts
        {
            get
            {
                return this.accountsField;
            }
            set
            {
                this.accountsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Order = 1)]
        public int totalCount
        {
            get
            {
                return this.totalCountField;
            }
            set
            {
                this.totalCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool totalCountSpecified
        {
            get
            {
                return this.totalCountFieldSpecified;
            }
            set
            {
                this.totalCountFieldSpecified = value;
            }
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveCustomerAccountsRequest
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveCustomerAccounts retrieveCustomerAccounts;

        public retrieveCustomerAccountsRequest()
        {
        }

        public retrieveCustomerAccountsRequest(RetrieveCustomerAccounts retrieveCustomerAccounts)
        {
            this.retrieveCustomerAccounts = retrieveCustomerAccounts;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class retrieveCustomerAccountsResponse1
    {

        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "http://isbank.com/OpSvcs/CustAccountMaint/AccountEnquiry/Service/V3", Order = 0)]
        public RetrieveCustomerAccountsResponse retrieveCustomerAccountsResponse;

        public retrieveCustomerAccountsResponse1()
        {
        }

        public retrieveCustomerAccountsResponse1(RetrieveCustomerAccountsResponse retrieveCustomerAccountsResponse)
        {
            this.retrieveCustomerAccountsResponse = retrieveCustomerAccountsResponse;
        }
    }

    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    public interface AccountEnquiryServiceV3x0Channel : AccountEnquiryServiceV3x0, System.ServiceModel.IClientChannel
    {
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.Tools.ServiceModel.Svcutil", "2.0.2")]
    public partial class AccountEnquiryServiceV3x0Client : System.ServiceModel.ClientBase<AccountEnquiryServiceV3x0>, AccountEnquiryServiceV3x0
    {

        /// <summary>
        /// Implement this partial method to configure the service endpoint.
        /// </summary>
        /// <param name="serviceEndpoint">The endpoint to configure</param>
        /// <param name="clientCredentials">The client credentials</param>
        static partial void ConfigureEndpoint(System.ServiceModel.Description.ServiceEndpoint serviceEndpoint, System.ServiceModel.Description.ClientCredentials clientCredentials);

        public AccountEnquiryServiceV3x0Client() :
                base(AccountEnquiryServiceV3x0Client.GetDefaultBinding(), AccountEnquiryServiceV3x0Client.GetDefaultEndpointAddress())
        {
            this.Endpoint.Name = EndpointConfiguration.AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }

        public AccountEnquiryServiceV3x0Client(EndpointConfiguration endpointConfiguration) :
                base(AccountEnquiryServiceV3x0Client.GetBindingForEndpoint(endpointConfiguration), AccountEnquiryServiceV3x0Client.GetEndpointAddress(endpointConfiguration))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }

        public AccountEnquiryServiceV3x0Client(EndpointConfiguration endpointConfiguration, string remoteAddress) :
                base(AccountEnquiryServiceV3x0Client.GetBindingForEndpoint(endpointConfiguration), new System.ServiceModel.EndpointAddress(remoteAddress))
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }

        public AccountEnquiryServiceV3x0Client(EndpointConfiguration endpointConfiguration, System.ServiceModel.EndpointAddress remoteAddress) :
                base(AccountEnquiryServiceV3x0Client.GetBindingForEndpoint(endpointConfiguration), remoteAddress)
        {
            this.Endpoint.Name = endpointConfiguration.ToString();
            ConfigureEndpoint(this.Endpoint, this.ClientCredentials);
        }

        public AccountEnquiryServiceV3x0Client(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
                base(binding, remoteAddress)
        {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        System.Threading.Tasks.Task<retrieveActivitiesResponse1> AccountEnquiryServiceV3x0.retrieveActivitiesAsync(retrieveActivitiesRequest request)
        {
            return base.Channel.retrieveActivitiesAsync(request);
        }

        public System.Threading.Tasks.Task<retrieveActivitiesResponse1> retrieveActivitiesAsync(RetrieveActivities retrieveActivities)
        {
            retrieveActivitiesRequest inValue = new retrieveActivitiesRequest();
            inValue.retrieveActivities = retrieveActivities;
            return ((AccountEnquiryServiceV3x0)(this)).retrieveActivitiesAsync(inValue);
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        System.Threading.Tasks.Task<retrieveLastActivitiesResponse1> AccountEnquiryServiceV3x0.retrieveLastActivitiesAsync(retrieveLastActivitiesRequest request)
        {
            return base.Channel.retrieveLastActivitiesAsync(request);
        }

        public System.Threading.Tasks.Task<retrieveLastActivitiesResponse1> retrieveLastActivitiesAsync(RetrieveLastActivities retrieveLastActivities)
        {
            retrieveLastActivitiesRequest inValue = new retrieveLastActivitiesRequest();
            inValue.retrieveLastActivities = retrieveLastActivities;
            return ((AccountEnquiryServiceV3x0)(this)).retrieveLastActivitiesAsync(inValue);
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        System.Threading.Tasks.Task<retrieveAccountInfoResponse1> AccountEnquiryServiceV3x0.retrieveAccountInfoAsync(retrieveAccountInfoRequest request)
        {
            return base.Channel.retrieveAccountInfoAsync(request);
        }

        public System.Threading.Tasks.Task<retrieveAccountInfoResponse1> retrieveAccountInfoAsync(RetrieveAccountInfo retrieveAccountInfo)
        {
            retrieveAccountInfoRequest inValue = new retrieveAccountInfoRequest();
            inValue.retrieveAccountInfo = retrieveAccountInfo;
            return ((AccountEnquiryServiceV3x0)(this)).retrieveAccountInfoAsync(inValue);
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        System.Threading.Tasks.Task<retrieveCustomerAccountsResponse1> AccountEnquiryServiceV3x0.retrieveCustomerAccountsAsync(retrieveCustomerAccountsRequest request)
        {
            return base.Channel.retrieveCustomerAccountsAsync(request);
        }

        public System.Threading.Tasks.Task<retrieveCustomerAccountsResponse1> retrieveCustomerAccountsAsync(RetrieveCustomerAccounts retrieveCustomerAccounts)
        {
            retrieveCustomerAccountsRequest inValue = new retrieveCustomerAccountsRequest();
            inValue.retrieveCustomerAccounts = retrieveCustomerAccounts;
            return ((AccountEnquiryServiceV3x0)(this)).retrieveCustomerAccountsAsync(inValue);
        }

        public virtual System.Threading.Tasks.Task OpenAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginOpen(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndOpen));
        }

        public virtual System.Threading.Tasks.Task CloseAsync()
        {
            return System.Threading.Tasks.Task.Factory.FromAsync(((System.ServiceModel.ICommunicationObject)(this)).BeginClose(null, null), new System.Action<System.IAsyncResult>(((System.ServiceModel.ICommunicationObject)(this)).EndClose));
        }

        private static System.ServiceModel.Channels.Binding GetBindingForEndpoint(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1))
            {
                System.ServiceModel.BasicHttpBinding result = new System.ServiceModel.BasicHttpBinding();
                result.MaxBufferSize = int.MaxValue;
                result.ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max;
                result.MaxReceivedMessageSize = int.MaxValue;
                result.AllowCookies = true;
                return result;
            }
            throw new System.InvalidOperationException(string.Format("Could not find endpoint with name \'{0}\'.", endpointConfiguration));
        }

        private static System.ServiceModel.EndpointAddress GetEndpointAddress(EndpointConfiguration endpointConfiguration)
        {
            if ((endpointConfiguration == EndpointConfiguration.AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1))
            {
                return new System.ServiceModel.EndpointAddress("http://eaesbgatewayuat.gm.isbank.com.tr/OpSvcs/CustAccountMaint/AccountEnquirySer" +
                        "viceV3");
            }
            throw new System.InvalidOperationException(string.Format("Could not find endpoint with name \'{0}\'.", endpointConfiguration));
        }

        private static System.ServiceModel.Channels.Binding GetDefaultBinding()
        {
            return AccountEnquiryServiceV3x0Client.GetBindingForEndpoint(EndpointConfiguration.AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1);
        }

        private static System.ServiceModel.EndpointAddress GetDefaultEndpointAddress()
        {
            return AccountEnquiryServiceV3x0Client.GetEndpointAddress(EndpointConfiguration.AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1);
        }

        public enum EndpointConfiguration
        {

            AccountEnquiryServiceV3x0_UAT_Provider_WebService_Port1,
        }
    }
}