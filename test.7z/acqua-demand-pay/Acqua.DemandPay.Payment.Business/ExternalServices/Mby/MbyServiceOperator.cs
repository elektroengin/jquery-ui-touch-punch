﻿using Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Configuration.Mby;
using Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.ExternalServices.Mby
{
    public class MbyServiceOperator
    {

        private const string ConsumerContextTag = "headerv1:consumerContext";
        private const string SecurityContextTag = "Security";
        private DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        private ILogger _logger;
        private AccountEnquiryServiceV3x0Client _serviceClient;
        private RetrieveAccountInfo _retrieveAccountInfo;
        private Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse _retrieveAccountInfoResponse;

        public MbyServiceOperator(DemandPayPaymentConfiguration demandPayPaymentConfiguration, ILogger<MbyServiceOperator> logger)
        {
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration;
            _retrieveAccountInfo = new RetrieveAccountInfo();
            _retrieveAccountInfoResponse = new Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse();
            _logger = logger;

            Initialize();
        }

        private void Initialize()
        {
            BasicHttpBinding basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.None);

            EndpointAddress endpointAddress = new EndpointAddress(_demandPayPaymentConfiguration.MbyServiceConfiguration.EndPointAddress);

            EndpointAddressBuilder endpointAddressBuilder = new EndpointAddressBuilder(endpointAddress);

            XmlObjectSerializer consumerSerializer = new SoaMessagingSerializer(typeof(MbyConsumerContext));

            MbyConsumerContext branchContextType = _demandPayPaymentConfiguration.MbyServiceConfiguration.ConsumerContext;

            AddressHeader consumerContext = AddressHeader.CreateAddressHeader(ConsumerContextTag, null, branchContextType, consumerSerializer);

            XmlObjectSerializer securitySerializer = new SoaMessagingSerializer(typeof(Security));

            Security security = _demandPayPaymentConfiguration.MbyServiceConfiguration.Security;

            AddressHeader securityHeader = AddressHeader.CreateAddressHeader(SecurityContextTag, _demandPayPaymentConfiguration.MbyServiceConfiguration.SecurityContextNameSpace, security, securitySerializer);

            endpointAddressBuilder.Headers.Add(securityHeader);

            endpointAddressBuilder.Headers.Add(consumerContext);

            _serviceClient = new AccountEnquiryServiceV3x0Client(basicHttpBinding, endpointAddressBuilder.ToEndpointAddress());
        }

        public Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse RetrieveAccountInfo(RetrieveAccountInfoRequest request, string unique)
        {
            try
            {
                var _retrieveAccountInfo = new RetrieveAccountInfo()
                {
                    account = new AccountIdentityInfo[]
                    {
                        new AccountIdentityInfo()
                        {
                            Item = new AccountKeyInfo()
                            {
                                branchCode = request.Account[0].Item.BranchCode,
                                number = request.Account[0].Item.Number,
                                type = new ReferenceDataType()
                                {
                                    code=request.Account[0].Item.Type.Code
                                }
                            }
                        }
                    },
                    options = new AccountOptionsInfo()
                    {
                        showBalance = true,
                        showBalanceSpecified = true,
                        showCustomerRelation = true,
                        showAccountRelation = true,
                        showCustomerRelationSpecified = true,
                        showAccountRelationSpecified = true,
                        showTermInfo = true,
                    }
                };

                _logger.LogInformation(unique + " Outgoing message to MbyServiceAccess: {0}", JsonConvert.SerializeObject(_retrieveAccountInfo));

                retrieveAccountInfoResponse1 serviceResponse = null;

                Task service = Task.Run(async () =>
                {
                    serviceResponse = await _serviceClient.retrieveAccountInfoAsync(_retrieveAccountInfo);
                });

                service.Wait();
                _logger.LogInformation(unique + "Mby service response : {0}", JsonConvert.SerializeObject(serviceResponse));

                var response = serviceResponse.retrieveAccountInfoResponse.RetrieveAccountInfoResponseDTO.FirstOrDefault();

                _logger.LogInformation(unique + "Mby response : {0}", JsonConvert.SerializeObject(response));

                _retrieveAccountInfoResponse.Iban = response.idInfo.iban;

                _retrieveAccountInfoResponse.Balance = response.balance.balance.ToString();

                _retrieveAccountInfoResponse.AccountName = response.accountMetadata.name;

                _retrieveAccountInfoResponse.AccountId = response.idInfo.id;

                if (response.holders != null)
                    _retrieveAccountInfoResponse.CustomerNumber = response.holders.FirstOrDefault().customerNo.ToString();
                else
                    _retrieveAccountInfoResponse.CustomerNumber = "0";


                PrepareResponse("000", "Basarili", ref _retrieveAccountInfoResponse);

            }
            catch (FaultException<SystemFaultType> fe)
            {
                _logger.LogError(fe, unique + " Error on MbyServiceAccess service.");

                _logger.LogInformation(unique + " Incoming message from MbyServiceAccess: {0}", JsonConvert.SerializeObject(fe));

                PrepareResponse("053", fe.InnerException.Message, ref _retrieveAccountInfoResponse);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, unique + " Error on MbyServiceAccess service.");

                _logger.LogInformation(unique + " Incoming message from MbyServiceAccess: {0}", JsonConvert.SerializeObject(ex));

                PrepareResponse("053", ex.InnerException.Message, ref _retrieveAccountInfoResponse);
            }
            finally
            {
                if (_retrieveAccountInfoResponse.ResultCode == "000")
                {
                    _logger.LogInformation(unique + " Incoming message from MbyServiceAccess: {0}", JsonConvert.SerializeObject(_retrieveAccountInfoResponse));
                }
            }

            return _retrieveAccountInfoResponse;
        }

        private void PrepareResponse(string resultCode, string resultDescription, ref Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse retrieveAccountInfoResponse)
        {
            retrieveAccountInfoResponse.ResultCode = resultCode;

            retrieveAccountInfoResponse.ResultDescription = resultDescription;
        }
    }
}
