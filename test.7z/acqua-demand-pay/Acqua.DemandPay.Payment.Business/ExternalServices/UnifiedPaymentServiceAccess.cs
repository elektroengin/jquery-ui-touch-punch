﻿using Acqua.DemandPay.Payment.Business.ExternalServices.Contracts;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Configuration.UnifiedPaymentServiceV1;
using Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using UnifiedPaymentServiceV1;
using Amount = UnifiedPaymentServiceV1.Amount;
using CurrencyCode = UnifiedPaymentServiceV1.CurrencyCode;
using Acqua.DemandPay.Payment.Model.Models;

namespace Acqua.DemandPay.Payment.Business.ExternalServices
{
    public class UnifiedPaymentServiceAccess
    {
        private const string ConsumerContextTag = "headerv1:consumerContext";
        private const string SecurityContextTag = "Security";
        private const string IdempotencyContextTag = "idempotencyContext";
        private DemandPayPaymentConfiguration _config;
        private ILogAdapter Logger;

        public UnifiedPaymentServiceAccess(IOptions<DemandPayPaymentConfiguration> options, ILogAdapter logger)
        {
            _config = options.Value;
            Logger = logger;
        }

        private UnifiedPaymentServiceV1x2Client Initialize(RefundPaymentReq request)
        {
            BasicHttpBinding basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.None);

            EndpointAddress endpointAddress = new EndpointAddress(_config.unifiedPaymentServiceConfiguration.EndPointAddress);

            EndpointAddressBuilder endpointAddressBuilder = new EndpointAddressBuilder(endpointAddress);

            XmlObjectSerializer consumerSerializer = new SoaMessagingSerializer(typeof(UnifiedPaymentConsumerContext));

            UnifiedPaymentConsumerContext branchContextType = _config.unifiedPaymentServiceConfiguration.ConsumerContext;

            branchContextType.CustomerContext.Customer.CustomerNumber = request.CustomerNumber.ToString();

            branchContextType.CustomerContext.Customer.Name = string.Empty;

            AddressHeader consumerContext = AddressHeader.CreateAddressHeader(ConsumerContextTag, null, branchContextType, consumerSerializer);

            XmlObjectSerializer securitySerializer = new SoaMessagingSerializer(typeof(Security));

            Security security = _config.unifiedPaymentServiceConfiguration.Security;

            AddressHeader securityHeader = AddressHeader.CreateAddressHeader(SecurityContextTag, _config.unifiedPaymentServiceConfiguration.SecurityContextNameSpace, security, securitySerializer);

            XmlObjectSerializer idempotencySerializer = new SoaMessagingSerializer(typeof(IdempotencyContext));

            IdempotencyContext IdempotencyContextValues = new IdempotencyContext() { IdempotencyKey = request.IdempotencyKey }; //_config.unifiedPaymentServiceConfiguration.IdempotencyContext;

            AddressHeader idempotencyHeader = AddressHeader.CreateAddressHeader(IdempotencyContextTag, "http://isbank.com/Technical/EA/Header/Schema/V1", IdempotencyContextValues, idempotencySerializer);

            endpointAddressBuilder.Headers.Add(securityHeader);

            endpointAddressBuilder.Headers.Add(consumerContext);

            endpointAddressBuilder.Headers.Add(idempotencyHeader);

            UnifiedPaymentServiceV1x2Client _serviceClient = new UnifiedPaymentServiceV1x2Client(basicHttpBinding, endpointAddressBuilder.ToEndpointAddress());

            return _serviceClient;
        }

        public async Task<RefundPaymentRes> RefundPayment(RefundPaymentReq request)
        {
            RefundPaymentRes _refundPaymentResponse = new RefundPaymentRes();
            Logger.LogInformation(request.IdempotencyKey + " UnifiedPaymentServiceAccess -  Request: {0}", JsonConvert.SerializeObject(request));

            try
            {
                UnifiedPaymentServiceV1x2Client _serviceClient = Initialize(request);

                var refundPayment = new RefundPaymentRequest()
                {
                    RefId = request.RefId,
                    Description = request.Description,
                    ReasonCode = request.ReasonCode,
                    Amount = new Amount() { CurrencyCode = CurrencyCode.TRY, Quantity = request.Amount.Quantity, QuantitySpecified = true, CurrencyCodeSpecified = true },
                    RefundDetail = new RefundDetail() { RefundQRReferenceNumber = request.RefundDemandPayReferenceNumber }
                };

                Logger.LogInformation(request.IdempotencyKey + " Outgoing message to UnifiedPaymentServiceAccess: {0}", JsonConvert.SerializeObject(refundPayment));

                RefundPaymentResponse serviceResponse = await _serviceClient.refundPaymentAsync(refundPayment);

                _refundPaymentResponse.TransactionResult = serviceResponse.TransactionResult;

                _refundPaymentResponse.TransactionDateTime = serviceResponse.TransactionDateTime;

                PrepareResponse("000", "Basarili", ref _refundPaymentResponse);
            }
            //catch (FaultException<SystemFaultType> fe)
            //{
            //    Logger.Error(request.IdempotencyKey + " Error on UnifiedPaymentServiceAccess service.", fe);

            //    //PrepareResponse(fe.Detail.code, fe.Detail.description, ref _refundPaymentResponse);
            //}
            catch (Exception ex)
            {
                var json = JsonConvert.SerializeObject(ex);

                //if(string.IsNullOrEmpty(json))
                //    json = JsonConvert.SerializeObject(ex.Detail);

                var exception = JsonConvert.DeserializeObject<InnerException>(json);

                Logger.LogInformation(request.IdempotencyKey + " Error on UnifiedPaymentServiceAccess service: " + JsonConvert.SerializeObject(exception) + " Message:" + ex.Message.ToString());

                if (exception.Detail == null)
                {
                    PrepareResponse("SFR-PYMNT-99998", ex.Message + "(SSID: unknown)", ref _refundPaymentResponse);
                }
                else
                {
                    PrepareResponse(exception.Detail.Code, exception.Detail.Description + "(SSID: " + exception.Detail.SIID + ")", ref _refundPaymentResponse);
                }
            }
            finally
            {
                Logger.LogInformation(request.IdempotencyKey + " Incoming message from UnifiedPaymentServiceAccess: {0}", JsonConvert.SerializeObject(_refundPaymentResponse));
            }

            return await Task.FromResult(_refundPaymentResponse);
        }

        private void PrepareResponse(string resultCode, string resultDescription, ref RefundPaymentRes refundPaymentResponse)
        {
            refundPaymentResponse.ResultCode = resultCode;

            refundPaymentResponse.ResultDescription = resultDescription;
        }

        private static string GetXMLFromObject(object o)
        {
            StringWriter sw = new StringWriter();
            System.Xml.XmlTextWriter tw = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(o.GetType());
                tw = new System.Xml.XmlTextWriter(sw);
                serializer.Serialize(tw, o);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                sw.Close();
                if (tw != null)
                {
                    tw.Close();
                }
            }
            return sw.ToString();
        }
    }
}
