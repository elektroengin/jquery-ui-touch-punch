﻿namespace Acqua.DemandPay.Payment.Business.ExternalServices.Contracts
{
    public class RefundPaymentReq
    {
        public string RefId { get; set; }
        public Amount Amount { get; set; }
        public string Description { get; set; }
        public int ReasonCode { get; set; }
        public int CustomerNumber { get; set; }
        public string IdempotencyKey { get; set; }
        public string RefundDemandPayReferenceNumber { get; set; }
    }

    public class Amount
    {
        public CurrencyCode CurrencyCode { get; set; }
        public decimal Quantity { get; set; }
    }

    public enum CurrencyCode
    {

        /// <remarks/>
        UNSPECIFIED,

        /// <remarks/>
        TRY,

        /// <remarks/>
        EUR,

        /// <remarks/>
        USD,

        /// <remarks/>
        AUD,

        /// <remarks/>
        DKK,

        /// <remarks/>
        GBP,

        /// <remarks/>
        SEK,

        /// <remarks/>
        CHF,

        /// <remarks/>
        JPY,

        /// <remarks/>
        CAD,

        /// <remarks/>
        KWD,

        /// <remarks/>
        NOK,

        /// <remarks/>
        SAR,

        /// <remarks/>
        XAU,

        /// <remarks/>
        CNY,

        /// <remarks/>
        RUB,
    }
}
