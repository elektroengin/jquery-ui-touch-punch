﻿using System;

namespace Acqua.DemandPay.Payment.Business.ExternalServices.Contracts
{
    public class RefundPaymentRes
    {
        public string ResultCode { get; set; }
        public string ResultDescription { get; set; }
        public bool TransactionResult { get; set; }
        public DateTime TransactionDateTime { get; set; }
    }
}
