﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.ExternalServices;
using Acqua.DemandPay.Payment.Business.ExternalServices.Contracts;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts;
using Acqua.DemandPay.Payment.Business.ServiceCallers;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Models;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Oracle;
using Acqua.DemandPay.Payment.Repository.Services;
using Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Safir.Online.Authorizer.Domain.DomainService;
using Safir.Online.Authorizer.Domain.model.Transaction.ProcessPosMessage;
using Safir.Online.Authorizer.Interface;
using Safir.Online.Entity;
using Safir.Online.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static Grpc.Core.Metadata;

namespace Acqua.DemandPay.Payment.Business.Transaction
{
    public class FastTransaction
    {
        private readonly ITransactionService _transactionService;
        private readonly OtherServices _otherServices;
        private readonly IOnlineUnitOfWork _onlineUnitOfWork;
        private readonly UnifiedPaymentServiceAccess _unifiedPaymentServiceAccess;
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly AcquaOnlineEodProcessService _acquaOnlineEodService;
        private readonly ILogAdapter _logger;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        //private readonly DemandPayUtils _demandPayUtils;
        private readonly OracleRepository _oracleRepository;
        private readonly MbyServiceOperator _mbyServiceOperator;

        public FastTransaction(ITransactionService transactionService,
            IDemandPayPaymentService demandPayPaymentService,
            AcquaOnlineEodProcessService acquaOnlineEodService,
            OtherServices otherServices,
            IOnlineUnitOfWork onlineUnitOfWork,
            UnifiedPaymentServiceAccess unifiedPaymentServiceAccess,
            //DemandPayUtils demandPayUtils,
            OracleRepository oracleRepository,
            MbyServiceOperator mbyServiceOperator,
            ILogAdapter logger, IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration)
        {
            _transactionService = transactionService;
            _otherServices = otherServices;
            _acquaOnlineEodService = acquaOnlineEodService;
            _onlineUnitOfWork = onlineUnitOfWork;
            //_demandPayUtils = demandPayUtils;
            _logger = logger;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
            _demandPayPaymentService = demandPayPaymentService;
            _unifiedPaymentServiceAccess = unifiedPaymentServiceAccess;
            _oracleRepository = oracleRepository;
            _mbyServiceOperator = mbyServiceOperator;
        }

        /// <summary>
        /// MBY Servisinden Müşteri bilgilerinin alınması
        /// </summary>
        /// <param name="branchCode"></param>
        /// <param name="number"></param>
        /// <param name="code"></param>
        /// <param name="unique"></param>
        /// <returns></returns>
        public ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse GetAccountInfo(int branchCode, int number, string code, string unique)
        {

            var request = new RetrieveAccountInfoRequest()
            {
                Account = new ExternalServices.Mby.Contracts.AccountIdentityInfo[]
                {
                        new ExternalServices.Mby.Contracts.AccountIdentityInfo()
                        {
                            Item = new ExternalServices.Mby.Contracts.AccountKeyInfo()
                            {
                                BranchCode = branchCode,
                                Number = number,
                                Type = new ExternalServices.Mby.Contracts.ReferenceDataType()
                                {
                                    Code = code
                                }
                            }
                        }
                },
                Options = new ExternalServices.Mby.Contracts.AccountOptionsInfo()
                {
                    ShowBalance = true,
                    ShowBalanceSpecified = true,
                    ShowCustomerRelation = true,
                    ShowAccountRelation = true,
                    ShowCustomerRelationSpecified = true,
                    ShowAccountRelationSpecified = true,
                    ShowTermInfo = true,
                }
            };

            var response = _mbyServiceOperator.RetrieveAccountInfo(request, unique);

            return response;

        }

        public async Task<ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse> FindMbyMerchantIBAN(string merchantNumber, string unique)
        {
            ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse accountInfo = null;

            var mrcAccInfo = new MrcAccInfo()
            {
                InsCode = '1',
                MrcNo = Convert.ToInt64(merchantNumber),
                AccType = 'Q',
                SeqNo = 1,
                CurrCode = 949,
                CommId = -1
            };

            var accInfo = _oracleRepository.GetMrcAccountNumber(mrcAccInfo, _logger, unique);

            _logger.LogInformation(unique + " FastTransaction => GetMrcAccountNumber => " + JsonConvert.SerializeObject(accInfo));


            if (accInfo != null && accInfo.ErrorCode == "00000")
            {
                accountInfo = GetAccountInfo(int.Parse(accInfo.AccNo.Substring(0, 4)), int.Parse(accInfo.AccNo.Substring(4)), "DEMAND", unique);

                _logger.LogInformation(unique + " GetMrcAccountNumber => " + JsonConvert.SerializeObject(accountInfo));
            }

            return await Task.FromResult(accountInfo);
        }

        public async Task<PosTrnxInfoResponse> AddFastTransaction(DemandPayTrnxInfo demandDetails, string unique, bool isPayment = false)
        {
            PosTrnxInfo posTrnxInfo =  new PosTrnxInfo();
            PosTrnxDetailInfo posTrnxDetailInfo = new PosTrnxDetailInfo();
            PosTrnxInfoResponse posTrnxInfoResponse = new PosTrnxInfoResponse();

            try
            {
                _logger.LogInformation(unique + " AddFastTransaction");

                string origF37 = "_";
                string referenceNumber = string.Empty;
                string trnxType = "N";

                if (demandDetails.PaymentType == "Sale")
                {
                    referenceNumber = _otherServices.GenerateRRN();
                }
                else if (demandDetails.PaymentType == "Cancel")
                {
                    referenceNumber = demandDetails.Rrn;
                    //trnxType = "V";
                }
                else if (demandDetails.PaymentType == "Refund")
                {
                    referenceNumber = _otherServices.GenerateRRN();

                    origF37 = demandDetails.Rrn;
                }

                string pCode = string.Empty;

                var source = demandDetails.TransactionType == (int)TransactionType.Havale ? "O" : "D";

                var terminalNumber = demandDetails.TerminalNumber;

                //ToDo: Refund eklenecek

                if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Sale")
                {
                    pCode = "109700";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Refund")
                {
                    pCode = "109750";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Fast) && demandDetails.PaymentType == "Cancel")
                {
                    pCode = "109700";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Sale")
                {
                    pCode = "109701";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Refund")
                {
                    pCode = "109702";
                }
                else if (demandDetails.TransactionType == ((int)TransactionType.Havale) && demandDetails.PaymentType == "Cancel")
                {
                    pCode = "109701";
                }

                //// FAST EFT Satis = 109700, FAST EFT Iade = 109750, FAST Havale Satis = 109701, FAST Havale Iade = 109702

                var processPosMessageRequest = new ProcessPosMessageRequest()
                {
                    Amount = demandDetails.Amount,
                    CurrencyCode = long.Parse("949"),
                    DebitCreditInd = "D",
                    IsFinancial = true,
                    MerchantNumber = demandDetails.MerchantNumber,
                    Pcode = long.Parse(pCode),
                    SeqNo = 1,
                    UseDefaultSeqNo = false,
                    Source = source,
                    TerminalType = "POS",
                    MxmMobilePaymentType = null,
                    TerminalNumber = terminalNumber,
                    Mti = demandDetails.IsReversal == (int)Answer.Yes ? 400 : 200
                };

                var processPosMessageResponse = _transactionService.ProcessPosMessage(processPosMessageRequest, unique);

                if (demandDetails.PaymentType == "Sale")
                {
                    origF37 = "_";
                }

                posTrnxInfo = new PosTrnxInfo();
                posTrnxInfo.InsCode = "1";
                posTrnxInfo.F42 = processPosMessageRequest.MerchantNumber;
                posTrnxInfo.TermId = processPosMessageRequest.TerminalNumber;
                posTrnxInfo.BatchNo = processPosMessageResponse.Terminal_BatchNo;
                posTrnxInfo.MsgType = demandDetails.IsReversal == (int)Answer.Yes ? 400 : 200;
                posTrnxInfo.TrnxCode = processPosMessageResponse.PcodeTrnxRel_TrnxCode;
                posTrnxInfo.TrnxSubCode = processPosMessageResponse.PcodeTrnxRel_TrnxSubCode;
                posTrnxInfo.F2 = "1111111111111111";
                posTrnxInfo.F3 = processPosMessageRequest.Pcode;
                posTrnxInfo.F4 = processPosMessageRequest.Amount;
                posTrnxInfo.OutF4 = processPosMessageRequest.Amount;
                posTrnxInfo.OutF6 = processPosMessageRequest.Amount;
                posTrnxInfo.F11 = 0;
                posTrnxInfo.SeqNo = long.Parse(referenceNumber.Substring(6, 6));
                posTrnxInfo.SequenceNo = 1; //Bölüm Bilgisi
                posTrnxInfo.F37 = referenceNumber;
                //posTrnxInfo.MrcLoyaltyGroupCommId = source == "O" ? DemandPayUtils.ConvertToDecimal(processPosMessageResponse.LoyaltyCommissionInfo_CommId) : -1;
                //posTrnxInfo.MrcLoyaltyGroupCode = source == "O" ? DemandPayUtils.ConvertToDecimal(processPosMessageResponse.LoyaltyCommissionInfo_GroupCode) : -1;
                //posTrnxInfo.MrcCommId = source == "D" ? DemandPayUtils.ConvertToDecimal(processPosMessageResponse.ComissionInfo_CommId) : -1;
                //posTrnxInfo.MrcCommGroupCode = source == "D" ? DemandPayUtils.ConvertToDecimal(processPosMessageResponse.ComissionInfo_GroupCode) : -1;
                //posTrnxInfo.TrnxType = demandDetails.IsReversal == (int)Answer.Yes ? "R" : trnxType; //satış ve iade için N, iptal için V, reversal için R olmalıdır  //2792
                posTrnxInfo.TrnxSign = processPosMessageResponse.TrnxSign;
                posTrnxInfo.Status = "N";
                posTrnxInfo.OrigF37 = origF37;
                //posTrnxInfo.OrigF37 = !string.IsNullOrEmpty(demandDetails.ORIGINAL_SALES_RRN) ? _repository.GetQrDetailsByRRN(new BkmQrTrnx() { RRN = qrDetails.ORIGINAL_SALES_RRN, ACQUIRER_ID = _bkmQrConfiguration.TrQrConfiguration.KarekodUreticiKodu }, _logger, unique).QR_REFERENCE_NUMBER : "_", 
                posTrnxInfo.ReverseFlag = "_";
                posTrnxInfo.VoidFlag = "_";
                posTrnxInfo.AutoRefundFlag = "_";
                posTrnxInfo.RefundedAmnt = 0;
                posTrnxInfo.F39Auth = "_";
                posTrnxInfo.F39 = "00";
                posTrnxInfo.AcqTrnxGroupCode = processPosMessageResponse.AcqTrnxGroupCode;
                posTrnxInfo.TermType = processPosMessageResponse.TermType;
                posTrnxInfo.ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd"));
                posTrnxInfo.ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss"));
                posTrnxInfo.SourceOrigFui = "SFSTR";
                posTrnxInfo.SourceFui = "SFSTR";
                posTrnxInfo.Dest = "FS";
                posTrnxInfo.DestFui = "SFST";
                posTrnxInfo.DestOrigFui = "FS";
                posTrnxInfo.Source = source;
                posTrnxInfo.Mcc = processPosMessageResponse.Mcc;
                posTrnxInfo.PosTermCap = "8";
                posTrnxInfo.TrnxSource = "P";
                posTrnxInfo.ProcessIdClr = 25;
                posTrnxInfo.Brand = "F";
                posTrnxInfo.DebitCreditInd = "D";
                posTrnxInfo.MrcMaximumFlag = processPosMessageResponse.MaximumFlag;
                posTrnxInfo.TrnxGroupCode = processPosMessageResponse.TrnxGroupCode;
                //posTrnxInfo.IssBankCode = Utils.ConvertToDecimal(demandDetails.ACQUIRER_ID.Substring(2, 2)),
                posTrnxInfo.F49 = processPosMessageRequest.CurrencyCode;
                posTrnxInfo.OutF49 = processPosMessageRequest.CurrencyCode;
                posTrnxInfo.SuppliesCode = -1;
                posTrnxInfo.SubscriberNo = "_";
                posTrnxInfo.FraudFlag = "N";
                posTrnxInfo.TargetCardId = "_";
                posTrnxInfo.Version = "_";
                //posTrnxInfo.FastTransactionId = demandDetails.PAYMENT_METHOD == (int)PaymentMethod.FAST ? Utils.CreateRelatedFastMessage(qrDetails) : "_",
                posTrnxInfo.OrigTrnxApproved = demandDetails.IsReversal == (int)Answer.Yes ? "Y" : "N";
                posTrnxInfo.F22PosEntryMode = 3;
                posTrnxInfo.F22PinEntryMode = 0;

                posTrnxDetailInfo = new PosTrnxDetailInfo()
                {
                    F37 = referenceNumber,
                    EodType = "S", //Synchronous = "S", Asynchronous = "A"
                    TrnxType = posTrnxInfo.TrnxType,
                    ProcessDate = posTrnxInfo.ProcessDate,
                    BatchSource = source,
                    ThyDuIban = demandDetails.MerchantAccIBAN,
                    IsFastTrnx = "Y"
                };

                //ToDo : Tek noktada toplantı burası kritik

                //await _demandPayPaymentService.Create(demandDetails);

                using (var scope = _onlineUnitOfWork.BeginScope())
                {
                    MerchantSequenceRelation merchantSequenceRelation = _onlineUnitOfWork.NonTrackingContainer.MerchantSequenceRelation.Get(x => x.InsCode == "1"
                    && x.MrcNo == demandDetails.MerchantNumber && x.SeqNo == posTrnxInfo.SequenceNo).FirstOrDefault();
                    posTrnxInfo.MainStoreNo = merchantSequenceRelation.MainStoreNo;

                    if (posTrnxInfo.MsgType == 400) //eğer iptali gelmişse orjinal işlemin statusunu R ye çek
                    {
                        var origPosTrnxInfo = _onlineUnitOfWork.NonTrackingContainer.PosTrnxInfoRepository.Get(a => a.InsCode == "1" && a.ProcessDate == posTrnxInfo.ProcessDate && a.TrnxType == "N" && a.F37 == posTrnxInfo.F37 && a.MsgType == 200 && a.TrnxCode == "05").FirstOrDefault();
                        if (origPosTrnxInfo != null)
                        {
                            origPosTrnxInfo.Status = "R";
                            _onlineUnitOfWork.NonTrackingContainer.PosTrnxInfoRepository.Update(origPosTrnxInfo);
                            _onlineUnitOfWork.Save(scope.ScopedContextId);

                        }
                    }
                }

                using (var scope = _onlineUnitOfWork.BeginScope())
                {
                    _onlineUnitOfWork.NonTrackingContainer.PosTrnxInfoRepository.Create(posTrnxInfo);
                    _onlineUnitOfWork.NonTrackingContainer.PosTrnxDetailInfoRepository.Create(posTrnxDetailInfo);
                    _onlineUnitOfWork.Save(scope.ScopedContextId);
                }

                //FraudStarIntegration(posTrnxInfo, posTrnxDetailInfo, demandDetails);

                //Günsonu Servisi
                var acquaOnlineEodServiceResponse = await CallAcquaOnlineEodServiceIntefrationAsync(posTrnxInfo, demandDetails);

                //NULL kontrolü eklenecek
                if (acquaOnlineEodServiceResponse != null)
                {
                    posTrnxInfoResponse.ServiceType = "EOD";
                    posTrnxInfoResponse.ResponseCode = acquaOnlineEodServiceResponse.ResponseCode;
                    posTrnxInfoResponse.ResponseMessage = acquaOnlineEodServiceResponse.ResponseMessage;
                    posTrnxInfoResponse.ServiceOperation = (int)ServiceOperation.EodSuspan;
                }
                else
                {
                    posTrnxInfoResponse.ServiceType = "TO";
                    posTrnxInfoResponse.ResponseCode = "053";
                    posTrnxInfoResponse.ResponseMessage = "EOD Service : The request was canceled due to the configured HttpClient.Timeout of 10 seconds elapsing";
                    posTrnxInfoResponse.ServiceOperation = (int)ServiceOperation.EodSuspan;
                }
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Timeout: Request cancelled after timeout periaod", ex);

                posTrnxInfoResponse.ResponseCode = "SF";
                posTrnxInfoResponse.ResponseMessage = "Fast Transaction Timeout: Request cancelled after timeout periaod";
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (TimeoutException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Timeout excepiton", ex);

                posTrnxInfoResponse.ResponseCode = "SF";
                posTrnxInfoResponse.ResponseMessage = "Fast Transaction Timeout excepiton";
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError($"{unique} - Fast Transaction Operation Cancelled", ex);

                posTrnxInfoResponse.ResponseCode = "SF";
                posTrnxInfoResponse.ResponseMessage = ex.Message;
                posTrnxInfo = new PosTrnxInfo { F39 = "91" }; //ISO 8853 Timeout
            }
            catch (Exception ex)
            {
                _logger.LogError(unique + " FastTransaction Exception: ", ex);

                posTrnxInfoResponse.ResponseCode = "SF";
                posTrnxInfoResponse.ResponseMessage = ex.Message;
                posTrnxInfo = new PosTrnxInfo() { F39 = "SF" };
            }
            finally 
            {
                FraudStarIntegration(posTrnxInfo, posTrnxDetailInfo, demandDetails, posTrnxInfoResponse);
            }

            posTrnxInfoResponse.PosTrnxInfo = posTrnxInfo;

            return await Task.FromResult(posTrnxInfoResponse);
        }

        private void FraudStarIntegration(PosTrnxInfo posTrnxInfo, PosTrnxDetailInfo posTrnxDetailInfo, DemandPayTrnxInfo demandPayTrnxInfos, PosTrnxInfoResponse posTrnxInfoResponse)
        {
            DemandPayUtils.ConvertToNull<PosTrnxInfo>(posTrnxInfo);

            DemandPayUtils.ConvertToNull<PosTrnxDetailInfo>(posTrnxDetailInfo);

            demandPayTrnxInfos.Rrn = posTrnxInfo.F37;

            demandPayTrnxInfos.PosTrnxInfo = JsonConvert.SerializeObject(posTrnxInfo, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            demandPayTrnxInfos.PosTrnxDetailInfo = JsonConvert.SerializeObject(posTrnxDetailInfo, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            //SORU-1: IsConsumed iptal ve iade de başarılı ise setlenecekmi
            //SORU-2: Günsonu servisinden sonra hata dönerse IsConsumed ne değeri ile setlenecek
            //SORU-3: Satış işlemi başarılı günsonu servisinden hata aldı satış işlemine iptal gönderilecek (yada reversal mı yapılacak)
            //        IsConsumed ne olacak? 
            //SORU-4: Merchant tablosuna Permissions string alanı eklenecek
            if (posTrnxInfo.F39 == "00")
            {
                demandPayTrnxInfos.IsConsumed = 1;
            }
            else
            {
                demandPayTrnxInfos.ResultStatus = posTrnxInfo.F39;
                demandPayTrnxInfos.ResultDescription = "FastTransaction Exception";
                demandPayTrnxInfos.DemandPaymentResponse = JsonConvert.SerializeObject(posTrnxInfoResponse, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
                demandPayTrnxInfos.IsConsumed = 0;
            }

            if (demandPayTrnxInfos.PaymentType.ToLower() == "refund" || demandPayTrnxInfos.PaymentType.ToLower() == "cancel")
            {
                demandPayTrnxInfos.RefundInformPosTime = DateTime.Now;
            }

            var result = _demandPayPaymentService.UpdateDemandPayToPosTrnxAndDetails(demandPayTrnxInfos);
        }

        public async Task<AcquaOnlineEodServiceResponse> CallAcquaOnlineEodServiceIntefrationAsync(PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandDetails)
        {
            AcquaOnlineEodServiceResponse acquaOnlineEodServiceResponse = new AcquaOnlineEodServiceResponse();
            //Günsonu servisi Süspan
            AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest = new AcquaOnlineEodServiceRequest();
            acquaOnlineEodServiceRequest.System_Entry_Date = posTrnxInfo.ProcessDate.ToString();
            acquaOnlineEodServiceRequest.Trnx_Code = posTrnxInfo.TrnxCode;
            acquaOnlineEodServiceRequest.F42 = posTrnxInfo.F42.ToString();
            acquaOnlineEodServiceRequest.F37 = posTrnxInfo.F37;

            acquaOnlineEodServiceResponse = await _acquaOnlineEodService.Process(acquaOnlineEodServiceRequest, posTrnxInfo, demandDetails);


            //if (acquaOnlineEodServiceResponse.ResponseCode == "00000")
            //{
            //    SaveEodSuspanLogSave(posTrnxInfo, demandDetails, acquaOnlineEodServiceRequest, acquaOnlineEodServiceResponse);
            //}

            return acquaOnlineEodServiceResponse;
        }

        public async Task<RefundPaymentRes> CallRefundPaymentService(                   
                   string referenceNumber,
                   decimal amount,
                   string refundDescription,
                   string merchantNo,
                   string paymentId,
                   string merchantCustomerNo,
                   string unique,
                   ServiceOperation serviceOperation,
                   string trnxCode = "_")
        {
            try
            {
                var retriableErrorCodes = DemandPaymentConstants.GetRetriableErrorCodes();

                var retryCount = 0;

                var adviceStatus = -1;

                RefundPaymentReq refundPaymentReq = new RefundPaymentReq();

                var mrcBatchInfo = _onlineUnitOfWork.NonTrackingContainer.MrcBatchInfoRepository.Get(x => x.InsCode == "1"
                    && x.MrcNo == Convert.ToDecimal(merchantNo)).FirstOrDefault();

                refundPaymentReq = new RefundPaymentReq()
                {
                    RefId = paymentId,
                    Description = refundDescription,
                    ReasonCode = 99,
                    Amount = new Amount() { CurrencyCode = CurrencyCode.TRY, Quantity = amount },
                    CustomerNumber = (!string.IsNullOrEmpty(merchantCustomerNo) && merchantCustomerNo != "_" && merchantCustomerNo != "0")
                    ? int.Parse(merchantCustomerNo)
                    : int.Parse(mrcBatchInfo.BankingCustNo.ToString()),
                    IdempotencyKey = unique,
                    RefundDemandPayReferenceNumber = referenceNumber
                };


                _logger.LogInformation(refundPaymentReq.IdempotencyKey + " refundPaymentReq => " + JsonConvert.SerializeObject(refundPaymentReq));

                RefundPaymentRes response = new RefundPaymentRes();

                if (refundPaymentReq.Amount.Quantity == (decimal)0.20 || refundPaymentReq.Amount.Quantity == (decimal)0.21 || refundPaymentReq.Amount.Quantity == (decimal)0.22 || refundPaymentReq.Amount.Quantity == (decimal)6.20 || refundPaymentReq.Amount.Quantity == (decimal)67.01 || refundPaymentReq.Amount.Quantity == (decimal)67.02 || refundPaymentReq.Amount.Quantity == (decimal)67.04 || refundPaymentReq.Amount.Quantity == (decimal)67.06 || refundPaymentReq.Amount.Quantity == (decimal)67.07)
                {
                    response = new RefundPaymentRes()
                    {
                        ResultCode = refundPaymentReq.Amount.Quantity == (decimal)0.20 ? "PYMNT-45008" : refundPaymentReq.Amount.Quantity == (decimal)0.21 ? "PYMNT-45010" : refundPaymentReq.Amount.Quantity == (decimal)0.22 ? "SFR-PYMNT-99998" : refundPaymentReq.Amount.Quantity == (decimal)0.23 ? "SFR-PYMNT-99998" : refundPaymentReq.Amount.Quantity == (decimal)6.20 ? "PYMNT-45029"
                        : refundPaymentReq.Amount.Quantity == (decimal)67.01 ? "PYMNT-45010" : refundPaymentReq.Amount.Quantity == (decimal)67.02 ? "PYMNT-45008" : refundPaymentReq.Amount.Quantity == (decimal)67.04 ? "PYMNT-30024" : refundPaymentReq.Amount.Quantity == (decimal)67.06 ? "PYMNT-30024" : refundPaymentReq.Amount.Quantity == (decimal)67.07 ? "SFR-PYMNT-99998" : "000"
                    };
                }
                else
                {
                    response = await _unifiedPaymentServiceAccess.RefundPayment(refundPaymentReq);
                }

                _logger.LogInformation(refundPaymentReq.IdempotencyKey + " refundPaymentresponse => " + JsonConvert.SerializeObject(response));

                return response;
            }
            finally
            {

            }
        }
        

        //public async Task SaveEodSuspanLogSave(PosTrnxInfo posTrnxInfo, DemandPayTrnxInfo demandPayTrnxInfo, AcquaOnlineEodServiceRequest acquaOnlineEodServiceRequest,AcquaOnlineEodServiceResponse response)
        //{
        //    var errorEntity = new DemandPayTrnxInfo()
        //    {
        //        ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //        ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //        ADPTrnxId = "ADP" + demandPayTrnxInfo.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
        //        MrcADPRefNo = demandPayTrnxInfo.MrcADPRefNo,
        //        MerchantNumber = Convert.ToInt64(demandPayTrnxInfo.MerchantNumber),
        //        TerminalNumber = posTrnxInfo.TermId,
        //        TransactionType = demandPayTrnxInfo?.TransactionType ?? 0,
        //        Amount = posTrnxInfo.F4,
        //        CurrCode = 949,
        //        ExpiredDate = demandPayTrnxInfo?.ExpiredDate ?? DateTime.Now,
        //        DelayPayFlag = 0,
        //        EarlyPayFlag = 0,
        //        PartialPayFlag = 0,
        //        IsSuspension = 0,
        //        MerchantAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
        //        MerchantAccIBAN = demandPayTrnxInfo?.MerchantAccIBAN,
        //        CustomerAccHold = demandPayTrnxInfo?.MerchantAccHold ?? "_",
        //        CustomerAccIBAN = demandPayTrnxInfo?.CustomerAccIBAN ?? "_",
        //        Rrn = "_",
        //        EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
        //        EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
        //        ServiceOperation = (int)ServiceOperation.EodSuspan,
        //        ResultStatus = !string.IsNullOrEmpty(response.ResponseCode) ? response.ResponseCode : "_",
        //        ResultDescription = $"Error: {response.ResponseMessage}",
        //        DemandPaymentRequest = JsonConvert.SerializeObject(acquaOnlineEodServiceRequest, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //        DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
        //        QueryId = demandPayTrnxInfo.QueryId ?? "_",
        //        PaymentId = demandPayTrnxInfo.PaymentId ?? "_",
        //        FastDescription = demandPayTrnxInfo.FastDescription ?? $"Hata - Ref:{posTrnxInfo.F37}",
        //        PaymentType = demandPayTrnxInfo.PaymentType ?? "unknown",
        //        IsReversal = 0,
        //        Orig_Rrn = "_"
        //    };

        //    await _demandPayPaymentService.Create(errorEntity);
        //}

    }
}
