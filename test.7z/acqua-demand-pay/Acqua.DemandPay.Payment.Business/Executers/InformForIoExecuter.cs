﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.Common;
using Acqua.DemandPay.Payment.Business.ExternalServices.Contracts;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts;
using Acqua.DemandPay.Payment.Business.Factories;
using Acqua.DemandPay.Payment.Business.ServiceCallers;
using Acqua.DemandPay.Payment.Business.ServiceValidation;
using Acqua.DemandPay.Payment.Business.Transaction;
using Acqua.DemandPay.Payment.Business.Validator;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Core.CustomException;
using Acqua.DemandPay.Payment.Core.Validation;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using Acqua.DemandPay.Payment.Model.Response;
using Acqua.DemandPay.Payment.Repository.Services;
using Confluent.Kafka;
using corf.Core.Messaging;
using FluentValidation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Safir.Online.Authorizer.Interface;
using Safir.Online.Entity;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Executers
{
    public class InformForIoExecuter : BaseExecuter
    {
        private readonly IDemandPayPaymentService _demandPayPaymentService;
        private readonly ITransactionService _transactionService;
        private readonly IWorkplaceValidationService _validationService;
        private readonly IResponseFactory _responseFactory;
        private readonly FastTransaction _fastTransaction;
        private readonly DemandPayUtils _demandPayUtils;
        private readonly DemandPayPaymentConfiguration _demandPayPaymentConfiguration;

        public InformForIoExecuter(ILogger<CreateWorkplaceInfoRecordExecuter> logger,
             IDemandPayPaymentService demandPayPaymentService,
             ITransactionService transactionService,
             IWorkplaceValidationService validationService,
             IResponseFactory responseFactory,
             FastTransaction fastTransaction,
             DemandPayUtils demandPayUtils,
             AcquaOnlineEodProcessService acquaOnlineEodService,
             IOptions<DemandPayPaymentConfiguration> demandPayPaymentConfiguration) : base(logger, demandPayPaymentConfiguration)
        {
            _demandPayPaymentService = demandPayPaymentService;
            _transactionService = transactionService;
            _validationService = validationService;
            _responseFactory = responseFactory;
            _fastTransaction = fastTransaction;
            _demandPayUtils = demandPayUtils;
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration.Value;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            Logger.LogInformation(message.Unique, $"Incoming Message", $"{message.InnerMessage}");

            InformForIoResponse response = new InformForIoResponse();
            InformForIoRequest request = JsonConvert.DeserializeObject<InformForIoRequest>(message.InnerMessage);

            Logger.LogInformation($"{message.Unique} - InformForIoRequest Data successfully deserialized");
            Logger.LogInformation($"{message.Unique} - InformForIoRequest deserialized message {JsonConvert.SerializeObject(request)}");

            var fastTransactionResponse = new PosTrnxInfo();

            try
            {
                switch (request.PaymentType?.ToLower())
                {
                    case "sale":
                        response = await ProcessSaleTransaction(request, message.Unique);
                        break;
                    case "reversal":
                        response = await ProcessReversalTransaction(request, message.Unique);
                        break;
                    case "refund":
                        response = await ProcessRefundTransaction(request, message.Unique);
                        break;
                    default:
                        Logger.LogWarning($"{message.Unique} - Unknown PaymentType:{request.PaymentType}");
                        response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString(), "Geçersiz Ödeme tipi");
                        break;
                }
            }
            catch (Exception ex)
            {
                response = _responseFactory.CreateInformForIoResponse("020", string.Empty);
                Logger.LogError(ex, $"{message.Unique} - General Error Exception Message :{ex.Message}");
            }

            message.InnerMessage = JsonConvert.SerializeObject(response);
            return await Task.FromResult(message);
        }

        /// <summary>
        /// Sale(Satış) işlemini işler - Trnx Code : 05
        /// </summary>
        /// <param name="request"></param>
        /// <param name="uniqueId"></param>
        /// <returns></returns>
        private async Task<InformForIoResponse> ProcessSaleTransaction(InformForIoRequest request, string uniqueId)
        {
            InformForIoResponse response = new InformForIoResponse();
            PosTrnxInfoResponse fastTransactionResponse = new PosTrnxInfoResponse();

            string merchantCustomerNumber = string.Empty;

            try
            {
                if (request.IsSuspension == "1")
                {
                    response = _responseFactory.CreateInformForIoResponse("000", string.Empty);

                    var getDemandPayTrnxInfoDetail = _demandPayPaymentService.GetDemandPayTrnxInfoDetail(request.MerchantNumber, request.MrcADPRefNo, "000");

                    if (getDemandPayTrnxInfoDetail != null)
                    {
                        if (getDemandPayTrnxInfoDetail.MerchantAccIBAN.Equals(request.Iban))
                        {                            
                            if (getDemandPayTrnxInfoDetail.TransactionType == (int)TransactionType.Fast)
                            {
                                //MBY servisinden AccountInfo->MerchantCustomerNumber verisi çekilecek.
                                RetrieveAccountInfoResponse accountInfo = await _fastTransaction.FindMbyMerchantIBAN(request.MerchantNumber, uniqueId);

                                if (accountInfo.ResultCode == "000")
                                {
                                    merchantCustomerNumber = accountInfo.CustomerNumber;
                                }
                                else
                                {
                                    //MBY servisinden hata alınırsa akışa deavm edilecek mi ? Akış nasıl olacak
                                }
                            }

                            DemandPayTrnxInfo demandPayTrnxInfo = new DemandPayTrnxInfo()
                            {
                                ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                                ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                                ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                                MrcADPRefNo = request.MrcADPRefNo,
                                MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                                TerminalNumber = getDemandPayTrnxInfoDetail.TerminalNumber,
                                TransactionType = Convert.ToInt16(getDemandPayTrnxInfoDetail.TransactionType),
                                Amount = Convert.ToDecimal(getDemandPayTrnxInfoDetail.Amount) / 100,
                                CurrCode = 949,
                                ExpiredDate = getDemandPayTrnxInfoDetail.ExpiredDate,
                                DelayPayFlag = 0,//data.DelayPayFlag,
                                EarlyPayFlag = 0,//data.EarlyPayFlag,
                                PartialPayFlag = 0,//data.PartialPayFlag,
                                IsSuspension = 0,
                                MerchantAccHold = "_",
                                MerchantAccIBAN = request.Iban,
                                CustomerAccHold = "_",
                                CustomerAccIBAN = "_",
                                Rrn = "_",
                                EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                                EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                                ServiceOperation = (int)ServiceOperation.InformForOi,
                                ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                                ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                                DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                                DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                                QueryId = request.QueryId,
                                PaymentId = request.PaymentId,
                                FastDescription = request.FastDescription,
                                PaymentType = request.PaymentType,
                                IsReversal = 0,
                                Orig_Rrn = "_",
                                MerchantCustomerNumber = !string.IsNullOrEmpty(merchantCustomerNumber) ? merchantCustomerNumber : "_",
                            };

                            //ToDo: Gelen Inform Mesajını kaydet
                            await _demandPayPaymentService.Create(demandPayTrnxInfo);

                            //ToDo: Günsonu süspan servisinden reponse code : başarılı kodu nedir
                            fastTransactionResponse = await _demandPayUtils.MakeAuthorization(demandPayTrnxInfo, _fastTransaction, uniqueId, true);

                            if (fastTransactionResponse != null
                                && fastTransactionResponse.PosTrnxInfo != null
                                && !string.IsNullOrEmpty(fastTransactionResponse.PosTrnxInfo.F39)
                                && fastTransactionResponse.PosTrnxInfo.F39 == "00"
                                && fastTransactionResponse.ResponseCode == "00000")
                            {
                                response.ReferenceNumber = fastTransactionResponse.PosTrnxInfo.F37;
                                response.IsSuccess = true;
                                Logger.LogInformation($"{uniqueId} - Sale transaction completed successfully");
                            }
                            else if (fastTransactionResponse != null)
                            {                                                             
                                //var cancelResponse = await ProcessCancelTransaction(request, uniqueId);

                                response.ReferenceNumber = fastTransactionResponse.PosTrnxInfo.F37;
                                response.ResultCode =  fastTransactionResponse.ResponseCode;
                                response.ResultDescription = fastTransactionResponse.ResponseMessage;
                                response.IsSuccess = false;
                            }
                        }
                        else
                        {
                            response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.InformIbanToMerchantAccIBANBeValidIban.GetHashCode().ToString(), string.Empty);
                        }
                    }
                    else
                    {
                        response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.DemandPayTrnxInfoDetailDataNotFound.GetHashCode().ToString(), string.Empty);
                    }
                }
                else
                {
                    response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString(), "IsSuspension değeri geçersiz.");
                }
            }
            catch (Exception ex)
            {
                response = _responseFactory.CreateInformForIoResponse("020", "Satış işlemi sırasında hata oluştu.");
                Logger.LogError(ex, $"{uniqueId} - Error during sale transaction processing: {ex.Message}");

                //Hata durumunu veritabanına kaydet
                await SaveInformForIoError(request, response, ex, uniqueId, request.PaymentType, fastTransactionResponse);
            }

            //if (response.ResultCode != "000")
            //{
            //    await SaveInformForIoError(request, response, new Exception(response.ResultDescription), uniqueId, request.PaymentType, fastTransactionResponse);
            //    return response;
            //}

            return response;
        }

        /// <summary>
        /// Cancel(İptal) işlemini işler - Trnx Code : 25
        /// </summary>
        /// <param name="request"></param>
        /// <param name="uniqueId"></param>
        /// <returns></returns>
        private async Task<InformForIoResponse> ProcessReversalTransaction(InformForIoRequest request, string uniqueId)
        {
            InformForIoResponse response = new InformForIoResponse();
            PosTrnxInfoResponse fastTransactionResponse = new PosTrnxInfoResponse();

            Logger.LogInformation($"{uniqueId} - Processing Cancel Transaction for ReferenceNumber:{request.ReferenceNumber}");

            //ReferenceNumber kontrolü
            if (string.IsNullOrEmpty(request.ReferenceNumber))
            {
                Logger.LogInformation($"{uniqueId} - Cancel işlemi için ReferenceNumber boş olamaz");
                response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.ReferenceNumberCannotBeNull.GetHashCode().ToString(), "İptal edilecek işlem reference numarası bulunamadı");

                await SaveInformForIoError(request, response, new Exception("ReferenceNumber is null or empty"), uniqueId, request.PaymentType, fastTransactionResponse);

                return response;
            }

            //orjinal satış işlemini bul
            var originalTransaction = await _demandPayPaymentService.GetOriginalTransactionByReferenceNumber(request.ReferenceNumber, request.MerchantNumber, request.MrcADPRefNo);

            if (originalTransaction == null)
            {
                Logger.LogInformation($"{uniqueId} - Original transaction not found ReferenceNumber: {request.ReferenceNumber}");
                response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.OriginalTransactionNotFound.GetHashCode().ToString(), "İptal edilecek orijinal işlem bulunamadı");

                await SaveInformForIoError(request, response, new Exception("ReferenceNumber is null or empty"), uniqueId, request.PaymentType, fastTransactionResponse);

                return response;
            }

            Logger.LogWarning($"{uniqueId} - Original transaction found. ADPTrnxId: {originalTransaction.ADPTrnxId}, Amount: {originalTransaction.Amount}, ReferenceNumber:{request.ReferenceNumber}");

            response = _responseFactory.CreateInformForIoResponse("000", string.Empty);

            DemandPayTrnxInfo demandPayTrnxInfo = new DemandPayTrnxInfo()
            {
                ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                MrcADPRefNo = request.MrcADPRefNo,
                MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                TerminalNumber = originalTransaction.TerminalNumber,
                TransactionType = Convert.ToInt16(originalTransaction.TransactionType),
                Amount = Convert.ToDecimal(originalTransaction.Amount),
                CurrCode = 949,
                ExpiredDate = originalTransaction.ExpiredDate,
                DelayPayFlag = 0,
                EarlyPayFlag = 0,
                PartialPayFlag = 0,
                IsSuspension = 0,
                MerchantAccHold = originalTransaction.MerchantAccHold,
                MerchantAccIBAN = originalTransaction.MerchantAccIBAN,
                CustomerAccHold = originalTransaction.MerchantAccHold,
                CustomerAccIBAN = originalTransaction.CustomerAccIBAN,
                Rrn = originalTransaction.Rrn,
                EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ServiceOperation = (int)ServiceOperation.InformCancel,
                ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                QueryId = request.QueryId,
                PaymentId = request.PaymentId,
                FastDescription = request.FastDescription,
                PaymentType = request.PaymentType,
                IsConsumed = 0,
                IsReversal = 1, //Cancel işlemi reversal olarak setlenir
                Orig_Rrn = "_"
            };

            try
            {
                fastTransactionResponse = await _demandPayUtils.MakeAuthorization(demandPayTrnxInfo, _fastTransaction, uniqueId, true);

                //Test için eklendi sonra kontrol eklenecek         

                //var refundPaymentService = Utils.MakeRefundPaymentService(
                //    _fastTransaction, 
                //    request.ReferenceNumber, 
                //    originalTransaction.Amount, 
                //    "Otorizasyon hatası", 
                //    request.MerchantNumber, 
                //    request.PaymentId, 
                //    string.Empty, //MBY den customer number
                //    string.Empty, 
                //    ServiceOperation.InformForOi);

                if (fastTransactionResponse != null
                    && fastTransactionResponse.PosTrnxInfo != null
                    && !string.IsNullOrEmpty(fastTransactionResponse.PosTrnxInfo.F39)
                    && fastTransactionResponse.PosTrnxInfo.F39 == "00"
                    && fastTransactionResponse.ResponseCode == "00000")
                {
                    Logger.LogInformation($"{uniqueId} - Cancel transaction completed successfully. Original ADPTrnxId: {originalTransaction.ADPTrnxId}");

                    response.ReferenceNumber = fastTransactionResponse.PosTrnxInfo.F37;
                    response = _responseFactory.CreateInformForIoResponse("000", "İptal işlemi başarılı.");
                }
                else
                {
                    Logger.LogWarning($"{uniqueId} - Cancel transaction failed. Response Code: {fastTransactionResponse.PosTrnxInfo?.F39}");
                    response.ResultCode = fastTransactionResponse.ResponseCode;
                    response.ResultDescription = fastTransactionResponse.ResponseMessage;
                    response.ReferenceNumber = fastTransactionResponse.PosTrnxInfo.F37;
                    response.IsSuccess = fastTransactionResponse.PosTrnxInfo.F39 == "00";

                    //sponse = _responseFactory.CreateInformForIoResponse("020", "İptal işlemi sırasında hata oluştu");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"{uniqueId} - Error during cancel transaction processing");
                response = _responseFactory.CreateInformForIoResponse("020", "İptal işlemi sırasında hata oluştu");
            }

            //Hata durumunu veritabanına kaydet
            if (response.ResultCode != "000")
            {
                //fastTransactionResponse eklenecek methoda
                await SaveInformForIoError(request, response, new Exception(response.ResultDescription), uniqueId, request.PaymentType, fastTransactionResponse);
                return response;
            }

            return response;
        }

        /// <summary>
        /// İade işlemini işler - Trnx Code : 06
        /// </summary>
        /// <param name="request"></param>
        /// <param name="uniqueId"></param>
        /// <returns></returns>
        private async Task<InformForIoResponse> ProcessRefundTransaction(InformForIoRequest request, string uniqueId)
        {
            InformForIoResponse response = new InformForIoResponse();
            PosTrnxInfoResponse fastTransactionResponse = new PosTrnxInfoResponse();

            Logger.LogInformation($"{uniqueId} - Processing Refund Transaction for ReferenceNumber:{request.ReferenceNumber}");

            //ReferenceNumber kontrolü
            if (string.IsNullOrEmpty(request.ReferenceNumber))
            {
                Logger.LogInformation($"{uniqueId} - Refund işlemi için ReferenceNumber boş olamaz");
                response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.ReferenceNumberCannotBeNull.GetHashCode().ToString(), "İade edilecek işlem reference numarası bulunamadı");

                await SaveInformForIoError(request, response, new Exception("ReferenceNumber is null or empty"), uniqueId, request.PaymentType, fastTransactionResponse);

                return response;
            }

            //orjinal satış işlemini bul
            var originalTransaction = await _demandPayPaymentService.GetOriginalTransactionByReferenceNumber(request.ReferenceNumber, request.MerchantNumber, request.MrcADPRefNo);

            if (originalTransaction == null)
            {
                Logger.LogInformation($"{uniqueId} - Original transaction not found ReferenceNumber: {request.ReferenceNumber}");
                response = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.OriginalTransactionNotFound.GetHashCode().ToString(), "İade edilecek orijinal işlem bulunamadı");

                await SaveInformForIoError(request, response, new Exception("Original transaction not found ReferenceNumber"), uniqueId, request.PaymentType, fastTransactionResponse);

                return response;
            }

            Logger.LogWarning($"{uniqueId} - Original transaction found. ADPTrnxId: {originalTransaction.ADPTrnxId}, Amount: {originalTransaction.Amount}, ReferenceNumber:{request.ReferenceNumber}");

            response = _responseFactory.CreateInformForIoResponse("000", string.Empty);

            //Refund için entity oluştur
            DemandPayTrnxInfo demandPayTrnxInfo = new DemandPayTrnxInfo()
            {
                ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                MrcADPRefNo = request.MrcADPRefNo,
                MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                TerminalNumber = originalTransaction.TerminalNumber,
                TransactionType = Convert.ToInt16(originalTransaction.TransactionType),
                Amount = Convert.ToDecimal(originalTransaction.Amount),
                CurrCode = 949,
                ExpiredDate = originalTransaction.ExpiredDate,
                DelayPayFlag = 0,
                EarlyPayFlag = 0,
                PartialPayFlag = 0,
                IsSuspension = 0,
                MerchantAccHold = originalTransaction.MerchantAccHold,
                MerchantAccIBAN = originalTransaction.MerchantAccIBAN,
                CustomerAccHold = originalTransaction.MerchantAccHold,
                CustomerAccIBAN = originalTransaction.CustomerAccIBAN,
                Rrn = originalTransaction.Rrn,
                EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                ServiceOperation = (int)ServiceOperation.InformRefund,
                ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                ResultDescription = !string.IsNullOrEmpty(response.ResultDescription) ? response.ResultDescription : "_",
                DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                QueryId = request.QueryId,
                PaymentId = request.PaymentId,
                FastDescription = request.FastDescription,
                PaymentType = request.PaymentType,
                IsReversal = 0,
                Orig_Rrn = request.ReferenceNumber //Ojinal işlemin Referans Numarası
            };

            try
            {
                fastTransactionResponse = await _demandPayUtils.MakeAuthorization(demandPayTrnxInfo, _fastTransaction, uniqueId, true);

                if (fastTransactionResponse != null && fastTransactionResponse.PosTrnxInfo != null && !string.IsNullOrEmpty(fastTransactionResponse.PosTrnxInfo.F39) && fastTransactionResponse.PosTrnxInfo.F39 == "00")
                {
                    Logger.LogInformation($"{uniqueId} - Refund transaction completed successfully. Original ADPTrnxId: {originalTransaction.ADPTrnxId}");

                    response.ReferenceNumber = fastTransactionResponse.PosTrnxInfo.F37;
                    response = _responseFactory.CreateInformForIoResponse("000", "İade işlemi başarılı.");
                }
                else
                {
                    Logger.LogWarning($"{uniqueId} - Cancel transaction failed. Response Code: {fastTransactionResponse.PosTrnxInfo?.F39}");
                    response.ResultCode = fastTransactionResponse.ResponseCode;
                    response.ResultDescription = fastTransactionResponse.ResponseMessage;
                    response.IsSuccess = fastTransactionResponse.PosTrnxInfo.F39 == "00";

                    //response = _responseFactory.CreateInformForIoResponse("020", "İptal işlemi sırasında hata oluştu");
                }

                //if (fastTransactionResponse != null && !string.IsNullOrEmpty(fastTransactionResponse.F39) && fastTransactionResponse.F39 == "00")
                //{
                //    Logger.LogInformation($"{uniqueId} - Refund transaction completed successfully. Original ADPTrnxId: {originalTransaction.ADPTrnxId}");

                //    response.ReferenceNumber = fastTransactionResponse.F37;
                //    response = _responseFactory.CreateInformForIoResponse("000", "İade işlemi başarılı.");
                //}
                //else
                //{
                //    Logger.LogWarning($"{uniqueId} - Refund transaction failed. Response Code: {fastTransactionResponse?.F39}");

                //    response = _responseFactory.CreateInformForIoResponse("020", "İade işlemi sırasında hata oluştu");
                //}
            }
            catch (BusinessException ex)
            {
                Logger.LogError(ex, $"{uniqueId} - Error during Refund transaction processing");
                response = _responseFactory.CreateInformForIoResponse("020", "İade işlemi sırasında hata oluştu");

                //Hata durumunu veritabanına kaydet
                await SaveInformForIoError(request, response, ex, uniqueId, request.PaymentType, fastTransactionResponse);
            }
            catch (Exception ex)
            {
                Logger.LogError(ex, $"{uniqueId} - Error during Refund transaction processing");
                response = _responseFactory.CreateInformForIoResponse("020", "İade işlemi sırasında hata oluştu");

                //Hata durumunu veritabanına kaydet
                //await SaveInformForIoError(request, response, ex, uniqueId, request.PaymentType);
            }

            //Hata durumunu veritabanına kaydet
            if (response.ResultCode != "000")
            {
                await SaveInformForIoError(request, response, new Exception(response.ResultDescription), uniqueId, request.PaymentType, fastTransactionResponse);
                return response;
            }

            return response;
        }

        private async Task SaveInformForIoError(
            InformForIoRequest request,
            InformForIoResponse response,
            Exception excetion,
            string uniqueId,
            string paymentTypeCode,
            PosTrnxInfoResponse fastTransactionResponse,
            DemandPayTrnxInfo originalTransaction = null)
        {
            try
            {
                int serviceOperation = 0;
                if (fastTransactionResponse.ServiceType == "EOD")
                {
                    serviceOperation = (int)ServiceOperation.EodSuspan;
                }
                else if (request.PaymentType == "Cancel")
                {
                    serviceOperation = (int)ServiceOperation.InformCancel;
                }
                else if (request.PaymentType == "Refund")
                {
                    serviceOperation = (int)ServiceOperation.InformRefund;
                }
                else
                {
                    serviceOperation = (int)ServiceOperation.InformForOi;
                }

                var errorEntity = new DemandPayTrnxInfo()
                {
                    ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                    MrcADPRefNo = request.MrcADPRefNo,
                    MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                    TerminalNumber = originalTransaction?.TerminalNumber ?? "_",
                    TransactionType = originalTransaction?.TransactionType ?? 0,
                    Amount = originalTransaction?.Amount ?? 0,
                    CurrCode = 949,
                    ExpiredDate = originalTransaction?.ExpiredDate ?? DateTime.Now,
                    DelayPayFlag = 0,
                    EarlyPayFlag = 0,
                    PartialPayFlag = 0,
                    IsSuspension = 0,
                    MerchantAccHold = originalTransaction?.MerchantAccHold ?? "_",
                    MerchantAccIBAN = originalTransaction?.MerchantAccIBAN ?? request.Iban ?? "_",
                    CustomerAccHold = originalTransaction?.MerchantAccHold ?? "_",
                    CustomerAccIBAN = originalTransaction?.CustomerAccIBAN ?? "_",
                    Rrn = "_",
                    EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                    EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                    ServiceOperation = serviceOperation,
                    ResultStatus = !string.IsNullOrEmpty(response.ResultCode) ? response.ResultCode : "_",
                    ResultDescription = $"{excetion.Message}",
                    DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                    DemandPaymentResponse = JsonConvert.SerializeObject(response, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                    QueryId = request.QueryId ?? "_",
                    PaymentId = request.PaymentId ?? "_",
                    FastDescription = request.FastDescription ?? $"Hata - Ref:{request.ReferenceNumber}",
                    PaymentType = request.PaymentType ?? "unknown",
                    IsReversal = 0,
                    Orig_Rrn = "_"
                };

                await _demandPayPaymentService.Create(errorEntity);
                Logger.LogInformation($"{uniqueId} - Error record saved to database (TransactionType:{request.ReferenceNumber})");
            }
            catch (Exception ex)
            {
                Logger.LogError($"{uniqueId} - Failed to save validation error");
            }
        }

        public override MessageValidationResult Validate(InternalMessage message)
        {
            InformForIoResponse informResponse = null;
            InformForIoRequest request = null;

            try
            {
                request = JsonConvert.DeserializeObject<InformForIoRequest>(message.InnerMessage);

                _validationService.ValidateInformIo(request);

                return new MessageValidationResult { Succeed = true, PayLoad = message };

            }
            catch (ValidationException validationException)
            {
                Logger.LogError(validationException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{validationException.Message}");

                var errorCode = validationException.Errors.ToList().FirstOrDefault().ErrorCode ?? "999";

                informResponse = _responseFactory.CreateInformForIoResponse(errorCode.PadLeft(3, '0'), EvaluateResponseMessage(validationException.Errors.ToList().FirstOrDefault()));
                message.InnerMessage = JsonConvert.SerializeObject(informResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (BusinessException businessException)
            {
                Logger.LogError(businessException, $"{message.Unique} - Veri valide edilirken hata oluştu! :{businessException.Message}");

                informResponse = _responseFactory.CreateInformForIoResponse(businessException.Message, EvaluateResponseMessage(businessException.Message));
                message.InnerMessage = JsonConvert.SerializeObject(informResponse);

                if (!string.IsNullOrEmpty(businessException.MessageDetail))
                {
                    informResponse = _responseFactory.CreateInformForIoResponse(businessException.Message, EvaluateResponseMessage(businessException.Message, businessException.MessageDetail));
                    message.InnerMessage = JsonConvert.SerializeObject(informResponse);
                }

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, $"{message.Unique} - Oracle hata oluştu! :{exception.Message}");

                informResponse = _responseFactory.CreateInformForIoResponse(BusinessExceptionCodes.AnUnexpectedErrorOccurred.GetHashCode().ToString(), EvaluateResponseMessage(exception.Message));
                message.InnerMessage = JsonConvert.SerializeObject(informResponse);

                return new MessageValidationResult { Succeed = false, PayLoad = message };
            }
            finally
            {
                //Validation hatası varsa veritabanına kaydet
                if (informResponse != null && !string.IsNullOrEmpty(informResponse.ResultCode) && request != null)
                {
                    try
                    {
                        var errorEntity = new DemandPayTrnxInfo()
                        {
                            ProcessDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                            ProcessTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                            ADPTrnxId = "ADP" + request.MerchantNumber.ToString() + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                            MrcADPRefNo = request.MrcADPRefNo,
                            MerchantNumber = Convert.ToInt64(request.MerchantNumber),
                            TerminalNumber = "_",
                            TransactionType = 0,
                            Amount = 0,
                            CurrCode = 949,
                            ExpiredDate = DateTime.Now,
                            DelayPayFlag = 0,
                            EarlyPayFlag = 0,
                            PartialPayFlag = 0,
                            IsSuspension = 0,
                            MerchantAccHold = "_",
                            MerchantAccIBAN = request?.Iban ?? "_",
                            CustomerAccHold = "_",
                            CustomerAccIBAN = "_",
                            Rrn = "_",
                            EntryDate = long.Parse(DateTime.Now.ToString("yyyyMMdd")),
                            EntryTime = long.Parse(DateTime.Now.ToString("HHmmss")),
                            ServiceOperation = (int)ServiceOperation.InformForOi,
                            ResultStatus = !string.IsNullOrEmpty(informResponse.ResultCode) ? informResponse.ResultCode : "_",
                            ResultDescription = !string.IsNullOrEmpty(informResponse.ResultDescription) ? informResponse.ResultDescription : "_",
                            DemandPaymentRequest = JsonConvert.SerializeObject(request, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                            DemandPaymentResponse = JsonConvert.SerializeObject(informResponse, Formatting.None, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }),
                            QueryId = request.QueryId ?? "_",
                            PaymentId = request.PaymentId ?? "_",
                            FastDescription = request.FastDescription ?? "_",
                            PaymentType = request.PaymentType ?? "unknown",
                            IsReversal = 0,
                            IsConsumed = 0,
                            Orig_Rrn = "_"
                        };

                        _demandPayPaymentService.Create(errorEntity).GetAwaiter().GetResult();
                        Logger.LogInformation($"{message.Unique} - Validation error saved to database");
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex, $"{message.Unique} - Failed to save validation error: {ex.Message}");
                    }
                }
            }
        }
    }
}
