﻿using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using FluentValidation;
using System.Globalization;
using System;
using System.Linq;

namespace Acqua.DemandPay.Payment.Business.Validator
{
    public class InformForIoValidator : AbstractValidator<InformForIoRequest>
    {
        public InformForIoValidator()
        {
            CascadeMode = CascadeMode.StopOnFirstFailure;

            RuleFor(m => m.QueryId).NotEmpty().WithErrorCode(BusinessExceptionCodes.QueryIdCannotBeNull.GetHashCode().ToString());
            RuleFor(m => m.MrcADPRefNo).NotEmpty().WithErrorCode(BusinessExceptionCodes.MrcADPRefNoCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.PaymentId).NotEmpty().WithErrorCode(BusinessExceptionCodes.PaymentIdCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.PaymentType).NotEmpty().WithErrorCode(BusinessExceptionCodes.PaymentTypeCanNotBeNull.GetHashCode().ToString());
            //RuleFor(m => m.PaymentType).NotEmpty().Must(BeValidPaymentType).WithErrorCode(BusinessExceptionCodes.PaymentTypeCanNotBeNull.GetHashCode().ToString());            
            RuleFor(m => m.PaymentType).NotEmpty().Must(x => new[] { "Sale" , "Cancel", "Refund", "Reversal"}.Any(v=>v.Equals(x,StringComparison.OrdinalIgnoreCase))).WithErrorCode(BusinessExceptionCodes.PaymentTypeCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.Iban).NotEmpty().WithErrorCode(BusinessExceptionCodes.MerchantAccIBANCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.FastDescription).NotEmpty().WithErrorCode(BusinessExceptionCodes.FastDescriptionCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.ValidDate).NotEmpty().WithErrorCode(BusinessExceptionCodes.ValidDateCanNotBeNull.GetHashCode().ToString());
            RuleFor(m => m.ValidDate).Must(ValidTryParseDateTime).WithErrorCode(BusinessExceptionCodes.FormatError.GetHashCode().ToString());
            RuleFor(m => m.IsSuspension).NotNull().Must(v => v == "0" || v == "1").WithErrorCode(BusinessExceptionCodes.InvalidIsSuspension.GetHashCode().ToString());
        }
        private bool ValidTryParseInt(string value)
        {
            return value != null && int.TryParse(value, out int outValue);
        }

        private bool ValidTryParseDateTime(string value)
        {
            return DateTime.TryParseExact(value, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out _);
        }
        private bool BeValidPaymentType(string paymentType)
        {
            return  Enum.TryParse(typeof(PaymentTypeEnum), paymentType,ignoreCase:true, out _);
        }
    }
}
