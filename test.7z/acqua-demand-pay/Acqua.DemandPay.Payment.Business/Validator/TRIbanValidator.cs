﻿using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Request;
using FluentValidation;
using IbanNet;

namespace Acqua.DemandPay.Payment.Business.Validator
{
    public class TRIbanValidator : AbstractValidator<CreateWorkplaceInfoRecordRequest>
    {        
        public TRIbanValidator()
        {            
            RuleFor(m => m.MerchantAccIBAN).NotEmpty().WithErrorCode(BusinessExceptionCodes.MerchantAccIBANCanNotBeNull.GetHashCode().ToString())
                .Must(BeAValidIban).WithErrorCode(BusinessExceptionCodes.MerchantAccIBANBeValidIban.GetHashCode().ToString());

            RuleFor(m => m.CustomerAccIBAN).NotEmpty().WithErrorCode(BusinessExceptionCodes.CustomerAccIBANConNotBeNull.GetHashCode().ToString())
                .Must(BeAValidIban).WithErrorCode(BusinessExceptionCodes.CustomerAccIBANBeValidIban.GetHashCode().ToString());
        }
        private bool BeAValidIban(string iban)
        {
            IIbanValidator _ibanValidator = new IbanValidator();

            if (string.IsNullOrEmpty(iban))
            {
                return false;
            }

            iban = iban.Trim().ToUpper();

            if (!iban.StartsWith("TR") || iban.Length != 26)
            {
                return false;
            }
            else
            {
                var result = _ibanValidator.Validate(iban);
                return result.IsValid;
            }
        }
    }
}