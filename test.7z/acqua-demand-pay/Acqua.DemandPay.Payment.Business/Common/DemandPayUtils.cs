﻿using Acqua.DeamndPay.Payment.Model.Entity;
using Acqua.DemandPay.Payment.Business.ExternalServices.Contracts;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby;
using Acqua.DemandPay.Payment.Business.ExternalServices.Mby.Contracts;
using Acqua.DemandPay.Payment.Business.Transaction;
using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Enum;
using Acqua.DemandPay.Payment.Model.Response;
using System;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Common
{
    public class DemandPayUtils
    {
 
        private DemandPayPaymentConfiguration _demandPayPaymentConfiguration;
        public static decimal ConvertFormattedAmount(string amount)
        {
            try
            {
                var tl = amount.Substring(0, 10);

                var kurus = amount.Substring(10, 2);

                var tlKurus = tl + "," + kurus;

                var formatted = decimal.Parse(tlKurus);

                return formatted;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

            }
        }
        public static decimal ConvertToDecimal(string value)
        {
            try
            {
                var result = decimal.TryParse(value, out decimal returnValue);

                return returnValue;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

            }
        }

        public DemandPayUtils(MbyServiceOperator mbyServiceOperator, DemandPayPaymentConfiguration demandPayPaymentConfiguration)
        {            
            _demandPayPaymentConfiguration = demandPayPaymentConfiguration;
        }

        public async Task<PosTrnxInfoResponse> MakeAuthorization(DemandPayTrnxInfo demandDetails, FastTransaction fastTransaction, string unique, bool isPayment = false)
        {
            var fastTransactionResponse = await fastTransaction.AddFastTransaction(demandDetails, unique, isPayment);

            return await Task.FromResult(fastTransactionResponse);
        }

        public async Task<ExternalServices.Mby.Contracts.RetrieveAccountInfoResponse> FindMbyMerchantIBAN(string merchantNumber, string unique, FastTransaction fastTransaction)
        {
            var retrieveAccountInfoResponse = await fastTransaction.FindMbyMerchantIBAN(merchantNumber, unique);

            return await Task.FromResult(retrieveAccountInfoResponse);
        }

        public async Task<RefundPaymentRes> MakeRefundPaymentService(
                   FastTransaction fastTransaction,
                   string referenceNumber,
                   decimal amount,
                   string refundDescription,
                   string merchantNo,
                   string paymentId,
                   string merchantCustomerNo,
                   string unique,
                   ServiceOperation serviceOperation,
                   string trnxCode = "_")
        {
            var fastTransactionResponse = await fastTransaction.CallRefundPaymentService(
                referenceNumber,
                amount,
                refundDescription,
                merchantNo,
                paymentId,
                merchantCustomerNo,
                unique,
                serviceOperation,
                trnxCode);

            return await Task.FromResult(fastTransactionResponse);
        }

        public static void ConvertToNull<T>(object obj)
        {
            try
            {
                foreach (var property in obj.GetType().GetProperties())
                {
                    if (property.PropertyType.Name == "String")
                    {
                        var value = (string)property.GetValue(obj);
                        if (string.IsNullOrEmpty(value) || value == "_")
                        {
                            property.SetValue(obj, null);
                        }
                    }
                    else if (property.PropertyType.Name == "Decimal")
                    {
                        var value = (decimal)property.GetValue(obj);
                        if (value == -1)
                        {
                            property.SetValue(obj, null);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {

            }
        }

    }
}
