﻿using Acqua.DemandPay.Payment.Configuration;
using Acqua.DemandPay.Payment.Model.Response;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acqua.DemandPay.Payment.Business.Factories
{
    public class ResponseFactory : IResponseFactory
    {
        private readonly DemandPayPaymentConfiguration _configuration;

        public ResponseFactory(IOptions<DemandPayPaymentConfiguration> configuration)
        {
            _configuration = configuration.Value ?? throw new ArgumentNullException(nameof(configuration));
        }
        public CreateWorkplaceInfoRecordResponse CreateWorkplaceInfoRecordResponse(string responseCode)
        {
            var message = _configuration.ResponseCodeList?.SingleOrDefault(x => x.Code == responseCode);

            return new CreateWorkplaceInfoRecordResponse
            {
                IsSuccess = responseCode == "000",
                ResultCode = responseCode,
                ResultDescription = message.Message ?? "Bilinmiyen hata kodu",
                ResultDate = DateTime.Now
            };
        }

        public CreateWorkplaceInfoDetailResponse CreateWorkplaceInfoDetailResponse(string responseCode, string responseMessage)
        {
            var message = _configuration.ResponseCodeList?.SingleOrDefault(x => x.Code == responseCode);

            return new CreateWorkplaceInfoDetailResponse
            {
                IsSuccess = responseCode == "000",
                ResultDescription = !string.IsNullOrEmpty(responseMessage) ? responseMessage : message.Message ?? "Bilinmiyen hata kodu",
                ResultDate = DateTime.Now,
                ResultCode = responseCode
            };
        }

        public InformForIoResponse CreateInformForIoResponse(string responseCode, string responseMessage)
        {
            var message = _configuration.ResponseCodeList?.SingleOrDefault(x => x.Code == responseCode.PadLeft(3, '0'));

            return new InformForIoResponse
            {
                IsSuccess = message.Code == "000",
                ResultDescription = !string.IsNullOrEmpty(responseMessage) ? responseMessage : message.Message ?? "Bilinmiyen hata kodu",
                ResultDate = DateTime.Now,
                ResultCode = message.Code
            };
        }
    }
}
