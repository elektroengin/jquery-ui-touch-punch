﻿namespace corf.blueprint.business
{
    public class PropertyDescryptor
    {
        public string Name { get; set; }
        public string Type { get; set; } //string,number,date, enum
        public string Description { get; set; }
        public bool IsReadOnly { get; set; }

        public object Value { get; set; }
        public PropertyDescryptor[] Properties { get; set; }

        public bool IsArray { get; set; }
        public bool IsEnum { get;  set; }
        public string[] EnumValues { get; set; }
        public bool IsClass { get;  set; }
        public bool IsActive { get; set; }
        public string DisplayText { get; set; }
    }
}