﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace corf.blueprint.business
{
    public class ModelList<TModel>
    {
        [Required]
        [MinLength(1)]
        public List<TModel> items { get; set; }
        public int? updated_count { get; set; }
        public int? created_count { get; set; }
        public int? deleted_count { get; set; }
    }

}
