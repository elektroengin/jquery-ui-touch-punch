﻿namespace corf.blueprint.business
{
    internal class Root
    {
        public Root()
        {

        }

        public AssetNotification assetNotification { get; set; }
    }
}