﻿using Newtonsoft.Json;

namespace corf.blueprint.business
{
    public class PushNotificationRequest
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("item_id")]
        public string ItemId { get; set; }

        [JsonProperty("customer_number")]
        public long CustomerNumber { get; set; }

        [JsonProperty("data", NullValueHandling = NullValueHandling.Ignore)]
        public object Data { get; set; }
    }
}