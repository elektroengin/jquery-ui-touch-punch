﻿namespace corf.blueprint.business
{
    internal class AssetNotification
    {
        //V1
        public AssetNotification()
        {
        }
            public string assetType { get; set; } = "string";
        public string customerNo { get; set; } = "string";
        public string notificationItemId { get; set; } = "string";
        public int notificationStatus { get; set; } = 0;
        public string parameters { get; set; } = "string";
        public string referenceId { get; set; } = "string";
    
    }
}