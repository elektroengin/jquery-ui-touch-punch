﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint
{
    public class Db2Settings
    {
        public string Db2ConnectionString { get; set; }
        public string OnlineConnectionString { get; set; }
    }
}
