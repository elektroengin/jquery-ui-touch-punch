﻿using corf.BinaryConverter;
using corf.blueprint.business.ApplicationIAM;
using corf.blueprint.business.ServiceCallers;
using corf.Core.Commands;
using corf.Core.Messaging;
using Logging;
using Microsoft.Diagnostics.Tracing.Parsers;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class RestMirrorExecuter1 : MultipleMessageCommand
    {
        public static bool Running = false;
        private static int messagesCount = 0; 
        private static int messagesCount2 = 0;
        private object lockObject = new object();
        public ApplicationIAMTokenServiceCaller _applicationIAMTokenServiceCaller;
        public IAMConfiguration _iamConfiguration;
        private IMetricMonitoringLogAdapter _metricLogger;
        public RestMirrorExecuter1(ILogger<RestMirrorExecuter1> logger, IMetricMonitoringLogAdapter metricLogger) : base(logger)
        {
            
        }
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        
        public async override Task<InternalMessage> Execute(InternalMessage message)
        {

            for (int i=0; i<3000; i++)
            {
                InternalMessages.Enqueue(message);
            }
            
            return await Task.FromResult(message);
        }

    }
}
