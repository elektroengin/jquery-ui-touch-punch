﻿using corf.Communication.HttpInfra.Rest;
using corf.Core.Commands;
using corf.Core.Messaging;
using Logging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace corf.blueprint.business
{
    public class MessageItem
    {
        public string message { get; set; }
    }
    [RequestPayload(typeof(WeatherForecast))]
    [ResponsePayload(typeof(ResponseObjectPagedList<PagedList<ConnectorModel>>))]
    public class RestMirrorExecuter3 : BusinessCommand
    {
        public Guid Id { get; set; }

        private readonly MessageContainer messageContainer;
        private IMetricMonitoringLogAdapter _metricLogger;

        public RestMirrorExecuter3(MessageContainer messageContainer, ILogger<RestMirrorExecuter3> logger, IMetricMonitoringLogAdapter metricLogger) : base(logger)
        {
            Id = Guid.NewGuid();
            this.messageContainer = messageContainer;
            _metricLogger = metricLogger;
        }

        //bkm iso to json
        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            var messageItem = JsonConvert.DeserializeObject<MessageItem>(message.InnerMessage);
            Thread.Sleep(1000);
            messageContainer.AddMessage(message);
            message.InnerMessage = messageItem.message;
            return await Task.FromResult(message);
        }

    }
}
