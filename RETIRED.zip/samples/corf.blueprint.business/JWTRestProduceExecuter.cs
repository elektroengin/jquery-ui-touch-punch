﻿using corf.Communication.JWTTokenResolver;
using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class JWTRestProduceExecuter : JWTIncludedCommand
    {
        JWTTokenResolver jWTTokenResolver = null;
        ILogger<JWTRestProduceExecuter> logger = null;

        public JWTRestProduceExecuter(ILogger<JWTRestProduceExecuter> logger, JWTTokenResolver jWTTokenResolver) : base(logger, jWTTokenResolver)
        {
            this.logger = logger;
            this.jWTTokenResolver = jWTTokenResolver;
        }
        public async override Task<InternalMessage> DoExecute(JWTIncludedInternalMessage message)
        {
            logger.LogInformation($"customer{message.JWTTokenClearData.XRlyJwtTokenBody.CustomerNumber}");
            return await Task.FromResult<InternalMessage>(message);
        }
    }
}
