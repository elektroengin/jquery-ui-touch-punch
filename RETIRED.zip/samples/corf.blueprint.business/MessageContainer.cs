﻿using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace corf.blueprint.business
{
    public class MessageContainer
    {
        private readonly ConcurrentDictionary<string, InternalMessage> CachedMessages = new ConcurrentDictionary<string, InternalMessage>();
        private readonly ILogger<MessageContainer> _logger;

        public MessageContainer(ILogger<MessageContainer> logger)
        {
            this._logger = logger;
        }

        

        public InternalMessage GetOriginalMessage(string unique)
        {
            InternalMessage messageCacheItem = null;

            var keyValuePair = CachedMessages.First();

            messageCacheItem =  keyValuePair.Value;

            return messageCacheItem;
        }

        public bool AddMessage(InternalMessage messageCacheItem)
        {
            return CachedMessages.TryAdd(messageCacheItem.Unique, messageCacheItem);
        }
    }
}
