﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class CardDetailExecuter : BusinessCommand
    {
        public CardDetailExecuter(ILogger<CardDetailExecuter> logger) : base(logger)
        {
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            Logger.LogInformation("{unique} | CardDetailExecuter InnerMessage | {additionalMessage} | {stipEventOffsetListCount}",
                                message.Unique,
                                message.InnerMessage,
                                $"stipEventList Count: 8");

            return await Task.FromResult(message);

        }
    }
}
