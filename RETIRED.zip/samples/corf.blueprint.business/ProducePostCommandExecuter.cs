﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class ProducePostCommandExecuter : BusinessCommand
    {
        public ProducePostCommandExecuter(ILogger logger) : base(logger)
        {

        }
        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            return await Task.FromResult<InternalMessage>(message);
        }
    }
}
