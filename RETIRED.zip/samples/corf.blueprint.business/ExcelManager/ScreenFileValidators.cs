﻿using corf.blueprint.business.BusinessValidators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ExcelManager
{
    public class ScreenFileValidators
    {
        public string ScreenCode { get; set; }
        public FileFieldHolder Fields { get; set; }
        public BusinessValidatorInfo[] BusinessValidators { get; set; }
    }
}
