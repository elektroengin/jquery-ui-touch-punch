﻿namespace corf.blueprint.business.ExcelManager
{
    public class BusinessValidatorInfo
    {
        public string Name { get; set; }
        public int Order { get; set; }
        public string Fields { get; set; }
    }
}