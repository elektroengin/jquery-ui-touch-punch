﻿using System.Collections.Generic;

namespace corf.blueprint.business.ExcelManager
{
    public class FileFieldHolder : Dictionary<string, string>
    {
        public int Order { get; set; }
    }
}