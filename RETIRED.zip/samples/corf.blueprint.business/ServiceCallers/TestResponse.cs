﻿using corf.Communication.HttpInfra.Grpc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ServiceCallers
{
    public class TestResponse : IGrpcResponse
    {
        [IgnoreDataMember]
        public HttpStatusCode StatusCode { get; set; }
        
        [DataMember]
        public string ExceptionMessage { get; set; }
        
        [DataMember]
        public string ResponseMessageBody { get; set; }
    }
}
