﻿using corf.Communication.ServiceCaller;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ServiceCallers
{
    public class TestServiceCaller : GenericServiceCaller<TestRequest, TestResponse>
    {
        BluePrintConfiguration _bluePrintConfiguration;
        public TestServiceCaller(BluePrintConfiguration acquaVposDeltaConfiguration, ILogger<GenericServiceCaller<TestRequest, TestResponse>> logger)
        {
            _bluePrintConfiguration = acquaVposDeltaConfiguration;

            this.Initialize(_bluePrintConfiguration.TestServiceConfiguration, logger);
        }

     
    }
}
