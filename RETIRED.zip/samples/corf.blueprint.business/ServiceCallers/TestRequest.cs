﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ServiceCallers
{
    public class TestRequest
    {
        public string RequestMessageBody { get; set; }
    }
}
