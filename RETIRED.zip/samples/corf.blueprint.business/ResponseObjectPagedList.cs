﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class ResponseObjectPagedList<T>
    {
        public T data { get; set; }
        public List<string> errors { get; set; }
        public string response_date_time => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
    }
}
