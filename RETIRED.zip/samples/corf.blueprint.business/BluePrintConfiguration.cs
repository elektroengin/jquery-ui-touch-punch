﻿using corf.blueprint.business.ExcelManager;
using corf.Core.Http;
using Newtonsoft.Json.Linq;

namespace corf.blueprint.business
{
    public class BluePrintConfiguration
    {
        public GrpcServiceEndPointInfo GrpcTestServiceCaller { get; set; }
        public ScreenFileValidators[] ScreenFileValidators { get; set; }
        public JObject TestServiceConfiguration { get; set; }
    }
}