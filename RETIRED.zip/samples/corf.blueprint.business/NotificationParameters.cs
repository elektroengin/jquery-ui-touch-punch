﻿using Newtonsoft.Json;

namespace corf.blueprint.business
{
    public class NotificationParameters
    {
        [JsonProperty("plaka")]
        public string PlateNumber { get; set; }

        [JsonProperty("ay")]
        public string Month { get; set; }

        [JsonProperty("yil")]
        public string Year { get; set; }

        [JsonProperty("kalangun")]
        public string DayCount { get; set; }
    }
}