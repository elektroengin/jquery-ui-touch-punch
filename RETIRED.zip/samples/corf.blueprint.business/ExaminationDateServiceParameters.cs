﻿namespace corf.blueprint.business
{
    internal class ExaminationDateServiceParameters
    {
        public string examinationDate { get; set; }
        public int page { get; set; }
        public int size { get; set; }
    }
}