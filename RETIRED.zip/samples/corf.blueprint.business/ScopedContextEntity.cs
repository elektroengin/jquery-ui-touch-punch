﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class ScopedContextEntity
    {
        public Guid Identifier { get; private set; }
        public ScopedContextEntity()
        {
            Identifier = Guid.NewGuid();
        }

        public override string ToString()
        {
            return $"[{Identifier}] {base.ToString()}";
        }
    }
}
