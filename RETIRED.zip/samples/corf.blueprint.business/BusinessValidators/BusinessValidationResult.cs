﻿namespace corf.blueprint.business.BusinessValidators
{
    public class BusinessValidationResult
    {
        public string Message { get; internal set; }
        public bool Validated { get; internal set; }
    }
}