﻿namespace corf.blueprint.business.BusinessValidators
{
    public interface IBusinessValidatorManager
    {
        void Register(string validatorKey, BusinessValidator validator);

        BusinessValidator this[string key] { get; }

        bool ContainsKey(string key);
    }
}