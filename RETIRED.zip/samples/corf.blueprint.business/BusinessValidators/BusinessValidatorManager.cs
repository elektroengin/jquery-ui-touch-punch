﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.BusinessValidators
{
    public class BusinessValidatorManager : IBusinessValidatorManager
    {
        protected readonly Dictionary<string, BusinessValidator>  BusinessValidators = new Dictionary<string, BusinessValidator>();

        public void Register(string validatorKey, BusinessValidator validator)
        {
            this.BusinessValidators.Add(validatorKey, validator);
        }

        public bool ContainsKey(string key)
        {
            return BusinessValidators.ContainsKey(key);
        }

        public BusinessValidator this[string key]
        {
            get
            {
                return BusinessValidators.ContainsKey(key) ? BusinessValidators[key] : null;
            }
        }
    }
}
