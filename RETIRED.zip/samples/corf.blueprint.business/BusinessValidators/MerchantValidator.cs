﻿using corf.blueprint.business.ExcelManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.BusinessValidators
{
    public class MerchantValidator : BusinessValidator
    {

        public MerchantValidator(IBusinessValidatorManager businessValidatorManager)
        {
            businessValidatorManager.Register("MerchantValidator", this);
        }

        public override BusinessValidationResult Validate(params string[] fields)
        {
            if (fields[0].Length < 7)
            {
                return new BusinessValidationResult
                {
                    Validated = false,
                    Message = "Invalid merchant number length"
                };
            }

            else return new BusinessValidationResult
            {
                Validated = true,
                Message = ""
            };
        }
    }
}
