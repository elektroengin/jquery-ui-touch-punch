﻿using System.Collections.Generic;

namespace corf.blueprint.business.BusinessValidators
{
    public abstract class BusinessValidator
    {
        public abstract BusinessValidationResult Validate(params string[] fields);
    }
}