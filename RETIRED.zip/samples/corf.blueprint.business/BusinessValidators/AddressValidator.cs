﻿using corf.blueprint.business.ExcelManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.BusinessValidators
{
    public class AddressValidator : BusinessValidator
    {

        public AddressValidator(IBusinessValidatorManager businessValidatorManager)
        {
            businessValidatorManager.Register("AddressValidator", this);
        }

        public override BusinessValidationResult Validate(params string[] fields)
        {
            if (fields[0].Length < 7)
            {
                return new BusinessValidationResult
                {
                    Validated = false,
                    Message = "Invalid address"
                };
            }

            else return new BusinessValidationResult
            {
                Validated = true,
                Message = ""
            };
        }
    }
}
