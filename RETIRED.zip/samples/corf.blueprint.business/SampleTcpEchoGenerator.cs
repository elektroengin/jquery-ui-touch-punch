﻿using corf.BinaryConverter;
using corf.Communication.Tcp.Client;
using corf.Core.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class SampleTcpEchoGenerator : ITcpEchoMessageGenerator
    {
        public byte[] GetEchoMessage()
        {
            return DataConvert.HexStringToBinary("0035700000000030383030A220000000000000040000000000000837303030313030323237313435333039363837393535333031303030");
        }
    }
}
