﻿using corf.Communication.HttpInfra.Rest;
using corf.Core.Commands;
using corf.Core.Messaging;
using Logging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace corf.blueprint.business
{
    [RequestPayload(typeof(WeatherForecast))]
    [ResponsePayload(typeof(ResponseObjectPagedList<PagedList<WeatherForecast>>))]
    public class RestMirrorExecuter2 : BusinessCommand
    {
        public Guid Id { get; set; }

        private readonly MessageContainer messageContainer;
        private IMetricMonitoringLogAdapter _metricLogger;

        public RestMirrorExecuter2(MessageContainer messageContainer, ILogger<RestMirrorExecuter2> logger, IMetricMonitoringLogAdapter metricLogger) : base(logger)
        {
            this.messageContainer = messageContainer;
            _metricLogger = metricLogger;
        }
        //bkm iso to json
        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            InternalMessage origMessage = messageContainer.GetOriginalMessage(string.Empty);
            message.Unique = origMessage.Unique;
            return await Task.FromResult(message);
        }

        private void LogMetric(InternalMessage message)
        {
            //messaging'e alınacak
            string transactionType = "None";
            string destination = "None";
            transactionType = "Reversal";

            destination = "OnUs";

            var metricMonitoringMessage = new MetricMonitoringSingleMessage()
            {
                InitialRecord = true,
                Acquirer = "Acqua",
                ApplicationId = "ACQUA-GATE-VPOS",
                ApplicationName = "Acqua Gate Vpos",
                IsReversal = false,
                EntryDate = message.AdditionalInfo.ModuleJourney[0].EntryDate,
                ExitDate = DateTime.Now,
                ServerName = Environment.MachineName,
                Tuid = message.Unique,
                Duration = (long)(DateTime.Now.Subtract(message.AdditionalInfo.ModuleJourney[0].EntryDate).TotalMilliseconds),
                Details = new MetricMonitoringMessageDetails()
                {
                    ResponseCode = "200",
                    IsOnlineTransaction = true,
                    TransactionType = transactionType,
                    UserIdentifier = "Identifier",
                    UserDescription = "Identifier SignName",
                    Destination = destination,
                    ErrorMessage = "Orda bir köy var uzakta",
                    Result = Result.Successful
                }
            };

            _metricLogger.Send(metricMonitoringMessage);
        }

    }
}
