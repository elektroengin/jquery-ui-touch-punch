﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Logging;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class MonitoringCommandSample1 : MonitoringCommand
    {
        public MonitoringCommandSample1(ILogger logger, IMetricMonitoringLogAdapter metricLogger) : base(logger, metricLogger)
        {
        }

        public override Task JourneyTimedOut(InternalMessage incoming, InternalMessage outgoing)
        {
            return base.JourneyTimedOut(incoming, outgoing);
        }

        public override Task MessageSendFailed(InternalMessage incoming, InternalMessage outgoing, Exception exception)
        {
            return base.MessageSendFailed(incoming, outgoing, exception);
        }

        public override Task MessageSent(InternalMessage cloneMessage, InternalMessage message)
        {
            return base.MessageSent(cloneMessage, message);
        }
    }
}