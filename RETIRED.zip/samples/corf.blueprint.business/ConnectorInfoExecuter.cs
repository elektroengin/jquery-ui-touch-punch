﻿using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class ConnectorInfoExecuter : BusinessCommand
    {
        private IServiceProvider _serviceProvider;
        readonly string[] colors = new string[] { "#DBBF5B", "#E8977A", "#86A97E", "#509FE4", "#FBD1A1", "#E5DFF7", "#DDD46B", "#EA967C", "#DCBE5C", "#FBD0A3", "#BDEFBC", "#E8E7AF", "#E59191", "#DC9591" };
        
        public ConnectorInfoExecuter(ILogger logger, IServiceProvider serviceProvider) : base(logger)
        {
            _serviceProvider = serviceProvider;
        }

        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            var configurator = _serviceProvider.GetService<IConfigurator>();

            List<ConnectorModel> connectorModels = new List<ConnectorModel>();

            int i = 0;

            foreach (var item in configurator.ConnectorConfiguration.Assemblies)
            {
                Type itemType = Type.GetType(item.Value);

                if (typeof(IConnector).IsAssignableFrom(itemType))
                {
                    connectorModels.Add(new ConnectorModel
                    {
                        Name = item.Key,
                        Description = item.Value,
                        Color = colors[i % colors.Length],
                        EdgeDirection = configurator.ConnectorDirections[item.Key],
                        Properties = getProperties(itemType, true).ToArray()
                    }) ;

                    i++;
                }
            }

            message.InnerMessage = JsonConvert.SerializeObject(connectorModels);
            return message;
        }

        private List<PropertyDescryptor> getProperties(Type itemType, bool isParentItem)
        {
            var descriptors = new List<PropertyDescryptor>();

            if (itemType.IsClass || itemType.IsInterface)
            {
                if (isParentItem || (!isParentItem && !itemType.FullName.Contains("System.String")))
                {
                    var properties = itemType.GetProperties();

                    foreach (var propertyInfo in properties.Where(p => p.CanWrite))
                    {
                        var flowDesignAttibute = (FlowDesignAttribute)propertyInfo.GetCustomAttributes(typeof(FlowDesignAttribute), true).FirstOrDefault();

                        bool display = true;

                        string description = propertyInfo.PropertyType.FullName;

                        if (flowDesignAttibute != null)
                        {
                            display = flowDesignAttibute.Display;
                            description = flowDesignAttibute.Description;
                        }

                        if (display)
                        {
                            descriptors.Add(new PropertyDescryptor
                            {
                                Description = description,
                                IsArray = propertyInfo.PropertyType.IsArray,
                                IsReadOnly = false,
                                Value = propertyInfo.PropertyType.IsArray ? (new List<object>()).ToArray() : propertyInfo.PropertyType.Name == "String" ? "" : GetDefault(propertyInfo.PropertyType),
                                Name = propertyInfo.Name,
                                IsClass = (propertyInfo.PropertyType.IsClass || propertyInfo.PropertyType.IsInterface) && propertyInfo.PropertyType.Name != "String",
                                IsActive = (propertyInfo.PropertyType.IsClass || propertyInfo.PropertyType.IsInterface) && propertyInfo.PropertyType.Name != "String" ? false : true,
                                Type = propertyInfo.PropertyType.Name,
                                Properties = getProperties(propertyInfo.PropertyType.IsArray ? propertyInfo.PropertyType.GetElementType() : propertyInfo.PropertyType, false).ToArray(),
                                IsEnum = propertyInfo.PropertyType.IsEnum,
                                DisplayText = "",
                                EnumValues = propertyInfo.PropertyType.IsEnum ? System.Enum.GetNames(propertyInfo.PropertyType) : null
                        });
                        }
                    }
                }
            }

            return descriptors;
        }

        public object GetDefault(Type t)
        {
            return this.GetType().GetMethod("GetDefaultGeneric").MakeGenericMethod(t).Invoke(this, null);
        }

        public T GetDefaultGeneric<T>()
        {
            return default(T);
        }
    }
}
