﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class CorfModelerExecuter : BusinessCommand
    {
        public CorfModelerExecuter(ILogger logger) : base(logger)
        {
        }

        public override Task<InternalMessage> Execute(InternalMessage message)
        {
            throw new NotImplementedException();
        }
    }
}
