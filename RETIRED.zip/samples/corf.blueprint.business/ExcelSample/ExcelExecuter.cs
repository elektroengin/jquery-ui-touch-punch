﻿using corf.blueprint.business.BusinessValidators;
using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;

namespace corf.blueprint.business.ExcelSample
{
    public class ExcelExecuter : BusinessCommand
    {
        private BluePrintConfiguration _bluePrintConfiguration;
        private IBusinessValidatorManager  _businessValidatorManager;

        public ExcelExecuter(ILogger logger, IBusinessValidatorManager businessValidatorManager, IOptions<BluePrintConfiguration> bluePrintConfiguration) : base(logger)
        {
            _bluePrintConfiguration = bluePrintConfiguration.Value;
            _businessValidatorManager = businessValidatorManager;
        }


        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            ScreenFileValidationResult validationResult = new ScreenFileValidationResult();

            try
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                IFormFile fileInfo = ((HttpMessage)message).Files[0];

                MemoryStream stream = new MemoryStream();

                fileInfo.CopyTo(stream);

                JArray jResult = new JArray();

                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet();

                    var screenCode = ((HttpMessage)message).ChannelCustomParameters["screenCode"];

                    //Checking incoming screen code that match with validator
                    var validator = _bluePrintConfiguration.ScreenFileValidators.FirstOrDefault(v => v.ScreenCode == screenCode);


                    //screen code not found ! thow exception and quit.
                    if (validator == null)
                    {
                        throw new ScreenValidatorNotFoundExeception(screenCode);
                    }

                    int headerRowIndex = 0;

                    Dictionary<string, int> columnOrders = new Dictionary<string, int>();

                    foreach (var kvp in validator.Fields)
                    {
                        columnOrders.Add(kvp.Key, -1);
                    }

                    for (int i = 0; i < result.Tables[0].Columns.Count; i++)
                    {
                        string columnName = result.Tables[0].Rows[headerRowIndex][i].ToString();

                        if (columnOrders.ContainsKey(columnName))
                        {
                            columnOrders[columnName] = i;
                        }
                    }

                    List<string> missingFields = new List<string>();

                    foreach (var kvp in columnOrders)
                    {
                        if (kvp.Value < 0)
                        {
                            missingFields.Add(kvp.Key);
                        }
                    }

                    if (missingFields.Count > 0)
                    {
                        throw new FileFieldMissingException(screenCode, string.Join(", ", missingFields.ToArray()));
                    }

                    for (int i = 1; i < result.Tables[0].Rows.Count; i++)
                    {
                        JObject jobject = new JObject();

                        foreach (var kvp in columnOrders)
                        {
                            jobject.Add(kvp.Key, result.Tables[0].Rows[i][kvp.Value].ToString());
                        }

                        foreach (var businessValidatorInfo in validator.BusinessValidators.OrderBy(v => v.Order))
                        {
                            if (_businessValidatorManager.ContainsKey(businessValidatorInfo.Name))
                            {
                                List<string> fieldList = new List<string>();

                                foreach (string field in businessValidatorInfo.Fields.Split(','))
                                {
                                    fieldList.Add(jobject[field].ToString());
                                }

                                var businessValidationResult = _businessValidatorManager[businessValidatorInfo.Name].Validate(fieldList.ToArray());


                                jobject.Add("Validated", businessValidationResult.Validated);
                                jobject.Add("BusinessValidationResult", businessValidationResult.Message);

                                if (businessValidationResult.Validated == false)
                                {
                                    break;
                                }
                            }
                        }

                        jResult.Add(jobject);
                    }

                }

                validationResult.Validated = true;
                validationResult.Message = "File parsed successfully";
                validationResult.Data = jResult;

            }
            catch(FileFieldMissingException ffex)
            {
                validationResult.Validated = false;
                validationResult.Message = ffex.Message;
            }
            catch(ScreenValidatorNotFoundExeception svne)
            {
                validationResult.Validated = false;
                validationResult.Message = svne.Message;
            }
            catch(Exception ex)
            {
                validationResult.Validated = false;
                validationResult.Message = ex.Message;
            }

            message.InnerMessage = JsonConvert.SerializeObject(validationResult);
            
            return await Task.FromResult(message);
        }
    }
}
