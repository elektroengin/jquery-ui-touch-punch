﻿using Newtonsoft.Json.Linq;

namespace corf.blueprint.business.ExcelSample
{
    public class ScreenFileValidationResult
    {
        public bool Validated { get; set; }
        public string Message { get; set; }
        public JArray Data { get; set; }
    }
}