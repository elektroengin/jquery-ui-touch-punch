﻿using System;
using System.Runtime.Serialization;

namespace corf.blueprint.business.ExcelSample
{
    [Serializable]
    internal class ScreenValidatorNotFoundExeception : Exception
    {
        public ScreenValidatorNotFoundExeception()
        {
        }

        public ScreenValidatorNotFoundExeception(string screenCode) : base($"File validator with screen code {screenCode} not found !")
        {
        }

        public ScreenValidatorNotFoundExeception(string screenCode, Exception innerException) : base($"File validator with screen code {screenCode} not found !", innerException)
        {
        }
    }
}