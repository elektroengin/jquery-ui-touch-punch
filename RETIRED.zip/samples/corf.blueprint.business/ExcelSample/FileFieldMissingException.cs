﻿using System;
using System.Runtime.Serialization;

namespace corf.blueprint.business.ExcelSample
{
    [Serializable]
    internal class FileFieldMissingException : Exception
    {
        public FileFieldMissingException()
        {
        }

        public FileFieldMissingException(string screenCode, string key) : base($"Field(s) {key} couldn't be found in file that sent with screencode {screenCode}")
        {
        }
    }
}