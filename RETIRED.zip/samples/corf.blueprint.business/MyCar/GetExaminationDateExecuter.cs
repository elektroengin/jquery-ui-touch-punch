﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.MyCar
{
    public class GetExaminationDateExecuter : MultipleMessageCommand
    {
        public GetExaminationDateExecuter(ILogger<GetExaminationDateExecuter> logger) : base(logger)
        {
        }

        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            var data = JsonConvert.DeserializeObject<DummyCarData[]>(message.InnerMessage);

            InternalMessages.Clear();

            foreach (var subData in data)
            {
                InternalMessage internalMessage = new InternalMessage() { InnerMessage = JsonConvert.SerializeObject(subData) };
                InternalMessages.Enqueue(internalMessage);
            }


            return message;
        }
    }
}
