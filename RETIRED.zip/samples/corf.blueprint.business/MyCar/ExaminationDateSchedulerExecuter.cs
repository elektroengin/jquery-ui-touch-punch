﻿using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.MyCar
{
    public class ExaminationDateSchedulerExecuter : MultipleMessageCommand
    {
        public ExaminationDateSchedulerExecuter(ILogger<ExaminationDateSchedulerExecuter> logger) : base(logger)
        {
        }

        public async override Task<InternalMessage> Execute(InternalMessage message)
        {
            var message1 = new InternalMessage();
            message1.ChannelCustomParameters.Add("mode", "first");

            var message2 = new InternalMessage();
            message2.ChannelCustomParameters.Add("mode", "second");

            var message3 = new InternalMessage();
            message3.ChannelCustomParameters.Add("mode", "third");

            var message4 = new InternalMessage();
            message4.ChannelCustomParameters.Add("mode", "fourth");

            InternalMessages.Enqueue(message1);
            InternalMessages.Enqueue(message2);
            InternalMessages.Enqueue(message3);
            InternalMessages.Enqueue(message4);

            return await Task.FromResult(message);
        }
    }
}
