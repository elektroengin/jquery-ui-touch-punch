﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.MyCar
{
    public class DummyCarData
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}
