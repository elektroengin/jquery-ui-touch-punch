using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;


namespace corf.blueprint.business
{
    public class TcpClientExecuter : BusinessCommand
    {
        private MessageContainer _messageContainer;
        private static int i = 0;
        public TcpClientExecuter(ILogger<TcpClientExecuter> logger, MessageContainer container) : base(logger)
        {
            _messageContainer = container;
        }

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
            var unique = message.InnerMessage.Substring(4,30);

            var dualMessageUniqueChannel  ="";


            message.DualMessageUniqueChannel = dualMessageUniqueChannel;

           return  await Task.FromResult(message);
        }

        /// <summary>
        /// Validate method wruns before execution
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public override MessageValidationResult Validate(InternalMessage message)
        {
            //Custom validations here
            return base.Validate(message);
        }
    }
}

