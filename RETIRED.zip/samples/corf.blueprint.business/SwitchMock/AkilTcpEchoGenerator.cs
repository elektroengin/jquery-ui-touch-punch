    using corf.BinaryConverter;
using corf.Core.Commands;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Threading.Tasks;


namespace corf.blueprint.business
{
    public class AkilTcpEchoGenerator : ITcpEchoMessageGenerator
    {
        private MessageContainer _messageContainer;
        private static int i = 0;
        public AkilTcpEchoGenerator(ILogger<TcpServerExecuter> logger, MessageContainer container) 
        {
            _messageContainer = container;
        }
        public byte[] GetEchoMessage()
        {
            string unique = "700000000030383030A22000000000";
            String dateTimeFormatter = DateTime.Now.ToString("MMddHHmmss");
            String sHandShakeMsg = "0035700000000030383030A2200000000000000400000000000008373030303130" + DataConvert.BinaryToHexString(Encoding.ASCII.GetBytes(dateTimeFormatter)) + "363837393535333031303030";
            return DataConvert.HexStringToBinary(sHandShakeMsg);
        }
    }
}

