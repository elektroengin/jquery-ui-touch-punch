using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;


namespace corf.blueprint.business
{
    public class TcpServerExecuter : BusinessCommand
    {
        private MessageContainer _messageContainer;
        private static int i = 0;
        public TcpServerExecuter(ILogger<TcpServerExecuter> logger, MessageContainer container) : base(logger)
        {
            _messageContainer = container;
        }

        public override bool CheckDependentConnector => true;

        public override async Task<InternalMessage> Execute(InternalMessage message)
        {
           var result = Interlocked.Increment(ref i);
           message.InnerMessage = $"0019{result.ToString().PadLeft(30, '0')}{message.InnerMessage}";
           return  await Task.FromResult(message);
        }

        /// <summary>
        /// Validate method wruns before execution
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public override MessageValidationResult Validate(InternalMessage message)
        {
            //Custom validations here
            return base.Validate(message);
        }

        public async override Task<InternalMessage> GetSignOnMessage()
        {
            return  await Task.FromResult(new InternalMessage { InnerMessage = "0003010203" });
        }

        public async override Task<bool> CheckSignOnResult(InternalMessage message)
        {
            return await base.CheckSignOnResult(message);
        }
    }
}

