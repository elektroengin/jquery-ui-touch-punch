﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class ConnectorModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string EdgeDirection { get; set; }
        public PropertyDescryptor[] Properties { get; set; }
        public string Color { get; set; }
    }
}
