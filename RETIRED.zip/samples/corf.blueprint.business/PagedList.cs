﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
        public class PagedList<TResponse> : ModelList<TResponse>
        {
            public int PageIndex { get; set; }

            public int PageSize { get; set; }

            public int TotalItem { get; set; }
        }
}
