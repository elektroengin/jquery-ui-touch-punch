﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ApplicationIAM
{
    public class IAMConfiguration
    {
        public JObject TokenGeneratorService { get; set; }
        public IAMTokenCreateRequest CreateRequest { get; set; }
    }
}
