﻿using corf.Communication.ServiceCaller;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business.ApplicationIAM
{
    public class ApplicationIAMTokenServiceCaller : GenericServiceCaller<IAMTokenCreateRequest, IAMTokenCreateResponse>
    {
        IAMConfiguration _IAMConfiguration;

        public ApplicationIAMTokenServiceCaller(IAMConfiguration IAMConfiguration, ILogger<ApplicationIAMTokenServiceCaller> logger)
        {
            _IAMConfiguration = IAMConfiguration;

            this.Initialize(_IAMConfiguration.TokenGeneratorService, logger);
        }
    }
}
