﻿namespace corf.blueprint.business
{
    public class TransactionLifeCycleManager
    {
        public TransactionLifeCycleManager()
        {

        }

        public int Count { get; set; }
    }
}