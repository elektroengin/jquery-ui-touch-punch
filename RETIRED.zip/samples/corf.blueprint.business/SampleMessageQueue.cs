﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.business
{
    public class SampleMessageQueue : ConcurrentQueue<string>
    {
        private class Nested
        {
            static Nested() { }
            internal static readonly SampleMessageQueue instance = new SampleMessageQueue();
        }

        public static SampleMessageQueue Instance { get { return Nested.instance; } }

        public void Add(string uniq)
        {
            Enqueue(uniq);
        }

        public string Remove()
        {
            string result;
            return TryDequeue(out result) ? result : "";
        }

        private SampleMessageQueue()
        {
        }
    }
}
