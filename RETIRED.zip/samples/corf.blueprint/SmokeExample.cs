﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using corf.Core.Smoke;
using Newtonsoft.Json.Linq;

namespace corf.blueprint
{
    public class SmokeExample : SmokeTest
    {
        public SmokeExample(JObject testData) : base(testData)
        {
        }

        public override bool RunTest()
        {
            return true;
        }
    }
}
