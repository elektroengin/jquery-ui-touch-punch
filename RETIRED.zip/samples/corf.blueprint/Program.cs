﻿using corf.blueprint.business;
using corf.blueprint.business.ApplicationIAM;
using corf.blueprint.business.BusinessValidators;
using corf.blueprint.business.ExcelSample;
using corf.blueprint.Hsm;
using corf.Caching;
using corf.Caching.InMemory;
using corf.Communication.JWTTokenResolver;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using corf.Routing;
using Grpc.Net.Client.Balancer;
using Logging;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using Serilog;

namespace corf.blueprint
{
    class Program
    {
        private static string executablePath
        {
            get
            {
                if (!System.Diagnostics.Debugger.IsAttached)
                    return Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
                return Environment.CurrentDirectory;
            }
        }
        
        public static void Main(string[] args)
        {
            try
            {
                GenericHostContainer.Instance
                    .AddConfigurationFile("appsettings.json")
                    .AddConfigMapFile("appSettings.ConfigMap.json")
                    .AddConfigurationFile("serilog.json")
                    //.AddConfigurationFile("springadmin.json")   //comment out this line, if rally sentinel is not installed in your local pc. Otherwise app won't start.!!!
                    //.AddConfigurationFile("distributedtracing.json")//comment out this line, if you wil not use distrubuted tracing
                    .SetConfiguration(executablePath)
                    .AddSingleton<IMetricMonitoringLogAdapter, MetricMonitoringLogAdapter>()
                    .AddSingleton<RestMirrorExecuter2>()
                    .AddSingleton<ResolverFactory>(sp => new DnsResolverFactory(refreshInterval: TimeSpan.FromSeconds(30)))
                    .AddSingleton<MonitoringCommandSample1>()
                    .AddSingleton<TransactionLifeCycleManager>()
                    .AddSingleton<MerchantValidator>()
                    .AddSingleton<IHsmManager, HsmManager>()
                    //.AddSingleton<HsmClientConnector>()
                    .AddSingleton<AddressValidator>()
                    .AddSingleton<JWTTokenResolver>()
                    .AddSingleton<MessageContainer>()
                    .AddSingleton<SampleTcpEchoGenerator>()
                    .AddSingleton<corf.Communication.Rest.Client.ApplicationIAM.ApplicationIAM.ApplicationIAMTokenServiceCaller>()
                    .AddSingleton<IMemoryCache, MemoryCache>()
                    .AddSingleton<IMemoryCacheService, MemoryCacheService>()
                    .AddSingleton<ICacheManager, CacheManager>()
                    .AddScoped<ScopedContextEntity>()
                    .AddScoped<ExcelExecuter>()
                    //.ConfigureSection<UriMapContainer>("iam-token-settings")
                    .Configure<LogConfiguration>("log-configuration")
                    .CreateBuilder(args, CreateLogConfiguration)
                //GenericHostContainer.Instance.AddSmokeTest(new SmokeExample(new JObject() { {"asd", "ff" } }))
                .RunAsService();
                GenericHostContainer.Instance.RunAsService();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}::::::::{1}", ex.Message, ex.StackTrace);
            }

            Console.ReadLine();

        }
      
        static void CreateLogConfiguration(IHostBuilder hostBuilder, IGenericHostContainer genericHostContainer)
        {
            /*
            --------------------------- NLog --------------------------------
            //Use Nlog.json file to customize your logging

            genericHostContainer.AddConfigurationFile("nlog.json");
            hostBuilder = hostBuilder.UseNLog(new NLogAspNetCoreOptions()
            {
                LoggingConfigurationSectionName = "NLog"
            });
            --------------------------- NLog -------------------------------- 
            */

            //Serilog
            //Use serilog.json file to customize your logging

            hostBuilder = hostBuilder.UseSerilog((context, services, configuration) => configuration
                   .ReadFrom.Configuration(context.Configuration)
                   .ReadFrom.Services(services));


        }
    }
}
