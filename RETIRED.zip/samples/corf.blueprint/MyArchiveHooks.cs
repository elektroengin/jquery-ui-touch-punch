﻿using Serilog.Sinks.File.Archive;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint
{
    public class MyArchiveHooks : ArchiveHooks
    {
        public MyArchiveHooks() : base(System.IO.Compression.CompressionLevel.Fastest, "C:\\Loglar\\corf-blueprint\\Trace\\archive")
        {
            
        }
    }
}
