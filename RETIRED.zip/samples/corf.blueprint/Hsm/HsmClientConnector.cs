﻿using corf.Communication.Tcp.Client;
using corf.Core.Hosting;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.Hsm
{
    public class HsmClientConnector : TcpClientConnector
    {
        public HsmClientConnector(ILogger<TcpClientConnector> logger, ITcpClientCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, communicator, provider, requestScopeManager)
        {

        }

        public override Task<bool> ConnectAsync()
        {
            this.Port = "2205";
            this.Address = "127.0.0.1";
            this.CheckHeader = true;
            this.HeaderLength = 2;
            ReceiveAsync();
            return base.ConnectAsync();
        }

        public override void FireMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs)
        {
            base.FireMessageReceived(messageReceivedEventArgs);
        }
    }
}
