﻿namespace corf.blueprint.Hsm
{
    public interface IHsmManager
    {
    }
}