﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint.Hsm
{
    public class HsmManager : IHsmManager
    {
        public HsmManager(ILogger<HsmManager> logger, HsmClientConnector hsmClientConnector)
        {
            hsmClientConnector.ConnectAsync().Wait();
        }
    }
}
