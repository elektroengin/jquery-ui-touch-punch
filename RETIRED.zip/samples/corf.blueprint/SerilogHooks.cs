﻿using Serilog.Sinks.File.Archive;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.blueprint
{
    public class SerilogHooks 
    {
        public static ArchiveHooks MyArchiveHooks => new ArchiveHooks(CompressionLevel.NoCompression, "C:\\Loglar\\corf-blueprint\\Trace\\archive");
    }
}
