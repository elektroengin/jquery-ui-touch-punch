﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace corf.Core.Hosting
{
    public static class HostingContextExtensions
    {

        public static IGenericHostContainer AddDbContext<TContext>(this IGenericHostContainer hostContainer, Action<DbContextOptionsBuilder> optionsAction = null, ServiceLifetime contextLifetime = ServiceLifetime.Scoped, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped) where TContext : DbContext
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContext>(optionsAction, contextLifetime, optionsLifetime);
            return hostContainer;
        }
        public static IGenericHostContainer AddDbContext<TContext>(this IGenericHostContainer hostContainer, ServiceLifetime contextLifetime, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped) where TContext : DbContext
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContext>(contextLifetime, optionsLifetime);
            return hostContainer;
        }
        public static IGenericHostContainer AddDbContext<TContext>(this IGenericHostContainer hostContainer, Action<IServiceProvider, DbContextOptionsBuilder> optionsAction, ServiceLifetime contextLifetime = ServiceLifetime.Scoped, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped) where TContext : DbContext
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContext>(optionsAction, contextLifetime, optionsLifetime);
            return hostContainer;
        }
        public static IGenericHostContainer AddDbContext<TContextService, TContextImplementation>(this IGenericHostContainer hostContainer, Action<DbContextOptionsBuilder> optionsAction = null, ServiceLifetime contextLifetime = ServiceLifetime.Scoped, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped) where TContextImplementation : DbContext, TContextService
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContextService, TContextImplementation>(optionsAction, contextLifetime, optionsLifetime);
            return hostContainer;
        }
        public static IGenericHostContainer AddDbContext<TContextService, TContextImplementation>(this IGenericHostContainer hostContainer, ServiceLifetime contextLifetime, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped)
            where TContextService : class
            where TContextImplementation : DbContext, TContextService
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContextService, TContextImplementation>(contextLifetime, optionsLifetime);
            return hostContainer;
        }
        public static IGenericHostContainer AddDbContext<TContextService, TContextImplementation>(this IGenericHostContainer hostContainer, Action<IServiceProvider, DbContextOptionsBuilder> optionsAction, ServiceLifetime contextLifetime = ServiceLifetime.Scoped, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped) where TContextImplementation : DbContext, TContextService
        {
            hostContainer.ExternalDescriptors.AddDbContext<TContextService, TContextImplementation>(optionsAction, contextLifetime, optionsLifetime);
            return hostContainer;
        }
    }
}
