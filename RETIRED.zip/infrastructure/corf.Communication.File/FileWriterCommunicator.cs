﻿using corf.Core;
using corf.Core.Messaging;
using Microsoft.AspNetCore.Mvc.Formatters;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.File
{
    public class FileWriterCommunicator : IFileWriterCommunicator
    {
        public bool IsConnected { get { return true; } }

        public IConnector Connector { get; private set; }

        Dictionary<string,StreamWriterHolder> _streamWriters = new Dictionary<string, StreamWriterHolder>();

        private static object _lock = new object();

        private int _messagesSize = 0;

        public bool Initialized { get; private set; }

        public async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            Initialized = true; 
            return true;
        }

        public void GetReady()
        {
        }

        public void Initialize(Connector connector)
        {
            Connector = connector;
        }

        protected FileWriterConnector FileWriterConnector { get { return (FileWriterConnector)Connector; } }

        public bool Send(InternalMessage message)
        {

            Task<bool> asyncTask = SendAsync(message);
            asyncTask.Wait();
            return asyncTask.Result;
        }

        public async Task<bool> SendAsync(InternalMessage message)
        {
            lock(_lock)
            {
                StreamWriterHolder streamWriterHolder;

                string fileName = FileWriterConnector.Path;

                if (message.Headers.ContainsKey("FileName"))
                {
                    fileName = fileName.Replace("#FileName", message.Headers["FileName"].ToString());
                }
                
                if (_streamWriters.ContainsKey(fileName))
                {
                    streamWriterHolder = _streamWriters[fileName];
                }
                else
                {
                    streamWriterHolder = new StreamWriterHolder(fileName, Encoding.GetEncoding(FileWriterConnector.Encoding));
                    _streamWriters.Add(fileName, streamWriterHolder);
                }

                streamWriterHolder.Write(message.InnerMessage, FileWriterConnector.MessageDelimiter);


                if (FileWriterConnector.BulkSize <= 1 || streamWriterHolder.MessagesCount == FileWriterConnector.BulkSize)
                {
                    streamWriterHolder.Dispose();
                    _streamWriters.Remove(fileName);
                }
            }

            return await Task.FromResult(true);
        }
    }
}
