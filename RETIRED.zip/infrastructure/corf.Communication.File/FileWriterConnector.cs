﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.File
{
    public class FileWriterConnector : DualConnector, IFileConnector
    {
        private readonly IFileWriterCommunicator _communicator;

        public FileWriterConnector(ILogger<FileWriterConnector> logger, IFileWriterCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string Path { get; set; } = string.Empty;
        public string MessageDelimiter { get; set; } = Environment.NewLine;
        public string Encoding { get; set; } = "UTF-8";

        [FlowDesign(EnvironmentBasedVariable = true)]
        public int BulkSize { get; set; }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }

        [FlowDesign(Display = false)]
        public override string ChannelDescription
        {
            get { return $"FilePath : {Path}, BulkSize : {BulkSize}, Encoding : {Encoding}, Delimiter : {MessageDelimiter}"; }
        }
    }
}
