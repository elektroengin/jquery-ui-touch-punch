﻿using corf.Core.Infrastructure;

namespace corf.Communication.File
{
    public interface IFileWriterCommunicator : IMessageSender
    {
    }
}