﻿using Confluent.Kafka;
using System;
using System.IO;
using System.Text;

namespace corf.Communication.File
{
    public class StreamWriterHolder 
    {
        public StreamWriterHolder(string path, Encoding encoding)
        {
            StreamWriter = new StreamWriter(path, true, encoding)
            {
                AutoFlush = false
            };
        }

        public int MessagesCount { get; internal set; }
        public StreamWriter StreamWriter { get; private set; }

        public void Dispose()
        {
            StreamWriter.Flush();
            StreamWriter.Close();
            StreamWriter.Dispose();
        }

        public void Write(string text, string delimiter)
        {
            if (delimiter == "Environment.NewLine")
            {
                StreamWriter.WriteLine(text);
            }
            else
            {
                StreamWriter.Write($"{text}{delimiter}");
            }

            MessagesCount++;
        }
    }
}