﻿
using System.Text;

namespace corf.Communication.File
{
    public interface IFileConnector
    {
        string Path { get; set; }
        string MessageDelimiter { get; set; }
        string Encoding { get; set; }
        int BulkSize { get; set; }  
    }
}