﻿using corf.BinaryConverter;
using corf.Configuration;
using corf.Core.Messaging;
using Experimental.System.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace corf.Communication.Msmq
{
    public class MsmqReceiveCommunicator : MsmqCommunicator, IMsmqReceiveCommunicator
    {

        public MsmqReceiveCommunicator(ILogger<MsmqReceiveCommunicator> logger) : base(logger)
        {
        }
        public async Task<InternalMessage> ReceiveMessage()
        {
            InternalMessage result = null;

            try
            {
                if (DestinationChannel != null && ReadyForRead)
                {
                    Message msMqMessage = DestinationChannel.Receive(waitForRead);

                    if (msMqMessage == null || msMqMessage.BodyStream.Length <= 0)
                    {
                        return result;
                    }

                    byte[] extension = msMqMessage.Extension;

                    byte[] bodyStream = new byte[msMqMessage.BodyStream.Length];

                    

                    msMqMessage.BodyStream.Read(bodyStream, 0, (int)msMqMessage.BodyStream.Length);

                    string serializedBody = string.Empty;

                    if (Connector.InnerMessageType == "Hex")
                    {
                        serializedBody = DataConvert.BinaryToHexString(bodyStream);
                    }
                    else
                    {
                        serializedBody = DataConvert.ByteToString(bodyStream);
                    }

                    if (MsmqConnector.InternalPayload)
                    {
                        result = JsonConvert.DeserializeObject<InternalMessage>(serializedBody);
                    }
                    else
                    {
                        result = new InternalMessage() { InnerMessage = serializedBody, DualMessageUniqueChannel = msMqMessage.AppSpecific.ToString() };
                    }

                    if (msMqMessage.ResponseQueue != null)
                    {
                        try
                        {
                            result.InternalReplyQueue = msMqMessage.ResponseQueue.QueueName.Replace("private$","").Replace("\\","");
                        }
                        catch(MessageQueueException mqe)
                        {
                            _logger.LogError(mqe, "{unique} | Response queue error. | {additionalMessage}.", LoggerUnique.CorfCore, $"Receive from[{ToString()}] had function exception[{mqe.Message}][{mqe.MessageQueueErrorCode}]");
                        }

                    }

                    result.AppSpecific = msMqMessage.AppSpecific;

                    if (result.AdditionalInfo == null)
                    {
                        result.AdditionalInfo = new MessageAdditionalInfo();
                        result.AdditionalInfo.ExtensionData = extension;
                    }
                }
                return result;
            }
            catch (MessageQueueException mqe)
            {
                if (mqe.MessageQueueErrorCode != MessageQueueErrorCode.IOTimeout)
                {
                    _logger.LogError(mqe,"{unique} | Receiving failed. | {additionalMessage}.", LoggerUnique.CorfCore, $"Receive from[{ ToString()}] had function exception[{ mqe.Message}][{ mqe.MessageQueueErrorCode}]");
                    await CloseAsync();
                }
            }
            catch (Exception exc)
            {
                _logger.LogError(exc, "{unique} | Receiving failed. | {additionalMessage}", LoggerUnique.CorfCore, $"Receive from[{ ToString()}] had function exception[{ exc.Message}]");

            }
            return null;
        }
    }
}
