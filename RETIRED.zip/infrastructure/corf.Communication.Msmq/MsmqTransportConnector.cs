﻿using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Msmq
{
    public class MsmqTransportConnector : MsmqDualConnector
    {
        public MsmqTransportConnector(ILogger<MsmqTransportConnector> logger, IMsmqTransportCommunicator msmqCommunicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, msmqCommunicator, provider, requestScopeManager)
        {
        }
    }
}
