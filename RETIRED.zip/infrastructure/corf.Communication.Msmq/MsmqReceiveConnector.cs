﻿using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Msmq
{
    public class MsmqReceiveConnector : MsmqDualConnector
    {
        public MsmqReceiveConnector(ILogger<MsmqReceiveConnector> logger, IMsmqReceiveCommunicator msmqCommunicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, msmqCommunicator, provider, requestScopeManager)
        {
        }
    }
}
