﻿using corf.Core;
using corf.Core.Messaging;
using Experimental.System.Messaging;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace corf.Communication.Msmq
{
    public abstract class MsmqCommunicator 
    {
        protected readonly ILogger<MsmqCommunicator> _logger;

        protected MessageQueue DestinationChannel;

        private ConcurrentQueue<InternalMessage> _incomingQueue = null;

        public bool IsConnected
        {
            get
            {
                return DestinationChannel != null && (DestinationChannel.CanRead || DestinationChannel.CanWrite);
            }
        }
        public bool ReadyForRead
        {
            get
            {
                return DestinationChannel != null && DestinationChannel.CanRead;
            }
        }

        public IConnector Connector { get; private set; }


        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
        }

        public bool Initialized { get; private set; }


        public MsmqCommunicator(ILogger<MsmqCommunicator> logger)
        {
            _logger = logger;
        }

        public async Task<bool> CloseAsync()
        {
            if (DestinationChannel != null)
            {
                DestinationChannel.Close();
                DestinationChannel.Dispose();
                DestinationChannel = null;
            }

            return await Task.FromResult<bool>(true);
        }


        public async Task<bool> ConnectAsync()
        {
            try
            {
                DestinationChannel = new MessageQueue(Path,QueueAccessMode.SendAndReceive);

                if (DestinationChannel == null)
                {
                    throw new Exception($"Could Not Connect to Queue {MsmqConnector.ChannelDescription}");
                }

                DestinationChannel.MessageReadPropertyFilter.SetAll();

                if (!DestinationChannel.CanRead && !DestinationChannel.CanWrite)
                {
                    DestinationChannel.Refresh();
                }
                return await Task.FromResult<bool>(true);

            }
            finally
            {
                Initialized = true;
            }
        }

        public MsmqDualConnector MsmqConnector
        {
            get
            {
                return (MsmqDualConnector)Connector;
            }
        }

        protected TimeSpan waitForRead = new TimeSpan(0, 0, 0, 0, 80);

        public bool UseDeathLetterQueue { get; set; }
        public void GetReady()
        {
            _incomingQueue = new ConcurrentQueue<InternalMessage>();

            _logger.LogInformation("{unique} | Connecting to queue", MsmqConnector.ChannelDescription);


            waitForRead = new TimeSpan(0, 0, 0, 0, MsmqConnector.TimeOut);

            UseDeathLetterQueue = false;

            if (String.IsNullOrEmpty(MsmqConnector.Host))
            {
                throw new Exception("Host is null or empty!");
            }
            if (String.IsNullOrEmpty(MsmqConnector.QueueName))
            {
                throw new Exception("MqName is null or empty!");
            }
            Path = GetQueueFormatName(MsmqConnector.Host, MsmqConnector.QueueName);
        }

        public bool Recoverable { get; set; }

        public string Path { get; private set; }

        public static string GetQueueFormatName(string hostName, string mqName)
        {
            if (hostName == "." || hostName == "127.0.0.1" || hostName == "localhost")
            {
                string machineName = Environment.MachineName;
                if (String.IsNullOrEmpty(machineName))
                    machineName = "localhost";
                return "FormatName:DIRECT=OS:" + machineName + "\\" + mqName;
            }
            return "FormatName:DIRECT=TCP:" + hostName + "\\" + mqName;
        }
    }
}
