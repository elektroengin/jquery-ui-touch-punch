﻿using corf.Core.Infrastructure;

namespace corf.Communication.Msmq
{
    public interface IMsmqReceiveCommunicator : IEndlessReceiver
    {
    }
}
