﻿using corf.Core.Infrastructure;

namespace corf.Communication.Msmq
{
    public interface IMsmqTransportCommunicator : IMessageSender
    {
    }
}
