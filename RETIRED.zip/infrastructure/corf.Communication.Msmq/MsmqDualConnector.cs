﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Msmq
{
    public abstract class MsmqDualConnector : DualConnector
    {
        ICommunicator _communicator;
        protected MsmqDualConnector(ILogger logger, ICommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }
        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }
        public override bool IsHealthy
        {
            get
            {
                return _communicator.IsConnected;
            }
        }
        public override string ChannelDescription
        {
            get
            {
                return $"{Host}:{QueueName}";
            }
        }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string Host { get; set; }
        public string QueueName { get; set; }
        public string Label { get; set; }
    }
}
