﻿using corf.BinaryConverter;
using corf.Configuration;
using corf.Core.Messaging;
using Experimental.System.Messaging;
using Microsoft.Extensions.Logging;

namespace corf.Communication.Msmq
{
    public class MsmqTransportCommunicator : MsmqCommunicator, IMsmqTransportCommunicator
    {
        public MsmqTransportCommunicator(ILogger<MsmqTransportCommunicator> logger) : base(logger)
        {
        }

        public bool Send(InternalMessage message)
        {
            try
            {
                var msMqMessage = new Message { TimeToBeReceived = Message.InfiniteTimeout, UseDeadLetterQueue = UseDeathLetterQueue };

                msMqMessage.BodyStream.Write(message.BinaryMessage, 0, message.BinaryMessage.Length);

                msMqMessage.Recoverable = Recoverable;

                if (!string.IsNullOrWhiteSpace(message.InternalReplyQueue))
                {
                    msMqMessage.ResponseQueue = new MessageQueue(MsmqCommunicator.GetQueueFormatName(".", $"private$\\{message.InternalReplyQueue}"));
                }

                msMqMessage.AppSpecific = message.AppSpecific;

                msMqMessage.Extension = DataConvert.StringToByte(message.Unique);

                int dualMessageUniqueChannel = 0;

                int.TryParse(message.DualMessageUniqueChannel, out dualMessageUniqueChannel);

                msMqMessage.AppSpecific = dualMessageUniqueChannel;

                DestinationChannel.Send(msMqMessage, MsmqConnector.Label, MessageQueueTransactionType.None);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "{unique} | msmq send exception! | {additionalMessage}", LoggerUnique.CorfCore, $"Reason[{exception.Message}] for [{ToString()}]");

                return false;
            }
            return true;
        }

        public Task<bool> SendAsync(InternalMessage message)
        {
            return Task.FromResult(Send(message));
        }
    }
}
