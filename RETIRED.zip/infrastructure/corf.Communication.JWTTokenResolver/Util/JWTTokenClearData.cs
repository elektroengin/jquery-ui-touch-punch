using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.JWTTokenResolver.Util
{
    public class JWTTokenClearData
    {
        public XRlyJwtTokenHeader? XRlyJwtTokenHeader { get; set; }
        public XRlyJwtTokenBody? XRlyJwtTokenBody { get; set; }
    }
}
