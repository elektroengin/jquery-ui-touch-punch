using Newtonsoft.Json;

namespace corf.Communication.JWTTokenResolver.Util
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class XISBCustomHeader
    {
        [JsonProperty("baas-cc-v1")]
        public BaasCcv1 baasCcv1 { get; set; } 

        [JsonProperty("baas-v1")]
        public Baasv1 baasv1 { get; set; } 
    }

    public class BaasCcv1
    {
        public string consumerCode { get; set; }
        public string agentId { get; set; }
    }

    public class Baasv1
    {
        public string consumerCode { get; set; }
    }
}
