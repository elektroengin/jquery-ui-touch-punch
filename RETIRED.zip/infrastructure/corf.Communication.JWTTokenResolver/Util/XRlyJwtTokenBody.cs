using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;
using System.Xml.Linq;
using System.Text.Json;

namespace corf.Communication.JWTTokenResolver.Util
{

    public class Realm_access
    {
        public IList<string> roles { get; set; }

    }
    public class Account
    {
        public IList<string> roles { get; set; }

    }
    public class Resource_access
    {
        public Account account { get; set; }
    }



    [JsonObjectAttribute]
    public class XRlyJwtTokenBody
    {
        public int exp { get; set; }
        public int iat { get; set; }
        public string jti { get; set; }
        public string iss { get; set; }
        public object aud { get; set; }
        public string sub { get; set; }
        public string typ { get; set; }
        public string azp { get; set; }
        public string session_state { get; set; }
        public string acr { get; set; }

        [JsonProperty("allowed-origins")]
        public IList<string> allowed_origins { get; set; }
        public Realm_access realm_access { get; set; }
        public Resource_access resource_access { get; set; }
        public string scope { get; set; }
        public string sid { get; set; }
        public string plt_cid { get; set; }
        
        public string plt_tc { get; set; }

        [JsonProperty("plt_idn")]
        public string IdentityNumber { get; set; }
        [JsonProperty("plt_cn")]
        public string CustomerNumber { get; set; }
        [JsonProperty("plt_tid")]
        public string TenantID { get; set; }
        public bool email_verified { get; set; }
        public string plt_tn { get; set; }
        public string name { get; set; }
        public string preferred_username { get; set; }
        public string given_name { get; set; }
        public string family_name { get; set; }
        public string token_username { get; set; }

    }
}