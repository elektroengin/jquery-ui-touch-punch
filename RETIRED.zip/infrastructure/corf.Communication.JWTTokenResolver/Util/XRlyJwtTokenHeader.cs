

namespace corf.Communication.JWTTokenResolver.Util
{
  
    public class XRlyJwtTokenHeader
    {
        public string alg { get; set; }
        public string typ { get; set; }
        public string kid { get; set; }
    }
}
