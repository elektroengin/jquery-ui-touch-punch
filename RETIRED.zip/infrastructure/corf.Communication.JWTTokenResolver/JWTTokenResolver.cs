
using corf.Communication.JWTTokenResolver.Util;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
namespace corf.Communication.JWTTokenResolver
{
    public class JWTTokenResolver 
    {

        public JWTTokenClearData ResolveToken(string token)
        {
            JWTTokenClearData jwtTokenClearData = new JWTTokenClearData();
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token) as JwtSecurityToken;

            if (jsonToken != null)
            {
                jwtTokenClearData.XRlyJwtTokenHeader = JsonConvert.DeserializeObject<XRlyJwtTokenHeader>(jsonToken.Header.SerializeToJson());
                jwtTokenClearData.XRlyJwtTokenBody = JsonConvert.DeserializeObject<XRlyJwtTokenBody>(jsonToken.Payload.SerializeToJson());
            }
            else
            {
                throw new Exception("Invalid JWT format.");
            }
            return jwtTokenClearData;
        }

       
    }
}
