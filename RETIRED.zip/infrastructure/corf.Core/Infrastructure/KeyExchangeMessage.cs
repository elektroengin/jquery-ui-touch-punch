﻿namespace corf.Core.Infrastructure
{
    public class KeyExchangeMessage
    {
        public string Key { get; set; } = string.Empty;
        public int KeyIndex { get; set; }
        public string KeyCheckValue { get; set; } = string.Empty;
    }
}
