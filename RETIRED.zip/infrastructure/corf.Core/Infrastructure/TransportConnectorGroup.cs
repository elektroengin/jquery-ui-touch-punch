﻿using corf.Core.Messaging;

namespace corf.Core
{
    public class TransportConnectorGroup : List<ITransportConnector>
    {
        public bool IsFailover { get; set; }
        public string GroupName { get; set; } = string.Empty;
        public DateTime LastSent { get; set; }

        public bool IsSignatory { get; set; }

        public ITransportConnector GetSuitableConnector(InternalMessage message, string destination, string? discard = null)
        {
            ITransportConnector connector = this.Where(_ => (string.IsNullOrWhiteSpace(discard) || _.Name != discard) 
                                                            && (((IConnectionController)_).IsConnected && (string.IsNullOrWhiteSpace(destination) || destination.Split(',').Contains(_.Name) || destination.Split(',').Contains(_.Group))) 
                                                            && (string.IsNullOrWhiteSpace(message.ReceiverChannelId) || !message.ReturnToReceiverChannel || (_.Name == message.ReceiverChannelId)))
                                                            .Aggregate((t1, t2) => t1.LastSent < t2.LastSent ? t1 : t2);

            return connector;
        }
    }
}
