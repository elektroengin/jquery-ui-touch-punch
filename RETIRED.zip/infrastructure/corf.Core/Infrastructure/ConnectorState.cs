﻿namespace corf.Core
{
    public enum ConnectorState : byte
    {
        Created = 0,
        Connecting = 1,
        Connected = 2,
        Disconnecting = 3,
        Disconnected = 4,
        Faulted = 5
    }
}