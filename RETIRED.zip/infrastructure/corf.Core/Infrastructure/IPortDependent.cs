﻿namespace corf.Core.Infrastructure
{
    public interface IPortDependent
    {
        int Port { get; set; }
        bool PortManagementAssigned { get; }
        IPortManagementService PortManagementService { get; }
        string PortManagementServiceAssembly { get; set; }
        void UpdatePortHealtyState();
    }
}
