﻿using corf.Core.Commands;
using corf.Core.Messaging;
using corf.Core.Smoke;
using Microsoft.Extensions.Logging;
using System.Net;

namespace corf.Core.Infrastructure
{
    public class SmokeTestExecuter : BusinessCommand, ISmokeTestExecuter
    {
        private readonly SmokeTestContainer _smokeTests;
        public SmokeTestExecuter(ILogger logger, SmokeTestContainer smokeTests) : base(logger)
        {
            _smokeTests = smokeTests;
        }

        public override Task<InternalMessage> Execute(InternalMessage message)
        {
            message.StatusCode = HttpStatusCode.OK;

            _smokeTests.ForEach(smokeTest =>
            {
                if (smokeTest.RunTest() is false)
                {
                    Logger.LogError($"{smokeTest.GetType().Name} test failed");

                    message.StatusCode = HttpStatusCode.InternalServerError;
                }
            });

            return Task.FromResult(message);
        }


    }
}
