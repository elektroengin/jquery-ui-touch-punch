﻿namespace corf.Core.Infrastructure
{
    public interface IPortManagementService
    {
        Task<PortInfo> GetAvailableConnection(string destination, string machineName);
        Task<bool> IsPortAvaible(string destination, string address, string port, string machineName);
        Task<PortInfo> GetPortWithConnectToPort(string destination, string address, string port);

        ConnectionClosedResult ConnectionDropped(string destination, string address, string port, string machineName);
        Task<bool> ConnectionEstablished(string destination, string address, string port, string machineName);

        Task<bool> UpdateAttributes(string destination, string address, string port, string attributes);
        Task<bool> UpdateAttributesForDestination(string destination, string attributes);
        Task<bool> UpdateSignOnStatus(string destination, string address, string port, bool signonStatus);
        bool UpdateLastHealthCheck(string destination, string address, string port, string machineName);

    }
}
