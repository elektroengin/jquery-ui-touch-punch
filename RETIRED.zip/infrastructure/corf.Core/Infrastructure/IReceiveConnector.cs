﻿using corf.Core.Messaging;
using corf.Core.Routing;

namespace corf.Core
{
    public interface IReceiveConnector  : IMessagePublisher
    {
        bool LongRunningExecution { get; set; }
        bool EndlessReceive { get; }
        Task ReceiveAsync();
        string PrerequisiteConnectors { get; set; }
        bool AllowAsyncSteps { get; set; }
    }

    public interface IMessagePublisher : IConnectionController
    {
        event EventHandler<MessageReceivedEventArgs> MessageReceived;
        int ExecutingMessagesCount { get; }
        void AddMessage();
        void RemoveMessage();
        string OnReceiveCommandAssembly { get; }
        IConnectionController[] DependentTo { get; set; }
    }
}
