﻿using corf.Core.Infrastructure;
using corf.Core.Routing;

namespace corf.Core
{
    public interface IConnector 
    {
        Guid Unique { get; }
        string Name { get; set; }
        string Group { get; set; }
        bool IsActive { get; }
        string Title { get; set; }
        string Description { get; set; }

        IServiceProvider ServiceProvider { get; set; }
        T GetCommand<T>(string assembly, string? scopeIdentity = null);
        void Initialize();
        ICommunicator Communicator { get; }
        string InnerMessageType { get; set; }
        string ChannelDescription { get; }
        string MonitoringCommand { get; set; }
        string MonitoringCommandAssembly { get; }
        public bool InternalPayload { get; set; }

        IRoute Route { get; set; }
        MachineSpecificInfo MachineSpecificInfo { get; set; }

    }
}