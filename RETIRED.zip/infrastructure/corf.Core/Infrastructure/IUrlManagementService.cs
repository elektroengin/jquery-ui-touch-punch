﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Core.Infrastructure
{
    public interface IUrlManagementService
    {
        Task<bool> IsConnectionStill(string queueType);
        Task<bool> UpdateLastHealthCheck(string queueType);
        Task<(string BaseAddress, string Path)> OpenConnection(string connectionType = "");
        Task<bool> CloseConnection(string queueType);
        Task<string> GetDestinationAddress(string queueType);
        Task OpenConnectionPod();
        Task<bool> IsConnectionPod();
        Task<bool> CloseConnectionPod();
        Task<bool> UpdateLastHealthCheckPod();
        Task<int> GetPodIndex();
        Task<int> GetMaxPodIndex();
    }
}
