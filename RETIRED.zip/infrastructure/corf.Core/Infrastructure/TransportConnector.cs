﻿using corf.Configuration;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Core
{
    public abstract class TransportConnector : Connector, ITransportConnector
    {
        public TransportConnector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {

        }
        /// <summary>
        /// LastSent
        /// </summary>
        [FlowDesign(Display = false)]
        public DateTime LastSent { get; set; }

        public string ReceiverChannelId { get; set; } = string.Empty;

        public bool ReturnToReceiverChannel { get; set; }

        [FlowDesign(Display = false)]
        public bool IsSignatory { get; set; }

        [FlowDesign(IsExecuterDefinition = true)]
        public string PostCommand { get; set; } = string.Empty;

        private string _postCommandAsembly = "";
        private bool _postCommandSet = false;

        [FlowDesign(Display = false)]
        public string PostCommandAssembly
        {
            get
            {
                if (!_postCommandSet)
                {
                    _postCommandAsembly = Configurator.GetExecuterAssembly(PostCommand);
                    _postCommandSet = true;
                }
                return _postCommandAsembly;
            }
        }

        public event EventHandler<MessageSentEventArgs>? MessageSent;

        /// <summary>
        /// Send message to destination
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task<bool> SendAsync(InternalMessage message)
        {
            Logger.LogDebug("{unique} | Message is sending to channel. | {additionalMessage}", message.Unique, $"[{this.Name} - {message.Unique}] with content : {message.InnerMessage}");

            var result = ((IMessageSender)CommunicatorInstance).SendAsync(message);

             Logger.LogInformation("{unique} | Sending completed. | {additionalMessage}", message.Unique, $"Result : [{result}]. [{this.Name} - {message.Unique}]");

            return await result;
        }
    }
}
