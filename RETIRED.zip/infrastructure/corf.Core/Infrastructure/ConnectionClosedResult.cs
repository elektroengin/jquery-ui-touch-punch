﻿namespace corf.Core.Infrastructure
{
    public class ConnectionClosedResult
    {
        public bool IsCompleted { get; set; }
    }
}