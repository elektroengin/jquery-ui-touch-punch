﻿using Newtonsoft.Json;

namespace corf.Core.Http
{
    public class HttpsRuleDefination : HttpRuleDefination
    {

        [JsonConstructor]
        public HttpsRuleDefination()
        {

        }

        public CertificateInfo Certificate { get; set; }
    }
}