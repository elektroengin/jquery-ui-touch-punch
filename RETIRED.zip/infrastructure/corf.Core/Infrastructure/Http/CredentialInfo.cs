﻿using System.Runtime.Serialization;

namespace corf.Core.Http
{
    [Serializable]
    public class CredentialInfo
    {
        [DataMember(Name = "username")]
        public string UserName { get; set; } = string.Empty;
        [DataMember(Name = "password")]
        public string Password { get; set; } = string.Empty;
    }
}