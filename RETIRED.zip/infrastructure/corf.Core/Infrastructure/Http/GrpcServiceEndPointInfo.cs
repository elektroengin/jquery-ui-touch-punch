﻿namespace corf.Core.Http
{
    public class GrpcServiceEndPointInfo : HttpEndPointInfo
    {
    }
}