﻿namespace corf.Core.Http
{
    public interface IHttpServerConnector
    {
        string AuthenticatonInfo { get; set; }

        HttpRootAddress RootAddress { get; set; }

        string ResponseHeaders { get; set; }

        ServerAuthenticatonInfo ServerAuthenticatonInfo { get; set; }
        bool AllowAnyCors { get; set; }
    }
}
