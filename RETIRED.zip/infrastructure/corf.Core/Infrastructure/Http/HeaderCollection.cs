﻿namespace corf.Core.Http
{
    public class HeaderCollection : Dictionary<string, string>
    {
    }
}