﻿using corf.Configuration;
using Newtonsoft.Json;

namespace corf.Core.Http
{
    public class HttpRuleDefination
    {
        [JsonConstructor]
        public HttpRuleDefination()
        {

        }

        [FlowDesign(DefaultValue = 2205)]

        public int Port { get; set; }
    }
}