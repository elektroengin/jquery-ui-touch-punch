﻿using Newtonsoft.Json;

namespace corf.Core.Http
{
    public class CertificateInfo
    {

        [JsonConstructor]
        public CertificateInfo()
        {

        }
        public string Path { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}