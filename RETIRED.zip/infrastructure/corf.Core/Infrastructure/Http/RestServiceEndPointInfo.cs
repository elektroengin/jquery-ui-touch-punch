﻿namespace corf.Core.Http
{
    public class RestServiceEndPointInfo : HttpEndPointInfo
    {
        public string Verb { get; set; } = string.Empty;
       
        //public string AuthType { get; set; }
        //public CredentialInfo Credentials { get; set; }
        public int SuccessResponseCode { get; set; }
    }
}
