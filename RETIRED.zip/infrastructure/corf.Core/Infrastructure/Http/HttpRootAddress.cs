﻿using corf.Configuration;
using Newtonsoft.Json;

namespace corf.Core.Http
{
    public class HttpRootAddress
    {
        [JsonConstructor]
        public HttpRootAddress() { }

        [FlowDesign(Description = "Enter host name. => 0.0.0.0 for all network intefaces", DefaultValue = "0.0.0.0", EnvironmentBasedVariable = true)]
        public string Host { get; set; } = string.Empty;
        public HttpRuleDefination? Http { get; set; }
        public HttpsRuleDefination? Https { get; set; }
    }
}