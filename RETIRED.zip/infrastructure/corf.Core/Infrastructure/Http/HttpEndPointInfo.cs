﻿using corf.Configuration;

namespace corf.Core.Http
{
    public abstract class HttpEndPointInfo
    {
        public string BaseAddress { get; set; } = string.Empty;
        public int TimeOut { get; set; }
        public string Path { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Headers { get; set; } = string.Empty;
        public int CheckInterval { get; set; }
        public int ConnectionCount { get; set; } = 1;
        public string AuthType { get; set; } = string.Empty;
        public CredentialInfo? Credentials { get; set; }
    }
}