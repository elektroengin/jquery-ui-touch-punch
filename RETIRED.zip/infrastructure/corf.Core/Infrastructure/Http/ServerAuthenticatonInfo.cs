﻿using corf.Configuration;
using System.Runtime.Serialization;

namespace corf.Core.Http
{
    public class ServerAuthenticatonInfo
    {
        public ServerAuthenticatonType ServerAuthenticatonType { get; set; } = ServerAuthenticatonType.None;
        public string AuthProperties { get; set; }

        [IgnoreDataMember]
        [FlowDesign(Display = false)]
        public ServerAuthenticaton ServerAuthenticaton { get; set; }
    }

    public abstract class ServerAuthenticaton
    {
    }
}