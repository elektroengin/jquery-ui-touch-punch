﻿namespace corf.Core.Http
{
    public enum ServerAuthenticatonType
    {
        None = 0,
        JwtToken = 1,
        OAuth = 2,
        BAuth = 3,
        JwtTokenWithoutValidation = 4
    }
}
