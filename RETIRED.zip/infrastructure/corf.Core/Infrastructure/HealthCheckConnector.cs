﻿namespace corf.Core
{
    public class HealthCheckConnector : IHealthCheckConnector
    {
        public List<IConnectionController> Connectors { get; set; }
        public int ControlPeriod { get; set; }
        public short RetryCount { get; set; }
    }
}
