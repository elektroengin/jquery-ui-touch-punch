﻿namespace corf.Core.Infrastructure
{
    public class PortInfo
    {
        public string Owner { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public int Port { get; set; }
        public string Attributes { get; set; } = string.Empty;
    }
}