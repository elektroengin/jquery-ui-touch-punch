﻿using corf.Core.Messaging;

namespace corf.Core.Infrastructure
{
    public interface ICommunicator
    {
        void GetReady();
        bool IsConnected { get; }
        Task<bool> CloseAsync();
        Task<bool> ConnectAsync();
        IConnector Connector { get; }
        bool Initialized { get; }
        void Initialize(Connector connector);
    }


    public interface IEndlessReceiver : ICommunicator
    {
        bool ReadyForRead { get; }
        Task<InternalMessage> ReceiveMessage();
    }

    public interface IMessageSender : ICommunicator
    {
        Task<bool> SendAsync(InternalMessage message);
        bool Send(InternalMessage message);
    }
}
