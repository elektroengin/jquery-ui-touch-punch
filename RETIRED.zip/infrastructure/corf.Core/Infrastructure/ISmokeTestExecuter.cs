﻿namespace corf.Core.Infrastructure
{
    public interface ISmokeTestExecuter
    {
    }
}