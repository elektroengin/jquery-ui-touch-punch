﻿using corf.Core.Messaging;

namespace corf.Core
{
    public interface ITransportConnector : IConnectionController
    {
        string PostCommandAssembly { get;}
        Task<bool> SendAsync(InternalMessage message);
        DateTime LastSent { get; set; }
        event EventHandler<MessageSentEventArgs> MessageSent;

        string ReceiverChannelId { get; set; }

        bool ReturnToReceiverChannel { get; set; }

    }
}
