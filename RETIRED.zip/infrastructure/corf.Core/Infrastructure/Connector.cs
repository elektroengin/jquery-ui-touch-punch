﻿using corf.Configuration;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using corf.Core.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Core
{
    public abstract class Connector :  IConnectionController  
    {
        internal ILogger Logger { get; private set; }
        public bool ConnectionEstablished { get; set; }
        public IServiceProvider ServiceProvider { get; set; }

        private IConfigurator? _configurator = null;
        protected IConfigurator? Configurator
        { get
            {
                if (_configurator == null)
                {
                    _configurator = ServiceProvider.GetService<IConfigurator>();
                }

                return _configurator;
            }
        }

        public IRoute Route { get; set; }
        protected IRequestScopeManager InternalScopeManager { get; private set; }

        #region Constructors
        public Connector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager)
        {
            Unique = Guid.NewGuid();
            Logger = logger;
            ServiceProvider = provider;
            InternalScopeManager = requestScopeManager;
        }

        #endregion
        
        [FlowDesign(Display = false)]
        public Guid Unique { get; private set; }

        [FlowDesign(Display = false)]
        public string Name { get; set; } = string.Empty;

        [FlowDesign(Display = false)]
        public string Title { get; set; } = string.Empty;

        [FlowDesign(Display = false)]
        public string Description { get; set; } = string.Empty;

        [FlowDesign(Display = false)]
        public string Group { get; set; } = string.Empty;

        #region CancellationToken
        public CancellationTokenSource? CancellationTokenSource { get; private set; }
        public CancellationToken CancellationToken { get; private set; }
        public Task CancellationTask { get; private set; }

        [FlowDesign(Description = "Type of incoming message.")]
        public string InnerMessageType { get; set; } = "Hex";
        private void createCancellationToken()
        {
            CancellationTokenSource = new CancellationTokenSource();
            CancellationToken = CancellationTokenSource.Token;
            CancellationTask = CancellationToken.AsTask();
             Logger.LogInformation("{unique} | Cancellation token created for Connector. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}]");

        }

        public virtual void Initialize()
        {
            createCancellationToken();
        }
        #endregion

        #region overrides -> Connector
        public abstract ICommunicator CommunicatorInstance { get; }

        [FlowDesign(Display = false)]
        public ConnectorState ConnectorState { get; set; } = ConnectorState.Created;

        public bool IsConnected
        {
            get
            {
                return CommunicatorInstance?.Initialized == true && CommunicatorInstance?.IsConnected == true;
            }
        }

        public T? GetCommand<T>(string assembly, string? scopeIdentity = null)
        {
            if (string.IsNullOrWhiteSpace(assembly) == false)
            {
                if (string.IsNullOrEmpty(scopeIdentity) == false && InternalScopeManager.Contains(scopeIdentity))
                {
                    return (T?)InternalScopeManager[scopeIdentity].GetService(Type.GetType(assembly));
                }
                else
                {
                    return (T?)ServiceProvider.GetService(Type.GetType(assembly));
                }
            }

            return default(T);
        }

        public virtual async Task<bool> ConnectAsync()
        {
            try
            {
                if (!IsConnected)
                {
                     Logger.LogInformation("{unique} | Connector is connecting to channel. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}]");

                    if (CancellationTokenSource == null || CancellationTokenSource.IsCancellationRequested)
                    {
                        createCancellationToken();
                    }

                    ConnectorState = ConnectorState.Connected;

                    CommunicatorInstance.Initialize(this);

                    CommunicatorInstance.GetReady();

                    bool connected = await CommunicatorInstance.ConnectAsync();

                    ConnectorState = connected ? ConnectorState.Connected : ConnectorState.Faulted;

                     Logger.LogInformation("{unique} | Connector connection result | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}], State :{ConnectorState.ToString()}.");

                    return connected;
                }
            }
            catch (Exception ex)
            {
                ConnectorState = ConnectorState.Faulted;
                Logger.LogError(ex, "{unique} | Could not connect to server. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}], ErrorMessage:{ex.Message}");
            }

            return true;
        }
        public virtual async Task<bool> DisconnectAsync()
        {

             Logger.LogInformation("{unique} | Connector is disconnecting... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}]");

            try
            {
                ConnectorState = ConnectorState.Disconnecting;

                if (!CancellationToken.IsCancellationRequested && CancellationTokenSource != null && CancellationToken.CanBeCanceled)
                {
                    CancellationTokenSource.Cancel();
                    CancellationTokenSource.Dispose();
                    CancellationTask.Dispose();
                }

                if (CommunicatorInstance != null)
                {
                    await CommunicatorInstance.CloseAsync();
                }

                ConnectorState = ConnectorState.Disconnected;
               
                 Logger.LogInformation("{unique} | Connector is disconnected. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}]");

                return true;
            }
            catch(Exception ex)
            {
                ConnectorState = ConnectorState.Faulted;
                Logger.LogError(ex, "{unique} | Could not disconnected from server. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}], ErrorMessage:{ex.Message}");
            }

            return false;
        }
        public async Task<bool> ReconnectAsync()
        {
            try
            {
                 Logger.LogInformation("{unique} | Reconnecting to connector. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}]");
                if (ConnectorState == ConnectorState.Disconnected
                || ConnectorState == ConnectorState.Faulted
                || ConnectorState == ConnectorState.Connected)
                {
                    await DisconnectAsync();
                    createCancellationToken();
                    bool isConnected = await ConnectAsync();
                    return isConnected;
                }
                else
                {
                    Logger.LogWarning("{unique} | Connector state is not suitable for reconnect. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}], State is {ConnectorState}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                ConnectorState = ConnectorState.Faulted;
                Logger.LogError(ex, "{unique} | Could not connect to server. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{Name}], ErrorMessage:{ex.Message}");
            }
            return false;
        }

        [FlowDesign(Display = false)]
        public string ActiveNodes { get; set; } = string.Empty;

        private bool? _isActive;
        public bool IsActive {
            get
            {
                if (!_isActive.HasValue && MachineSpecificInfo != null)
                {
                    _isActive = string.IsNullOrWhiteSpace(ActiveNodes) || string.IsNullOrWhiteSpace("ModuleId") || ActiveNodes.Split('|').Contains(MachineSpecificInfo.ModuleId) || ActiveNodes.Split('|').Contains("0");
                }
                return _isActive == null ? true : _isActive.Value;
            }
        }

        public bool SuitableForReconnect
        {
            get
            {
                return CommunicatorInstance.Initialized && (ConnectorState == ConnectorState.Disconnected
                    || ConnectorState == ConnectorState.Faulted
                    || ConnectorState == ConnectorState.Connected
                    || ConnectorState == ConnectorState.Created);
            }
        }

        [FlowDesign(Description = "It expresses the waiting time in milliseconds after each reading in endless reading channels.")]
        public int CheckInterval { get; set; } = 20;

        [FlowDesign(Description = "Indicates the maximum number of messages to wait in the channel. 0 : Unlimited")]
        public int BackPressureSize { get; set; }
        public ICommunicator Communicator { get { return CommunicatorInstance; } }

        public abstract string ChannelDescription { get; }

        [FlowDesign(IsExecuterDefinition = true, Description = "External assembly for execution on monitoring events.")]
        public string MonitoringCommand { get; set; } = string.Empty;

        private string _monitoringCommandAsembly = "";
        private bool _monitoringCommandSet = false;

        [FlowDesign(Display = false)]
        public string MonitoringCommandAssembly 
        { 
            get 
            { 
                if (!_monitoringCommandSet)
                {
                    _monitoringCommandAsembly = Configurator.GetAssembly(MonitoringCommand);
                    _monitoringCommandSet = true;
                }
                return _monitoringCommandAsembly;
            } 
        }

        public virtual bool IsHealthy { get { return true; } }

        [FlowDesign(Description = "In a server application developed with corf, this field can be marked as true if the client application is also developed with corf.")]
        public bool InternalPayload { get; set ; }
        public MachineSpecificInfo MachineSpecificInfo { get; set; }

        #endregion
    }
}
