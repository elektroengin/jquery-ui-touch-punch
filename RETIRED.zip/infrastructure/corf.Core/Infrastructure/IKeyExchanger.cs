﻿namespace corf.Core.Infrastructure
{
    public interface IKeyExchanger
    {
        Task<bool> ExchangeKeys(KeyExchangeMessage message);
        Task<bool> UpdateKeysByDestination(KeyExchangeMessage message);
    }
}
