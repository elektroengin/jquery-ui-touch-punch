﻿using corf.Configuration;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace corf.Core
{
    public sealed class ConnectorWatcher : IConnectorWatcher
    {
        private ILogger<ConnectorWatcher> _logger;
        private bool _isWatching = true;

        private readonly ConcurrentDictionary<Guid, IConnectorHealthController> _connectors;

        public string Name { get; set; }

        private int _checkInterval = 2000;
        public int CheckInterval { get { return _checkInterval; } set { _checkInterval = value; } }

        public ConnectorWatcher(ILogger<ConnectorWatcher> logger)
        {
            _logger = logger;

            _connectors = new ConcurrentDictionary<Guid, IConnectorHealthController>();
        }

        public async void WatchAsync() // assume we return a bool from this long running operation 
        {
            string aggregatedNames = _connectors.Select(c => c.Value.Connector.Name).Aggregate((i, j) => i + "," + j);

            _logger.LogInformation("{unique} | Watching connectors | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{Name}, [{aggregatedNames}]");

            while (_isWatching)
            {
                foreach (KeyValuePair<Guid, IConnectorHealthController> keyValue in _connectors)
                {
                    if ((keyValue.Value.Connector.SuitableForReconnect && !keyValue.Value.Connector.IsConnected))
                    {
                        try
                        {
                            _logger.LogInformation("{unique} | Trying reconnect. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{keyValue.Value.Connector.Name}]");

                            var connected = await keyValue.Value.ReconnectAsync();

                            if (connected)
                            {
                                _logger.LogInformation("{unique} | Connected to connector by [ConnectorWatcher] | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{keyValue.Value.Connector.Name}]");

                                if (keyValue.Value.Connector is IReceiveConnector && ((IReceiveConnector)keyValue.Value.Connector).EndlessReceive)
                                {
                                    await Task.Factory.StartNew(async () => await ((IReceiveConnector)keyValue.Value.Connector).ReceiveAsync(), TaskCreationOptions.LongRunning);
                                }
                            }
                            else
                            {
                                _logger.LogWarning("{unique} | Connection faulted. - ConnectorWatcher | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{keyValue.Value.Connector.Name}]");
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "{unique} | An error occured while reconnectiong. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{keyValue.Value.Connector.Name}], ErrorMessage :{ex.Message}");
                            continue;
                        }
                    }
                }

                await Task.Delay(_checkInterval);
            }
        }

        public void AddConnector(IConnectionController connector)
        {
            if (!_connectors.ContainsKey(connector.Unique))
            {
                if (_connectors.TryAdd(connector.Unique, new ConnectorHealthController(connector)))
                {
                    _logger.LogInformation("{unique} | Connector added into dictionary. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{connector.Name}, Unique :{connector.Unique}]");
                }
                else
                {
                    _logger.LogWarning("{unique} | Connector could'nt added into dictionary. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :[{connector.Name}, Unique :{connector.Unique}]");
                }
            }
        }

        public async Task<bool> StopAsync()
        {
            _isWatching = false;
            return await Task.FromResult<bool>(true);
        }
    }
}
