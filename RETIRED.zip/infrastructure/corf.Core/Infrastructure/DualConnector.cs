﻿
using corf.Core.Messaging;
using Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using corf.Core.Infrastructure;
using corf.Core.Commands;
using Microsoft.Extensions.Options;
using corf.Core.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Concurrent;
using corf.Configuration;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Routing;

namespace corf.Core
{
    public abstract class DualConnector : Connector, IReceiveConnector, ITransportConnector
    {
        private IRequestScopeManager _requestScopeManager;

        protected DualConnector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _requestScopeManager = requestScopeManager;
            if (!string.IsNullOrWhiteSpace(OnReceiveCommand))
            {
                PollControlCommand = (IBusinessCommand)ServiceProvider.GetService(Type.GetType(OnReceiveCommandAssembly));
            }
        }
        public string PrerequisiteConnectors { get; set; }


        [FlowDesign(Display = false)]
        public IConnectionController[] DependentTo { get; set; }

        /// <summary>
        /// LastSent
        /// </summary>
        [FlowDesign(Display = false)]
        public DateTime LastSent { get; set; }

        private bool isReceiving = false;

        #region commands

        [FlowDesign(IsExecuterDefinition = true, Description = "External assembly for execution on message received.")]
        public string OnReceiveCommand { get; set; }

        private string _onReceiveCommandAsembly = "";
        private bool _onReceiveCommandSet = false;

        [FlowDesign(Display = false)]
        public string OnReceiveCommandAssembly
        {
            get
            {
                if (!_onReceiveCommandSet)
                {
                    _onReceiveCommandAsembly = Configurator.GetExecuterAssembly(OnReceiveCommand);
                    _onReceiveCommandSet = true;
                }
                return _onReceiveCommandAsembly;
            }
        }
        [FlowDesign(IsExecuterDefinition = true, Description = "External assembly for execution before message sent.")]
        public string PostCommand { get; set; }

        private string _postCommandAsembly = "";
        private bool _postCommandSet = false;

        [FlowDesign(Display = false)]
        public string PostCommandAssembly
        {
            get
            {
                if (!_postCommandSet)
                {
                    _postCommandAsembly = Configurator.GetExecuterAssembly(PostCommand);
                    _postCommandSet = true;
                }
                return _postCommandAsembly;
            }
        }

        #endregion

        [FlowDesign(Description = "When true corf calculate the message timeouts over end to end journey")]
        public bool CheckJourneyTimeOuts { get; set; }

        [FlowDesign(Display = false)]
        public IBusinessCommand PollControlCommand { get; private set; }
        public ConcurrentDictionary<string, MessageTimer> MessageDiscovery { get; private set; } = new ConcurrentDictionary<string, MessageTimer>();

        [FlowDesign(Description = "If message could not send to destination, failover destination specify the destination on failover")]
        public string FailoverDestination { get; set; }

        private string _receiverChannelId;

        [FlowDesign(Description = "While two services are communicating, it is the area where the relevant channel is defined on the sending service side if the sending service expects a response from a specific channel.")]
        public string ReceiverChannelId
        {
            get
            {
                return _receiverChannelId;
            }
            set
            {
                _receiverChannelId = MachineSpecificInfo != null ? value.Replace("#ModuleId#",  MachineSpecificInfo.AdditionalQueueNumber) : value;
            }
        }

        [FlowDesign(Description = "True if ReceiverChannelId is necessary")]
        public bool ReturnToReceiverChannel { get; set; }
        public async override Task<bool> ConnectAsync()
        {
            bool isConnected = await base.ConnectAsync();

            if (isConnected)
            {
                var preCommand = GetCommand<IBusinessCommand>(OnReceiveCommandAssembly);

                if (preCommand != null && RequireInitialSignOn)
                {
                    InternalMessage message = await preCommand.GetSignOnMessage();

                    if (message != null)
                    {
                        try
                        {
                            Logger.LogInformation("{unique} | Trying sign on... | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");

                            await SendAsync(message);

                            Logger.LogInformation("{unique} | Sending sign on succeed. | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, "{unique} | Error on sending sign on message. | {additionalMessage}", message.Unique, $"ErrorMessage:{ex.Message}");
                        }
                    }
                }

                if (this.CheckJourneyTimeOuts)
                {
                    await Task.Factory.StartNew(async () => await OperateJourneyTimeOuts(), TaskCreationOptions.LongRunning);
                }
            }

            return isConnected;
        }

        protected async Task OperateJourneyTimeOuts()
        {
            while (true)
            {
                foreach (var keyVal in MessageDiscovery)
                {
                    if ((DateTime.Now - keyVal.Value.ReceiveDate).TotalMilliseconds > this.TimeOut)
                    {
                        if (MessageDiscovery.Remove(keyVal.Key, out MessageTimer messageTimer))
                        {
                            var monitoringCommand = GetCommand<IMonitoringCommand>(MonitoringCommandAssembly);

                            if (monitoringCommand != null)
                            {
                                monitoringCommand.JourneyTimedOut(keyVal.Value.ReceivedMessage, keyVal.Value.SentMessage);
                            }
                        }
                    }
                }
                await Task.Delay(100);
            }
        }

        public override async Task<bool> DisconnectAsync()
        {
            if (IsConnected)
            {
                if (PollControlCommand != null)
                {
                    InternalMessage message = await PollControlCommand.GetSignOffMessage();
                    if (message != null)
                    {
                        try
                        {
                            Logger.LogInformation("{unique} | Trying sign off... | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");
                            await SendAsync(message);

                            if (this is IHandShaker handShaker)
                            {
                                handShaker.ChangeSignOnStatus(new SignOnMessageResult() { SignOnStatus = false });
                            }
                            Logger.LogInformation("{unique} | Sending sign off succeed. | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, "{unique} | Error on sending sign off message. | {additionalMessage}", message.Unique, $"Connector Name :{this.Name} - ErrorMessage:{ex.Message}");
                        }
                    }
                }
            }
            return await base.DisconnectAsync();
        }
        /// <summary>
        /// Start async receive
        /// </summary>
        public async Task ReceiveAsync()
        {
            if (!CancellationToken.IsCancellationRequested)
            {
                Logger.LogInformation("{unique} | Cancellation token state is correct. Connector will start to listening...", LoggerUnique.CorfCore);
            }

            if (isReceiving == false)
            {
                isReceiving = true;

                if (CommunicatorInstance is IEndlessReceiver)
                {
                    while (true)
                    {
                        try
                        {
                            Logger.LogDebug("{unique} | ReceiveAsync... | {additionalMessage}", LoggerUnique.CorfCore, $"ConnectorState {Thread.CurrentThread.ManagedThreadId}: {ConnectorState}, PollControlCommand : {PollControlCommand}, PollControlCommand.CheckAvailability().IsAvailable : {(PollControlCommand != null ? PollControlCommand.CheckAvailability().IsAvailable : "")}, BackPressureSize : {BackPressureSize}, ExecutingMessagesCount : {ExecutingMessagesCount}");

                            if (ConnectorState == ConnectorState.Disconnected || ConnectorState == ConnectorState.Disconnecting)
                                break;
                            if (PollControlCommand == null || PollControlCommand.CheckAvailability().IsAvailable)
                            {
                                if (BackPressureSize == 0 || ExecutingMessagesCount < BackPressureSize)
                                {
                                    InternalMessage message = await getNextMessageAsync();

                                    if (message != null && message.BinaryMessage != null)
                                    {
                                        AddMessage();
                                        _requestScopeManager.Add(message, ServiceProvider.CreateScope().ServiceProvider);

                                        FireMessageReceived(new MessageReceivedEventArgs(message));
                                        continue;
                                    }
                                    else
                                    {
                                        await Task.Delay(CheckInterval);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, "{unique} | An error occured while receiving messages. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:{ex.Message}");
                        }

                    }
                }
                isReceiving = false;
            }
        }

        /// <summary>
        /// get next message async
        /// </summary>
        /// <returns></returns>
        private async Task<InternalMessage> getNextMessageAsync()
        {
            InternalMessage resultData = null;

            Logger.LogDebug("{unique} | getNextMessageAsync started... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}, ReadyForRead : {((IEndlessReceiver)CommunicatorInstance).ReadyForRead}, IsActive : {IsActive}");


            if (((IEndlessReceiver)CommunicatorInstance).ReadyForRead && IsActive)
            {
                Logger.LogDebug("{unique} | getNextMessageAsync started... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}");

                resultData = await ((IEndlessReceiver)CommunicatorInstance).ReceiveMessage();
                
                if (resultData == null)
                {
                    //No received messages. If it is necessary, log it.
                    //Logger.Warn(string.Format("!!! No received messages.{0}", Environment.NewLine));
                }
            }
            else
            {
                Logger.LogDebug("{unique} | Connector was not ready to read. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}");
            }
            return await Task.FromResult(resultData);
        }

        /// <summary>
        /// Send message to destination
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public virtual async Task<bool> SendAsync(InternalMessage message)
        {
            Logger.LogDebug("{unique} | Message is sending to channel. | {additionalMessage}", message.Unique, $"Connector Name - Unique:[{this.Name} - {message.Unique}] with content :{message.InnerMessage}");

            var result = await ((IMessageSender)CommunicatorInstance).SendAsync(message);

            Logger.LogInformation("{unique} | Sending completed. | {additionalMessage}", message.Unique, $"Result :[{result}], Connector Name - Unique:[{this.Name} - {message.Unique}]");

            if (this.CheckJourneyTimeOuts)
            {
                if (!MessageDiscovery.TryRemove(message.Unique, out MessageTimer messageTimer))
                {
                    Logger.LogDebug("{unique} | Message could not sent to channel. Message journey time out!!! | {additionalMessage}", message.Unique, $"Connector Name - Unique:[{this.Name} - {message.Unique}] with content :{message.InnerMessage}");
                }
            }

            return result;
        }

        public virtual void FireMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs)
        {
            if (Route != null)
            {
                Route.OperateNextStep(this, messageReceivedEventArgs, AllowAsyncSteps);
            }
        }


        public void AddMessage()
        {
            Interlocked.Increment(ref _executingMessagesCount);
            Logger.LogDebug("{unique} | Executing... | {additionalMessage}", LoggerUnique.CorfCore, $"Messages count after adding new one : {_executingMessagesCount} - {this.Name}");
        }

        public void RemoveMessage()
        {
            if (_executingMessagesCount > 0)
            {
                Interlocked.Decrement(ref _executingMessagesCount);
            }
            Logger.LogDebug("{unique} | Executing... | {additionalMessage}", LoggerUnique.CorfCore, $"Messages count after removed current : {_executingMessagesCount} - {this.Name}");

        }

        private int _executingMessagesCount = 0;

        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

        public event EventHandler<MessageSentEventArgs> MessageSent;

        public int ExecutingMessagesCount
        {
            get { return _executingMessagesCount; }
        }

        public virtual bool EndlessReceive { get { return true; } }

        [FlowDesign(DefaultValue = 4000, Description = "Specify the timeout for cancellation")]
        public int TimeOut { get; set; } = 4000;

        public bool LongRunningExecution { get; set; } = false;

        public virtual bool AllowAsyncSteps { get; set; } = true;
        public bool RequireInitialSignOn { get;  set; }
    }
}
