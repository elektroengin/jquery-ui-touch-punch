﻿using corf.Configuration;
using corf.Core.Commands;
using corf.Core.Hosting;
using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Core
{
    public abstract class ScheduledConnector : Connector, IScheduledConnector
    {
        public ScheduledConnector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
        }

        private int _executingMessagesCount = 0;
        public virtual bool AllowAsyncSteps { get; set; } = true;

        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

        [FlowDesign(IsExecuterDefinition = true)]
        public string OnReceiveCommand { get; set; } = string.Empty;

        private string _onReceiveCommandAsembly = "";
        private bool _onReceiveCommandSet = false;

        [FlowDesign(Display = false)]
        public string OnReceiveCommandAssembly
        {
            get
            {
                if (!_onReceiveCommandSet)
                {
                    _onReceiveCommandAsembly = Configurator.GetExecuterAssembly(OnReceiveCommand);
                    _onReceiveCommandSet = true;
                }
                return _onReceiveCommandAsembly;
            }
        }
        public IBusinessCommand ReceiveCommand { get { return GetCommand<IBusinessCommand>(OnReceiveCommandAssembly); } }

        public string CronExpression { get; set; } = string.Empty;
        public bool RetryOnFailure { get; set; } = false;
        public int RetryCount { get; set; } = 0;
        public int WaitDurationForRetry { get; set; } = 10;
        public string JobId { get; set; } = string.Empty;

        public int ExecutingMessagesCount
        {
            get { return _executingMessagesCount; }
        }

        [FlowDesign(Display = false)]

        public DateTime LastSent { get; set; }

        public bool DisallowConcurrentExecution { get; set; }
        public IConnectionController[] DependentTo { get; set; }

        public void AddMessage()
        {
            Interlocked.Increment(ref _executingMessagesCount);
        }

        public void RemoveMessage()
        {
            Interlocked.Decrement(ref _executingMessagesCount);
        }
        public void FireMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs)
        {
            if (Route != null)
            {
                Route.OperateNextStep(this, messageReceivedEventArgs, AllowAsyncSteps);
            }
        }
    }
}
