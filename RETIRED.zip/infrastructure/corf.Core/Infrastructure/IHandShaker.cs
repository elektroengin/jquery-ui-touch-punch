﻿namespace corf.Core.Infrastructure
{
    public interface IHandShaker
    {
        bool ChangeSignOnStatus(SignOnMessageResult signOnMessageResult);
    }
}
