﻿using corf.Core.Messaging;

namespace corf.Core
{
    public class MessageTimer
    {
        public InternalMessage? SentMessage { get; set; }
        public DateTime ReceiveDate { get; set; }
        public InternalMessage? ReceivedMessage { get; set; }
    }
}