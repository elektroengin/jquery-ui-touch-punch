﻿namespace corf.Core
{
    public interface IConnectorWatcher
    {
        string Name { get; set; }
        void WatchAsync();
        void AddConnector(IConnectionController connector);
        Task<bool> StopAsync();

        int CheckInterval { get; set; }
    }
}