﻿namespace corf.Core
{
    public interface IHealthCheckConnector
    {
        List<IConnectionController> Connectors { get; set; }
        int ControlPeriod { get; set; }
        short RetryCount { get; set; }
    }
}
