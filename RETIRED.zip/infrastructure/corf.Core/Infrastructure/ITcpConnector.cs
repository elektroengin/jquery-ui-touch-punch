﻿using corf.Configuration;
using corf.Core.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Core.Infrastructure
{
    public interface ITcpConnector
    {
        string Address { get; set; }

        string Port { get; set; }
        bool Poll();
        bool NoDelay { get; set; }
        int HeaderLength { get; set; }
        bool CheckPadding { get; set; }
        int PaddingLength { get; set; }
    }
}
