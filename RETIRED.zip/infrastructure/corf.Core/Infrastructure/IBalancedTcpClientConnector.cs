﻿namespace corf.Core.Infrastructure
{
    public interface IBalancedTcpClientConnector
    {
        void UseTcpEchoMessageGenerator(ITcpEchoMessageGenerator echoMessageGenerator);
        string Hosts { get; set; }
        string Ports { get; set; }
        string EchoMessageGeneratorAssembly { get; set; }
    }
}