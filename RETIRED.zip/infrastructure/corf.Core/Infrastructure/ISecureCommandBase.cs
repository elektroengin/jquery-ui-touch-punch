﻿using corf.Core.Messaging;

namespace corf.Core.Infrastructure
{
    public interface ISecureCommandBase
    {
        string CommandCode { get;}
        string ResponseCode { get;}
        string ErrorCode { get; set; }
        double TotalSendMs { get; set; }
        double TotalReceiveMs { get; set; }
        string ErrorDescription { get; set; }
        byte[] IncomingMessage { get; set; }
        byte[] BuildResponse();
        ReturnValue<bool> ExtractResponse(byte[] data);
        byte[] BuildRequest();
        ReturnValue<bool> ExtractRequest(byte[] data);
        ReturnValue<bool> CheckResponse(byte[] data);
        ReturnValue<bool> CheckRequest(byte[] data);
    }
}
