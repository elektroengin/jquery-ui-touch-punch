﻿namespace corf.Core.Infrastructure
{
    public interface ITcpEchoMessageGenerator
    {
        public byte[] GetEchoMessage();
    }
}