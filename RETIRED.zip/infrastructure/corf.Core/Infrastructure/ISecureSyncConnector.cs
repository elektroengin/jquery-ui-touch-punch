﻿namespace corf.Core.Infrastructure
{
    public interface ISecureSyncConnector
    {
        byte[] Encrpyt(string messageUnique, byte[] data);
        byte[] Decrypt(string messageUnique, byte[] data);
        byte[] TranslateZpkToZpk(string messageUnique, string accountNumber, string incomingPinBlock, string incomingZpk, string outgoingZpk);
    }
}
