﻿namespace corf.Core
{
    public class ConnectorHealthController : IConnectorHealthController
    {
        public ConnectorHealthController(IConnectionController channel)
        {
            this.Connector = channel;
        }

        public DateTime LastCheck { get; private set; }

        public IConnectionController Connector { get; private set; }
        public Task<bool> ReconnectAsync()
        {
            return this.Connector.ReconnectAsync();
        }
    }
}
