﻿namespace corf.Core
{
    public class SignOnMessageResult
    {
        public bool SignOnStatus { get; set; }
    }
}