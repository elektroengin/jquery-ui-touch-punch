﻿using corf.Core.Messaging;
using corf.Core.Routing;

namespace corf.Core
{
    public interface IScheduledConnector : IMessagePublisher
    {
        string CronExpression { get; set; }
       bool RetryOnFailure { get; set; }
       int RetryCount { get; set; }
       int WaitDurationForRetry { get; set; }
       string JobId { get; set; }
        bool AllowAsyncSteps { get; set; }
        void FireMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs);

    }
}