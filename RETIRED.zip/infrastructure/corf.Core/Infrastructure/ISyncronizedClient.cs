﻿namespace corf.Core.Infrastructure
{
    public interface ISyncronizedClient
    {
        void Initialize(string address, int port, int maxreceiveSize);
        bool IsConnected { get; }
        bool Start();
        byte[] Receive(int size);

        void Send(byte[] message);
    }
}