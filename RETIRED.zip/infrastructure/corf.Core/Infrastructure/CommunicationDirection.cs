﻿namespace corf.Core.Infrastructure
{
    public enum CommunicationDirection
    {
        Receiver = 1,
        Transporter =2,
        Dual = 3
    }
}
