﻿namespace corf.Core
{
    public interface IConnectionController : IConnector
    {
        ConnectorState ConnectorState { get; set; }
        bool IsConnected { get; }
        bool IsHealthy { get; }
        Task<bool> ReconnectAsync();
        Task<bool> ConnectAsync();
        Task<bool> DisconnectAsync();

        bool ConnectionEstablished { get; set; }
        bool SuitableForReconnect { get; }
        int CheckInterval { get; set; }
        int BackPressureSize { get; set; }

    }
}