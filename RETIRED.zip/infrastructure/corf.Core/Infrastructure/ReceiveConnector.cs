﻿using corf.Configuration;
using corf.Core.Commands;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace corf.Core
{
    public abstract class ReceiveConnector : Connector, IReceiveConnector
    {
        private IRequestScopeManager _requestScopeManager;
        private static object _executingMessagesLockObject = new object();
        public ReceiveConnector(ILogger logger,  IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _requestScopeManager = requestScopeManager;
            if (!string.IsNullOrWhiteSpace(OnReceiveCommand))
            {
                PollControlCommand = (IBusinessCommand)ServiceProvider.GetService(Type.GetType(OnReceiveCommandAssembly));
            }
        }

        public IBusinessCommand PollControlCommand { get; private set; }

        private bool isReceiving = false;


        [FlowDesign(Display = false)]
        public IConnectionController[] DependentTo { get; set; }

        public ConcurrentDictionary<string, MessageTimer> MessageDiscovery { get; private set; } = new ConcurrentDictionary<string, MessageTimer>();

        [FlowDesign(IsExecuterDefinition = true)]
        public string OnReceiveCommand { get; set; }

        private string _onReceiveCommandAsembly = "";
        private bool _onReceiveCommandSet = false;

        [FlowDesign(Display = false)]
        public string OnReceiveCommandAssembly
        {
            get
            {
                if (!_onReceiveCommandSet)
                {
                    _onReceiveCommandAsembly = Configurator.GetExecuterAssembly(OnReceiveCommand);
                    _onReceiveCommandSet = true;
                }
                return _onReceiveCommandAsembly;
            }
        }

        public override async Task<bool> DisconnectAsync()
        {
            if (IsConnected)
            {

                if (PollControlCommand != null)
                {
                    InternalMessage message = await PollControlCommand.GetSignOffMessage();
                    if (message != null)
                    {
                        try
                        {
                            Logger.LogInformation("{unique} | Trying sign off... | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");

                            if (this is IHandShaker handShaker)
                            {
                                handShaker.ChangeSignOnStatus(new SignOnMessageResult() { SignOnStatus = false });
                            }
                            Logger.LogInformation("{unique} | Sending sign off succeed. | {additionalMessage}", message.Unique, $"Connector Name :{this.Name}");
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, "{unique} | Error on sending sign off message. | {additionalMessage}", message.Unique, $"Connector Name :{this.Name} - ErrorMessage:{ex.Message}");
                        }
                    }
                }
            }
            return await base.DisconnectAsync();
        }
        /// <summary>
        /// Start async receive
        /// </summary>
        public async Task ReceiveAsync()
        {

            if (!CancellationToken.IsCancellationRequested)
            {
                Logger.LogInformation("{unique} | Cancellation token state is correct. Connector will start to listening... | {additionalMessage}", LoggerUnique.CorfCore);
            }

            if (isReceiving == false)
            {
                isReceiving = true;

                if (CommunicatorInstance is IEndlessReceiver)
                {
                    while (true)
                    {
                        try
                        {
                            Logger.LogDebug("{unique} | ReceiveAsync... | {additionalMessage}", LoggerUnique.CorfCore, $"ConnectorState {Thread.CurrentThread.ManagedThreadId}: {ConnectorState}, PollControlCommand : {PollControlCommand}, PollControlCommand.CheckAvailability().IsAvailable : {(PollControlCommand != null ? PollControlCommand.CheckAvailability().IsAvailable : "")}, BackPressureSize : {BackPressureSize}, ExecutingMessagesCount : {ExecutingMessagesCount}");

                            if (ConnectorState == ConnectorState.Disconnected || ConnectorState == ConnectorState.Disconnecting)
                                break;
                            if (PollControlCommand == null || PollControlCommand.CheckAvailability().IsAvailable)
                            {
                                if (BackPressureSize == 0 || ExecutingMessagesCount < BackPressureSize)
                                {
                                    InternalMessage message = await getNextMessageAsync();

                                    if (message != null && message.BinaryMessage != null)
                                    {
                                        AddMessage();
                                        _requestScopeManager.Add(message, ServiceProvider.CreateScope().ServiceProvider);
                                        FireMessageReceived(new MessageReceivedEventArgs(message));
                                        continue;
                                    }
                                    else
                                    {
                                        Thread.Sleep(CheckInterval);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Logger.LogError(ex, "{unique} | Teknik Hata | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:{ex.Message}");
                        }
                    }
                }

            }
        }

        public void FireMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs)
        {
            if (Route != null)
            {
                Route.OperateNextStep(this, messageReceivedEventArgs, AllowAsyncSteps);
            }
        }


        /// <summary>
        /// get next message async
        /// </summary>
        /// <returns></returns>
        private async Task<InternalMessage> getNextMessageAsync()
        {
            InternalMessage resultData = null;

            Logger.LogDebug("{unique} | getNextMessageAsync started... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}, ReadyForRead : {((IEndlessReceiver)CommunicatorInstance).ReadyForRead}, IsActive : {IsActive}");


            if (((IEndlessReceiver)CommunicatorInstance).ReadyForRead && IsActive)
            {
                Logger.LogDebug("{unique} | getNextMessageAsync started... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}");

                resultData = await ((IEndlessReceiver)CommunicatorInstance).ReceiveMessage();

                if (resultData == null)
                {
                    //No received messages. If it is necessary, log it.
                    //Logger.Warn(string.Format("!!! No received messages.{0}", Environment.NewLine));
                }
            }
            else
            {
                Logger.LogDebug("{unique} | Connector was not ready to read. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Name}");
            }
            return resultData;
        }

        public string PrerequisiteConnectors { get; set; }
        public void AddMessage()
        {
            Interlocked.Increment(ref _executingMessagesCount);
            Logger.LogDebug("{unique} | Executing... | {additionalMessage}", LoggerUnique.CorfCore, $"Messages count after adding new one : {_executingMessagesCount} - {this.Name}");
        }
        public void ResetWaitingMessages()
        {
            lock (_executingMessagesLockObject)
            {
                _executingMessagesCount = 0;
            }
        }
        public void RemoveMessage()
        {
            if (_executingMessagesCount > 0)
            {
                Interlocked.Decrement(ref _executingMessagesCount);
            }
            Logger.LogDebug("{unique} | Executing... | {additionalMessage}", LoggerUnique.CorfCore, $"Messages count removed current : {_executingMessagesCount} - {this.Name}");

        }

        private int _executingMessagesCount = 0;

        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

        public int ExecutingMessagesCount
        {
            get { return _executingMessagesCount; }
        }

        public virtual bool EndlessReceive { get { return true; } }

        public bool AutoReverseOnError { get; set; }

        public bool LongRunningExecution { get; set; } = false;

        public virtual bool AllowAsyncSteps { get; set; } = true;
    }
}
