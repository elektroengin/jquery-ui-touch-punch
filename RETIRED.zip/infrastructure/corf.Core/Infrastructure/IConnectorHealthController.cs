﻿namespace corf.Core
{
    public interface IConnectorHealthController
    {
        DateTime LastCheck { get;  }
        IConnectionController Connector { get;  }
        Task<bool> ReconnectAsync();
    }
}