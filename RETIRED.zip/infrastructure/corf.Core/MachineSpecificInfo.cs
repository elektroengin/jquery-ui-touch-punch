﻿namespace corf.Core
{
    public class MachineSpecificInfo
    {
        private string _additionalQueueNumber = string.Empty;
        public string AdditionalQueueNumber {
            get
            {
                return _additionalQueueNumber;
            }
            internal set
            {
                _additionalQueueNumber = value;
            }
        }

        private string _moduleId = string.Empty;
        public string ModuleId
        {
            get
            {
                return _moduleId;
            }
            internal set
            {
                _moduleId = value;
            }
        }
    }
}