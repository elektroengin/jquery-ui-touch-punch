﻿using System.Runtime.Serialization;

namespace corf.Core
{
    public class ServiceSettings
    {
        public ServiceSettings()
        {
        }

        public int Port { get; set; }

        [DataMember(Name = "nodeDictionary")]
        public string NodeDictionary { get; set; }


        private readonly Dictionary<string, string> _externalParameters = new Dictionary<string, string>();

        [IgnoreDataMember]
        public Dictionary<string, string> ExternalParameters
        {
            get
            {
                if (_externalParameters.Count == 0)
                {
                    Initialize();
                }

                return _externalParameters;
            }
        }

        private MachineSpecificInfo _machineSpecificInfo = null;

        private void Initialize()
        {
            if (_machineSpecificInfo == null)
            {
                _machineSpecificInfo = new MachineSpecificInfo()
                {
                    AdditionalQueueNumber = "",
                };

                if (!string.IsNullOrWhiteSpace(NodeDictionary))
                {
                    string[] machineInfos = NodeDictionary.Split(',');

                    string machineInfoStringArray = machineInfos.FirstOrDefault(s => (s.Split(':')[0]).ToLower() == Environment.MachineName.ToLower());

                    if (string.IsNullOrWhiteSpace(machineInfoStringArray) == false)
                    {
                        string[] currentMachineInfos = machineInfoStringArray.Split(':');
                        _machineSpecificInfo.ModuleId = currentMachineInfos[1];
                        _machineSpecificInfo.AdditionalQueueNumber = currentMachineInfos[2] == "N" ? "" : currentMachineInfos[2];

                        if (currentMachineInfos.Length > 3)
                        {
                            for (int i = 3; i < currentMachineInfos.Length; i++)
                            {
                                _externalParameters.Add($"#P{i - 2}", currentMachineInfos[i]);
                            }
                        }
                    }
                }
            }
        }

        [IgnoreDataMember]
        public MachineSpecificInfo MachineSpecificInfo
        {
            get
            {
                if (_machineSpecificInfo == null)
                {
                    Initialize();
                }

                return _machineSpecificInfo;
            }
        }

    }
}
