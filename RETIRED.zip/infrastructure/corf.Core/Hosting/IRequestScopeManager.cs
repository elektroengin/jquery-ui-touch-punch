﻿using corf.Core.Messaging;

namespace corf.Core.Hosting
{
    public interface IRequestScopeManager
    {
        IServiceProvider GetScopedProvider(string identifier);
        void Add(InternalMessage identifier, IServiceProvider serviceProvider);
        void Remove(string identifier);
        bool Contains(string identifier);
        IServiceProvider this[string key] { get; }
    }
}