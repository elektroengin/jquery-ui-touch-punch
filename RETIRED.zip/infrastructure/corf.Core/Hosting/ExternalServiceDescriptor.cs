﻿using Microsoft.Extensions.DependencyInjection;

namespace corf.Core.Hosting
{
    public class ExternalServiceDescriptor : ServiceDescriptor
    {
        public ExternalServiceDescriptor(Type serviceType, Func<IServiceProvider, object> factory, ServiceLifetime lifetime) : base(serviceType, factory, lifetime)
        {
        }

        public bool HostDependent { get; set; }
    }
}