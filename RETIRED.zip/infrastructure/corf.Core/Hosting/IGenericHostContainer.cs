﻿using corf.Core.Messaging;
using corf.Core.Smoke;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace corf.Core.Hosting
{
    public interface IGenericHostContainer : IHostBuilder, IExternalDependenyProvider
    {
        Task RunAsync(string[] args);
        void ShutdownAsync(object source, FileSystemEventArgs e);
        IGenericHostContainer SetConfiguration(string path);
        IGenericHostContainer AddConfigurationFile(string fileName, bool isReadOnly = false);
        IGenericHostContainer AddConfigMapFile(string fileName);
        IGenericHostContainer AddSecretFile(string fileName);
        IGenericHostContainer AddShutdownControlFile(string fileName);
        void RunAsService();
        IGenericHostContainer AddScoped<TService>() where TService : class;

        IGenericHostContainer AddScoped(Type serviceType, Type implementationType);

        IGenericHostContainer AddScoped(Type serviceType, Func<IServiceProvider, object> implementationFactory);

        IGenericHostContainer AddRoutingDeserializer<T>() where T : IDeserializerProvider;

        IGenericHostContainer AddScoped<TService, TImplementation>() where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddScoped(Type serviceType);

        IGenericHostContainer AddScoped<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class;

        IGenericHostContainer AddScoped<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
            where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddSingleton<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
            where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddSingleton<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class;

        IGenericHostContainer AddSingleton<TService>() where TService : class;

        IGenericHostContainer AddSingleton(Type serviceType);

        IGenericHostContainer AddSingleton<TService, TImplementation>()
            where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddSingleton(Type serviceType, Func<IServiceProvider, object> implementationFactory);

        IGenericHostContainer AddSingleton(Type serviceType, Type implementationType);

        IGenericHostContainer AddSingleton<TService>(TService implementationInstance) where TService : class;

        IGenericHostContainer AddSingleton(Type serviceType, object implementationInstance);

        IGenericHostContainer ConfigureSection<TConfiguration>(string sectionName);

        IGenericHostContainer AddTransient<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
            where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddTransient<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class;

        IGenericHostContainer AddTransient<TService>() where TService : class;

        IGenericHostContainer AddTransient(Type serviceType);

        IGenericHostContainer AddTransient<TService, TImplementation>()
            where TService : class
            where TImplementation : class, TService;

        IGenericHostContainer AddTransient(Type serviceType, Func<IServiceProvider, object> implementationFactory);

        IGenericHostContainer AddTransient(Type serviceType, Type implementationType);

        IGenericHostContainer Configure<TOptions>(string sectionName) where TOptions : class;
        IGenericHostContainer Configure<TOptions>(string sectionName, Action<BinderOptions> configureBinder) where TOptions : class;
        IGenericHostContainer AddSmokeTest(SmokeTest test);
        IGenericHostContainer CreateBuilder(string[] args, Action<IHostBuilder, IGenericHostContainer> action);
        IGenericHostContainer AddSwaggerAuth(OpenApiSecurityScheme securityScheme);

    }
}