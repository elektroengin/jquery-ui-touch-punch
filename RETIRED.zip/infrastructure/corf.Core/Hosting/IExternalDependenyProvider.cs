﻿using Microsoft.Extensions.DependencyInjection;

namespace corf.Core.Hosting
{
    public interface IExternalDependenyProvider
    {
        IServiceCollection ExternalDescriptors { get; }
    }
}