﻿using corf.Core.Messaging;
using System.Collections.Concurrent;

namespace corf.Core.Hosting
{
    public class RequestScopeManager : IRequestScopeManager
    {
        private readonly ConcurrentDictionary<string, IServiceProvider> _providers = new ConcurrentDictionary<string, IServiceProvider>();

        public RequestScopeManager()
        {
        }

        public IServiceProvider GetScopedProvider(string identifier)
        {
            if (_providers.ContainsKey(identifier))
            {
                return _providers[identifier];
            }

            return null;
        }

        public IServiceProvider this[string key]
        {
            get { return GetScopedProvider(key); }
        } 

        public bool Contains(string identifier)
        {
            return _providers.ContainsKey(identifier);
        }

        public void Add(InternalMessage identifier, IServiceProvider serviceProvider)
        {
            if (_providers.ContainsKey(identifier.Unique) == false)
            {
                identifier.ScopeManager = this;
                _providers.TryAdd(identifier.Unique, serviceProvider);
            }
        }

        public void Remove(string identifier)
        {
            if (_providers.ContainsKey(identifier))
            {
                _providers.TryRemove(identifier, out _);
            }
        }
    }
}