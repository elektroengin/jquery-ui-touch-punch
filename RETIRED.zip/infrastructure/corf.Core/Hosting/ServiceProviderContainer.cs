﻿namespace corf.Core.Hosting
{
    public class ServiceProviderContainer
    {
        
    }
}