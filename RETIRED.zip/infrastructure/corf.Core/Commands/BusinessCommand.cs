﻿using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;

namespace corf.Core.Commands
{
    public abstract class BusinessCommand : IBusinessCommand
    {
        public ILogger Logger { get; private set; }

        public BusinessCommand(ILogger logger)
        {
            this.Logger = logger;
        }

        public abstract Task<InternalMessage> Execute(InternalMessage message);
        
        public virtual bool CheckDependentConnector { get; private set; } = true;

        public virtual string Convert2BusinessIdentifier(InternalMessage message)
        {
            return message.Unique;
        }

        public virtual MessageValidationResult Validate(InternalMessage message) => new() { Succeed = true, ResultMessage = "OK" };

        public virtual async Task<MessageValidationResult> Authorize(InternalMessage message) => new() { Succeed = true, ResultMessage = "OK" };

        private bool? _authorized = null;
        public bool Authorized
        {
            get
            {
                if (_authorized == null)
                {
                    var attributes = GetType().GetCustomAttributes(typeof(CheckAuthAttribute), false);

                    if (attributes != null && attributes.Length > 0)
                    {
                        _authorized = true;
                    }
                    else
                    {
                        _authorized = false;
                    }
                }

                return _authorized.Value;
            }
        }

        public MessageFormat InputMessageFormat { get ; set ; }
        public MessageFormat OutputMessageFormat { get ; set ; }

        public async Task<InternalMessage> ExecuteInternal(InternalMessage message)
        {
            try
            {
                message.State = MessageState.Executing;
                
                var authorization = await Authorize(message);

                var validation = Validate(message);

                if (validation.Succeed && authorization.Succeed)
                {
                    var result = await Execute(message);

                    message.State = message.State != MessageState.Failed && 
                                    message.State != MessageState.ExecutionFailed && 
                                    message.State != MessageState.Terminate ? MessageState.Executed : message.State;

                    return result;
                }
                else
                {
                    if (validation.PayLoad != null)
                    {
                        Logger.LogWarning("{unique} | Couldn't validate incoming message. | {additionalMessage}", message.Unique, $"Inner Message : {message.InnerMessage}");

                        validation.PayLoad.State = MessageState.Failed;

                        return validation.PayLoad;
                    }
                    else if(!authorization.Succeed)
                    {
                        var responseMessage = message;
                        if (authorization.PayLoad != null)
                            responseMessage = authorization.PayLoad;

                        responseMessage.State = MessageState.Failed;
                        responseMessage.StatusCode = System.Net.HttpStatusCode.Unauthorized;
                        return responseMessage;
                    }
                    else
                    {
                        throw new MessageValidationException("Couldn't validate incoming message.");
                    }
                }
            }
            catch (MessageValidationException mve)
            {
                message.State = MessageState.Failed;
                Logger.LogError(mve, "{unique} | An error occured while processing the message. | {additionalMessage}", message.Unique, $"ErrorMessage:{mve.Message}");
            }
            catch (Exception ex)
            {
                message.State = MessageState.Failed;
                Logger.LogError(ex, "{unique} | An error occured while processing the message. | {additionalMessage}", message.Unique, $"ErrorMessage:{ex.Message}");
            }

            return message;

        }

        public virtual async Task<InternalMessage> ReverseMessage(InternalMessage message)
        {
            message.State = MessageState.Failed;

            return await Task.FromResult<InternalMessage>(message);
        }

        public virtual async Task AfterMessageSent(InternalMessage message)
        {
        }

        public virtual async Task SingleMessageSent(InternalMessage message)
        {
        }

        public virtual async Task<InternalMessage> GetSignOnMessage()
        {
            return await Task.FromResult<InternalMessage>(null);
        }

        public virtual async Task<InternalMessage> GetSignOffMessage()
        {
            return await Task.FromResult<InternalMessage>(null);
        }

        public virtual async Task<bool> CheckSignOnResult(InternalMessage message)
        {
            return await Task.FromResult(true);
        }

        public virtual AvailabilityResult CheckAvailability(InternalMessage request = null)
        {
            return new AvailabilityResult { IsAvailable = true };
        }

        public IRoute Route { get; set; }

        public IBusinessCommand Clone()
        {
            return this.MemberwiseClone() as IBusinessCommand;
        }
    }
}