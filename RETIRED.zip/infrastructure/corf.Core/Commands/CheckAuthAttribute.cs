﻿namespace corf.Core.Commands
{
    [System.AttributeUsage(AttributeTargets.Class)]
    public class CheckAuthAttribute : Attribute
    {
        public CheckAuthAttribute()
        {
        }
    }
}