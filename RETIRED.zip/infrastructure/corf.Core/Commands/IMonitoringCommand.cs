﻿using corf.Core.Messaging;

namespace corf.Core.Commands
{
    public interface IMonitoringCommand
    {
        Task JourneyTimedOut(InternalMessage incoming, InternalMessage outgoing);

        Task MessageSendFailed(InternalMessage incoming, InternalMessage outgoing, Exception exception);

        Task MessageSent(InternalMessage cloneMessage, InternalMessage message);
    }
}