﻿using corf.Core.Messaging;
using Logging;
using Microsoft.Extensions.Logging;

namespace corf.Core.Commands
{
    public abstract class MonitoringCommand : IMonitoringCommand
        
    {
        public ILogger Logger { get; private set; }
        public IMetricMonitoringLogAdapter MetricLogger { get; private set; }

        public MonitoringCommand(ILogger logger, IMetricMonitoringLogAdapter metricLogger)
        {
            this.Logger = logger;
            this.MetricLogger = metricLogger;
        }

        public async virtual Task JourneyTimedOut(InternalMessage incoming, InternalMessage outgoing)
        {
        }

        public async virtual Task MessageSendFailed(InternalMessage incoming, InternalMessage outgoing, Exception exception)
        {
        }

        public async virtual Task MessageSent(InternalMessage cloneMessage, InternalMessage message)
        {

        }
    }
}
