﻿using corf.Core.Messaging;

namespace corf.Core.Commands
{
    public class AvailabilityResult
    {
        public bool IsAvailable { get; set; } = true;
        public InternalMessage Response { get; set; }
    }
}