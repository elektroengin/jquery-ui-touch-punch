﻿namespace corf.Core.Commands
{
    public enum RunningMode
    {
        Parallel = 1,
        Sync = 2,
        SyncNoWait =3,
    }
}