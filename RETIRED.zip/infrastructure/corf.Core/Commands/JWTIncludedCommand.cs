﻿using Confluent.Kafka;
using corf.Communication.JWTTokenResolver;
using corf.Core.Messaging;
using Logging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog.LayoutRenderers;
using System.Linq;
using System.Text;
using System.Web;

namespace corf.Core.Commands
{
    public abstract class JWTIncludedCommand : BusinessCommand
    {
        private JWTTokenResolver _tokenResolver;
        private const string BearerPrefix = "Bearer ";
        public ILogger logger { get; private set; }

        public JWTIncludedCommand(ILogger logger, JWTTokenResolver tokenResolver) : base(logger)
        {
            this.logger = logger;
            _tokenResolver = tokenResolver;
        }
        private void PrepareMessageHeaders(InternalMessage message)
        {
            if (message is HttpMessage httpMessage)
            {
                foreach (var header in httpMessage.HttpHeaders)
                {

                    if (header.Value.GetType().Name == "String[]" || header.Value.GetType().Name == "StringValues")
                    {
                        message.Headers.Add(header.Key, header.Value[0]);
                    }
                    else
                    {
                        message.Headers.Add(header.Key, header.Value.ToString());
                    }
                }
            }
        }
        public override Task<InternalMessage> Execute(InternalMessage message)
        {
            PrepareMessageHeaders(message);
            JWTIncludedInternalMessage jwtIncludedMessage =
                JsonConvert.DeserializeObject<JWTIncludedInternalMessage>(JsonConvert.SerializeObject(message));
            string? token = "";
            if (message is HttpMessage httpMessage)
            {
                token = httpMessage.AuthorizationHeader.ToString();
                if (!string.IsNullOrEmpty(token) && token.StartsWith(BearerPrefix))
                {
                    token = token.Substring(BearerPrefix.Length);
                }
            }
            if (!String.IsNullOrEmpty(token))
            {
                jwtIncludedMessage.JWTTokenClearData = _tokenResolver.ResolveToken(token);
                string encoded = System.Text.Encoding.ASCII.GetString(Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(jwtIncludedMessage.JWTTokenClearData)));
                jwtIncludedMessage.Headers.Add("JWTTokenClearData", encoded);
            }
            return DoExecute(jwtIncludedMessage);
        }

        public abstract Task<InternalMessage> DoExecute(JWTIncludedInternalMessage message);
    }
}
