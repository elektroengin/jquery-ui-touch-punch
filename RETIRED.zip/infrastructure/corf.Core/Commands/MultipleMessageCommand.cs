﻿using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Core.Commands
{
    public abstract class MultipleMessageCommand : BusinessCommand
    {
        public ConcurrentQueue<InternalMessage> InternalMessages { get; private set; }

        public RunningMode RunningMode { get; set; } = RunningMode.Parallel;


        //Wait Duration before next run. It is only used with SyncNoWait mode and needs to MaxMessagesCountBeforeWait bigger than zero
        public int WaitDuration { get; set; }
        public int MaxMessagesCountBeforeWait { get; set; }

        public MultipleMessageCommand(ILogger logger) : base(logger)
        {
            InternalMessages = new ConcurrentQueue<InternalMessage>();
        }

        public virtual void MultipleTasksExecuted(InternalMessage message)
        {
        }
    }
}
