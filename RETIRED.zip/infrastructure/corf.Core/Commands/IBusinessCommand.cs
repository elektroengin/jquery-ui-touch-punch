﻿using corf.Core.Messaging;
using corf.Core.Routing;

namespace corf.Core.Commands
{
    public interface IBusinessCommand
    {
        Task<InternalMessage> Execute(InternalMessage message);
        Task<InternalMessage> GetSignOnMessage();
        Task<bool> CheckSignOnResult(InternalMessage message);
        Task<InternalMessage> ExecuteInternal(InternalMessage message);
        MessageValidationResult Validate(InternalMessage message);

        AvailabilityResult CheckAvailability(InternalMessage request = null);
        Task<MessageValidationResult> Authorize(InternalMessage message);
        bool Authorized { get; }

        IRoute Route { get; set; }

        bool CheckDependentConnector { get; }
        string Convert2BusinessIdentifier(InternalMessage message);
        Task<InternalMessage> ReverseMessage(InternalMessage message);
        Task AfterMessageSent(InternalMessage message);
        Task<InternalMessage> GetSignOffMessage();

        MessageFormat InputMessageFormat { get; set; }
        MessageFormat OutputMessageFormat { get; set; }

        IBusinessCommand Clone();
        Task SingleMessageSent(InternalMessage originalMessage);
    }
}