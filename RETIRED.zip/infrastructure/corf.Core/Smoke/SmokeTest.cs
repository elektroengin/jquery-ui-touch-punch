﻿using Newtonsoft.Json.Linq;

namespace corf.Core.Smoke
{
    public abstract class SmokeTest
    {
        public JObject TestData { get; set; }

        public SmokeTest(JObject testData = null)
        {
            this.TestData = testData;
        }
        public abstract bool RunTest();

    }
}