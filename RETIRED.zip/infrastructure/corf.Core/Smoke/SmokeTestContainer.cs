﻿namespace corf.Core.Smoke
{
    public class SmokeTestContainer : List<SmokeTest>
    {
    }
}
