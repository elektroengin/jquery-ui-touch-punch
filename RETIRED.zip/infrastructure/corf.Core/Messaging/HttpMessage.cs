﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace corf.Core.Messaging
{
    public class HttpMessage : InternalMessage
    {
        public StringValues AuthorizationHeader { get; set; }
        public IFormFileCollection Files { get; set; }
        public IHeaderDictionary HttpHeaders { get; set; }

        public HttpMessage() : base()
        {
        }

        public override TModel CreateModel<TModel>()
        {
            return CreateModel<TModel>((JsonSerializerSettings)null);
        }

        public override TModel CreateModel<TModel>(JsonSerializerSettings settings)
        {
            return JsonConvert.DeserializeObject<TModel>(CreateJsonWithParameters(), settings);
        }

        public override TModel CreateModel<TModel>(params JsonConverter[] converters)
        {
            return JsonConvert.DeserializeObject<TModel>(CreateJsonWithParameters(), converters);
        }

        private string CreateJsonWithParameters()
        {
            var jObject = JObject.Parse(string.IsNullOrEmpty(InnerMessage) ? "{}" : InnerMessage);

            // route values and query strings
            foreach (var (key, value) in ChannelCustomParameters)
            {
                if (!jObject.ContainsKey(key))
                {
                    jObject.Add(key, value);
                }
            }

            return jObject.ToString();
        } 

        public static HttpMessage ParseFromJson(string json)
        {
            var httpMessage = new HttpMessage();
            var jObject = JObject.Parse(json);

            httpMessage.InnerMessage = jObject["InnerMessage"]?.ToString();
            httpMessage.OriginalMessage = jObject["OriginalMessage"]?.ToString();
            httpMessage.ReceiverChannelId = jObject["ReceiverChannelId"]?.ToString();
            httpMessage.ReturnToReceiverChannel =
                jObject["ReturnToReceiverChannel"]?.ToObject<bool>() ?? false;
            httpMessage.Unique = jObject["Unique"]?.ToString();
            httpMessage.RemoteIpAddress = jObject["RemoteIpAddress"]?.ToString();

            var additionalInfoObject = jObject["AdditionalInfo"];

            if (additionalInfoObject?["ModuleJourney"] is { } moduleJourneys)
            {
                foreach (var journey in moduleJourneys)
                {
                    httpMessage.AdditionalInfo.ModuleJourney.Add(new ModuleMessageLifeCycle
                    {
                        ModuleName = journey["ModuleName"]?.ToString(),
                        EntryDate = journey["EntryDate"]?.ToObject<DateTime>() ?? default,
                        ExitDate = journey["ExitDate"]?.ToObject<DateTime>() ?? default,
                        DestinationChannelName = journey["DestinationChannelName"]?.ToString(),
                        SourceChannelName = journey["SourceChannelName"]?.ToString()
                    });
                }
            }

            return httpMessage;
        }
    }
}
