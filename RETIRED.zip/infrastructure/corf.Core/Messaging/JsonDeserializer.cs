﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System.Dynamic;

namespace corf.Core.Messaging
{
    public class JsonDeserializer : IDeserializer
    {
        private readonly ILogger _logger;
        public JsonDeserializer(ILogger<JsonDeserializer> logAdapter)
        {
            _logger = logAdapter;
        }
        public object Deserialize(InternalMessage message)
        {
            _logger.LogInformation("{unique} | Json Deserializer | {additionalMessage}", message.Unique, $"Incoming message: {message.InnerMessage}");
            dynamic innerMessage = JsonConvert.DeserializeObject<ExpandoObject>(message.InnerMessage);
            return innerMessage;
        }

        public ExpandoObject? DeserializeToExpandoObject(InternalMessage message)
        {
            return JsonConvert.DeserializeObject<ExpandoObject>(message?.InnerMessage, new ExpandoObjectConverter());
        }

        public JObject DeserializeToJObject(InternalMessage message)
        {
            return JObject.Parse(message.InnerMessage);
        }
    }
}
