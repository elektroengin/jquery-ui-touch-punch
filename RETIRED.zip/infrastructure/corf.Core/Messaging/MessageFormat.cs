﻿namespace corf.Core.Messaging
{
    public enum MessageFormat
    {
        Json = 0, 
        BkmIso,
        MastercardIso,
        VisaIso,
        AkilIso,
        VposIso,
        UnionIso,
        MirIso,
        PposIso,
        TposIso
    }
}
