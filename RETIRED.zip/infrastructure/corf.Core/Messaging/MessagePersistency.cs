﻿namespace corf.Core.Messaging
{
    public enum MessagePersistency
    {
        /// <summary>
        /// Message is persistent, meaning not affected by queue manager's status.
        /// </summary>
        Persistent,
        /// <summary>
        /// Message is non persistent, meaning not stored if queue manager is down.
        /// </summary>
        NonPersistent,
        /// <summary>
        /// Message is stored according to queue manager's persistency settings.
        /// </summary>
        QueueDefined
    }
}
