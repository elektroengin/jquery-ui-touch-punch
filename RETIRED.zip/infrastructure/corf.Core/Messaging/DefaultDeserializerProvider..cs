﻿using Microsoft.Extensions.Logging;

namespace corf.Core.Messaging
{
    public class DefaultDeserializerProvider : IDeserializerProvider
    {
        private ILogger _logger;
        private JsonDeserializer _jsonDeserializer;
        public DefaultDeserializerProvider(ILogger<DefaultDeserializerProvider> logger, JsonDeserializer jsonDeserializer)
        {
            _logger = logger;
            _jsonDeserializer = jsonDeserializer;
        }
        public IDeserializer GetDeserializer(MessageFormat messageFormat)
        {
            return _jsonDeserializer;
        }
    }
}
