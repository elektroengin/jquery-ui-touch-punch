﻿namespace corf.Core.Messaging
{
    public interface IMessageReceived
    {
    }
}