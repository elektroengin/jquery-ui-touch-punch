﻿namespace corf.Core.Messaging
{
    public class ReturnValue<T>
    {
        public T? ReturnCode { get; set; }
        public string Description { get; set; } = string.Empty;

        private List<Exception>? _exceptions;
        public List<Exception> Exceptions
        {
            get
            {
                if (null != _exceptions) return _exceptions;
                _exceptions = new List<Exception>();
                return _exceptions;
            }
        }
    }
}
