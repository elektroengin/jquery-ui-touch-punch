﻿using corf.Communication.JWTTokenResolver.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Core.Messaging
{
    public  class JWTIncludedInternalMessage: InternalMessage
    {
        public JWTIncludedInternalMessage() : base()
        {
        }
      
        public JWTTokenClearData JWTTokenClearData { get; set; } = new JWTTokenClearData();
    }
}
