﻿namespace corf.Core.Messaging
{
    public interface IMessageSent
    {
    }
}