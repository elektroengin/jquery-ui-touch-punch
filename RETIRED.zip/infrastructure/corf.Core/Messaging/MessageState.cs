﻿namespace corf.Core.Messaging
{
    public enum MessageState
    {
        Arrived = 0,
        Executing = 1,
        Executed = 2,
        Sent = 3,
        Failed = 4,
        ExecutionFailed = 5,
        Terminate = 6
    }
}