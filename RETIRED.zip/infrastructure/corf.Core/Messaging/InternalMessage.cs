﻿using corf.BinaryConverter;
using corf.Core.Hosting;
using corf.Core.Routing;
using Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;

namespace corf.Core.Messaging
{
    public class InternalMessage
    {
   
        public Dictionary<string, object> Headers { get; set; }
        public ChannelCustomParameters ChannelCustomParameters { get; set; }

        public MessageAdditionalInfo AdditionalInfo { get; set; }

        public int AppSpecific {  get; set; }
        public string InternalReplyQueue { get; set; }
        public MessageFormat InnerMessageFormat { get; set; }
        public string IncomingMessageType { get; set; } = "Hex";

        [JsonIgnore]
        public JObject RuleExecutionObject { get; set; }

        public InternalMessage()
        {
            Headers = new Dictionary<string, object>();
            ChannelCustomParameters = new ChannelCustomParameters();
            AdditionalInfo = new MessageAdditionalInfo();
            Unique = Guid.NewGuid().ToString().Replace("-", "");
        }

        ~InternalMessage()
        {
            if (ScopeManager != null)
            {
                ScopeManager.Remove(Unique);
            }
        }

        private string? _innerMessage;

        public string? InnerMessage
        {
            get
            {
                return _innerMessage;
            }
            set
            {
                _innerMessage = value;
                _binaryMessage = null;
            }
        }

        [System.Text.Json.Serialization.JsonIgnore]
        [JsonIgnore]
        public MetricMonitoringMessage MonitoringDetails { get; set; }

        [JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public IConnectionController Connector { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [JsonIgnore]
        public string SpecificDestination { get; set; }

        private byte[]? _binaryMessage;

        [System.Text.Json.Serialization.JsonIgnore]
        [JsonIgnore]
        public byte[] BinaryMessage
        {
            get
            {
                if (_binaryMessage == null)
                {
                    if (string.IsNullOrWhiteSpace(InnerMessage) == false)
                    {
                        _binaryMessage = IncomingMessageType == "Hex" ? DataConvert.HexStringToBinary(InnerMessage) : DataConvert.StringToByte(InnerMessage);
                    }
                }

                return _binaryMessage;
            }
        }

        [System.Text.Json.Serialization.JsonIgnore]
        [JsonIgnore]
        public RequestScopeManager ScopeManager { get; internal set; }

        public string Unique { get; set; }
        
        public string DualMessageUniqueChannel { get; set; }
        
        public string ReceiverChannelId { get; set; }
        
        public bool ReturnToReceiverChannel { get; set; }

        public MessageState State { get; set; }

        public string FailReason { get; set; }

        public string OriginalMessage { get; set; }
        
        public string RemoteIpAddress { get; set; }

        public HttpStatusCode StatusCode { get; set; }

        public RoutingType RoutingType { get; set; } = RoutingType.Normal;

        public string BusinessResponse { get; set; }
       
        public string IncomingChannel { get; set; }
        public bool StopSending { get; set; }

        public virtual TModel CreateModel<TModel>()
        {
            return CreateModel<TModel>((JsonSerializerSettings)null);
        }

        public virtual TModel CreateModel<TModel>(JsonSerializerSettings settings)
        {
            return JsonConvert.DeserializeObject<TModel>(InnerMessage, settings);
        }

        public virtual TModel CreateModel<TModel>(params JsonConverter[] converters)
        {
            return JsonConvert.DeserializeObject<TModel>(InnerMessage, converters);
        }

        public InternalMessage Clone()
        {
            return this.MemberwiseClone() as InternalMessage;
        }

    }
}
