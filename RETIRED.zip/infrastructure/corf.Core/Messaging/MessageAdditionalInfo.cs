﻿namespace corf.Core.Messaging
{
    [Serializable]
    public class MessageAdditionalInfo
    {

        public List<ModuleMessageLifeCycle> ModuleJourney { get; set; }
        public object? ExtensionData { get; set; }
        public object? Payload { get; set; }

        public MessageAdditionalInfo()
        {
            ModuleJourney = new List<ModuleMessageLifeCycle>();
        }

        public string? ClientIpAddress { get; set; } 
        public string? ClientPort { get; set; } 
    }

    public class ModuleMessageLifeCycle
    {
        public string? ModuleName { get; set; }
        public string? MessageInstance { get; set; } 
        public DateTime EntryDate { get; set; }
        public DateTime ExitDate { get; set; }
        public string? DestinationChannelName { get; set; } 
        public string? SourceChannelName { get; set; } 
    }
}