﻿namespace corf.Core.Messaging
{
    public class KeyValueCollection : Dictionary<string, string>
    {
    }
}
