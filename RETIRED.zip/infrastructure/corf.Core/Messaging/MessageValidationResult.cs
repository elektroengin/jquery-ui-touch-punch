﻿namespace corf.Core.Messaging
{
    public class MessageValidationResult
    {
        public bool Succeed { get; set; }
        public string ResultMessage { get; set; } = string.Empty;
        public InternalMessage PayLoad { get;set; }
    }
}