﻿namespace corf.Core.Messaging
{
    public class MessageSentEventArgs : IMessageSent 
    {
        public MessageSentEventArgs(InternalMessage message)
        {
            Message = message;
        }
        public InternalMessage Message { get; private set; }
    }
}