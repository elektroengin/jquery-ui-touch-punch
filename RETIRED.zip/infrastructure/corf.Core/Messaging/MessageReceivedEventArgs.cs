﻿using corf.Core.Commands;

namespace corf.Core.Messaging
{
    public class MessageReceivedEventArgs : IMessageReceived 
    {
        public MessageReceivedEventArgs(InternalMessage message)
        {
            CreatedAt = DateTime.Now;
            Message = message;
        }

        public DateTime CreatedAt { get; }
        public InternalMessage Message { get; private set; }
        public bool UseSpecificExecuter { get; set; }
        public string Destination { get; set; } = string.Empty;
        public IBusinessCommand? Executer { get; set; }
    }
}