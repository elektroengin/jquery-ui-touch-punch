﻿namespace corf.Core.Messaging
{
    public interface IDeserializerProvider
    {
        IDeserializer GetDeserializer(MessageFormat messageFormat);
    }
}
