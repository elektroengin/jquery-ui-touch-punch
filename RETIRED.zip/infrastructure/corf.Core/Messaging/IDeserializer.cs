﻿using Newtonsoft.Json.Linq;
using System.Dynamic;

namespace corf.Core.Messaging
{
    public interface IDeserializer
    {
        public object Deserialize(InternalMessage message);

        public ExpandoObject DeserializeToExpandoObject(InternalMessage message);
        public JObject DeserializeToJObject(InternalMessage message);
    }
}
