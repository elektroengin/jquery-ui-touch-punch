﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace corf.Core.Messaging
{
    public static class InternalMessageExtention
    {
        private static string SerializeInnerMessage(object response)
        {
            return JsonConvert.SerializeObject(response, Formatting.Indented, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        }
        private static void AddHeaders(InternalMessage message, Dictionary<string, string> headers = null)
        {
            message.Headers.Add("Content-Type", "application/json");
            if (headers != null)
            {
                foreach (var header in headers)
                {
                    message.Headers.TryAdd(header.Key, header.Value);
                }
            }
        }
        public static void OK(this InternalMessage message, object response, Dictionary<string, string> headers = null)
        {
            message.InnerMessage = SerializeInnerMessage(response);
            message.StatusCode = System.Net.HttpStatusCode.OK;
            AddHeaders(message, headers);

        }
        public static void Created(this InternalMessage message, object response, Dictionary<string, string> headers = null)
        {
            message.InnerMessage = SerializeInnerMessage(response);
            message.StatusCode = System.Net.HttpStatusCode.Created;
            AddHeaders(message, headers);
        }

        public static bool IsSuccessStatusCode(this InternalMessage message)
        {
            return ((int)message.StatusCode >= 200) && ((int)message.StatusCode <= 299);
        }
    }
}
