﻿using System.Collections.Generic;

namespace corf.Core.Messaging
{
    public class ChannelCustomParameters: KeyValueCollection
    {
    }
}