﻿using Newtonsoft.Json;
using System.Reflection;

namespace corf.Core
{
    public static class ParseExtentions
    {
        public static T ToEnum<T>(this string value) where T : struct
        {
            T result;
            Enum.TryParse<T>(value, true, out result);
            return result;
        }

        public static int ToInt(this string value) 
        {
            int result;
            int.TryParse(value, out result);
            return result;
        }

        public static Int16 ToShort(this string value)
        {
            Int16 result;
            Int16.TryParse(value, out result);
            return result;
        }

        public static T FromDictionary<T>(Dictionary<string, string> parameters)
        {
            var instance = Activator.CreateInstance<T>();
            var properties = typeof(T).GetProperties();


            foreach (var property in properties)
            {
                var jsonPropertyAttribute = property.GetCustomAttribute<JsonPropertyAttribute>();

                if (jsonPropertyAttribute != null)
                {
                    if (parameters.Any(i => i.Key == jsonPropertyAttribute.PropertyName))
                    {

                        SetPropertyValue(instance, property.Name, parameters.First(i => i.Key == jsonPropertyAttribute.PropertyName).Value);


                    }
                }
                else
                {
                    if (parameters.Any(i => i.Key == property.Name))
                    {
                        SetPropertyValue(instance, property.Name, parameters.First(i => i.Key == property.Name).Value);
                    }
                }
            }

            return instance;
        }

        private static void SetPropertyValue<T>(this object obj, string propertyName, T propertyValue)
          where T : IConvertible
        {
            PropertyInfo pi = obj.GetType().GetProperty(propertyName);

            if (pi != null && pi.CanWrite)
            {
                pi.SetValue
                (
                    obj,
                    Convert.ChangeType(propertyValue, pi.PropertyType),
                    null
                );
            }
        }
    }
}
