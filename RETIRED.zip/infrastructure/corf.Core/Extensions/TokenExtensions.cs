﻿namespace corf.Core
{
    public static class TokenExtensions
    {
        struct Unit { }
        public static Task AsTask(this CancellationToken @this)
        {
            var tcs = new TaskCompletionSource<Unit>();

            @this.Register(() => tcs.SetResult(default));

            return tcs.Task;
        }
    }
}
