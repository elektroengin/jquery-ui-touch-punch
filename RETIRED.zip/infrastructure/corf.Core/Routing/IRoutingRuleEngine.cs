﻿using corf.Core.Messaging;
using Newtonsoft.Json.Linq;

namespace corf.Core.Routing
{
    public interface IRoutingRuleEngine
    {
        string ExecuteRules(string key, InternalMessage message);
        void AddRoutingRule(string key, JObject[] rules);
    }
}
