﻿namespace corf.Core.Routing
{
    public enum ConnectorUseType : short
    {
        Receive = 1,
        Transport = 2,
        Failover = 3,
        Signatory = 4,
        Scheduled = 5
    }
}