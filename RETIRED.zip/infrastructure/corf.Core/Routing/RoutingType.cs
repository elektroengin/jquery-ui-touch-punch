﻿namespace corf.Core.Routing
{
    public enum RoutingType
    {
        Normal,
        Signatory,
        Failover
    }
}