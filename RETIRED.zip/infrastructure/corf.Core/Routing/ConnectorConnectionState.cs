﻿namespace corf.Core.Routing
{
    public class ConnectorConnectionState
    {
        public string Name { get; set; } = string.Empty;
        public ConnectorUseType UseType { get; set; }
        public bool Connected { get; set; }
    }
}