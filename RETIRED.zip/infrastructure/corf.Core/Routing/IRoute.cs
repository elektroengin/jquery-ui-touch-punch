﻿using corf.Core.Messaging;

namespace corf.Core.Routing
{
    public interface IRoute
    {
        string Name { get; set; }
        IReceiveConnector[] ReceiveConnectors { get; }
        IScheduledConnector[] ScheduledConnectors { get; }
        TransportConnectorGroup TransportConnectors { get;}
        TransportConnectorGroup Signatories { get;}
        TransportConnectorGroup FailoverDestinations { get; }
        Task OperateNextStep(object sender, MessageReceivedEventArgs e, bool callAsync);
        bool Balanced { get; }
        Task<List<ConnectorConnectionState>> StartAsync();
        Task<bool> StopAsync();
        bool ExcludeHealthCheckControl { get; set; }
    }
}