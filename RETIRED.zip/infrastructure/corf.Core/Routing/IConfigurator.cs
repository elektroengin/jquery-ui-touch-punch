﻿using corf.Configuration;

namespace corf.Core.Routing
{
    public interface IConfigurator
    {
        List<IRoute> Routes { get; }
        Dictionary<string, List<IConnector>> ConnectorsDictionary { get; }
        IConnectorConfiguration ConnectorConfiguration { get; }
        List<IConnectorWatcher> Watchers { get; }
        string GetAssembly(string assemblyName);
        IHealthCheckConnector HealthCheckConnector { get; }
        string GetExecuterAssembly(string executerName);
        Dictionary<string, string> ConnectorDirections { get; }
    }
}
