﻿namespace corf.Configuration
{
    public class HealthCheckConnectorElement
    {
        public string Connectors { get; set; } = string.Empty;
        public string ControlPeriod { get; set; } = string.Empty;
        public string RetryCount { get; set; } = string.Empty;
    }
}