﻿namespace corf.Configuration
{
    public interface IConnectorConfiguration
    {
        ConnectorElement[]? Connectors { get; set; }

        UsingElement[]? Usings { get; set; }
        RouteElement[]? Routes { get; set; }
        ConnectorWatcherElement[]? Watchers { get; set; }
        Dictionary<string,string>? Assemblies { get; set; }
        ExecuterElement[]? Executers { get; set; }
        string ModuleName { get; set; }
        Redis? Redis { get; set; }
        HealthCheckConnectorElement? HealthCheckConnector { get; set; }
        SmokeTestConnectorElement? SmokeTestConnector { get; set; }


    }
}