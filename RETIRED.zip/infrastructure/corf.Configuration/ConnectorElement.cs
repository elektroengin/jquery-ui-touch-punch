﻿using Newtonsoft.Json.Linq;

namespace corf.Configuration
{
    public class ConnectorElement
    {
        [FlowDesign(Description = "Unique name of connector.4")]
        public string Name { get; set; } = string.Empty;

        [FlowDesign(Description = "Title")]
        public string Title { get; set; } = string.Empty;

        [FlowDesign(Description = "Description")]
        public string Description { get; set; } = string.Empty;

        [FlowDesign(ReadOnly = true)]
        public string Type { get; set; } = string.Empty;

        [FlowDesign(Display = false)]
        public JObject? Properties { get; set; }

        [FlowDesign(Description = "Connection count of connector. (It is used when RecurringChannel is true)")]
        public int ScaleSize { get; set; }

        [FlowDesign(Description = "True when multiple connections are needed", DefaultValue = false)]
        public bool RecurringChannel { get; set; }
    }
}
