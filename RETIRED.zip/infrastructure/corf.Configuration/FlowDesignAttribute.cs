﻿namespace corf.Configuration
{
    public class FlowDesignAttribute : Attribute
    {
        public string Description { get; set; } = "";
        public bool ReadOnly { get; set; } = false;
        public bool Display { get; set; } = true;
        public bool IsExecuterDefinition { get; set; }

        public object DefaultValue { get; set; } = string.Empty;
        public bool EnvironmentBasedVariable { get; set; }
    }
}