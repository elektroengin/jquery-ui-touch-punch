﻿namespace corf.Configuration
{
    public class ExecuterElement
    {

        public string Name { get; set; } = string.Empty;

        [FlowDesign(Display = false)]
        public string Assembly { get; set; } = string.Empty;
        public string InputMessageFormat { get; set; } = string.Empty;
        public string OutputMessageFormat { get; set; } = string.Empty;
        public string LifeTimeOption { get; set; } = string.Empty;
    }
}
