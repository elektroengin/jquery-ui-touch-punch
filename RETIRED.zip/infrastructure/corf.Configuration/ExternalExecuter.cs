﻿namespace corf.Configuration
{
    public class ExternalExecuter
    {
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string SpecificDestination { get; set; } = string.Empty;
    }
}
