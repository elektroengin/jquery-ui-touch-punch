﻿namespace corf.Configuration
{
    public class Redis
    {
        public string Server { get; set; } = string.Empty;
        public int Port { get; set; }
        public int ConnectTimeout { get; set; } = 5000;//milisecond default 5000 milisecond = 5 second
        public string Password { get; set; } = string.Empty;
        public double AbsoluteExpirationOnMinutes { get; set; }
        public double SlidingExpirationOnMinutes { get; set; }
    }
}