﻿using Newtonsoft.Json.Linq;

namespace corf.Configuration
{
    public class SmokeTestConnectorElement
    {
        public JObject? Properties { get; set; }
    }
}
