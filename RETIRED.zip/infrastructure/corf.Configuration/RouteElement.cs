﻿using Newtonsoft.Json.Linq;

namespace corf.Configuration
{
    public class RouteElement
    {
        public string Name { get; set; } = string.Empty;
        public string Receivers { get; set; } = string.Empty;
        public string Destinations { get; set; } = string.Empty;
        public string Signatories { get; set; } = string.Empty;
        public bool LoadBalance { get; set; }
        public string FailoverDestinations { get; set; } = string.Empty;
        public bool ExcludeHealthCheckControl { get; set; }
        public JObject[]? RoutingRules { get; set; }
    }
}
