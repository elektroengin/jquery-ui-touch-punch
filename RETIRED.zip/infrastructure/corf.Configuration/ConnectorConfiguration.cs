﻿namespace corf.Configuration
{
    public class ConnectorConfiguration : IConnectorConfiguration
    {

        public string ModuleName { get; set; } = string.Empty;

        public UsingElement[]? Usings { get; set; }
        public ConnectorElement[]? Connectors { get; set; }
        public RouteElement[]? Routes { get; set; }
        public ConnectorWatcherElement[]? Watchers { get; set; }
        public Dictionary<string, string>? Assemblies { get; set; }
        public Redis? Redis { get; set; }
        public ExecuterElement[]? Executers { get; set; }
        public HealthCheckConnectorElement? HealthCheckConnector { get; set; }
        public SmokeTestConnectorElement? SmokeTestConnector { get; set; }
    }
}
