﻿namespace corf.Configuration
{
    public class ConnectorWatcherElement
    {
        public string Name { get; set; } = string.Empty;
        public string Connections { get; set; } = string.Empty;
        public int CheckInterval { get; set; }
    }
}
