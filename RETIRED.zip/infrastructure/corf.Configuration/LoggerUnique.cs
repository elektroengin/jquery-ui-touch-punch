﻿namespace corf.Configuration
{
    public static class LoggerUnique
    {
        public const string CorfCore = "corf-core";
    }
}
