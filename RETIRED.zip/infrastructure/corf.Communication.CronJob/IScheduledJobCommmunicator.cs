﻿using corf.Core.Infrastructure;

namespace corf.Communication.CronJob
{
    public interface IScheduledJobCommunicator : ICommunicator
    {
    }
}
