﻿namespace corf.Communication.CronJob
{
    public class CustomConcurrentQuartzJob : BaseQuartzJob
    {
    }
}