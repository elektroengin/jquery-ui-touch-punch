﻿using Confluent.Kafka;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Quartz;
using System.Diagnostics;

namespace corf.Communication.CronJob
{
    public abstract class BaseQuartzJob : IJob
    {

        public virtual async Task Execute(IJobExecutionContext context)
        {
            Guid jobUnique = Guid.NewGuid();

            var logger = (ILogger)context.MergedJobDataMap["Logger"];
            var connector = (IScheduledConnector)context.MergedJobDataMap["Connector"];
            var provider = (IServiceProvider)context.MergedJobDataMap["Provider"];

            if (connector.RetryOnFailure && context.RefireCount > 0)
            {

                jobUnique = (Guid)context.MergedJobDataMap["JobUnique"];

                logger.LogInformation("{unique} | Retryring... | {additionalMessage}", LoggerUnique.CorfCore, $"RefireCount :[{context.RefireCount}], jobId : {jobUnique}");
            }
            else
            {
                context.MergedJobDataMap.Add("JobUnique", jobUnique);
            }

            Stopwatch stopwatch = Stopwatch.StartNew();

            IBusinessCommand? executer = null;
            
            bool multipleTaskExecutedFired = false;

            var cronJobMessage = new InternalMessage() { InnerMessage = "" };

            try
            {
                logger.LogInformation("{unique} | Job execution starting. | {additionalMessage}", LoggerUnique.CorfCore, $"Unique : {jobUnique}");

                executer = (IBusinessCommand)provider.CreateScope().ServiceProvider.GetService(Type.GetType(((ScheduledConnector)connector).OnReceiveCommandAssembly));

                var internalMessage = await executer.ExecuteInternal(cronJobMessage);

                if (internalMessage != null && internalMessage.State != MessageState.Failed)
                {
                    if (internalMessage.State == MessageState.Terminate)
                    {
                        logger.LogInformation("{unique} | Message terminated. | {additionalMessage}", internalMessage.Unique, $"Connector Name :[{connector.Name}]");
                        return;
                    }

                    multipleTaskExecutedFired = true;
                    connector.FireMessageReceived(new MessageReceivedEventArgs(internalMessage) { Executer = executer, UseSpecificExecuter = true });
                }
                else
                {
                    logger.LogWarning("{unique} | Job execution failed. Execution result message is null !! | {additionalMessage}", internalMessage?.Unique, $"Job Unique : {jobUnique} ");

                    if (executer != null && executer is MultipleMessageCommand multipleMessageCommand)
                    {
                        if (!multipleTaskExecutedFired)
                        {
                            multipleMessageCommand.MultipleTasksExecuted(cronJobMessage);
                        }
                        multipleMessageCommand.InternalMessages.Clear();
                    }


                    if (connector.RetryOnFailure)
                    {
                        await Task.Delay(connector.WaitDurationForRetry);

                        JobExecutionException je = new JobExecutionException("Failed on execution");

                        if (context.RefireCount < connector.RetryCount)
                        {
                            je.RefireImmediately = true;
                        }
                        else
                        {
                            je.RefireImmediately = false;
                        }

                        throw je;
                    }
                }
            }
            finally
            {
                stopwatch.Stop();

                logger.LogInformation("{unique} | Job execution finished. | {additionalMessage}", LoggerUnique.CorfCore, $"Unique : {jobUnique}  | Duration : {stopwatch.ElapsedMilliseconds} ms");
            }
        }
    }
    
}