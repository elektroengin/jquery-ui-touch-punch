﻿using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.CronJob
{
    public class ScheduledJobConnector : ScheduledConnector
    {
        public IScheduledJobCommunicator _communicator;

        public ScheduledJobConnector(ILogger<ScheduledJobConnector> logger, IScheduledJobCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }


        public override string ChannelDescription { get { return $"Scheduled Job Connector With [{CronExpression}]"; } }

    }
}
