﻿using corf.Configuration;
using corf.Core;
using Microsoft.Extensions.Logging;
using Quartz;
using Quartz.Impl;

namespace corf.Communication.CronJob
{
    public class ScheduledJobCommunicator : IScheduledJobCommunicator
    {
        protected ILogger<ScheduledJobCommunicator> _logger;
        IScheduler _schedular;
        private IServiceProvider _globalServiceProvider;


        public ScheduledJobCommunicator(ILogger<ScheduledJobCommunicator> logger, IServiceProvider serviceProvider)
        {
            _logger = logger;
            _globalServiceProvider = serviceProvider;
        }

        public bool IsConnected { get { return _schedular != null && _schedular.IsStarted; } }

        public IConnector Connector { get; private set; }

        public bool Initialized { get; private set; }

        public async Task<bool> CloseAsync()
        {
            try
            {
                await _schedular.Shutdown();

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Schedular could not be closed!!! | {additionalMessage}", LoggerUnique.CorfCore, $"scheduler name : {_schedular.SchedulerName}, ErrorMessage:{ex.Message}");
            }

            return await Task.FromResult(false);
        }

        public async Task<bool> ConnectAsync()
        {
            try
            {

                if (_schedular != null && _schedular.IsStarted)
                {
                    _logger.LogWarning("{unique} | Schedular is already started. Attempt is aborted. | {additionalMessage}", LoggerUnique.CorfCore, $"scheduler name : {_schedular.SchedulerName}");
                    return true;
                }

                ISchedulerFactory schedFact = new StdSchedulerFactory();
                //get a scheduler
                _schedular = await schedFact.GetScheduler();

                await _schedular.Start();

                string jobId = string.IsNullOrWhiteSpace(((ScheduledConnector)Connector).JobId) ? $"ScJob-{Connector.Name}" : ((ScheduledConnector)Connector).JobId;

                IDictionary<string, object> jobData = new Dictionary<string, object>
                {
                    { "Logger", _logger },
                    { "Connector", this.Connector },
                    { "Provider", this._globalServiceProvider}
                };

                JobBuilder jobBuilder = null;

                if (((ScheduledConnector)Connector).DisallowConcurrentExecution)

                {
                    jobBuilder = JobBuilder.Create<CustomUniqueQuartzJob>();
                }
                else
                {
                    jobBuilder = JobBuilder.Create<CustomConcurrentQuartzJob>();
                }

                IJobDetail job = jobBuilder
                        .SetJobData(new JobDataMap(jobData))
                        .WithIdentity(jobId, $"GenericGroup-{Connector.Name}")
                        .Build();

                ITrigger trigger = TriggerBuilder.Create()
                  .WithIdentity($"GenericTrigger-{Connector.Name}", $"GenericGroup-{Connector.Name}")
                  .StartNow()
                  .WithCronSchedule(((ScheduledConnector)Connector).CronExpression)
                  .Build();

                await _schedular.ScheduleJob(job, trigger);

                _logger.LogInformation("{unique} | Schedular started with cron expression | {additionalMessage}", LoggerUnique.CorfCore, $"scheduler name : {_schedular.SchedulerName}, cronExpression : {((ScheduledConnector)Connector).CronExpression}");

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "{unique} | Start failed with GeneralException Message! | {additionalMessage}", LoggerUnique.CorfCore, $"scheduler name : {_schedular.SchedulerName}, exception message : {ex.Message}");
                return false;
            }

            finally
            {
                Initialized = true;
            }
        }

        public void GetReady()
        {
        }

        public void Initialize(Connector connector)
        {
            Connector = connector;
        }
    }
}
