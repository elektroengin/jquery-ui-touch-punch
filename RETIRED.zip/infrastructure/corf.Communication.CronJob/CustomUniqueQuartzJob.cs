﻿using Quartz;

namespace corf.Communication.CronJob
{
    [DisallowConcurrentExecution]
    public class CustomUniqueQuartzJob : BaseQuartzJob
    {
    }
}
