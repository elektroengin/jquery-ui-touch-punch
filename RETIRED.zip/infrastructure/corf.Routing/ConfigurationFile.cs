﻿namespace corf.Routing
{
    internal class ConfigurationFile
    {
        public string FileName { get; set; }
        public string Path { get; set; }
    }
}