﻿using corf.Core.Routing;
using System;

namespace corf.Routing
{
    public class RoutingEventArgs : EventArgs
    {
        public RouteManager RouteManager { get; private set; }
        public IServiceProvider ServiceProvider { get; private set; }
        public ConnectorConnectionState[] ConnectorStates { get; private set; }
    }
}