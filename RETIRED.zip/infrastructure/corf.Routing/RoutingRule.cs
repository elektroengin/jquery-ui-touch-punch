﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace corf.Routing
{
    public class RoutingRule
    {
        public string Fields { get; set; }
        public string Values { get; set; }
        public string Decision { get; set; }
    }
}
