﻿using corf.Caching;
using corf.Caching.Redis;
using corf.Communication.HttpInfra;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Hosting;
using corf.Core.Messaging;
using corf.Core.Routing;
using corf.Core.Smoke;
using Grpc.Net.Client.Balancer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Diagnostics.Tracing.Parsers.Clr;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace corf.Routing
{

    public class GenericHostContainer : IGenericHostContainer
    {
        private IConfigurationRoot _configuration;

        private IHost _host;

        private IHostBuilder _hostBuilder;

        private bool _hasExternalRoutingDeserializer;


        private CancellationToken _hostCancelationToken = new CancellationToken();
        private CancellationTokenSource _hostCancelationTokenSource = new CancellationTokenSource();
        FileSystemWatcher shutDownWatcher = new FileSystemWatcher();



        public Dictionary<string, bool> ConfigurationFiles { get; private set; } = new Dictionary<string, bool>();
        private List<string> _allConfigFiles = new List<string>();
        private List<string> _replaceableConfigFiles = new List<string>();

        private readonly List<string> _configMapFiles = new List<string>();
        private readonly List<string> _secretFiles = new List<string>();
        private Dictionary<string, Type> _userDefinedSections = new Dictionary<string, Type>();
        private FileInfo shutdownFile;
        List<JObject> _allconfigurationFiles = new List<JObject>();

        public event EventHandler<RoutingEventArgs> RoutingStarted;
        private static readonly object _lockObject = new object();
        private string _configurationPath;

        public static IGenericHostContainer Instance { get { return Nested.instance; } }

        public IServiceCollection ExternalDescriptors { get; private set; } = new ServiceCollection();

        //TODO:Burada ne dönüleceğine bakıp mantıklı bir cevap dönülebilir.
        public IDictionary<object, object> Properties
        {
            get
            {
                return new Dictionary<object, object>();
            }
        }

        private class Nested
        {
            static Nested() { }
            internal static readonly GenericHostContainer instance = new GenericHostContainer();
        }

        private GenericHostContainer()
        {
        }

        public IGenericHostContainer AddConfigurationFile(string fileName, bool isReadOnly = false)
        {
            ConfigurationFiles.Add(fileName, isReadOnly);
            return this;
        }


        public IGenericHostContainer AddConfigMapFile(string fileName)
        {
            _configMapFiles.Add(fileName);
            return this;
        }
        public IGenericHostContainer AddSecretFile(string fileName)
        {
            _secretFiles.Add(fileName);
            return this;
        }
        public IGenericHostContainer AddShutdownControlFile(string filename)
        {
            shutdownFile = new FileInfo(filename);
            return this;
        }

        public IGenericHostContainer SetConfiguration(string path)
        {
            _configurationPath = path;

            var builder = new ConfigurationBuilder()
                    .SetBasePath(path);

            _allConfigFiles = ConfigurationFiles.Select(x => x.Key).ToList();

            _replaceableConfigFiles = ConfigurationFiles.Where(x => x.Value == false).Select(x => x.Key).ToList();

            string[] replaceableFiles = _replaceableConfigFiles.ToArray();

            ReplaceDictionaryValues(path, _configMapFiles.ToArray(), replaceableFiles, null, false);

            ReplaceDictionaryValues(path, _secretFiles.ToArray(), replaceableFiles, Encoding.GetEncoding("iso-8859-1"), true);

            foreach (string file in replaceableFiles)
            {
                builder.AddJsonFile(file, optional: false, reloadOnChange: true);
            }
            HttpServerCommunicator.ConfigurationFiles = this._allConfigFiles;
            HttpServerCommunicator.ConfigurationPath = _configurationPath;
            _configuration = builder.Build();

            return this;
        }

        private void ReplaceDictionaryValues(string configurationPath, string[] sourceFiles, string[] destinationFiles, Encoding encoding, bool base64Encoded)
        {
            Encoding defaultEncoding = encoding ?? Encoding.ASCII;
            foreach (var sourceFile in sourceFiles)
            {
                var sourceFilePairs = JsonConvert.DeserializeObject<Dictionary<string, string>>(File.ReadAllText(Path.Combine(configurationPath, sourceFile)));

                foreach (string destinationFile in destinationFiles)
                {
                    string configContent = File.ReadAllText(Path.Combine(configurationPath, destinationFile));

                    string ipVariable = Environment.GetEnvironmentVariable("MY_POD_IP");
                    if (string.IsNullOrWhiteSpace(ipVariable) == false)
                    {
                        configContent = configContent.Replace("{{MachineName}}", ipVariable);
                    }
                    else
                    {
                        //TODO:Dinamik aldırmanın bir yolu var mı?
                        configContent = configContent.Replace("{{MachineName}}", Environment.MachineName);
                    }
                    foreach (KeyValuePair<string, string> keyValuePair in sourceFilePairs)
                    {
                        configContent = configContent.Replace("{{" + keyValuePair.Key + "}}", base64Encoded ? defaultEncoding.GetString(Convert.FromBase64String(keyValuePair.Value)) : keyValuePair.Value);
                    }



                    File.WriteAllText(Path.Combine(configurationPath, destinationFile), configContent);
                }

            }

        }

        public async Task RunAsync(string[] args)
        {
            Init();
            _host = Host.CreateDefaultBuilder(args)
                 .ConfigureAppConfiguration((hostingContext, config) =>
                 {
                     setConfig(config, args);

                 }).ConfigureLogging((hostingContext, logging) =>
                 {
                     logging.AddFilter<ConsoleLoggerProvider>(level => level == LogLevel.None);
                     logging.ClearProviders();
                 }).Build();

            await _host.RunAsync(_hostCancelationToken);
        }

        public async void ShutdownAsync(object source, FileSystemEventArgs e)
        {
            IHostedService routeManager = _host.Services.GetService<IHostedService>();
            await routeManager.StopAsync(new CancellationToken());
            _hostCancelationTokenSource.Cancel();
        }
        private void Init()
        {
            var hostContainer = Configure<ServiceSettings>("service-global-settings")
            .AddTransient<IRoute, Route>()
            .AddSingleton<SmokeTestContainer>()
            .AddSingleton<ResolverFactory>(sp => new DnsResolverFactory(refreshInterval: TimeSpan.FromSeconds(30)))
            .AddTransient<IConnectorWatcher, ConnectorWatcher>()
            .AddSingleton<IRequestScopeManager, RequestScopeManager>()
            .AddSingleton<IRouteProvider, RouteProvider>()
            .AddSingleton<IRoutingRuleEngine, RoutingRuleEngine>()
            .AddSingleton<IExternalDependenyProvider>(Instance)
            .AddSingleton<IConfigurator, Configurator>()
            .AddSingleton<IHttpContextAccessor, HttpContextAccessor>()
            .AddSingleton<IConfigurationRoot>(_configuration);

            if (!_hasExternalRoutingDeserializer)
            {

                ExternalDescriptors.AddSingleton<JsonDeserializer>();
                ExternalDescriptors.AddSingleton<IDeserializerProvider, DefaultDeserializerProvider>();
            }

            ConfigureRouting(hostContainer);
            ConfigureUserDefinedSections();
            ConfigureShutdownWatcher();
            _hostCancelationToken = _hostCancelationTokenSource.Token;
        }

        private void ConfigureShutdownWatcher()
        {
            if (shutdownFile != null)
            {
                shutDownWatcher = new FileSystemWatcher(shutdownFile.DirectoryName, shutdownFile.Name);
                shutDownWatcher.Changed += new FileSystemEventHandler(ShutdownAsync);
                shutDownWatcher.Created += new FileSystemEventHandler(ShutdownAsync);
                shutDownWatcher.EnableRaisingEvents = true;
            }
        }

        private void ConfigureUserDefinedSections()
        {
            foreach (var keyvalue in _userDefinedSections)
            {
                foreach (var file in _allconfigurationFiles)
                {
                    var userDefinedSection = file.GetValue(keyvalue.Key);
                    if (userDefinedSection != null)
                    {
                        var providedObject = JsonConvert.DeserializeObject<JObject>(userDefinedSection.ToString());
                        AddSingleton(keyvalue.Value, providedObject.ToObject(keyvalue.Value));
                    }
                }
            }
        }

        private void ConfigureRouting(IGenericHostContainer hostContainer)
        {
            foreach (string file in _allConfigFiles)
            {
                StreamReader streamReader = new StreamReader(Path.Combine(_configurationPath, file));


                string content = streamReader.ReadToEnd();

                var currentFile = JObject.Parse(content);

                _allconfigurationFiles.Add(currentFile);

                var connectorSection = currentFile.GetValue("connectorConfiguration");

                if (connectorSection != null)
                {

                    ConnectorConfiguration connectorConfiguration = JsonConvert.DeserializeObject<ConnectorConfiguration>(connectorSection.ToString());
                    hostContainer.AddSingleton<IConnectorConfiguration>(connectorConfiguration);

                    if (connectorConfiguration.Usings != null)
                    {
                        foreach (var usingElement in connectorConfiguration.Usings)
                        {
                            string connectorAssembly = $"{usingElement.Value.Split(',')[0].Trim()}Connector, {usingElement.Value.Split(',')[1].Trim()}";

                            string communicatorAssembly = $"{usingElement.Value.Split(',')[0].Trim()}Communicator, {usingElement.Value.Split(',')[1].Trim()}";

                            var connectorName = communicatorAssembly.Split(',')[0].Trim().Split('.').Last();

                            string communicatorInterface = communicatorAssembly.Replace("." + connectorName, ".I" + connectorName);

                            try
                            {
                                hostContainer.AddTransient(Type.GetType(connectorAssembly));
                                hostContainer.AddTransient(Type.GetType(communicatorInterface), Type.GetType(communicatorAssembly));
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Could'nt load assembly [{connectorAssembly}]. Please add [{connectorAssembly}] reference to project. ex:{ex.Message}");
                            }
                        }
                    }

                    if (connectorConfiguration.Executers != null)
                    {
                        foreach (ExecuterElement executerElement in connectorConfiguration.Executers)
                        {
                            try
                            {
                                var lifeTimeOption = executerElement.LifeTimeOption.ToEnum<ServiceLifetime>();
                                Func<IServiceProvider, object> bussinessCommandfactory = (IServiceProvider provider) =>
                                {
                                    IBusinessCommand businessCommand = (IBusinessCommand)ActivatorUtilities.CreateInstance(provider, Type.GetType(executerElement.Assembly));
                                    businessCommand.InputMessageFormat = executerElement.InputMessageFormat.ToEnum<MessageFormat>();
                                    businessCommand.OutputMessageFormat = executerElement.OutputMessageFormat.ToEnum<MessageFormat>();
                                    return businessCommand;
                                };
                                hostContainer.ExternalDescriptors.Add(new ServiceDescriptor(Type.GetType(executerElement.Assembly), bussinessCommandfactory, lifeTimeOption));
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Could'nt load executer [{executerElement.Name}]. Please add assembly for [{executerElement.Name}]. ex:{ex.Message}");
                            }
                        }
                    }

                    if (connectorConfiguration.Redis != null)
                    {
                        AddStackExchangeRedisCache(connectorConfiguration.Redis);
                        hostContainer.AddSingleton<ICacheService, RedisCacheService>();
                    }
                    else
                    {
                        hostContainer.AddSingleton<ICacheService, TemporaryRedisCacheService>();
                    }
                }
            }
        }


        public IGenericHostContainer ConfigureSection<TConfiguration>(string sectionName)
        {
            _userDefinedSections.Add(sectionName, typeof(TConfiguration));
            return this;
        }

        public void AddStackExchangeRedisCache(Redis redis)
        {
            ExternalDescriptors.AddStackExchangeRedisCache(options =>
            {
                options.Configuration =
                    $"{redis.Server}:{redis.Port},password={redis.Password},connectTimeout={redis.ConnectTimeout},syncTimeout={redis.ConnectTimeout}";
            });
        }

        public IGenericHostContainer CreateBuilder(string[] args, Action<IHostBuilder, IGenericHostContainer> action)
        {
            Init();

            _hostBuilder = Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    HttpServerCommunicator.ConfigurationFiles = _allConfigFiles;
                    setConfig(config, args);
                })
                .ConfigureLogging((hostingContext, logging) =>
                {
                    logging.AddFilter<ConsoleLoggerProvider>(level => level == LogLevel.None);

                    logging.ClearProviders();
                })
                .ConfigureServices((context, services) =>
                {
                    addDependences(services);
                });

            action.Invoke(_hostBuilder, this);

            return this;
        }
        public void RunAsService()
        {
            _host = _hostBuilder.Build();
            _host.RunAsync().Wait(_hostCancelationToken);
        }

        private void addDependences(IServiceCollection services)
        {
            lock (_lockObject)
            {
                foreach (ServiceDescriptor descriptor in Instance.ExternalDescriptors)
                {
                    services.Add(descriptor);
                }

                services.AddHostedService<RouteManager>();
            }
        }

        private void setConfig(IConfigurationBuilder config, string[] args)
        {
            config.SetBasePath(_configurationPath);
            foreach (string file in _allConfigFiles)
            {
                config.AddJsonFile(file, optional: false, reloadOnChange: true);
            }
            config.AddEnvironmentVariables();

            if (args != null)
            {
                config.AddCommandLine(args);
            }

        }

        public IGenericHostContainer AddScoped<TService>() where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped<TService>();
            }
            return this;
        }

        public IGenericHostContainer AddScoped(Type serviceType, Type implementationType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped(serviceType, implementationType);
            }
            return this;
        }

        public IGenericHostContainer AddScoped(Type serviceType, Func<IServiceProvider, object> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped(serviceType, implementationFactory);
            }
            return this;
        }


        public IGenericHostContainer AddScoped(Type serviceType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped(serviceType);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddScoped<TService, TImplementation>()
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped<TService, TImplementation>();
            }
            return this;
        }

        public IGenericHostContainer AddScoped<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped<TService>(implementationFactory);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddScoped<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddScoped<TService, TImplementation>(implementationFactory);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddSingleton<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton<TService, TImplementation>(implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddSingleton<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton<TService>(implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddSingleton<TService>() where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton<TService>();
            }
            return this;
        }

        public IGenericHostContainer AddSingleton(Type serviceType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton(serviceType);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddSingleton<TService, TImplementation>()
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton<TService, TImplementation>();
            }
            return this;
        }

        public IGenericHostContainer AddSingleton(Type serviceType, Func<IServiceProvider, object> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton(serviceType, implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddSingleton(Type serviceType, Type implementationType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton(serviceType, implementationType);
            }
            return this;
        }

        public IGenericHostContainer AddSingleton<TService>(TService implementationInstance) where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton<TService>(implementationInstance);
            }
            return this;
        }

        public IGenericHostContainer AddSingleton(Type serviceType, object implementationInstance)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddSingleton(serviceType, implementationInstance);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddTransient<TService, TImplementation>(Func<IServiceProvider, TImplementation> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient<TService, TImplementation>(implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddTransient<TService>(Func<IServiceProvider, TService> implementationFactory) where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient<TService>(implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddTransient<TService>() where TService : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient<TService>();
            }
            return this;
        }

        public IGenericHostContainer AddTransient(Type serviceType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient(serviceType);
            }
            return this;
        }

        IGenericHostContainer IGenericHostContainer.AddTransient<TService, TImplementation>()
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient<TService, TImplementation>();
            }
            return this;
        }

        public IGenericHostContainer AddTransient(Type serviceType, Func<IServiceProvider, object> implementationFactory)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient(serviceType, implementationFactory);
            }
            return this;
        }

        public IGenericHostContainer AddTransient(Type serviceType, Type implementationType)
        {
            lock (_lockObject)
            {
                ExternalDescriptors.AddTransient(serviceType, implementationType);
            }
            return this;
        }

        public IGenericHostContainer Configure<TOptions>(string sectionName) where TOptions : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.Configure<TOptions>(_configuration.GetSection(sectionName));
            }
            return this;
        }

        public IGenericHostContainer Configure<TOptions>(string sectionName, Action<BinderOptions> configureBinder) where TOptions : class
        {
            lock (_lockObject)
            {
                ExternalDescriptors.Configure<TOptions>(_configuration.GetSection(sectionName), configureBinder);
            }
            return this;
        }

        public IGenericHostContainer AddSmokeTest(SmokeTest test)
        {
            ServiceProvider provider = ExternalDescriptors.BuildServiceProvider();
            SmokeTestContainer container = provider.GetRequiredService<SmokeTestContainer>();
            container.Add(test);
            return this;
        }


        public IHost Build()
        {
            return _hostBuilder.Build();
        }

        public IHostBuilder ConfigureAppConfiguration(Action<HostBuilderContext, IConfigurationBuilder> configureDelegate)
        {
            return _hostBuilder.ConfigureAppConfiguration(configureDelegate);
        }

        public IHostBuilder ConfigureServices(Action<IServiceCollection> configureServices)
        {
            return _hostBuilder.ConfigureServices(configureServices);
        }

        public IHostBuilder ConfigureServices(Action<HostBuilderContext, IServiceCollection> configureServices)
        {
            return _hostBuilder.ConfigureServices(configureServices);
        }

        public IHostBuilder ConfigureContainer<TContainerBuilder>(Action<HostBuilderContext, TContainerBuilder> configureDelegate)
        {
            return _hostBuilder.ConfigureContainer<TContainerBuilder>(configureDelegate);
        }

        public IHostBuilder ConfigureHostConfiguration(Action<IConfigurationBuilder> configureDelegate)
        {
            return _hostBuilder.ConfigureHostConfiguration(configureDelegate);
        }

        public IHostBuilder UseServiceProviderFactory<TContainerBuilder>(IServiceProviderFactory<TContainerBuilder> factory)
        {
            return _hostBuilder.UseServiceProviderFactory<TContainerBuilder>(factory);
        }

        public IHostBuilder UseServiceProviderFactory<TContainerBuilder>(Func<HostBuilderContext, IServiceProviderFactory<TContainerBuilder>> factory)
        {
            return _hostBuilder.UseServiceProviderFactory<TContainerBuilder>(factory);
        }

        public IGenericHostContainer AddRoutingDeserializer<T>() where T : IDeserializerProvider
        {
            lock (_lockObject)
            {
                _hasExternalRoutingDeserializer = true;
                ExternalDescriptors.AddSingleton(typeof(IDeserializerProvider), typeof(T));
            }
            return this;
        }

        public IGenericHostContainer AddSwaggerAuth(OpenApiSecurityScheme securityScheme)
        {
            ExternalDescriptors.AddSwaggerGen(options =>
            {
                options.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);

                options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    { securityScheme, Array.Empty<string>() }
                });
            });

            return this;
        }
    }
}
