﻿using corf.Core;
using corf.Core.Routing;

namespace corf.Routing
{
    public interface IRouteProvider
    {
        IRoute CreateRoute(string name, IReceiveConnector[] receiveConnectors, IScheduledConnector[] scheduledConnectors, TransportConnectorGroup transportConnectors, TransportConnectorGroup signatorires, TransportConnectorGroup failoverDestinations, bool balanced,  bool excludeHealthCheckControl);
    }
}
