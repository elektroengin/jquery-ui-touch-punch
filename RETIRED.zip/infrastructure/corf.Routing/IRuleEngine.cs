﻿using corf.Core.Messaging;
using System.Threading.Tasks;

namespace corf.Routing
{
    public interface IRuleEngine
    {
        Task<string> Evaluate(InternalMessage message, string routeName);
    }
}