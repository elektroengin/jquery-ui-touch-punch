﻿using corf.Core;
using corf.Core.Routing;

namespace corf.Routing
{
    public class RouteProvider : IRouteProvider
    {
        private IServiceProvider _serviceProvider;
        public RouteProvider(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        public IRoute CreateRoute(string name, IReceiveConnector[] receiveConnectors, IScheduledConnector[] scheduledConnectors, TransportConnectorGroup transportConnectors, TransportConnectorGroup signatorires, TransportConnectorGroup failoverDestinations, bool balanced, bool excludeHealthCheckControl)
        {
            var route = (Route)_serviceProvider.GetService(typeof(IRoute));
            route.ReceiveConnectors = receiveConnectors;
            route.ScheduledConnectors = scheduledConnectors;
            route.TransportConnectors = transportConnectors;
            route.Signatories= signatorires;
            route.FailoverDestinations = failoverDestinations;
            route.Balanced = balanced;
            route.Name = name;
            route.ExcludeHealthCheckControl = excludeHealthCheckControl;
            route.Initialize();
            return route;

        }
    }
}
