﻿using corf.Configuration;
using corf.Core;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace corf.Routing
{
    public class RouteManager : BackgroundService
    {
        private bool _isStarted = false;
        private ILogger<RouteManager> _logger;
        private IConfigurator _configurator;
        
        public RouteManager(ILogger<RouteManager> logger, IConfigurator configurator)
        {
            _logger = logger;
            _configurator = configurator;
        }

        public override async Task<List<ConnectorConnectionState>> StartAsync(CancellationToken cancellationToken)
        {
            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            if (!_isStarted)
            {
                _logger.LogInformation("{unique} | Route manager is starting...", LoggerUnique.CorfCore);
                _logger.LogInformation("{unique} | Starting defined routes.", LoggerUnique.CorfCore);

                foreach (var route in _configurator.Routes.FindAll(route => route.ExcludeHealthCheckControl == true))
                {
                    connectionStates.AddRange(await route.StartAsync());
                }

                List<Task> healthCheckConnectorControlTasks = new List<Task>();


                if (_configurator.HealthCheckConnector != null && _configurator.HealthCheckConnector.Connectors != null && _configurator.HealthCheckConnector.Connectors.Count > 0)
                {
                    Dictionary<string, IConnectionController> healthyConnector = new Dictionary<string, IConnectionController>();
                    foreach (var connector in _configurator.HealthCheckConnector.Connectors)
                    {
                        if (healthyConnector.ContainsKey(connector.Group))
                            continue;
                        healthyConnector.Add(connector.Group, connector);

                        _logger.LogDebug("{unique} | Waiting for the connector to be healthy, before starting the routes ... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{connector.Name}");
                        Action action = () =>
                        {
                            while (!connector.IsHealthy)
                            {
                                Thread.Sleep(2000); // + ControlPeriod for initializing
                                try
                                {
                                    connector.ConnectAsync().Wait();
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, "{unique} | error on connection | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:{ex.Message}");
                                }
                            }
                            if (connector.IsHealthy)
                                _logger.LogDebug("{unique} | Connector is healthy, routes starting... | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{connector.Name}");

                        };
                        Task task = new Task(action);
                        task.Start();
                        healthCheckConnectorControlTasks.Add(task);

                    }


                    long retryCount = 0;
                    while (healthCheckConnectorControlTasks.Count > 0)
                    {
                        if (healthCheckConnectorControlTasks[0].IsCompleted)
                        {
                            healthCheckConnectorControlTasks.RemoveAt(0);
                            continue;
                        }
                        Thread.Sleep(_configurator.HealthCheckConnector.ControlPeriod);
                        retryCount++;
                        if (retryCount > _configurator.HealthCheckConnector.RetryCount)
                        {
                            throw new Exception($"{healthCheckConnectorControlTasks.Count} con is not healty!");
                        }
                    }
                }


                try
                {
                    foreach (var route in _configurator.Routes.FindAll(route => route.ExcludeHealthCheckControl == false))
                    {
                        connectionStates.AddRange(await route.StartAsync());
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogCritical(ex, "{unique} | An error occured while starting the route. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:{ex.Message}");
                }

                _logger.LogDebug("{unique} | All defined routes started.", LoggerUnique.CorfCore);
                _logger.LogInformation("{unique} | Route manager started...", LoggerUnique.CorfCore);


                _logger.LogDebug("{unique} | Checking connector watchers...", LoggerUnique.CorfCore);

                try
                {
                    foreach (var watcher in _configurator.Watchers)
                    {
                        _logger.LogDebug("{unique} | Watcher is starting | {additionalMessage}", LoggerUnique.CorfCore, $"Watcher Name :{watcher.Name}");

                        //do not await it.
                        watcher.WatchAsync();

                        _logger.LogDebug("{unique} | Watcher is started | {additionalMessage}", LoggerUnique.CorfCore, $"Watcher Name :{watcher.Name}");

                    }

                    _logger.LogDebug("{unique} | Watchers started to keep alive the connections.", LoggerUnique.CorfCore);
                }

                catch (Exception ex)
                {
                    _logger.LogCritical(ex,"{unique} | An error occured while starting the route. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");
                }

            }
            return connectionStates;

        }
        public override async  Task StopAsync(CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogInformation("{unique} | Watchers are stopping..", LoggerUnique.CorfCore);

                foreach (var watcher in _configurator.Watchers)
                {
                    await watcher.StopAsync();
                }

                _logger.LogInformation("{unique} | Watchers are stopped.", LoggerUnique.CorfCore);


                _logger.LogInformation("{unique} | Route manager is stopping...", LoggerUnique.CorfCore);


                foreach (var route in _configurator.Routes)
                {
                    await route.StopAsync();
                }
                _logger.LogInformation("{unique} | Route manager is stopped.", LoggerUnique.CorfCore);

            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "{unique} | An error occured while stopping the route. | {additinalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:{ex.Message}");
            }
        }

        protected async override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (stoppingToken.IsCancellationRequested == false)
            {
                _logger.LogInformation("{unique} | IHostedService working", LoggerUnique.CorfCore);
                await Task.Delay(2000, stoppingToken);
            }

            _logger.LogInformation("{unique} | IHostedService stopped!", LoggerUnique.CorfCore);
            Console.ReadLine();

        }
    }
}
