﻿using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Text;

namespace corf.Routing
{
    public class JsonContractResolver : DefaultContractResolver
    {
        private IServiceProvider _serviceProvider;
        public JsonContractResolver(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

         protected override JsonObjectContract CreateObjectContract(Type objectType)
        {
            JsonObjectContract contract = base.CreateObjectContract(objectType);
            contract.DefaultCreator = () => _serviceProvider.GetService(objectType);

            return contract;
        }
    }
}
