﻿using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System.Buffers;

namespace corf.Routing
{
    public class RootStartup
    {
        public void Configure()
        {
        }

        public void ConfigureServices(IServiceCollection services)
        {

            //foreach (ServiceDescriptor descriptor in WebHostContainer.Instance.ExternalDescriptors)
            //{
            //    services.Add(descriptor);
            //}

            services.AddHostedService<RouteManager>();

        }

    }
}