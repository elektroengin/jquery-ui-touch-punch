﻿using corf.Configuration;
using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Runtime.InteropServices;

namespace corf.Routing
{
    public class RoutingRuleEngine : Dictionary<string, List<RoutingRule>>, IRoutingRuleEngine
    {
        private readonly Dictionary<string, string> _cachedResults = new Dictionary<string, string>();
        private readonly IDeserializerProvider _deserializerProvider;
        private ILogger<RoutingRuleEngine> _logger;
        public RoutingRuleEngine(IDeserializerProvider deserializerProvider, ILogger<RoutingRuleEngine> logger)
        {
            this._deserializerProvider = deserializerProvider;
            _logger = logger;
        }

        private static string executablePath
        {
            get
            {
                if (!System.Diagnostics.Debugger.IsAttached && RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    return Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
                return Environment.CurrentDirectory;
            }
        }
        public void AddRoutingRule(string key, JObject[] rules)
        {
            try
            {
                var rulesList = new List<RoutingRule>();
                foreach (var rule in rules)
                {
                    var routingRule = new RoutingRule();

                    routingRule.Decision = rule["then"].ToString();
                    routingRule.Fields = rule["fields"].ToString();
                    routingRule.Values = rule["when"].ToString();
                    rulesList.Add(routingRule);
                }
                this.Add(key, rulesList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error on adding rule with the key. | {additionalMessage}", LoggerUnique.CorfCore, $"Key :{key}, ErrorMessage:{ex.Message}");
            }
        }

        public string ExecuteRules(string key, InternalMessage message)
        {
            if (ContainsKey(key) && message.State != MessageState.ExecutionFailed)
            {
                JObject messageJObject = message.RuleExecutionObject;

                if (message.RuleExecutionObject == null)
                {
                    IDeserializer deserializer = _deserializerProvider.GetDeserializer(message.InnerMessageFormat);
                    messageJObject = deserializer.DeserializeToJObject(message);
                }

                foreach (var rule in this[key])
                {
                    bool matched;

                    try
                    {
                        if(rule.Fields.ToLower() == "else")
                            return rule.Decision;

                        string compareString = string.Empty;

                        foreach(string field in rule.Fields.Split(";"))
                        {
                            compareString += messageJObject[field] + ";";
                        }
                        compareString = compareString.Substring(0, compareString.Length - 1);
                        _logger.LogInformation("{unique} | Field Compare. | {additionalMessage}", message.Unique, $"Compare String :[{compareString}] Field Name:{rule.Fields}");

                        matched = compareString == rule.Values;
                    }
                    catch(Exception ex)
                    {
                        matched = false;
                    }
                    if (!matched)
                    {
                        continue;
                    }

                    return rule.Decision;
                }

            }

            return string.Empty;
        }


    }
}
