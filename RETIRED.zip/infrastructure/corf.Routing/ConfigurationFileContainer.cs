﻿namespace corf.Routing
{
    public class ConfigurationFileContainer
    {
        public string FileName { get; set; }
    }
}