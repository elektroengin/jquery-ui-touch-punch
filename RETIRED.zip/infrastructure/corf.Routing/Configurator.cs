﻿using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Grpc;
using corf.Communication.HttpInfra.Rest;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Infrastructure;
using corf.Core.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Steeltoe.Common.Expression.Internal;
using System.Collections.Concurrent;
using System.Linq.Expressions;

namespace corf.Routing
{
    public class Configurator : IConfigurator
    {
        private readonly ConcurrentDictionary<Guid, Route> _routesDictionary;
        public Dictionary<string, List<IConnector>> ConnectorsDictionary { get; private set; }
        public Dictionary<string, IBusinessCommand> BusinessCommandsDictionary { get; private set; }
        public IHealthCheckConnector HealthCheckConnector { get; private set; }

        private readonly Dictionary<string, List<string>> _recurringConnectors;
        private readonly IRoutingRuleEngine _routingRuleEngine;
        private readonly IServiceProvider _provider;

        private readonly IOptions<ServiceSettings> _serviceSettings;
        public IConnectorConfiguration ConnectorConfiguration { get; private set; }

        private readonly ILogger<Configurator> _logger;

        public Configurator(IConnectorConfiguration connectorConfiguration, IOptions<ServiceSettings> serviceSettings, ILogger<Configurator> logger, IServiceProvider provider, IRoutingRuleEngine routingRuleEngine)
        {
            _routingRuleEngine = routingRuleEngine;
            _routesDictionary = new ConcurrentDictionary<Guid, Route>();
            HealthCheckConnector = new HealthCheckConnector();
            ConnectorsDictionary = new Dictionary<string, List<IConnector>>();
            BusinessCommandsDictionary = new Dictionary<string, IBusinessCommand>();
            _recurringConnectors = new Dictionary<string, List<string>>();
            _watchers = new List<IConnectorWatcher>();
            ConnectorDirections = new Dictionary<string, string>();
            ConnectorConfiguration = connectorConfiguration;
            _serviceSettings = serviceSettings;
            _provider = provider;
            _logger = logger;
            Configure();
        }

        private List<IRoute> _routes;
        public List<IRoute> Routes
        {
            get
            {
                if (_routes == null)
                {
                    _routes = new List<IRoute>();

                    foreach (var kvp in _routesDictionary)
                    {
                        _routes.Add(kvp.Value);
                    }
                }
                return _routes;
            }
        }

        private readonly List<IConnectorWatcher> _watchers;
        public List<IConnectorWatcher> Watchers
        {
            get
            {
                return _watchers;
            }
        }

        public Dictionary<string, string> ConnectorDirections { get; private set; }

        private void Configure()
        {
            try
            {
                AddDefaultAssemblies();

                CreateConnectors();

                CreateHealthCheckConnectors();

                CreateRoutes();

                CreateWatchers();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | An error occured while starting the route. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");
            }

        }

        private void CreateHealthCheckConnectors()
        {
            if (ConnectorConfiguration.HealthCheckConnector != null && !string.IsNullOrEmpty(ConnectorConfiguration.HealthCheckConnector.Connectors))
            {
                HealthCheckConnector.ControlPeriod = ConnectorConfiguration.HealthCheckConnector.ControlPeriod.ToInt();
                HealthCheckConnector.RetryCount = ConnectorConfiguration.HealthCheckConnector.RetryCount.ToShort();
                HealthCheckConnector.Connectors = new List<IConnectionController>();

                foreach (string connectorName in ConnectorConfiguration.HealthCheckConnector.Connectors.Split(','))
                {

                    var res = ConnectorsDictionary[connectorName];

                    if (res.Count > 0)
                    {
                        if (res[0] is IReceiveConnector)
                        {
                            HealthCheckConnector.Connectors.AddRange(ConnectorsDictionary[connectorName].Select(con => (IReceiveConnector)con));
                        }
                        else if (res[0] is IScheduledConnector)
                        {
                            HealthCheckConnector.Connectors.AddRange(ConnectorsDictionary[connectorName].Select(con => (IScheduledConnector)con));
                        }
                    }
                }
            }
        }

        private void AddDefaultAssemblies()
        {
            if (ConnectorConfiguration.Assemblies == null)
            {
                ConnectorConfiguration.Assemblies = new Dictionary<string, string>();
            }
            
            foreach (var usingElement in ConnectorConfiguration.Usings)
            {
                if (!ConnectorConfiguration.Assemblies.ContainsKey(usingElement.Key))
                {
                    string connectorAssembly = $"{usingElement.Value.Split(',')[0].Trim()}Connector, {usingElement.Value.Split(',')[1].Trim()}";
                    ConnectorConfiguration.Assemblies.Add(usingElement.Key, connectorAssembly);
                }
            }
        }

        private void AddAssembly<T>(string key, string direction)
        {
            ConnectorDirections.TryAdd(key, direction);

            if (!ConnectorConfiguration.Assemblies.ContainsKey(key))
            {
                ConnectorConfiguration.Assemblies.Add(key, string.Format("{0},{1}", typeof(T).FullName, typeof(T).Assembly.GetName().Name));
            }
        }
        private void CreateWatchers()
        {

            if (ConnectorConfiguration.Watchers != null)
            {
                foreach (ConnectorWatcherElement element in ConnectorConfiguration.Watchers)
                {

                    if (_watchers.FirstOrDefault(w => w.Name == element.Name) == null)
                    {
                        IConnectorWatcher watcher = _provider.GetService<IConnectorWatcher>();

                        watcher.Name = element.Name;

                        if (element.CheckInterval > 0)
                        {
                            watcher.CheckInterval = element.CheckInterval; //Do not override default value
                        }

                        var connections = element.Connections;

                        List<string> receiversArray = new List<string>();

                        foreach (var connection in connections.Split(','))
                        {
                            var originalContainerNames = string.Empty;

                            if (_recurringConnectors.ContainsKey(connection))
                            {
                                originalContainerNames = string.Join(",", _recurringConnectors[connection]);

                                element.Connections = element.Connections.Replace(connection, originalContainerNames);
                            }
                        }

                        foreach (string connectionName in element.Connections.Split(','))
                        {
                            foreach (IConnectionController connector in ConnectorsDictionary[connectionName])
                            {
                                watcher.AddConnector(connector);
                            }
                        }

                        _watchers.Add(watcher);
                    }
                }
            }
            _logger.LogInformation("{unique} | Watchers initialized..", LoggerUnique.CorfCore);
        }

        /// <summary>
        /// createRoutes
        /// </summary>
        private void CreateRoutes()
        {
            foreach (RouteElement routeElement in ConnectorConfiguration.Routes)
            {
                TransportConnectorGroup transportConnectors = new TransportConnectorGroup();

                var destinations = routeElement.Destinations;

                List<string> destinationsArray = new List<string>();

                foreach (var destination in destinations.Split(','))
                {
                    var originalContainerNames = string.Empty;

                    if (_recurringConnectors.ContainsKey(destination))
                    {
                        originalContainerNames = string.Join(",", _recurringConnectors[destination]);

                        routeElement.Destinations = routeElement.Destinations.Replace(destination, originalContainerNames);
                    }
                }

                foreach (string connectorName in routeElement.Destinations.Split(','))
                {
                    if (string.IsNullOrEmpty(connectorName) == false)
                    {
                        transportConnectors.GroupName = connectorName;
                        transportConnectors.AddRange(ConnectorsDictionary[connectorName].Where(con => con is ITransportConnector).Select(cn => (ITransportConnector)cn));
                    }
                }

                TransportConnectorGroup signatories = new TransportConnectorGroup();

                if (string.IsNullOrWhiteSpace(routeElement.Signatories) == false)
                {
                    foreach (string connectorName in routeElement.Signatories.Split(','))
                    {
                        if (string.IsNullOrEmpty(connectorName) == false)
                        {
                            signatories.GroupName = connectorName;

                            signatories.AddRange(ConnectorsDictionary[connectorName].Where(con => con is ITransportConnector).Select(cn => (ITransportConnector)cn));

                            signatories.IsSignatory = true;
                        }
                    }
                }

                TransportConnectorGroup failoverDestinations = new TransportConnectorGroup();

                if (string.IsNullOrWhiteSpace(routeElement.FailoverDestinations) == false)
                {
                    foreach (string connectorName in routeElement.FailoverDestinations.Split(','))
                    {
                        if (string.IsNullOrEmpty(connectorName) == false)
                        {
                            failoverDestinations.GroupName = connectorName;

                            failoverDestinations.AddRange(ConnectorsDictionary[connectorName].Where(con => con is ITransportConnector).Select(cn => (ITransportConnector)cn));

                            failoverDestinations.IsFailover = true;
                        }
                    }
                }

                List<IReceiveConnector> receiveConnectors = new List<IReceiveConnector>();
                List<IScheduledConnector> scheduledConnectors = new List<IScheduledConnector>();

                var receivers = routeElement.Receivers;

                List<string> receiversArray = new List<string>();
                
                foreach (var receiver in receivers.Split(','))
                {
                    var originalContainerNames = string.Empty;

                    if (_recurringConnectors.ContainsKey(receiver))
                    {
                        originalContainerNames = string.Join(",", _recurringConnectors[receiver]);

                        routeElement.Receivers = routeElement.Receivers.Replace(receiver, originalContainerNames);
                    }
                }

                foreach (string connectorName in routeElement.Receivers.Split(','))
                {
                    var res = ConnectorsDictionary[connectorName];

                    if (res.Count > 0)
                    {
                        if (res[0] is IReceiveConnector receiveConnector)
                        {
                            if (!string.IsNullOrWhiteSpace(receiveConnector.PrerequisiteConnectors))
                            {
                                var prerequisiteConnectors = new List<IConnectionController>();

                                foreach (var connector in receiveConnector.PrerequisiteConnectors.Split(';'))
                                {
                                    if (_recurringConnectors.ContainsKey(connector))
                                    {
                                        foreach (var connectonController in _recurringConnectors[connector])
                                        {
                                            prerequisiteConnectors.Add((IConnectionController)ConnectorsDictionary[connectonController][0]);
                                        }
                                    }
                                    else
                                    {
                                        foreach (var connectonController in ConnectorsDictionary[connector])
                                        {
                                            prerequisiteConnectors.Add((IConnectionController)connectonController);
                                        }
                                    }
                                }

                                receiveConnector.DependentTo = prerequisiteConnectors.ToArray();

                            }

                            if (_recurringConnectors.ContainsKey(connectorName))
                            {
                                foreach (string recurringConnector in _recurringConnectors[connectorName])
                                {
                                    var receiveList = ConnectorsDictionary[recurringConnector].Where(con => con is IReceiveConnector).Select(cn => (IReceiveConnector)cn);
                                    receiveConnectors.AddRange(receiveList);
                                }
                            }
                            else
                            {
                                receiveConnectors.AddRange(ConnectorsDictionary[connectorName].Where(con => con is IReceiveConnector).Select(cn => (IReceiveConnector)cn));
                            }
                        }
                        else if (res[0] is IScheduledConnector)
                        {
                            scheduledConnectors.AddRange(ConnectorsDictionary[connectorName].Select(con => (IScheduledConnector)con));
                        }
                    }
                }

                if (routeElement.RoutingRules != null && routeElement.RoutingRules.Length > 0)
                {
                    _routingRuleEngine.AddRoutingRule(routeElement.Name, routeElement.RoutingRules);
                }

                IRouteProvider routeProvider = _provider.GetService<IRouteProvider>();

                Route route = (Route)routeProvider.CreateRoute(routeElement.Name, receiveConnectors.ToArray(), scheduledConnectors.ToArray(), transportConnectors, signatories, failoverDestinations, routeElement.LoadBalance, routeElement.ExcludeHealthCheckControl);

                _routesDictionary.TryAdd(Guid.NewGuid(), route);
            }
        }

        private void CreateConnectors()
        {
            foreach (ConnectorElement connectorElement in ConnectorConfiguration.Connectors)
            {
                List<IConnector> connectors = new List<IConnector>();

                int scaleSize = connectorElement.ScaleSize == 0 ? 1 : connectorElement.ScaleSize;

                for (int i = 0; i < scaleSize; i++)
                {
                    int channelIndex = i + 1;

                    string assembly = GetAssembly(connectorElement.Type);

                    try
                    {
                        JsonContractResolver resolver = new JsonContractResolver(_provider);

                        string json = JsonConvert.SerializeObject(connectorElement.Properties);

                        json = json.Replace("#INDEX#", channelIndex.ToString());


                        IConnector connector = (IConnector)JsonConvert.DeserializeObject(json, Type.GetType(assembly), new JsonSerializerSettings
                        {
                            ContractResolver = resolver
                        }); 

                        connector.MachineSpecificInfo = _serviceSettings != null && _serviceSettings.Value != null ? _serviceSettings.Value.MachineSpecificInfo : null;
                        
                        connector.Name = connectorElement.Name.Replace("#INDEX#", channelIndex.ToString());
                        connector.Title = connectorElement.Title;
                        connector.Description = connectorElement.Description;


                        if (connectorElement.RecurringChannel && scaleSize > 0 && connectorElement.Name.Contains("#INDEX#") == false)
                        {
                            connector.Name = string.Format("{0}_{1}", connectorElement.Name, channelIndex);
                        }

                        connector.Group = connectorElement.Name.Replace("#INDEX#", "");

                        if (connector is DualConnector dual)
                        {
                            if (string.IsNullOrWhiteSpace(dual.ReceiverChannelId) == false)
                            {
                                dual.ReceiverChannelId = connector.MachineSpecificInfo != null ? dual.ReceiverChannelId?.Replace("#ModuleId#", connector.MachineSpecificInfo.AdditionalQueueNumber) : dual.ReceiverChannelId;
                            }
                        }


                        if (connector is IScheduledConnector scheduledConn)
                        {
                            string expression = scheduledConn.CronExpression;

                            if (expression.Contains("#P"))
                            {
                                string index = expression.Substring(expression.IndexOf("#P"), 3);

                                scheduledConn.CronExpression = scheduledConn.CronExpression.Replace(index, _serviceSettings.Value.ExternalParameters[index]);
                            }
                        }

                        if (connector is ITcpConnector tcpConnector)
                        {
                            string addressExpression = tcpConnector.Address;
                            string portExpression = tcpConnector.Port;

                            if (addressExpression.Contains("#P"))
                            {
                                tcpConnector.Address = tcpConnector.Address.Replace(addressExpression, _serviceSettings.Value.ExternalParameters[addressExpression].Split(':')[0]);
                            }
                            if (portExpression.Contains("#P"))
                            {
                                tcpConnector.Port = tcpConnector.Port.Replace(portExpression, _serviceSettings.Value.ExternalParameters[portExpression].Split(':')[1]);
                            }
                        }

                         connector.Initialize();

                        if (connector is IGrpcServerConnector grpcServerConnector)
                        {
                            foreach (var path in grpcServerConnector.Paths)
                            {
                                if (path.AllowPost)
                                {
                                    path.Post.ExecuterAssembly = AssignCommand(path, path.Post.ExecuterName, connectorElement);
                                    path.Post.ExecuterSpecificDestination = string.IsNullOrEmpty(path.Post.ExecuterSpecificDestination) == false ?
                                                                                path.Post.ExecuterSpecificDestination : "";
                                }
                            }
                        }

                        if (connector is IBalancedTcpClientConnector balancedTcpConnector)
                        {
                            if (string.IsNullOrWhiteSpace(balancedTcpConnector.EchoMessageGeneratorAssembly) == false)
                            {
                                var generator = (ITcpEchoMessageGenerator)ActivatorUtilities.CreateInstance(_provider, Type.GetType(GetAssembly(balancedTcpConnector.EchoMessageGeneratorAssembly)));
                                balancedTcpConnector.UseTcpEchoMessageGenerator(generator);
                            }
                        }

                        if (connector is IRestServerConnector serverConnector)
                        {
                            foreach (var path in serverConnector.Paths)
                            {
                                if (path.AllowGet)
                                {
                                    path.Get.ExecuterAssembly = AssignCommand(path, path.Get.ExecuterName, connectorElement);
                                    path.Get.ExecuterSpecificDestination = string.IsNullOrEmpty(path.Get.ExecuterSpecificDestination) == false ?
                                                                                path.Get.ExecuterSpecificDestination : "";

                                }
                                if (path.AllowPost)
                                {
                                    path.Post.ExecuterAssembly = AssignCommand(path, path.Post.ExecuterName, connectorElement);
                                    path.Post.ExecuterSpecificDestination = string.IsNullOrEmpty(path.Post.ExecuterSpecificDestination) == false ?
                                                                                path.Post.ExecuterSpecificDestination : "";

                                }
                                if (path.AllowPut)
                                {
                                    path.Put.ExecuterAssembly = AssignCommand(path, path.Put.ExecuterName, connectorElement);
                                    path.Put.ExecuterSpecificDestination = string.IsNullOrEmpty(path.Put.ExecuterSpecificDestination) == false ?
                                                                               path.Put.ExecuterSpecificDestination : "";

                                }
                                if (path.AllowDelete)
                                {
                                    path.Delete.ExecuterAssembly = AssignCommand(path, path.Delete.ExecuterName, connectorElement);
                                    path.Delete.ExecuterSpecificDestination = string.IsNullOrEmpty(path.Delete.ExecuterSpecificDestination) == false ?
                                                                              path.Delete.ExecuterSpecificDestination : "";

                                }
                            }
                        }

                        
                        if (connector is HttpClientConnector httpClientConnector)
                        {

                            if (httpClientConnector.UrlManagementAssigned)
                            {
                                var queueInfo = httpClientConnector.UrlManagementService.OpenConnection(httpClientConnector.UrlManagementQueueType).Result;

                                if (!string.IsNullOrEmpty(queueInfo.Path))
                                {
                                    httpClientConnector.Path = queueInfo.Path;
                                }

                                if (!string.IsNullOrEmpty(queueInfo.BaseAddress))
                                {
                                    httpClientConnector.BaseAddress = queueInfo.BaseAddress;

                                }
                            }

                            httpClientConnector.Path = httpClientConnector.Path.Replace("#INDEX#", channelIndex.ToString());
                            httpClientConnector.Path = httpClientConnector.Path.Replace("#ModuleId#", _serviceSettings?.Value.MachineSpecificInfo.AdditionalQueueNumber);
                        }

                        connectors.Add(connector);

                        if (connectorElement.RecurringChannel)
                        {
                            if (!_recurringConnectors.ContainsKey(connector.Group))
                            {
                                _recurringConnectors.Add(connector.Group, new List<string>());
                            }

                            _recurringConnectors[connector.Group].Add(connector.Name);
                            ConnectorsDictionary.Add(connector.Name, new List<IConnector> { connector });
                        }

                    }
                    catch (Exception ex)
                    {
                        throw new NotImplementedException($"Connector type {connectorElement.Type} is not implemented correctly", ex);
                    }
                }
                if (connectorElement.RecurringChannel == false)
                {
                    ConnectorsDictionary.Add(connectorElement.Name, connectors);
                }
            }
        }
        private string AssignCommand(IPathInfo path, string executerName, ConnectorElement connectorElement)
        {

            string assemblyName = !string.IsNullOrWhiteSpace(executerName) ? executerName : "";

            var connectorAssembly = "";

            if (string.IsNullOrWhiteSpace(assemblyName) == false)
            {
                connectorAssembly = GetExecuterAssembly(assemblyName);
            }

            return connectorAssembly;
        }

        public string GetAssembly(string assemblyName)
        {
            if (!string.IsNullOrEmpty(assemblyName))
            {
                if (ConnectorConfiguration.Assemblies.ContainsKey(assemblyName))
                {
                    return ConnectorConfiguration.Assemblies[assemblyName];
                }
            }

            return string.Empty;
        }

        public string GetExecuterAssembly(string executerName)
        {
            string executerAssembly = null;
            if (!string.IsNullOrEmpty(executerName))
            {
                ExecuterElement executerElement = ConnectorConfiguration.Executers?.Where(executer => executer.Name == executerName).FirstOrDefault();
                if (executerElement != null)
                    executerAssembly = executerElement.Assembly;
                else
                    executerAssembly = GetAssembly(executerName);
            }
            return executerAssembly;
        }
    }
}
