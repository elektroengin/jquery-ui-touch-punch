﻿using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using corf.Core.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace corf.Routing
{
    public class Route : IRoute
    {
        private readonly ILogger<Route> _logger;
        static readonly List<Connector> startedReceiveConntectors = new List<Connector>();
        static readonly List<Connector> startedTransportConnectors = new List<Connector>();
        IRoutingRuleEngine _routingRuleEngine;
        IConnectorConfiguration _connectorConfiguration;
        IRequestScopeManager _requestScopeManager;

        private string _moduleName;
        public bool ExcludeHealthCheckControl { get; set; }
        //Dependencies : Receive Connectors, Transport Connectors
        public Route(IRoutingRuleEngine routingRuleEngine, IConnectorConfiguration connectorConfiguration, ILogger<Route> logAdapter, IRequestScopeManager requestScopeManager)
        {
            _connectorConfiguration = connectorConfiguration;
            _routingRuleEngine = routingRuleEngine;
            _requestScopeManager = requestScopeManager;
            _logger = logAdapter;
        }

        public void Initialize()
        {
            _logger.LogInformation("{unique} | Route is initializing. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");
            _moduleName = string.IsNullOrEmpty(_connectorConfiguration.ModuleName)
               ? Process.GetCurrentProcess().MainModule.ModuleName
               : _connectorConfiguration.ModuleName;
        }

        public async Task<List<ConnectorConnectionState>> StartAsync()
        {
            _logger.LogInformation("{unique} | Route is starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            //TODO: Başlama adımları ortak bir metodda birleştirilebilir. Şu an için farklılaşma olabileceği ihtimaline karşı ayrı turuldu. İA - 27.12.2020

            connectionStates.AddRange(await StartTransportConnectors());

            connectionStates.AddRange(await StartSignatories());

            connectionStates.AddRange(await StartFailoverDestinations());

            connectionStates.AddRange(await StartReceiveConnectors());

            connectionStates.AddRange(await StartSchedularConnectors());

            _logger.LogInformation("{unique} | Route is started. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return connectionStates;
        }

        private async Task<List<ConnectorConnectionState>> StartSchedularConnectors()
        {
            _logger.LogInformation("{unique} | Scheduling connectors are starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            foreach (ScheduledConnector connector in ScheduledConnectors)
            {
                connector.Route = this;
                bool isConnected = await connector.ConnectAsync();
                connectionStates.Add(new ConnectorConnectionState { Name = connector.Name, UseType = ConnectorUseType.Receive, Connected = isConnected });
            }

            _logger.LogInformation("{unique} | Scheduling connectors are started. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return connectionStates;
        }

        private async Task<List<ConnectorConnectionState>> StartReceiveConnectors()
        {
            _logger.LogInformation("{unique} | Receive connectors are starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            foreach (IReceiveConnector connector in ReceiveConnectors)
            {
                connector.Route = this;
                bool isConnected = false;

                if (startedReceiveConntectors.Contains(connector as Connector) == false
                    && startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    isConnected = await connector.ConnectAsync();
                }

                if (startedReceiveConntectors.Contains(connector as Connector) == false)
                {
                    if (connector.EndlessReceive)
                    {
                        await Task.Factory.StartNew(async () => await connector.ReceiveAsync(), TaskCreationOptions.LongRunning);
                    }
                }

                connectionStates.Add(new ConnectorConnectionState { Name = connector.Name, UseType = ConnectorUseType.Receive, Connected = isConnected });

                startedReceiveConntectors.Add(connector as Connector);
            }
            _logger.LogInformation("{unique} | Receive connectors are started. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return connectionStates;
        }

        private async Task<List<ConnectorConnectionState>> StartFailoverDestinations()
        {
            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            if (FailoverDestinations != null && FailoverDestinations.Count > 0)
                _logger.LogInformation("{unique} | Failover connectors are starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            foreach (ITransportConnector connector in FailoverDestinations)
            {
                if (startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    connector.MessageSent += Connector_MessageSent;
                }

                bool isConnected = false;

                if (startedReceiveConntectors.Contains(connector as Connector) == false
                    && startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    isConnected = await connector.ConnectAsync();
                }

                connectionStates.Add(new ConnectorConnectionState { Name = connector.Name, UseType = ConnectorUseType.Failover, Connected = isConnected });

                startedTransportConnectors.Add(connector as Connector);
            }

            _logger.LogInformation("{unique} | Failover connectors started. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return connectionStates;
        }

        private async Task<List<ConnectorConnectionState>> StartSignatories()
        {
            _logger.LogInformation("{unique} | Signatory connectors are starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            foreach (ITransportConnector connector in Signatories)
            {
                bool isConnected = false;
                if (startedReceiveConntectors.Contains(connector as Connector) == false
                    && startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    isConnected = await connector.ConnectAsync();
                }

                if (startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    connector.MessageSent += Connector_MessageSent;
                }

                connectionStates.Add(new ConnectorConnectionState { Name = connector.Name, UseType = ConnectorUseType.Signatory, Connected = isConnected });

                startedTransportConnectors.Add(connector as Connector);
            }

            _logger.LogInformation("{unique} | Signatory connectors started. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return connectionStates;
        }

        private async Task<List<ConnectorConnectionState>> StartTransportConnectors()
        {
            _logger.LogInformation("{unique} | Transport connectors are starting. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            List<ConnectorConnectionState> connectionStates = new List<ConnectorConnectionState>();

            foreach (ITransportConnector connector in TransportConnectors)
            {
                bool isConnected = false;
                if (startedReceiveConntectors.Contains(connector as Connector) == false
                   && startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    isConnected = await connector.ConnectAsync();
                }

                if (startedTransportConnectors.Contains(connector as Connector) == false)
                {
                    connector.MessageSent += Connector_MessageSent;
                }

                connectionStates.Add(new ConnectorConnectionState { Name = connector.Name, UseType = ConnectorUseType.Transport, Connected = isConnected });

                startedTransportConnectors.Add(connector as Connector);
            }

            _logger.LogInformation("{unique} | Transport connectors started. | {additionalMessage}", LoggerUnique.CorfCore, $"[{Name}]");

            return connectionStates;
        }

        public async Task OperateNextStep(object sender, MessageReceivedEventArgs e, bool callAsync)
        {
            if (callAsync)
            {
                await Task.Delay(1);
            }


            IMessagePublisher connector = (IMessagePublisher)sender;

            IBusinessCommand command = null;

            bool sent = false;

            InternalMessage message = e.Message;

            if (message == null)
            {
                _logger.LogWarning("Message is null. Will not be processed. Skipping...}");
                return;
            }

            string originalMessageUnique = message.Unique;

            var cloneMessage = message.Clone();

            bool multipleTaskEventFired = false;

            bool addedIntoDiscovery = false;

            DualConnector journeyConnector = null;

            Exception sendingException = null;

            if (connector is DualConnector dualConnector && dualConnector.CheckJourneyTimeOuts)
            {
                journeyConnector = dualConnector;

                if (dualConnector.MessageDiscovery.TryAdd(message.Unique, new MessageTimer { ReceivedMessage = cloneMessage, ReceiveDate = DateTime.Now }))
                {
                    addedIntoDiscovery = true;
                }
            }

            try
            {

                command = e.UseSpecificExecuter && e.Executer != null ? e.Executer : connector.GetCommand<IBusinessCommand>(connector.OnReceiveCommandAssembly, e.Message.Unique);

                message.IncomingChannel = connector.Group;

                message.IncomingMessageType = connector.InnerMessageType;

                message.State = MessageState.Arrived;

                if (message.AdditionalInfo == null)
                {
                    message.AdditionalInfo = new MessageAdditionalInfo();
                }

                var journey = message.AdditionalInfo.ModuleJourney.FirstOrDefault(j => j.ModuleName == this.Name);

                if (journey != null)
                {
                    journey.ExitDate = DateTime.Now;
                }
                else
                {
                    journey = new ModuleMessageLifeCycle()
                    {
                        ModuleName = this.Name,
                        SourceChannelName = $"{connector.ChannelDescription}",
                        EntryDate = DateTime.Now
                    };

                    message.AdditionalInfo.ModuleJourney.Add(journey);
                }

                _logger.LogInformation("{unique} | New message received.. | {additionalMessage}", message.Unique, connector.Name);

                _logger.LogInformation("{unique} | Inner Message | {additionalMessage}", message.Unique, message.InnerMessage);


                if (command != null && !(connector is IScheduledConnector))
                {
                    command.Route = this;
                    _logger.LogTrace("{unique} | PreCommand execution. | {additionalMessage}", message.Unique, $"Command : [{command.GetType().Name}]");
                    message.Connector = connector;
                    message.InnerMessageFormat = command.InputMessageFormat;

                    if (command is MultipleMessageCommand multipleCommand)
                    {
                        command = command.Clone();
                        multipleCommand.InternalMessages.Clear();
                    }
                    message = await command.ExecuteInternal(message);

                    if (message == null)
                    {
                        sendingException = new ArgumentNullException("message", $"A null message returned from {command.GetType().Name}. Will not be executed.");
                        _logger.LogWarning("{unique} | A null message returned. Will not be executed. | {additionalMessage}", $"Command:{command.GetType().Name}");
                        return;
                    }
                    message.InnerMessageFormat = command.OutputMessageFormat;

                }

                sent = true;

                if (addedIntoDiscovery && journeyConnector != null)
                {
                    journeyConnector.MessageDiscovery[message.Unique].SentMessage = message.Clone();
                }

                string destination = string.IsNullOrWhiteSpace(message.SpecificDestination) ? _routingRuleEngine.ExecuteRules(this.Name, message) : message.SpecificDestination;

                if (string.IsNullOrWhiteSpace(destination))
                {
                    destination = e.Destination;
                }

                _logger.LogInformation("{unique} | Custom Destination Check. | {additionalMessage}", message.Unique, $"Destination : {destination}");

                if (message.State == MessageState.Terminate)
                {
                    _logger.LogInformation("{unique} | Message terminated. | {additionalMessage}", message.Unique, $"RouteName:{Name}");
                    return;
                }

                if (command is MultipleMessageCommand multipleMessageCommand)
                {
                    var multipleMessages = multipleMessageCommand.InternalMessages.ToArray();

                    if (multipleMessageCommand.RunningMode == RunningMode.Parallel)
                    {
                        try
                        {
                            var tasks = multipleMessages.Select(async internalMessage => await sendWithMonitoring(connector, command, internalMessage.Clone(), internalMessage, destination, true));
                            var results = await Task.WhenAll(tasks);

                            sent = results.All(r => r) && sent;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "{unique} | An error occured while sending queued message. | {additionalMessage}", message.Unique, $"MessageContent : {message.InnerMessage}, ErrorMessage:{ex.Message}");
                        }
                    }
                    else if (multipleMessageCommand.RunningMode == RunningMode.Sync)
                    {
                        foreach (var queued in multipleMessages)
                        {
                            try
                            {
                                sent = await sendWithMonitoring(connector, command, queued.Clone(), queued, destination, true) && sent;
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "{unique} | An error occured while sending queued message. | {additionalMessage}", queued.Unique, $"MessageContent : {queued.InnerMessage}, ErrorMessage:{ex.Message}");
                            }

                        }
                    }
                    else if (multipleMessageCommand.RunningMode == RunningMode.SyncNoWait)
                    {
                        int messageSequence = 1;
                        foreach (var queued in multipleMessages)
                        {
                            try
                            {
                                sendWithMonitoring(connector, command, queued.Clone(), queued, destination, true);

                                if (messageSequence == multipleMessageCommand.MaxMessagesCountBeforeWait)
                                {
                                    if (multipleMessageCommand.WaitDuration > 0)
                                    {
                                        await Task.Delay(multipleMessageCommand.WaitDuration);
                                        messageSequence = 0;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "{unique} | An error occured while sending queued message. | {additionalMessage}", queued.Unique, $"MessageContent : {queued.InnerMessage}, ErrorMessage:{ex.Message}");
                            }
                            messageSequence++;
                        }

                    }
                    message.State = sent ? MessageState.Sent : MessageState.Failed;

                    multipleMessageCommand.MultipleTasksExecuted(message);

                    multipleTaskEventFired = true;
                }

                command?.AfterMessageSent(message);

                if (!message.StopSending)
                {
                    sent = await sendWithMonitoring(connector, command, cloneMessage, message, destination);
                }
            }

            catch (TaskCanceledException tex)
            {
                sent = false;
                sendingException = tex;
                _logger.LogError(tex, "{unique} | An error occured while sending message. | {additionalMessage}", originalMessageUnique, $"ErrorMessage:{tex.Message}");
            }

            catch (HttpRequestException hex)
            {
                sent = false;
                sendingException = hex;
                _logger.LogError(hex, "{unique} | An error occured while sending message over HTTP. | {additionalMessage}", originalMessageUnique, $"ErrorMessage:{hex.Message}");
            }

            catch (Exception ex)
            {
                sent = false;
                sendingException = ex;
                _logger.LogError(ex, "{unique} | A general error occured while sending message. | {additionalMessage}", originalMessageUnique, $"ErrorMessage:{ex.Message}");

            }
            finally
            {
                connector.RemoveMessage();

                if (command != null && command is MultipleMessageCommand multipleMessageCommand)
                {
                    if (!multipleTaskEventFired)
                    {
                        multipleMessageCommand.MultipleTasksExecuted(message);
                    }
                    multipleMessageCommand.InternalMessages.Clear();
                }

                if (!sent)
                {
                    var monitoringCommand = connector.GetCommand<IMonitoringCommand>(connector.MonitoringCommandAssembly);
                    if (monitoringCommand != null)
                    {
                        monitoringCommand.MessageSendFailed(cloneMessage, message, sendingException);
                    }
                }
                var journey = message.AdditionalInfo.ModuleJourney.FirstOrDefault(j => j.ModuleName == this.Name);

                if (journey != null)
                {
                    journey.ExitDate = DateTime.Now;
                }
            }
        }

        private async Task<bool> sendWithMonitoring(IConnector connector, IBusinessCommand command, InternalMessage cloneMessage, InternalMessage originalMessage, string destination, bool createScope = false)
        {
            bool sent = false;
            try
            {
                if (createScope)
                {
                    _requestScopeManager.Add(cloneMessage, connector.ServiceProvider.CreateScope().ServiceProvider);
                }

                sent = await SendAsync(originalMessage, destination);

                if (sent)
                {
                    var monitoringCommand = connector.GetCommand<IMonitoringCommand>(connector.MonitoringCommandAssembly);
                    if (monitoringCommand != null)
                    {
                        monitoringCommand.MessageSent(cloneMessage, originalMessage);
                    }
                }
                else
                {
                    _logger.LogWarning("{unique} | Message could not sent to anywhere. | {additionalMessage}", originalMessage.Unique, $"ConnectorName:{connector.Name}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error while sending message to destination.  | {additionalMessage}", originalMessage.Unique, $"Ex message:{ ex.Message}");
            }

            originalMessage.State = sent ? MessageState.Sent : MessageState.Failed;

            command?.SingleMessageSent(originalMessage);

            return sent;
        }

        public async Task<bool> StopAsync()
        {
            _logger.LogInformation("{unique} | Transport connectors are stopping. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            foreach (ITransportConnector connector in TransportConnectors)
            {
                connector.MessageSent -= Connector_MessageSent;
                await connector.DisconnectAsync();
            }

            _logger.LogInformation("{unique} | Transport connectors are stopped. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            foreach (ITransportConnector connector in Signatories)
            {
                connector.MessageSent -= Connector_MessageSent;
                await connector.DisconnectAsync();
            }

            _logger.LogInformation("{unique} | Signatory connectors are stopped. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            foreach (ITransportConnector connector in FailoverDestinations)
            {
               connector.MessageSent -= Connector_MessageSent;
               await connector.DisconnectAsync();
            }

            _logger.LogInformation("{unique} | Failover connectors are stopped. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            foreach (IReceiveConnector connector in ReceiveConnectors)
            {
                //connector.MessageReceived -= Connector_MessageReceived;
                await connector.DisconnectAsync();
            }
            _logger.LogInformation("{unique} | Receive connectors are stopped. | {additionalMessage}", LoggerUnique.CorfCore, $"RouteName:[{Name}]");

            return true;
        }

        private void Connector_MessageSent(object sender, MessageSentEventArgs e)
        {
        }

        public IReceiveConnector[] ReceiveConnectors { get; internal set; }
        public IScheduledConnector[] ScheduledConnectors { get; internal set; }

        public TransportConnectorGroup TransportConnectors { get; internal set; }
        
        //Signatories : İşlem akışını kesmeden, akış bittikten sonra mesajın harici kanallara gönderilmesi gerekiyor ise 
        //              bu kanallar signatory olarak tanımlanır.
        public TransportConnectorGroup Signatories { get; internal set; }
        public TransportConnectorGroup FailoverDestinations { get; internal set; }

        public bool Balanced { get; internal set; }
        public string Name { get; set; }
        private async Task<bool> SendAsync(InternalMessage message, string destination)
        {
            //TODO: _messageDiscovery üzerinden gelen mesajların birden fazla kanala dönme durumları araştırılacak
            //_messageDiscovery.TryAdd(message.Unique, message);

            bool sent = false;
            InternalMessage clone = message.Clone();

            if (this.Balanced)
            {
                if (message.State != MessageState.ExecutionFailed)
                {
                    var destinationConnector = TransportConnectors.GetSuitableConnector(message, destination);

                    sent = await Send2UniqueDestionationAsync(destinationConnector, message, destination);

                    if (sent)
                    {
                        if (Signatories != null && Signatories.Count > 0)
                        {

                            foreach (var signatory in Signatories)
                            {
                                try
                                {
                                    InternalMessage internalClone = clone.Clone();

                                    internalClone.ReturnToReceiverChannel = false;
                                    internalClone.ReceiverChannelId = String.Empty;

                                    await Send2UniqueDestionationAsync(signatory, internalClone, "", RoutingType.Signatory);
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, "{unique} | Message could not sent to signatories. | {additionalMessage}", message.Unique, $"GroupName:{signatory.Group},ErrorMessage:{ex.Message}");
                                }
                            }

                        }
                    }
                }

                if (!sent)
                {
                    if (FailoverDestinations != null && FailoverDestinations.Count > 0)
                    {
                        _logger.LogInformation("{unique} | Sending to failover destinations..", message.Unique);

                        foreach (var failoverConnector in FailoverDestinations)
                        {
                            try
                            {
                                InternalMessage internalClone = clone.Clone();

                                internalClone.ReturnToReceiverChannel = false;
                                internalClone.ReceiverChannelId = String.Empty;

                                await Send2UniqueDestionationAsync(failoverConnector, internalClone, "", RoutingType.Failover);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "{unique} | Message could not sent to failover destionations. | {additionalMessage}", message.Unique, $"GroupName:{failoverConnector.Group},ErrorMessage:{ex.Message}");
                            }
                        }

                    }
                }

            }
            else
            {
                if (TransportConnectors.Count > 0)
                {
                    var tasks = TransportConnectors.Select(tCon => Send2UniqueDestionationAsync(tCon, message.Clone(), destination));

                    var results = await Task.WhenAll(tasks);

                    sent = results.All(r => r);
                }
                try
                {
                    if (Signatories.Count > 0)
                    {
                        var sinatoryTasks = Signatories.Select(tCon => Send2UniqueDestionationAsync(tCon, message.Clone(), "", RoutingType.Signatory));

                        await Task.WhenAll(sinatoryTasks);
                    }
                }

                catch (Exception ex)
                {
                    _logger.LogError(ex, "{unique} | Message could not sent to signatories. | {additionalMessage}", message.Unique, $"ErrorMessage:{ex.Message}");

                }
            }

            return sent;
        }

        private async Task<bool> Send2UniqueDestionationAsync(ITransportConnector connector, InternalMessage message, string destination, RoutingType routingType = RoutingType.Normal)
        {

            if (connector != null)
            {
                connector.LastSent = DateTime.Now;

                message.Connector = connector;

                if (!string.IsNullOrEmpty(connector.ReceiverChannelId))
                    message.ReceiverChannelId = connector.ReceiverChannelId;

                message.ReturnToReceiverChannel = connector.ReturnToReceiverChannel;

                _logger.LogInformation("{unique} | Sending to destination. | {additionalMessage}", message.Unique, $"destination : {destination} - {connector.Name}");

                IBusinessCommand postCommand = connector.GetCommand<IBusinessCommand>(connector.PostCommandAssembly, message.Unique);

                if (postCommand != null)
                {
                    _logger.LogTrace("{unique} | PostCommand execution. | {additionalMessage}", message.Unique, postCommand);

                    string messageUnique = message.Unique;

                    message.InnerMessageFormat = postCommand.InputMessageFormat;

                    message.RoutingType = routingType;

                    message = await postCommand.ExecuteInternal(message);

                    if (message.State == MessageState.Terminate)
                    {
                        _logger.LogInformation("{unique} | Message terminated. | {additionalMessage}", message.Unique, $"RouteName:{Name}");
                        return false;
                    }

                    if (message != null)
                    {
                        message.Unique = messageUnique;
                        message.InnerMessageFormat = postCommand.OutputMessageFormat;
                    }

                }

                if (message == null)
                {
                    _logger.LogWarning("{unique} | Message format is not valid. Message content is null.", message.Unique);
                    return false;
                }


                var journey = message.AdditionalInfo?.ModuleJourney.FirstOrDefault(j => j.ModuleName == _moduleName);

                if (journey != null && this.ReceiveConnectors.Length > 0 && this.ReceiveConnectors.FirstOrDefault().Group == connector.Group)
                {
                    journey.ExitDate = DateTime.Now;
                }

                


                message.IncomingMessageType = connector.InnerMessageType;

                bool sent = await connector.SendAsync(message);

                if (!sent && routingType == RoutingType.Normal)
                {
                    _logger.LogWarning("{unique} | Message could not sent. Trying other channel. | {additionalMessage}", message.Unique, $"GroupName:{connector.Group}");

                    var suitableChannel = TransportConnectors.GetSuitableConnector(message,destination, connector.Name);

                    if (suitableChannel != null)
                    {
                        _logger.LogWarning("{unique} | Now trying over different connector. | {additionalMessage}", message.Unique, $"GroupName:{suitableChannel.Name}");

                        if (await ((IMessageSender)suitableChannel.Communicator).SendAsync(message))
                        {
                            _logger.LogWarning("{unique} | Succeeded. | {additionalMessage}", message.Unique, $"GroupName:{connector.Group}");
                            return true;
                        }
                        else
                        {
                            _logger.LogWarning("{unique} | No alternative channel found and process stopped! | {additionalMessage}", message.Unique, $"GroupName:{connector.Group}");
                        }
                    }
                }
                else
                {
                    return sent;
                }

            }
            return false;
        }
    }
}
