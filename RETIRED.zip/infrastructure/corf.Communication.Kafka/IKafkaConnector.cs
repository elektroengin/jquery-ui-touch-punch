﻿using corf.Configuration;

namespace corf.Communication.Kafka
{
    public interface IKafkaConnector
    {
        string Topic { get; set; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        string KafkaProperties { get; set; }
        int CheckInterval { get; set; }
        int TimeOut { get; set; }
        Dictionary<string,string> ClientConfig { get; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        string EncodedKeytabConfiguration { get; set; }
    }
}