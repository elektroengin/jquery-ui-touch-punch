﻿namespace corf.Communication.Kafka
{
    public class EncodedKeytabConfiguration
    {
        public string EncodedKeytabPath { get; set; }
        public string DecodedKeytabPath { get; set; }
    }
}
