﻿using Confluent.Kafka;
using corf.Configuration;
using corf.Core;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using System.Text;

namespace corf.Communication.Kafka.Producing
{
    public class KafkaProducerCommunicator : IKafkaProducerCommunicator
    {
        ILogger<KafkaProducerCommunicator> _logger;

        private IProducer<Null, string> _producer;

        private static ManualResetEvent allDone = new ManualResetEvent(false);

        public KafkaProducerCommunicator(ILogger<KafkaProducerCommunicator> logger)
        {
            _logger = logger;
        }

        public bool IsConnected
        {
            get { return true; }
        }

        public bool ReadyForRead
        {
            get
            {
                return true;
            }
        }

        public IConnector Connector { get; private set; }
        public bool Initialized { get; private set; }

        public async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {
                     _logger.LogInformation("{unique} | /app/librdkafka.so is exists | {additionalMessage}", LoggerUnique.CorfCore, $"{File.Exists("/app/librdkafka.so")}");
                    Library.Load("/app/librdkafka.so");
                }

                 _logger.LogInformation("{unique} | Confluent.Kafka.Library.IsLoaded | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.IsLoaded}");
                 _logger.LogInformation("{unique} | Confluent.Kafka.Library.Version | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.Version}");
                 _logger.LogInformation("{unique} | Confluent.Kafka.Library.VersionString | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.VersionString}");
                 _logger.LogInformation("{unique} | Confluent.Kafka.Library.DebugContexts | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.DebugContexts}");

                ProducerConfig config = new ProducerConfig(((KafkaProducerConnector)Connector).ClientConfig);
                 _logger.LogInformation("{unique} | Config Key Count | {additionalMessage}", LoggerUnique.CorfCore, $"{((KafkaProducerConnector)Connector).ClientConfig.Count}");
                 _logger.LogInformation("{unique} | EncodedKeytabConfiguration | {additionalMessage}", LoggerUnique.CorfCore, $"{((KafkaProducerConnector)Connector).EncodedKeytabConfiguration}");

                if (!string.IsNullOrWhiteSpace(((KafkaProducerConnector)Connector).EncodedKeytabConfiguration))
                {
                    EncodedKeytabConfiguration encodedKeytabConfiguration = Newtonsoft.Json.JsonConvert.DeserializeObject<EncodedKeytabConfiguration>(((KafkaProducerConnector)Connector).EncodedKeytabConfiguration);
                    
                    StreamReader sr = new StreamReader(File.OpenRead(encodedKeytabConfiguration.EncodedKeytabPath));
                    string keyTab = sr.ReadToEnd();
                    byte[] data = Convert.FromBase64String(keyTab);
                    string decodedString = Encoding.GetEncoding("iso-8859-1").GetString(data);
                    File.WriteAllText(encodedKeytabConfiguration.DecodedKeytabPath, decodedString, Encoding.GetEncoding("iso-8859-1"));
                    config.SaslKerberosKeytab = encodedKeytabConfiguration.DecodedKeytabPath;
                    sr.Close();
                    
                    config.SaslKerberosKinitCmd = $"kinit -k -t {config.SaslKerberosKeytab} {config.SaslKerberosPrincipal}";

                     _logger.LogInformation("{unique} | Kerberos configuration - produce :  | {additionalMessage}", LoggerUnique.CorfCore);
                     _logger.LogInformation("{unique} | SaslKerberosPrincipal | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosPrincipal}");
                     _logger.LogInformation("{unique} | SaslKerberosServiceName | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosServiceName}");
                     _logger.LogInformation("{unique} | SaslUsername | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslUsername}");
                     _logger.LogInformation("{unique} | SaslKerberosKinitCmd | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosKinitCmd}");
                     _logger.LogInformation("{unique} | SaslKerberosKeytab | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosKeytab}");
                     _logger.LogInformation("{unique} | SaslKerberosKeytab content | {additionalMessage}", LoggerUnique.CorfCore, $"{decodedString}");
                }
                
                
                foreach(var keyValue in ((KafkaProducerConnector)Connector).ClientConfig)
                {
                    _logger.LogInformation("{unique} | Client configuration | {additionalMessage}", LoggerUnique.CorfCore, $"{keyValue.Key} = {keyValue.Value}");
                }
                _producer = (new ProducerBuilder<Null, string>(config)).Build();
                return await Task.FromResult(true);
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");

                 return false;
            }

            finally
            {
                Initialized = true;
            }
        }

        public void GetReady()
        {
        }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
        }

        public bool Send(InternalMessage message)
        {
            Task<bool> asyncTask = SendAsync(message);
            asyncTask.Wait();
            return asyncTask.Result;
        }

        public async Task<bool> SendAsync(InternalMessage message)
        {
            if (message.State == MessageState.Failed)
                return false;
            DeliveryResult<Null, string> result = new DeliveryResult<Null, string>();

            try
            {
                string produceMesage;
                if (((KafkaProducerConnector)Connector).InternalPayload)
                    produceMesage = Newtonsoft.Json.JsonConvert.SerializeObject(message);
                else
                    produceMesage = message.InnerMessage;

                if (string.IsNullOrEmpty(produceMesage))
                    return true;

                Headers headers = new Headers();
                foreach (var header in message.Headers)
                {
                    headers.Add(header.Key, Encoding.UTF8.GetBytes(header.Value.ToString()));
                }

                result = await _producer.ProduceAsync(((KafkaProducerConnector)Connector).Topic, new Message<Null, string> { Value = produceMesage, Headers = headers});
                 _logger.LogInformation("{unique} | Message produced! | {additionalMessage}", message.Unique, $"Delivery Result : {JsonConvert.SerializeObject(result, Formatting.Indented)} Topic Name :{((KafkaProducerConnector)Connector).Topic}");
            }
            catch (Exception ex)
            {
                message.State = MessageState.Failed;
                _logger.LogError(ex, "{unique} | Producing failed! | {additionalMessage}", message.Unique, $"Topic Name :{((KafkaProducerConnector)Connector).Topic}, ErrorMessage :{ex.Message}");
                return false;
            }
            return true;
        }
    }
}
