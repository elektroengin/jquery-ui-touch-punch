﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Kafka.Producing
{
    public class KafkaProducerConnector : TransportConnector, IKafkaConnector
    {
        private readonly IKafkaProducerCommunicator _communicator;
        public KafkaProducerConnector(ILogger<KafkaProducerConnector> logger, IKafkaProducerCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }
        
        public string Topic { get; set; }
        
        public override string ChannelDescription
        {
            get { return string.Format("{0} #{1}", ClientConfig.FirstOrDefault(x => x.Key == "bootstrap.servers").Value, Topic); }
        }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string KafkaProperties { get;  set; } = @"{'bootstrap.servers':'localhost:9092','group.id':'testConsumer','message.timeout.ms': '5000','auto.offset.reset': 'earliest', 'socket.timeout.ms': '5000',  'security.protocol':'PLAINTEXT', 'enable.auto.commit' : 'true', 'auto.commit.interval.ms' : '600'}";

        public Dictionary<string, string> ClientConfig
        {
            get
            {
                return Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(KafkaProperties);
            }
        }

        public int TimeOut { get; set; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string EncodedKeytabConfiguration { get; set; }
    }
}
