﻿using corf.Core.Infrastructure;

namespace corf.Communication.Kafka.Producing
{
    public interface IKafkaProducerCommunicator : IMessageSender
    {
    }
}
