﻿using corf.Core.Infrastructure;

namespace corf.Communication.Kafka.Consuming
{
    public interface IKafkaConsumerCommunicator : ICommunicator
    {
    }
}
