﻿namespace corf.Communication.Kafka.Consuming
{
}
