﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;

namespace corf.Communication.Kafka.Consuming
{
    public class KafkaConsumerConnector : ReceiveConnector, IKafkaConnector
    {
        private IKafkaConsumerCommunicator _communicator;

        public KafkaConsumerConnector(ILogger<KafkaConsumerConnector> logger, IKafkaConsumerCommunicator communicator,  IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public IRequestScopeManager ScopeManager { get { return this.InternalScopeManager; } }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }
        public override bool EndlessReceive { get { return true; } }

        //****** Kafka Properties *********/
        public string Topic { get; set; }

        public JObject HeaderFilters { get; set; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string KafkaProperties { get; set; } = @"{'bootstrap.servers':'localhost:9092','group.id':'testConsumer','message.timeout.ms': '5000','auto.offset.reset': 'earliest', 'socket.timeout.ms': '5000',  'security.protocol':'PLAINTEXT', 'enable.auto.commit' : 'true', 'auto.commit.interval.ms' : '600'}";

        public bool NotScaledConsumer { get; set; }

        public override string ChannelDescription
        {
            get { return string.Format("{0} #{1}", ClientConfig.FirstOrDefault(x => x.Key == "bootstrap.servers").Value, Topic); }
        }

        public Dictionary<string, string> ClientConfig
        {
            get
            {
                return Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(KafkaProperties);
            }
        }

        public int TimeOut { get; set; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string EncodedKeytabConfiguration { get; set; }
    }
}
