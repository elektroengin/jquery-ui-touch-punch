﻿using Confluent.Kafka;
using corf.Configuration;
using corf.Core;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using System.Text;

namespace corf.Communication.Kafka.Consuming
{
    public class KafkaConsumerCommunicator : IKafkaConsumerCommunicator, IEndlessReceiver
    {
        readonly ILogger<KafkaConsumerCommunicator> _logger;

        IConsumer<string, string> _consumer;


        private bool _pollAllowed = false;

        public KafkaConsumerCommunicator(ILogger<KafkaConsumerCommunicator> logger)
        {
            _logger = logger;
        }

        public bool IsConnected
        {
            get { return _pollAllowed; }
        }

        public bool ReadyForRead
        {
            get
            {
                return _pollAllowed;
            }
        }

        public IConnector Connector { get; private set; }
        public bool Initialized { get; private set; }

        public async Task<bool> CloseAsync()
        {
            _pollAllowed = false;

            try
            {
                _consumer.Unsubscribe();
                _consumer.Close();
                _consumer.Dispose();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Could not stop kafka consumer named  | {additionalMessage}", LoggerUnique.CorfCore, $"Connector:{this.Connector.Name}, ErrorMessage:{ex.Message}");
            }

            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            Initialized = true;


            return await Task.FromResult(true);


        }

        private KafkaConsumerConnector _consumerConnector;
        protected KafkaConsumerConnector ConsumerConnector
        {
            get
            {
                if (_consumerConnector == null)
                {
                    _consumerConnector = (KafkaConsumerConnector)Connector;
                }
                return _consumerConnector;
            }
        }


        public void GetReady()
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {
                    _logger.LogInformation("{unique} | /app/librdkafka.so is exists | {additionalMessage}", LoggerUnique.CorfCore, $"{File.Exists("/app/librdkafka.so")}");
                    Library.Load("/app/librdkafka.so");
                }
                _logger.LogInformation("{unique} | Confluent.Kafka.Library.IsLoaded | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.IsLoaded}");
                _logger.LogInformation("{unique} | Confluent.Kafka.Library.Version | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.Version}");
                _logger.LogInformation("{unique} | Confluent.Kafka.Library.VersionString | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.VersionString}");
                _logger.LogInformation("{unique} | Confluent.Kafka.Library.DebugContexts | {additionalMessage}", LoggerUnique.CorfCore, $"{Library.DebugContexts}");

                ConsumerConfig config = new ConsumerConfig(((KafkaConsumerConnector)Connector).ClientConfig);
                if (((KafkaConsumerConnector)Connector).NotScaledConsumer)
                    config.GroupId += Environment.MachineName;
                _logger.LogInformation("{unique} | Config Key Count | {additionalMessage}", LoggerUnique.CorfCore, $"{((KafkaConsumerConnector)Connector).ClientConfig.Count}");
                _logger.LogInformation("{unique} | EncodedKeytabConfiguration | {additionalMessage}", LoggerUnique.CorfCore, $"{((KafkaConsumerConnector)Connector).EncodedKeytabConfiguration}");

                if (!string.IsNullOrWhiteSpace(((KafkaConsumerConnector)Connector).EncodedKeytabConfiguration))
                {
                    EncodedKeytabConfiguration encodedKeytabConfiguration = Newtonsoft.Json.JsonConvert.DeserializeObject<EncodedKeytabConfiguration>(((KafkaConsumerConnector)Connector).EncodedKeytabConfiguration);

                    StreamReader sr = new StreamReader(File.OpenRead(encodedKeytabConfiguration.EncodedKeytabPath));
                    string keyTab = sr.ReadToEnd();
                    byte[] data = Convert.FromBase64String(keyTab);
                    string decodedString = Encoding.GetEncoding("iso-8859-1").GetString(data);
                    File.WriteAllText(encodedKeytabConfiguration.DecodedKeytabPath, decodedString, Encoding.GetEncoding("iso-8859-1"));
                    config.SaslKerberosKeytab = encodedKeytabConfiguration.DecodedKeytabPath;
                    sr.Close();

                    config.SaslKerberosKinitCmd = $"kinit -k -t {config.SaslKerberosKeytab} {config.SaslKerberosPrincipal}";

                    _logger.LogInformation("{unique} | Kerberos configuration - consumer: | {additionalMessage}", LoggerUnique.CorfCore);
                    _logger.LogInformation("{unique} | SaslKerberosPrincipal | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosPrincipal}");
                    _logger.LogInformation("{unique} | SaslKerberosServiceName | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosServiceName}");
                    _logger.LogInformation("{unique} | SaslUsername | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslUsername}");
                    _logger.LogInformation("{unique} | SaslKerberosKinitCmd | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosKinitCmd}");
                    _logger.LogInformation("{unique} | SaslKerberosKeytab | {additionalMessage}", LoggerUnique.CorfCore, $"{config.SaslKerberosKeytab}");
                    _logger.LogInformation("{unique} | SaslKerberosKeytab content | {additionalMessage}", LoggerUnique.CorfCore, $"{decodedString}");
                }

                foreach (var keyValue in ((KafkaConsumerConnector)Connector).ClientConfig)
                {
                    _logger.LogInformation("{unique} | Client Config: | {additionalMessage}", LoggerUnique.CorfCore, $"{keyValue.Key} = {keyValue.Value}");
                }


                _consumer = (new ConsumerBuilder<string, string>(config)).Build();
                _consumer.Subscribe(((IKafkaConnector)Connector).Topic);
                _logger.LogInformation("{unique} | Subscribing succeeded... | {additionalMessage}", LoggerUnique.CorfCore, $"Topic Name: {((IKafkaConnector)Connector).Topic}");

                _pollAllowed = true;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Subscribing failed! | {additionalMessage}", LoggerUnique.CorfCore, $"Topic Name: {((IKafkaConnector)Connector).Topic}, ErrorMessage :{ex.Message}");
                _pollAllowed = false;
            }
        }

        public async Task<InternalMessage> ReceiveMessage()
        {
            try
            {
                _logger.LogTrace("{unique} | PollInfinity... | {additionalMessage}", LoggerUnique.CorfCore, $"ConnectorState {Thread.CurrentThread.ManagedThreadId}: {ConsumerConnector.ConnectorState}, PollControlCommand : {ConsumerConnector.PollControlCommand}, PollControlCommand.CheckAvailability().IsAvailable : {(ConsumerConnector.PollControlCommand != null ? ConsumerConnector.PollControlCommand.CheckAvailability().IsAvailable : "")}, BackPressureSize : {ConsumerConnector.BackPressureSize}, ExecutingMessagesCount : {ConsumerConnector.ExecutingMessagesCount}");

                var message = _consumer.Consume();

                if (message != null)
                {
                    InternalMessage incomingMessage;
                    if (ConsumerConnector.InternalPayload)
                        incomingMessage = JsonConvert.DeserializeObject<InternalMessage>(message.Message.Value);
                    else
                        incomingMessage = new InternalMessage() { InnerMessage = message.Message.Value };

                    if (string.IsNullOrWhiteSpace(incomingMessage.Unique))
                    {
                        incomingMessage.Unique = Guid.NewGuid().ToString().Replace("-", "");
                    }

                    foreach (var header in message.Message.Headers)
                    {
                        incomingMessage.Headers.Add(header.Key, header.GetValueBytes());
                    }

                    if (ConsumerConnector.HeaderFilters != null && ConsumerConnector.HeaderFilters.Count > 0)
                    {
                        foreach (var header in ConsumerConnector.HeaderFilters)
                        {
                            var messageHeaderValue = message.Message.Headers.FirstOrDefault(x => x.Key == header.Key);

                            if (messageHeaderValue == null || header.Value.ToString() != Encoding.ASCII.GetString(messageHeaderValue.GetValueBytes()))
                            {
                                return null;
                            }
                        }
                    }

                    _logger.LogTrace("{unique} | Message consumed! | {additionalMessage}", incomingMessage.Unique, $"Message : {JsonConvert.SerializeObject(message, Formatting.Indented)}");

                    return incomingMessage;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Consuming failed! | {additionalMessage}", LoggerUnique.CorfCore, $"Topic Name :{((IKafkaConnector)Connector).Topic}, ErrorMessage :{ex.Message}");
            }
            return null;
        }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
        }
    }
}
