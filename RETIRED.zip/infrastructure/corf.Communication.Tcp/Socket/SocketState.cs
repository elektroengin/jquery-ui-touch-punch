﻿using System.Net.Sockets;

namespace corf.Communication.Tcp.SocketManagement
{
    internal class SocketState
    {
        private static readonly object SyncObject = new object();

        #region Variables

        bool _aborted;

        #endregion

        #region Properties

        readonly ConnectionInformation _clientInformation;

        public int ReceiveCount { get; set; }

        public int SendCount { get; set; }

        public SocketAwaitable Awaitable { get; private set; }
        public ConnectionInformation ClientInformation
        {
            get
            {
                _clientInformation.SendCount = SendCount;
                _clientInformation.ReceiveCount = ReceiveCount;
                return _clientInformation;
            }
        }

        public Socket Socket { get; private set; }

        public Thread ThreadId { get; private set; }

        public bool Aborted
        {
            get
            {
                bool bRet;
                lock (SyncObject)
                {
                    bRet = _aborted;
                }
                return bRet;
            }
            set
            {
                lock (SyncObject)
                {
                    _aborted = value;
                }
            }
        }
        #endregion
        public SocketState(Socket socket, Thread thread, SocketAwaitable awaitable)
        {
            SendCount = 0;
            ReceiveCount = 0;
            Socket = socket;
            ThreadId = thread;
            _aborted = false;
            _clientInformation = new ConnectionInformation(
                socket.Handle.ToInt64(),
                socket.GetAddress(),
                socket.GetPort(), String.Empty, ThreadId.ManagedThreadId, 0, 0);

            Awaitable = awaitable;
        }
    }
}
