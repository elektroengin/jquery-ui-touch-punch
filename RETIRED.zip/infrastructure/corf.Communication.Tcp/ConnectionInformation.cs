﻿using System.Net;

namespace corf.Communication.Tcp
{
    public class ConnectionInformation
    {
        /// <summary>
        /// Gets or sets the receive count.
        /// </summary>
        /// <value>The receive count.</value>
        public int ReceiveCount
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the send count.
        /// </summary>
        /// <value>The send count.</value>
        public int SendCount
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the socket id.
        /// </summary>
        /// <value>The id.</value>
        public long Id
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets or sets the extended information.
        /// </summary>
        /// <value>The extended information.</value>
        public string ExtendedInformation { get; set; }

        /// <summary>
        /// Gets the duration of the connection.
        /// </summary>
        /// <value>The duration of the connection.</value>
        public TimeSpan ConnectionDuration
        {
            get { return DateTime.Now - ConnectionTime; }
        }
        /// <summary>
        /// Gets or sets the when connection initiated.
        /// </summary>
        /// <value>The connection time.</value>
        public DateTime ConnectionTime
        {
            get;
            private set;
        }

        /// <summary>
        /// Underlying thread ID
        /// </summary>
        public int ThreadId { get; private set; }

        /// <summary>
        /// Connection name
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Gets or sets the ip address
        /// </summary>
        /// <value>The address.</value>
        public IPAddress Address
        {
            get;
            private set;
        }
        /// <summary>
        /// Gets or sets the string ip address
        /// </summary>
        /// <value>The address.</value>
        public string AdressIp
        {
            get;
            private set;
        }
        /// <summary>
        /// Gets or sets the port address.
        /// </summary>
        /// <value>The port.</value>
        public int Port
        {
            get;
            private set;
        }

        /// <summary>
        /// Default ctor
        /// </summary>
        public ConnectionInformation() : this(0, 0, 0) { }

        /// <summary>
        /// Ctor with id parameter
        /// </summary>
        /// <param name="id"></param>
        public ConnectionInformation(long id) : this(id, 0, 0) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectionInformation"/> class.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="sendCount">The send count.</param>
        /// <param name="receiveCount">The receive count.</param>
        public ConnectionInformation(long id, int sendCount, int receiveCount)
        {

            Id = id;
            ConnectionTime = DateTime.Now;
            SendCount = sendCount;
            ReceiveCount = receiveCount;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectionInformation"/> class.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="extendedInormation">The extended inormation.</param>
        /// <param name="sendCount">The send count.</param>
        /// <param name="receiveCount">The receive count.</param>
        public ConnectionInformation(long id, string extendedInormation, int sendCount, int receiveCount)
        {
            Id = id;
            ExtendedInformation = extendedInormation;
            ConnectionTime = DateTime.Now;
            SendCount = sendCount;
            ReceiveCount = receiveCount;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectionInformation"/> class.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="sendCount"></param>
        /// <param name="receiveCount"></param>
        /// <param name="name"></param>
        public ConnectionInformation(long id, int sendCount, int receiveCount, string name)
        {
            Id = id;
            ConnectionTime = DateTime.Now;
            SendCount = sendCount;
            ReceiveCount = receiveCount;
            Name = name;
        }

        /// Initializes a new instance of the <see cref="ConnectionInformation"/> class.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="address">The address.</param>
        /// <param name="port">The port.</param>
        /// <param name="sendCount">The send count.</param>
        /// <param name="receiveCount">The receive count.</param>
        public ConnectionInformation(long id, IPAddress address, int port, int sendCount, int receiveCount) : this(id, sendCount, receiveCount)
        {
            Address = address;
            Port = port;
        }
        //Sukru
        public ConnectionInformation(long id, IPAddress address, string name, int port, int sendCount, int receiveCount)
            : this(id, sendCount, receiveCount)
        {
            Name = name;
            Address = address;
            Port = port;
        }
        //Sukru
        public ConnectionInformation(long id, string address, int port, int sendCount, int receiveCount)
            : this(id, sendCount, receiveCount)
        {
            AdressIp = address;
            Port = port;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ConnectionInformation"/> class.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <param name="address">The address.</param>
        /// <param name="port">The port.</param>
        /// <param name="extendedInormation">The extended inormation.</param>
        /// <param name="sendCount">The send count.</param>
        /// <param name="receiveCount">The receive count.</param>
        public ConnectionInformation(long id, IPAddress address, int port, string extendedInformation, int sendCount, int receiveCount)
            : this(id, extendedInformation, sendCount, receiveCount)
        {
            Address = address;
            Port = port;
        }

        public ConnectionInformation(long id, IPAddress address, int port, string extendedInormation, int threadId, int sendCount, int receiveCount)
            : this(id, extendedInormation, threadId, sendCount, receiveCount)
        {
            Address = address;
            Port = port;
        }

        public ConnectionInformation(long id, IPAddress address, int port, int sendCount, int receiveCount, string name)
            : this(id, sendCount, receiveCount, name)
        {
            Address = address;
            Port = port;
        }
    }
}
