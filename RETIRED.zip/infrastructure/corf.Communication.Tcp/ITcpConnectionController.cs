﻿namespace corf.Communication.Tcp.Server
{
    public interface ITcpConnectionController
    {
        bool ConnectionEstablished { get; set; }
    }
}