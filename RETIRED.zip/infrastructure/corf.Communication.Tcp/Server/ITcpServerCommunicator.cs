﻿using corf.Core.Infrastructure;

namespace corf.Communication.Tcp.Server
{
    public interface ITcpServerCommunicator : IEndlessReceiver, IMessageSender
    {
        public bool HasClient { get; }
    }
}
