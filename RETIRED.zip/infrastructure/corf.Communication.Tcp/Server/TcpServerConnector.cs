﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Tcp.Server
{
    public class TcpServerConnector : TcpConnectorBase
    {
        private ITcpServerCommunicator _communicator;
        public override bool IsHealthy 
        {
            get
            {
                return _communicator.HasClient;
            }
        }
        public TcpServerConnector(ILogger<TcpServerConnector> logger, ITcpServerCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }

        [FlowDesign(Description = "Limits the number of clients to connect")]
        public int MaximumClientCount { get; set; }

        public byte[] GetSignOnMessage { get; set; }

        [FlowDesign(Description = "Set to true if the number of unanswered messages control is required.")]
        public bool CheckUnrepliedMessages { get; set; }

        [FlowDesign(Description = "If DualMessageUniqueChannel is empty and AllowClientsLoadBalance is true then messages will be distributed over connected clients using round robin")]
        public bool AllowClientsLoadBalance { get; set; }
    }
}
