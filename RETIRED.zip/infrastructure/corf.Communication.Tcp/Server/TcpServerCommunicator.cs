﻿using Confluent.Kafka;
using corf.BinaryConverter;
using corf.Communication.Tcp.SocketManagement;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;

namespace corf.Communication.Tcp.Server
{
    public class TcpServerCommunicator : ITcpServerCommunicator
    {

        private TcpListener _listener = null;
        private IPEndPoint _localEndPoint = null;
        readonly ILogger<TcpServerCommunicator> _logger;
        private bool _listening;

        private ConcurrentDictionary<string, TcpStateObject> _clients = null;


        private ConcurrentQueue<InternalMessage> _incomingQueue = null;
        private bool signonReplied;

        public TcpServerCommunicator(ILogger<TcpServerCommunicator> logger)
        {
            _logger = logger;
        }

        TcpServerConnector TcpConnector
        {
            get
            {
                return (TcpServerConnector)Connector;
            }
        }

        public void GetReady()
        {
            _clients = new ConcurrentDictionary<string, TcpStateObject>();

            _incomingQueue = new ConcurrentQueue<InternalMessage>();

            _logger.LogInformation("{unique} | Connection Properties | {additionalMessage}", LoggerUnique.CorfCore, $"Connection Addr : {TcpConnector.Address}, Connection UEP : {TcpConnector.Port}");

            SetLocalEndPoint();
        }

        private void SetLocalEndPoint()
        {
            var currentIp = IPAddress.Any;

            _logger.LogInformation("{unique} | Tcp server initializing... | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{TcpConnector.Address}");

            if (!string.Equals("0.0.0.0", TcpConnector.Address))
            {
                IPAddress[] addresses = Dns.GetHostAddresses(TcpConnector.Address);
                currentIp = addresses[0];
            }

            _listener = new TcpListener(currentIp, Convert.ToInt32(TcpConnector.Port));

            if (TcpConnector.KeepAlive)
            {
                _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
            }

            _logger.LogInformation("{unique} | Tcp server initialized. | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{currentIp}, Port :{TcpConnector.Port}");
            _logger.LogInformation("{unique} | Configuration | {additionalMessage}", LoggerUnique.CorfCore, $"MaximumClientCount : {TcpConnector.MaximumClientCount}");
        }

        private async Task waitForClientsAsync()
        {
            while (_listening)
            {
                try
                {
                    if (_listener.Pending())
                    {
                        if (TcpConnector.MaximumClientCount <= 0 || (_clients.Count <= TcpConnector.MaximumClientCount))
                        {
                            await AcceptCallbackAsync(await _listener.AcceptTcpClientAsync());
                        }
                    }
                }
                catch(Exception ex)
                {
                    _logger.LogError(ex, $"Error on accepting new connections");
                    return;
                }
                await Task.Delay(40);
            }
        }
        public async Task<bool> ConnectAsync()
        {
            try
            {
                if (!_listening)
                {
                    if (TcpConnector.DependentTo == null || !CheckDependentConnector || (TcpConnector.DependentTo != null && TcpConnector.DependentTo.Any(c =>  c.IsConnected)))
                    {
                        _listener.Start();

                        _logger.LogInformation("{unique} | Binding to node... | {additionalMessage}", LoggerUnique.CorfCore, $"Endpoint :{_listener.LocalEndpoint}");

                        _listening = true;

                        _logger.LogInformation("{unique} | Binding to node succeed. | {additionalMessage}", LoggerUnique.CorfCore, $"Endpoint :{_listener.LocalEndpoint}");

                        await Task.Factory.StartNew(async () => await waitForClientsAsync(), TaskCreationOptions.LongRunning);
                    }
                }

                return await Task.FromResult(true);
            }

            catch (SocketException exc)
            {
                _logger.LogError("{unique} | Start failed with Socket Exception. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:[{exc.Message}], Socket Error Code:[{exc.SocketErrorCode}]");
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:[{ex.Message}]");
                return false;
            }

            finally
            {
                Initialized = true;
            }
        }

        private async Task AcceptCallbackAsync(TcpClient ar)
        {
            TcpClient handler = (TcpClient)ar;

            try
            {
                _logger.LogInformation("{unique} | Connnection accepted. | {additionalMessage}", LoggerUnique.CorfCore, $"{SocketExtensions.GetAddress(handler.Client)}:{SocketExtensions.GetPort(handler.Client)}. Handle is {handler.Client.Handle.ToInt64().ToString()}");
                // Create the state object.  
                TcpStateObject state = new TcpStateObject
                {
                    TcpClient = handler,
                    ThreadId = Thread.CurrentThread.ManagedThreadId,
                    HandleId = handler.Client.Handle.ToInt64().ToString(),
                    DeadMessagesCount = 0
                };


                bool added = _clients.TryAdd(handler.Client.Handle.ToInt64().ToString(), state);

                if (added)
                {
                    _logger.LogInformation("{unique} | Connection Info | {additionalMessage}", LoggerUnique.CorfCore, $"Connected clients count:{_clients.Count}");

                    var ns = handler.GetStream();
                    state.Stream = ns;


                    if (TcpConnector.MaximumClientCount > 0 && (_clients.Count > TcpConnector.MaximumClientCount))
                    {
                        closeHandler(ns, state);
                        return;
                    }

                    state.Header = new byte[TcpConnector.HeaderLength];

                    if (TcpConnector.RequireClientSignOn)
                    {
                        var preCommand = TcpConnector.GetCommand<IBusinessCommand>(TcpConnector.OnReceiveCommandAssembly);
                        if (preCommand != null)
                        {
                            var signOnMessage = await preCommand.GetSignOnMessage();
                            
                            if (signOnMessage != null)
                            {
                                var tryCount = 0;

                                bool replied = false;
                                
                                var signonResult = new byte[512];

                                while (tryCount < 3)
                                {
                                    tryCount++;
                                    try
                                    {
                                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(2000);
                                        
                                        ns.Write(DataConvert.HexStringToBinary(signOnMessage.InnerMessage));
                                        
                                        await ns.ReadAsync(signonResult, 0, 512, cancellationTokenSource.Token);
                                        
                                        replied = true;

                                        break;
                                    }
                                    catch(Exception ex)
                                    {
                                        _logger.LogError(ex, $"try count : {tryCount} | message :{ex.Message}");
                                    }
                                    
                                    signonResult = new byte[512];
                                }

                                signonReplied = replied;

                                if (!replied || !(await preCommand.CheckSignOnResult(new InternalMessage { InnerMessage = DataConvert.BinaryToHexString(signonResult) })))
                                {
                                    closeHandler(ns, state);
                                }
                            }
                        }
                    }

                    ns.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
                }
                else
                {
                    _logger.LogWarning("{unique} | Socket could not add into client socket list. | {additionalMessage}", LoggerUnique.CorfCore, $"ThreadId :{state.ThreadId}, Address :{SocketExtensions.GetAddress(handler.Client)}, Port :{SocketExtensions.GetPort(handler.Client)}");
                }

            }
            catch (SocketException exc)
            {
                TcpStateObject? stateObject;
                if (handler != null && handler.Client != null)
                {
                    _clients.TryRemove(handler.Client.Handle.ToInt64().ToString(), out stateObject);
                }
                _logger.LogError(exc, "{unique} | Start failed with Socket Exception. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :[{exc.Message}], Socket Error Code :[{exc.SocketErrorCode}]");
            }
            catch (Exception ex)
            {
                TcpStateObject? stateObject;
                if (handler != null && handler.Client != null)
                {
                    _clients.TryRemove(handler.Client.Handle.ToInt64().ToString(), out stateObject);
                }
                _logger.LogError(ex, "{unique} | Start failed with GeneralException | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :[{ex.Message}]");
            }

            await Task.Delay(1);
        }

        private void ReadCallback(IAsyncResult ar)
        {
            TcpStateObject state = (TcpStateObject)ar.AsyncState;

            var ns = state.Stream;

            bool disposed = false;


            try
            {
                _logger.LogInformation("{unique} | Tcp Server - readcallback started ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");

                int streamBytes = ns.EndRead(ar);

                if (state.TcpClient.Available == 0)
                {
                    if (streamBytes == 0)
                    {
                        disposed = true;
                        closeHandler(ns, state);
                        return;
                    }
                }

                if (TcpConnector.HeaderLength > 0)
                {
                    int lenght = DataConvert.HexStringToInt32(DataConvert.BinaryToHexString(state.Header));

                    int paddingLength = TcpConnector.CheckPadding && TcpConnector.PaddingLength > 0 ? TcpConnector.PaddingLength : 0;

                    lenght += paddingLength;

                    var tryCount = 0;

                    var receivedBytes = new byte[lenght + TcpConnector.HeaderLength];

                    Array.Copy(state.Header, 0, receivedBytes, 0, TcpConnector.HeaderLength);

                    var currentReceiveLength = lenght;

                    _logger.LogInformation($"[{TcpConnector.Name}-{TcpConnector.Address}-{TcpConnector.Port}]#handle:{state.HandleId}# Incoming stream length : {currentReceiveLength}");

                    if (currentReceiveLength > 0)
                    {
                        int copiedLength = state.Header.Length;

                        while (true)
                        {
                            tryCount++;

                            byte[] currentReceivedBytes = new byte[currentReceiveLength];

                            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(1500);

                            int receivedLength = ns.ReadAsync(currentReceivedBytes, 0, currentReceiveLength, cancellationTokenSource.Token).Result;

                            currentReceiveLength -= receivedLength;

                            if (receivedLength > 0)
                            {
                                Array.Copy(currentReceivedBytes, 0, receivedBytes, copiedLength, receivedLength);

                                _logger.LogInformation($"[{TcpConnector.Name}-{TcpConnector.Address}-{TcpConnector.Port}]#handle:{state.HandleId}# Incoming stream bytes : {DataConvert.BinaryToHexString(currentReceivedBytes)}");

                                copiedLength += receivedLength;

                                if (copiedLength == lenght + state.Header.Length)
                                {
                                    state.DeadMessagesCount++;
                                    Add2Queue(receivedBytes, state.TcpClient.Client);
                                    break;
                                }
                            }

                            if (tryCount > 3 || (TcpConnector.CheckUnrepliedMessages == true && state.DeadMessagesCount > 3))
                            {
                                disposed = true;
                                closeHandler(ns, state);
                                throw new TimeoutException($"Received message could not be processed, tryCount {tryCount}, UnRepliedMessagesCount {state.DeadMessagesCount}");
                            }
                        }
                    }
                }
                else
                {
                     byte[] receiveBuffer = new byte[streamBytes];

                    Array.Copy(state.Buffer, receiveBuffer, streamBytes);

                    Add2Queue(receiveBuffer, state.TcpClient.Client);
                }
            }
            catch (SocketException sex)
            {
                disposed = true;
                _logger.LogError(sex, "{unique} | Received socket exception | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], code : {sex.SocketErrorCode}-{sex.NativeErrorCode}, ErrorMessage : [{sex.Message}].");
                closeHandler(ns, state);
            }
            catch (OperationCanceledException ocex)
            {
                disposed = true;
                _logger.LogError(ocex, "{unique} | Received function time out exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], Message : [{ocex.Message}].");
                closeHandler(ns, state);

            }
            catch (Exception ex)
            {
                disposed = true;
                _logger.LogError(ex, "{unique} | Received function exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], ErrorMessage : [{ex.Message}].");
                closeHandler(ns, state);
            }

            finally
            {
                if (!disposed && _clients.ContainsKey(state.HandleId))
                {
                    if (TcpConnector.CheckHeader && state.TcpClient.Available < TcpConnector.HeaderLength)
                    {
                        state.Header = new byte[TcpConnector.HeaderLength];
                    }

                    ns.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
                }
            }
        }
        private void closeHandler(NetworkStream ns, TcpStateObject tcpServerStateObject)
        {
            _clients.TryRemove(tcpServerStateObject.HandleId, out TcpStateObject removed);
            _logger.LogInformation("{unique} | Tcp Client shutdown ... | {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {tcpServerStateObject.HandleId}");
            _logger.LogInformation("{unique} | Connection info  | {additionalMessage}", LoggerUnique.CorfCore, $"Connected clients count:{_clients.Count}");
            ns.Close();
            ns.Dispose();
            tcpServerStateObject.TcpClient.Close();
            tcpServerStateObject.TcpClient.Dispose();
        }
        private void Add2Queue(byte[] receiveBuffer, Socket handler)
        {
            InternalMessage incoming = new InternalMessage { InnerMessage = DataConvert.BinaryToHexString(receiveBuffer), DualMessageUniqueChannel = handler.Handle.ToInt64().ToString() };

            IPAddress address = SocketExtensions.GetAddress(handler);
            incoming.RemoteIpAddress = address.ToString();

            _incomingQueue.Enqueue(incoming);
        }

        public bool IsConnected
        {
            get
            {
                return _listening && (!TcpConnector.RequireClientSignOn || signonReplied) && _clients.Count > 0 && (TcpConnector.DependentTo == null || (!CheckDependentConnector || TcpConnector.DependentTo.Any(c => c.IsConnected)));
            }
        }

        public bool ReadyForRead
        {
            get
            {
                return Initialized;
            }
        }

        public async Task<bool> CloseAsync()
        {
            _listening = false;
            bool erronOnClientClose = false;
            try
            {
                _listener.Stop();
                foreach (var kvp in _clients.ToArray())
                {
                    try
                    {
                        _clients.TryRemove(kvp.Key, out TcpStateObject removed);
                        kvp.Value.TcpClient.Close();
                        kvp.Value.TcpClient.Dispose();
                    }
                    catch (Exception exc)
                    {
                        erronOnClientClose = true;
                        _logger.LogError(exc, "{unique} | An error occured while closing the client communicator. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:[{exc.Message}]");
                    }
                }
            }

            catch (Exception ex)
            {
                erronOnClientClose = true;
                _logger.LogError(ex, "{unique} | An error occured while closing the client communicator. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage:[{ex.Message}]");
            }

            return await Task.FromResult(erronOnClientClose == false);

        }

        public IConnector Connector { get; private set; }
        public bool Initialized { get; private set; }
        public bool CheckDependentConnector { get; private set; }

        public bool HasClient
        {
            get
            {
                return _clients != null && _clients.Count > 0;
            }
        }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;

            var receiveCommand = Connector.GetCommand<IBusinessCommand>(TcpConnector.OnReceiveCommandAssembly);
            CheckDependentConnector = receiveCommand != null && receiveCommand.CheckDependentConnector;

        }


        public async Task<InternalMessage> ReceiveMessage()
        {
            bool dequeued = _incomingQueue.TryDequeue(out InternalMessage message);

            if (dequeued)
            {
                return await Task.FromResult<InternalMessage>(message);
            }
            else
            {
                return null;

            }
        }


        public async Task<bool> SendAsync(InternalMessage message)
        {
            return await Task.FromResult(Send(message));
        }

        public bool Send(InternalMessage message)
        {
            try
            {
                if ((!String.IsNullOrEmpty(message.DualMessageUniqueChannel) && _clients.ContainsKey(message.DualMessageUniqueChannel)))
                {
                    var ns = _clients[message.DualMessageUniqueChannel].Stream;

                    _clients[message.DualMessageUniqueChannel].DeadMessagesCount--;
                    _clients[message.DualMessageUniqueChannel].LastSent = DateTime.Now;


                    ns.Write(message.BinaryMessage, 0, message.BinaryMessage.Length);

                    return true;
                }
                else if (TcpConnector.MaximumClientCount == 1 && _clients.Count == 1)
                {
                    var ns = _clients.FirstOrDefault().Value.Stream;

                    _clients.FirstOrDefault().Value.DeadMessagesCount--;
                    _clients.FirstOrDefault().Value.LastSent = DateTime.Now;


                    ns.Write(message.BinaryMessage, 0, message.BinaryMessage.Length);
                    return true;
                }
                else
                {
                    if (TcpConnector.AllowClientsLoadBalance)
                    {
                        var client = _clients.ToArray().Aggregate((t1, t2) => t1.Value.LastSent < t2.Value.LastSent ? t1 : t2);
                        var ns = client.Value.Stream;

                        client.Value.DeadMessagesCount--;
                        client.Value.LastSent = DateTime.Now;

                        ns.Write(message.BinaryMessage, 0, message.BinaryMessage.Length);
                        return true;

                    }

                    _logger.LogWarning("{unique} | Send failed !!", message.Unique);
                    return false;
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "{unique} | Send failed. | {additionalMessage}", LoggerUnique.CorfCore, $"Reason[{exception.Message}] for [{ToString()}]");
                return false;
            }
        }
    }
}
