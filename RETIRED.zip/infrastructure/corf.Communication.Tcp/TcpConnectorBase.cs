﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace corf.Communication.Tcp
{
    public abstract class TcpConnectorBase : DualConnector, ITcpConnector
    {
        [FlowDesign(EnvironmentBasedVariable = true, DefaultValue = "localhost",Description = "Dns name or ip address. For clients : remote server ip or dns name. For servers : Local ip adresses like 127.0.0.1, localhost or you can set 0.0.0.0 for all network interfaces.")]
        public string Address { get; set; }

        [FlowDesign(Description = "Port number to connect.", DefaultValue = 9443)]
        public string Port { get; set; }

        public bool KeepAlive { get; set; } = true;
        public TcpConnectorBase(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
        }

        public bool RequireClientSignOn { get; set; }


        [FlowDesign(Description = "Set no delay property for tcp socket option level. [true/false]")]
        public virtual bool NoDelay { get; set; }

        public override string ChannelDescription
        {
            get { return string.Format("{0}:{1}", Address, Port); }
        }

        [FlowDesign(DefaultValue = true, Description = "It keeps the information whether there is a header in the message where the length can be read. If this field is 'false', the incoming message will be read in its entirety.")]
        public bool CheckHeader { get; set; } = true;
        [FlowDesign(DefaultValue = 2, Description = "If CheckHeader is true, the length of the header information from which the message length will be read is specified in this field.")]
        public int HeaderLength { get; set; } = 2;

        [FlowDesign(Description = "It is used when there is padding in the message content.")]
        public bool CheckPadding { get; set; }

        [FlowDesign(Description = "If CheckPadding is true, define length of padding")]
        public int PaddingLength { get; set; }

        [FlowDesign(Display = false, Description = "Is used for port management service.")]
        public string Destination { get; set; }

        public virtual bool Poll() { return true; }
    }
}
