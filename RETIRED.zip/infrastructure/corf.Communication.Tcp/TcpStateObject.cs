﻿using corf.Communication.Tcp.Client;
using Microsoft.VisualStudio.Threading;
using System.Net.Sockets;
using System.Text;

namespace corf.Communication.Tcp.Server
{
    public class TcpStateObject
    {
        public TcpClient TcpClient { get; set; }
        // Client  socket.  
        // Size of receive buffer.  
        // Receive buffer.  
        public const int BufferSize = 6553600;

        public ITcpConnectionController TcpConnectionController { get; set; }

        public byte[] Buffer = new byte[BufferSize];
        // Received data string.  
        public StringBuilder StringBuilder = new StringBuilder();
        public byte[] Received { get; set; }

        public int ThreadId { get; internal set; }

        public bool Available { get; set; }

        public bool ReadData { get; set; }
        public string HandleId { get; set; }
        public NetworkStream Stream { get; set; }
        public byte[] Header { get; set; }
        public int DeadMessagesCount { get; set; }
        public bool Connected { get;  set; }
        public TcpClientItem TcpClientItem { get; internal set; }
        public AsyncManualResetEvent ResetEvent { get; internal set; }
        public bool WaitingEcho { get; internal set; }
        public DateTime LastSent { get; internal set; }
    }
}
