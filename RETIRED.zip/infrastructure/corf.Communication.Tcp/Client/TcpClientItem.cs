﻿using corf.Communication.Tcp.Server;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace corf.Communication.Tcp.Client
{
    public class TcpClientItem : IDisposable, ITcpConnectionController
    {
        private ILogger _logger;

        private int _waitingMessagesCount = 0;

        public int WaitingMessagesCount { get
            {
                return _waitingMessagesCount;
            }
        }

        public void IncreaseWaitingMessagesCount()
        {
            Interlocked.Increment(ref _waitingMessagesCount);
        }

        public void HandleMessageReceived()
        {
            Interlocked.Exchange(ref _waitingMessagesCount, 0);
        }

        public TcpClientItem(TcpClient tcpClient, string host, int port, int headerLength, ILogger logger)
        {
            Client = tcpClient;
            Host = host;
            Port = port;
            HeaderLength = headerLength;
            _logger = logger;
        }
        public TcpClient Client { get; private set; }

        public string Host { get; private set; }
        public int Port { get; private set; }

        public int HeaderLength { get; private set; }
        public TcpStateObject? State { get; private set; }

        public NetworkStream NetworkStream { get; private set; }
        public bool ConnectionEstablished { get; set; }

        public void Dispose()
        {
            Client.Close();
            Client.Dispose();
        }

        public async Task<TcpStateObject?> ConnectAsync(bool reconnect)
        {
            if (reconnect)
            {
                if (Client != null)
                {
                    Client.Dispose();
                }

                Client = new TcpClient(AddressFamily.InterNetwork);
            }

            Client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);

            bool connected = false;
            var ipAddress = GetIPAddress(Host);
            string handleId = string.Empty;

            try
            {
                await Client.ConnectAsync(ipAddress, Port);
                NetworkStream = Client.GetStream();
                handleId = Client.Client.Handle.ToInt64().ToString();
                connected = true;
                ConnectionEstablished = true;
            }
            catch (Exception ex)
            {
                NetworkStream = null;
                _logger.LogError(ex, $"Could not connect to {Host}:{Port}");
                State = null;
            }
            State = new TcpStateObject
            {
                TcpClient = Client,
                ThreadId = Thread.CurrentThread.ManagedThreadId,
                HandleId = handleId,
                Stream = NetworkStream,
                TcpClientItem = this,
                Header = new byte[HeaderLength],
                TcpConnectionController = this,
                Connected = connected
            };
            return State;
        }

        private IPAddress GetIPAddress(string host)
        {
            var currentIp = IPAddress.Any;

            if (!string.Equals("0.0.0.0", host))
            {
                IPAddress[] addresses = Dns.GetHostAddresses(host);
                currentIp = addresses[0];
            }

            return currentIp;
        }

        internal async Task WriteAsync(byte[] binaryMessage, int offset, int length)
        {
            LastSent = DateTime.Now;
            await NetworkStream.WriteAsync(binaryMessage, offset, length);
        }

        internal void Write(byte[] binaryMessage, int offset, int length)
        {
            LastSent = DateTime.Now;
            NetworkStream.Write(binaryMessage, offset, length);
        }

        public int Available
        {
            get
            {
                return Client.Available;
            }
        }

        public bool Connected
        {
            get
            {
                return Client != null ? Client.Connected : false;
            }
        }

        public DateTime LastSent { get; internal set; } = DateTime.Now;
    }
}