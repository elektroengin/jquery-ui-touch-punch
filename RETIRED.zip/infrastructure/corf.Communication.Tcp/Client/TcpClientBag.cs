﻿using Elasticsearch.Net.Specification.IndicesApi;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;

namespace corf.Communication.Tcp.Client
{
    internal class TcpClientBag
    {
        private List<TcpClientItem> _clients = new List<TcpClientItem>();

        private AddressFamily _addressFamily;
        private ILogger _logger;
        private bool _checkUnrepliedMessages = false;
        private int _maxUnrepliedMessagesCount = 50;


        private static object _lock = new object();
        public TcpClientBag(AddressFamily addressFamily, ILogger logger, bool checkUnrepliedMessages, int maxUnrepliedMessagesCount)
        {
            _addressFamily = addressFamily;
            _logger = logger;
            _maxUnrepliedMessagesCount = maxUnrepliedMessagesCount;
            _checkUnrepliedMessages = checkUnrepliedMessages;
        }

        public async Task<TcpClientItem> CreateNew(string host, int port, int headerLength)
        {
            var tcpClient = new TcpClient(_addressFamily);
            
            var item = new TcpClientItem(tcpClient, host, port, headerLength,_logger);

            _clients.Add(item);

            await item.ConnectAsync(false);
            
            return item;
        }

     
        public TcpClientItem? GetActiveItem()
        {
           return _clients.ToArray().Where(_ => _.ConnectionEstablished).Aggregate((t1, t2) => t1.LastSent < t2.LastSent ? t1 : t2); ;
        }

        public void Dispose()
        {
            foreach (var clientItem in _clients.ToArray())
            {
                DisposeSingleItem(clientItem);
            }
        }

        public async Task WriteAsync(byte[] binaryMessage, int offset, int length)
        {
            var activeItem = validateAndGetActiveItem(offset);

            await activeItem.WriteAsync(binaryMessage, offset, length);
        }

        private TcpClientItem? validateAndGetActiveItem(int offset)
        {
            var activeItem = GetActiveItem();
            if (_checkUnrepliedMessages && activeItem?.WaitingMessagesCount == _maxUnrepliedMessagesCount)
            {
                _logger.LogWarning("{unique} Waiting messages count reached to max limit. Disposing current connection. Address -> {host}:{port} -> {machineName}", offset, activeItem.Host, activeItem.Port, Environment.MachineName);
                DisposeSingleItem(activeItem);
                //now get active item again
                activeItem = GetActiveItem();
            }

            activeItem?.IncreaseWaitingMessagesCount();

            return activeItem;
        }

        public void Write(byte[] binaryMessage, int offset, int length)
        {
            var activeItem = validateAndGetActiveItem(offset);
            activeItem?.Write(binaryMessage, offset, length);
        }

        public async Task ReconnectClients()
        {
            await Task.Delay(1);

            foreach (var client in _clients.Where(c => c.ConnectionEstablished == false).ToArray()) 
            {
                try
                {
                    client.Client.Close();
                }
                catch(Exception ex) 
                {
                    _logger.LogError(ex, $"client could not be connected to {client.Host}:{client.Port}, MachineName : {Environment.MachineName}");
                }

                await client.ConnectAsync(true);
            }
        }

        internal void DisposeSingleItem(TcpClientItem clientItem)
        {
            clientItem.Dispose();
            lock (_lock)
            {
                _clients.Remove(clientItem);
            }
        }

        public int Available
        {
            get
            {
                var connectedItem = _clients.FirstOrDefault(_ => _.ConnectionEstablished);
                return connectedItem != null ? connectedItem.Available : 0;
            }
        }

        public bool Ready
        {
            get
            {
                var activeItem = GetActiveItem();
                return activeItem != null && activeItem.Connected;
            }
        }
        public bool Connected
        {
            get
            {
                return _clients.Exists(_ => _.Connected);
            }
        }
    }
}