﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Tcp.Client
{
    public class TcpClientConnector : TcpConnectorBase
    {
        private readonly ITcpClientCommunicator _communicator;
        public override bool IsHealthy
        {
            get
            {
                return _communicator.IsConnected;
            }
        }
        public TcpClientConnector(ILogger<TcpClientConnector> logger, ITcpClientCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }

        [FlowDesign(DefaultValue = 1, Description = "Limits the number of clients to connect")]
        public int MaximumConnectionCount { get; set; }

        [FlowDesign(Description = "If CheckUnrepliedMessages is true, it is used to force the connection to be re-established when the number of unanswered messages exceeds a certain rate. 0 : Unlimited")]
        public int MaxDeadMessagesCount { get; set; }

        [FlowDesign(Description = "Set to true if the number of unanswered messages control is required.")]
        public bool CheckDeadMessages { get; set; }

        public override bool Poll()
        {
            return _communicator.Poll();
        }
    }
}
