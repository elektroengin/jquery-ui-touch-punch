﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.Tcp.Client
{
    public class BalancedTcpClientConnector : DualConnector, IBalancedTcpClientConnector
    {
        internal ITcpEchoMessageGenerator TcpEchoMessageGenerator { get; private set; }

        public BalancedTcpClientConnector(ILogger<BalancedTcpClientConnector> logger, IServiceProvider provider, IBalancedTcpClientCommunicator communicator, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override bool IsHealthy
        {
            get
            {
                return _communicator.IsConnected;
            }
        }

        public string Hosts { get; set; }   
        public string Ports { get; set; }   

        private readonly IBalancedTcpClientCommunicator _communicator;

        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }

        [FlowDesign(Display = false)]
        public override string ChannelDescription
        {
            get { return string.Format("{0}:{1}", Hosts, Ports); }
        }

        public string EchoMessageGeneratorAssembly { get; set; }
        public void UseTcpEchoMessageGenerator(ITcpEchoMessageGenerator echoMessageGenerator)
        {
            TcpEchoMessageGenerator = echoMessageGenerator;
        }

        [FlowDesign(DefaultValue = 1, Description = "Limits the number of clients to connect")]
        public int MaximumConnectionCount { get; set; }

        [FlowDesign(Description = "If CheckUnrepliedMessages is true, it is used to force the connection to be re-established when the number of unanswered messages exceeds a certain rate. 0 : Unlimited")]
        public int MaxDeadMessagesCount { get; set; }

        [FlowDesign(Description = "Set to true if the number of unanswered messages control is required.")]
        public bool CheckDeadMessages { get; set; }

        [FlowDesign(DefaultValue = true, Description = "It keeps the information whether there is a header in the message where the length can be read. If this field is 'false', the incoming message will be read in its entirety.")]
        public bool CheckHeader { get; set; } = true;
        [FlowDesign(DefaultValue = 2, Description = "If CheckHeader is true, the length of the header information from which the message length will be read is specified in this field.")]
        public int HeaderLength { get; set; } = 2;

        [FlowDesign(DefaultValue = true, Description = "It keeps the information whether there is a header in the message where the length can be read. If this field is 'false', the incoming message will be read in its entirety.")]
        public bool CheckPadding { get; set; }

        [FlowDesign(Description = "If CheckPadding is true, define length of padding")]
        public int PaddingLength { get; set; }

    }
}
