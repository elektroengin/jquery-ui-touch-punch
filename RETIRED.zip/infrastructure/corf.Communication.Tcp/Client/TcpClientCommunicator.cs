﻿using corf.BinaryConverter;
using corf.Communication.Tcp.Server;
using corf.Communication.Tcp.SocketManagement;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;

namespace corf.Communication.Tcp.Client
{
    public class TcpClientCommunicator : ITcpClientCommunicator
    {
        private TcpClient _tcpClient = null;
        private NetworkStream _stream = null;
        private IPAddress _ipAddress;
        private ConcurrentQueue<InternalMessage> _incomingQueue = null;
        private int _unRepliedMessagesCount = 0;
        private DateTime _lastSend = DateTime.Now;
        private bool signonReplied;

        private readonly ILogger<TcpClientCommunicator> _logger;

        public TcpClientCommunicator(ILogger<TcpClientCommunicator> logger)
        {
            _logger = logger;
        }
        public void GetReady()
        {
            _incomingQueue = new ConcurrentQueue<InternalMessage>();
        }
        public bool ReadyForRead { get { return Initialized; } }
        public int MessageLength { get { return _tcpClient.Available; } }
        public bool CheckDependentConnector { get; private set; }


        public bool IsConnected
        {
            get
            {

                var isConnected = _tcpClient != null && _tcpClient.Connected 
                    && (!TcpConnector.RequireClientSignOn || signonReplied)
                    && (TcpConnector.DependentTo == null || ( TcpConnector.DependentTo.Any(c => c.IsConnected)))
                    && (TcpConnector.CheckDeadMessages == false || (_unRepliedMessagesCount < TcpConnector.MaxDeadMessagesCount));
                if (!isConnected )
                {
                    _logger.LogDebug("{unique} | TcpClientCommunicator is not connected!!! | {additionalMessage}", LoggerUnique.CorfCore, $"_tcpClient != null : {_tcpClient != null}, _tcpClient.Connected : {_tcpClient?.Connected}, (TcpConnector.CheckUnrepliedMessages == false || (_unRepliedMessagesCount < TcpConnector.MaxUnrepliedMessagesCount) {(TcpConnector.CheckDeadMessages == false || (_unRepliedMessagesCount < TcpConnector.MaxDeadMessagesCount))}  ");
                }
                return isConnected;
            }
        }

        TcpClientConnector TcpConnector
        {
            get
            {
                return (TcpClientConnector)Connector;
            }
        }
       
        public async Task<bool> ConnectAsync()
        {
            try
            {
                if (TcpConnector.DependentTo == null  || (TcpConnector.DependentTo != null && TcpConnector.DependentTo.Any(c => c.IsConnected)))
                {
                    _logger.LogInformation("{unique} | Connecting to server | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{TcpConnector.Address}, Port:{TcpConnector.Port}");

                    Interlocked.Exchange(ref _unRepliedMessagesCount, 0);

                    _lastSend = DateTime.Now;

                    _tcpClient = new TcpClient(AddressFamily.InterNetwork);

                    if (TcpConnector.KeepAlive)
                    {
                        _tcpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
                    }

                    SocketError result = SocketError.SocketError;

                    await _tcpClient.ConnectAsync(TcpConnector.Address, Convert.ToInt32(TcpConnector.Port));


                    result = SocketError.Success;

                    _stream = _tcpClient.GetStream();

                    TcpStateObject state = new TcpStateObject
                    {
                        TcpClient = _tcpClient,
                        ThreadId = Thread.CurrentThread.ManagedThreadId,
                        HandleId = _tcpClient.Client.Handle.ToInt64().ToString(),
                        Stream = _stream,
                        Header = new byte[TcpConnector.HeaderLength]
                    };

                    await Task.Factory.StartNew(async () => await StartReceiving(state), TaskCreationOptions.LongRunning);


                    _logger.LogInformation("{unique} | Connected to server | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{TcpConnector.Address}, Port:{TcpConnector.Port}");

                    return result == SocketError.Success;
                }

                return await Task.FromResult(false);
            }
            catch (SocketException exc)
            {
                _logger.LogError("{unique} | Start failed with SocketException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{exc.Message}, Socket Error Code :{exc.SocketErrorCode}");
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");
                return false;
            }
            finally
            {
                Initialized = true;
            }
        }
        public async Task<bool> CloseAsync()
        {
            try
            {

                if (_tcpClient != null && _tcpClient.Connected)
                {
                    _tcpClient.Close();
                    _stream.Dispose();
                }

                return await Task.FromResult<bool>(true);
            }
            catch (Exception exc)
            {
                _logger.LogError(exc, "{unique} | An error occured while closing the client communicator. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{exc.Message}");
                return false;
            }
        }

        private void Add2Queue(byte[] receiveBuffer, Socket handler)
        {
            InternalMessage incoming = new InternalMessage { InnerMessage = DataConvert.BinaryToHexString(receiveBuffer), DualMessageUniqueChannel = handler.Handle.ToInt64().ToString() };

            IPAddress address = SocketExtensions.GetAddress(handler);
            incoming.RemoteIpAddress = address.ToString();

            _incomingQueue.Enqueue(incoming);

            _logger.LogDebug("{unique} | Queuing | {additionalMessage}", incoming.Unique, $"Connector Name :{TcpConnector.Name}, Queue size :{_incomingQueue.Count}");
        }

        public async Task<InternalMessage> ReceiveMessage()
        {

            bool dequeued = _incomingQueue.TryDequeue(out InternalMessage message);

            if (dequeued)
            {
                message = await Task.FromResult<InternalMessage>(message);
            }

            return message;
        }
        public async Task<bool> SendAsync(InternalMessage channelMessage)
        {
            if (_unRepliedMessagesCount == 0)
            {
                _lastSend = DateTime.Now;
            }

            Interlocked.Increment(ref _unRepliedMessagesCount);

            await _stream.WriteAsync(channelMessage.BinaryMessage, 0, channelMessage.BinaryMessage.Length);

            return true;
        }

        private async Task StartReceiving(TcpStateObject state)
        {
          try
            {
                _logger.LogInformation($"Tcp Client - StartReceiving started ...", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, isConnected : {IsConnected}");

                if (TcpConnector.RequireClientSignOn)
                {
                    var preCommand = TcpConnector.GetCommand<IBusinessCommand>(TcpConnector.OnReceiveCommandAssembly);
                    if (preCommand != null)
                    {
                        var signOnMessage = await preCommand.GetSignOnMessage();

                        if (signOnMessage != null)
                        {
                            var tryCount = 0;

                            bool replied = false;

                            var signonResult = new byte[512];

                            while (tryCount < 3)
                            {
                                tryCount++;
                                try
                                {
                                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(2000);

                                    _stream.Write(DataConvert.HexStringToBinary(signOnMessage.InnerMessage));

                                    await _stream.ReadAsync(signonResult, 0, 512, cancellationTokenSource.Token);

                                    replied = true;

                                    break;
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, $"try count : {tryCount} | message :{ex.Message}");
                                }

                                signonResult = new byte[512];
                            }

                            signonReplied = replied;

                            if (!replied || !(await preCommand.CheckSignOnResult(new InternalMessage { InnerMessage = DataConvert.BinaryToHexString(signonResult) })))
                            {
                                closeHandler(_stream, state);
                            }
                        }
                    }
                }

                if (IsConnected)
                {
                    Interlocked.Exchange(ref _unRepliedMessagesCount, 0);

                    _stream.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
                }
                else
                {
                    _logger.LogDebug("{unique} | Message could not received and queued from connection. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{TcpConnector.Name}, IsConnected = false, LastSend = {_lastSend},  Unreplied Messages : {_unRepliedMessagesCount}");

                    await Task.Delay(2000);
                }


                _logger.LogInformation("{unique} | Tcp Client - StartReceiving finished ... | {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, isConnected : {IsConnected}");
            }
            catch (ObjectDisposedException)
            {
                _logger.LogWarning("{unique} | Socket is disposed. Not connected to server. | {additionalMessage}", LoggerUnique.CorfCore, $"Tcp Connector Name :{TcpConnector.Name}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error while tcp message receiving. | {additionalMessage}", LoggerUnique.CorfCore, $"Tcp Connector Name :{TcpConnector.Name}");
            }
        }
        public void ReadCallback(IAsyncResult ar)
        {
            TcpStateObject state = (TcpStateObject)ar.AsyncState;

            var ns = state.Stream;

            bool disposed = false;

            try
            {
                _logger.LogInformation("{unique} | Tcp Client - readcallback started ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");

                int streamBytes = ns.EndRead(ar);

                if (state.TcpClient.Available == 0)
                {
                    if (streamBytes == 0)
                    {
                        disposed = true;
                        closeHandler(ns, state);
                        _logger.LogDebug("{unique} | Tcp Client - readcallback : Stream available size was zero. Returning ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");
                        return;
                    }
                }

                if (TcpConnector.HeaderLength > 0)
                {
                    int lenght = DataConvert.HexStringToInt32(DataConvert.BinaryToHexString(state.Header));

                    _logger.LogInformation("{unique} | Tcp Client - length value ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, length {lenght}");

                    int paddingLength = ((TcpClientConnector)Connector).CheckPadding && ((TcpClientConnector)Connector).PaddingLength > 0 ? ((TcpClientConnector)Connector).PaddingLength : 0;

                    lenght += paddingLength;

                    var tryCount = 0;

                    var receivedBytes = new byte[lenght + TcpConnector.HeaderLength];

                    Array.Copy(state.Header, 0, receivedBytes, 0, TcpConnector.HeaderLength);

                    var currentReceiveLength = lenght;

                    _logger.LogInformation($"[{TcpConnector.Name}-{TcpConnector.Address}-{TcpConnector.Port}]#handle:{state.HandleId}# Incoming stream length : {currentReceiveLength}");

                    if (currentReceiveLength > 0)
                    {
                        int copiedLength = state.Header.Length;

                        while (true)
                        {
                            tryCount++;


                            byte[] currentReceivedBytes = new byte[currentReceiveLength];

                            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(1500);

                            int receivedLength = ns.ReadAsync(currentReceivedBytes, 0, currentReceiveLength, cancellationTokenSource.Token).Result;

                            _logger.LogInformation("{unique} | Tcp Client - packet value ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, value {DataConvert.BinaryToHexString(currentReceivedBytes)}");

                            currentReceiveLength -= receivedLength;

                            if (receivedLength > 0)
                            {
                                Array.Copy(currentReceivedBytes, 0, receivedBytes, copiedLength, receivedLength);

                                _logger.LogInformation($"[{TcpConnector.Name}-{TcpConnector.Address}-{TcpConnector.Port}]#handle:{state.HandleId}# Incoming stream bytes : {DataConvert.BinaryToHexString(currentReceivedBytes)}");

                                copiedLength += receivedLength;

                                if (copiedLength == lenght + state.Header.Length)
                                {
                                    state.DeadMessagesCount++;
                                    Add2Queue(receivedBytes, state.TcpClient.Client);
                                    break;
                                }
                            }

                            if (tryCount > 3 || (TcpConnector.CheckDeadMessages == true && state.DeadMessagesCount > 3))
                            {
                                disposed = true;
                                closeHandler(ns, state);
                                throw new TimeoutException($"Received message could not be processed, tryCount {tryCount}, UnRepliedMessagesCount {state.DeadMessagesCount}");
                            }
                        }
                    }
                }
                else
                {
                    byte[] receiveBuffer = new byte[streamBytes];

                    Array.Copy(state.Buffer, receiveBuffer, streamBytes);

                    Add2Queue(receiveBuffer, state.TcpClient.Client);
                }

                _logger.LogInformation("{unique} | Tcp Client - readcallback finished ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");
            }
            catch (SocketException sex)
            {
                _logger.LogError(sex, "{unique} | Received socket exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], code : {sex.SocketErrorCode}-{sex.NativeErrorCode}, Message : [{sex.Message}] , StackTrace : {sex.StackTrace}.");
            }
            catch (OperationCanceledException ocex)
            {
                _logger.LogError(ocex, "{unique} | Received function time out exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], Message : [{ocex.Message}], StackTrace : {ocex.StackTrace}.");
                disposed = true;
                closeHandler(ns, state);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Received function exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], Message : [{ex.Message}], StackTrace : {ex.StackTrace}.");
            }
            finally
            {
                if (!disposed && _tcpClient.Connected && this._tcpClient.Client != null && this._tcpClient.Client.Connected)
                {
                    if (TcpConnector.CheckHeader && state.TcpClient.Available < TcpConnector.HeaderLength)
                    {
                        state.Header = new byte[TcpConnector.HeaderLength];
                    }

                    _stream.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
                }
            }
        }
        private void closeHandler(NetworkStream ns, TcpStateObject tcpServerStateObject)
        {
            _logger.LogInformation("{unique} | Tcp Client shutdown ... | {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {tcpServerStateObject.HandleId}");
            ns.Close();
            ns.Dispose();
            tcpServerStateObject.TcpClient.Close();
            tcpServerStateObject.TcpClient.Dispose();
        }
        public bool Send(InternalMessage channelMessage)
        {
            _stream.Write(channelMessage.BinaryMessage, 0, channelMessage.BinaryMessage.Length);

            return true;
        }

        public IConnector Connector { get; private set; }


        public bool Initialized { get; private set; }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;

            var receiveCommand = Connector.GetCommand<IBusinessCommand>(TcpConnector.OnReceiveCommandAssembly);
            CheckDependentConnector = receiveCommand != null && receiveCommand.CheckDependentConnector;
        }

        public bool Poll()
        {
            try 
            {
                return !(_tcpClient.Client.Poll(10, SelectMode.SelectRead) && _tcpClient.Client.Available <= 0);
            }
            catch
            {
                return false;
            }
        }
    }
}
