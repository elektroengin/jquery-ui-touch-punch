﻿using corf.Core.Infrastructure;

namespace corf.Communication.Tcp.Client
{
    public interface ITcpClientCommunicator : IEndlessReceiver, IMessageSender
    {
        bool Poll();
    }
}
