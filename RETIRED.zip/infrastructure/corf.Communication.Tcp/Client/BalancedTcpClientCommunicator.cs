﻿using corf.BinaryConverter;
using corf.Communication.Tcp.Server;
using corf.Communication.Tcp.SocketManagement;
using corf.Configuration;
using corf.Core;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Logging;
using Microsoft.VisualBasic;
using Microsoft.VisualStudio.Threading;
using Elasticsearch.Net.Specification.SnapshotApi;

namespace corf.Communication.Tcp.Client
{
    public class BalancedTcpClientCommunicator : IBalancedTcpClientCommunicator
    {
        private TcpClientBag _tcpClientBag;
        private ConcurrentQueue<InternalMessage> _incomingQueue;
        private DateTime _lastSend = DateTime.Now;
        private DateTime _lastHealthCheck = DateTime.Now;

        private readonly ILogger<BalancedTcpClientCommunicator> _logger;

        public BalancedTcpClientCommunicator(ILogger<BalancedTcpClientCommunicator> logger)
        {
            
            _logger = logger;
        }
        public void GetReady()
        {
            _incomingQueue = new ConcurrentQueue<InternalMessage>();
        }
        public bool ReadyForRead { get { return Initialized; } }

        public bool EchoMessageReceived { get; set; }

        private bool _pendingConnection = false;

        public int MessageLength { get { return _tcpClientBag.Available; } }
        
        public bool IsConnected
        {
            get
            {
                
                return _pendingConnection || (PhsicallyConnected && (TcpConnector.TcpEchoMessageGenerator == null || EchoMessageReceived));
            }
        }

        protected bool PhsicallyConnected
        {
            get
            {
                return _tcpClientBag.Connected;
            }
        }

        BalancedTcpClientConnector TcpConnector
        {
            get
            {
                return (BalancedTcpClientConnector)Connector;
            }
        }
        public async Task<bool> ConnectAsync()
        {
            try
            {
                EchoMessageReceived = false;

                _pendingConnection = true;

                TcpConnector.ConnectionEstablished = false;

                _logger.LogInformation("{unique} | Connecting to server | {additionalMessage}", LoggerUnique.CorfCore, $"Addresses :{TcpConnector.Hosts}, Ports:{TcpConnector.Ports}");

                _lastSend = DateTime.Now;

                if (string.IsNullOrWhiteSpace(TcpConnector.Hosts) || string.IsNullOrWhiteSpace(TcpConnector.Ports))
                {
                    throw new ArgumentException("Hosts and ports must be declared !!");
                }

                string[] hosts = TcpConnector.Hosts.Split(',');
                string[] ports = TcpConnector.Ports.Split(',');

                if (hosts.Length != ports.Length) 
                { 
                    throw new ArgumentException("Hosts length and ports length must be equal !!");
                }

                var portIndex = 0;

                SocketError result = SocketError.SocketError;

                string connectedHost = "";
                int connectedPort = 0;

                foreach (string host in hosts)
                {
                    var port = int.Parse(ports[portIndex]);

                    TcpClientItem clientItem = null;

                    try
                    {
                        clientItem = await _tcpClientBag.CreateNew(host, port, TcpConnector.HeaderLength);

                        connectedHost = host;
                        connectedPort = port;


                        if (clientItem.State.Connected)
                        {
                            

                            if (TcpConnector.TcpEchoMessageGenerator != null)
                            {
                                clientItem.State.WaitingEcho = true;

                                await Task.Factory.StartNew(() => StartReceiving(clientItem.State), TaskCreationOptions.LongRunning);

                                var echoMessage = TcpConnector.TcpEchoMessageGenerator.GetEchoMessage();
                                await sendByte(echoMessage, clientItem.NetworkStream);

                                AsyncManualResetEvent resetEvent = new AsyncManualResetEvent(false);

                                clientItem.State.ResetEvent = resetEvent;
                                
                                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(5000);

                                try 
                                {
                                    await resetEvent.WaitAsync(cancellationTokenSource.Token);
                                    EchoMessageReceived = true;
                                    TcpConnector.ConnectionEstablished = true;
                                    clientItem.ConnectionEstablished = true;
                                    _logger.LogInformation("{unique} | Connected to server (with EchoMessageGenerator) | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{connectedHost}, Port:{connectedPort}, MachineName : {Environment.MachineName}");
                                    return true;
                                }
                                catch(OperationCanceledException) 
                                {
                                    forceCloseConnection(clientItem);
                                    portIndex++;
                                    continue;
                                }
                                finally
                                {
                                    clientItem.State.WaitingEcho = false;
                                }
                            }
                            else
                            {
                                StartReceiving(clientItem.State);
                            }
                            TcpConnector.ConnectionEstablished = true;
                            clientItem.ConnectionEstablished = true;

                            _logger.LogInformation("{unique} | Connected to server | {additionalMessage}", LoggerUnique.CorfCore, $"Address :{connectedHost}, Port:{connectedPort}, MachineName : {Environment.MachineName}");
                        }
                    } 
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Could not connected to {host}:{port}. Ex : {ex.Message}, MachineName : {Environment.MachineName}");
                        forceCloseConnection(clientItem);
                    }
                    portIndex++;
                }

                return _tcpClientBag.Connected;
            }
            catch (SocketException exc)
            {
                _logger.LogError("{unique} | Start failed with SocketException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{exc.Message}, Socket Error Code :{exc.SocketErrorCode}, MachineName : {Environment.MachineName}");
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}, MachineName : {Environment.MachineName}");
                return false;
            }
            finally
            {
                _pendingConnection = false;
                Initialized = true;
            }
        }

        private void forceCloseConnection(TcpClientItem? clientItem)
        {
            try
            {
                if (clientItem != null)
                {
                    _tcpClientBag.DisposeSingleItem(clientItem);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, $"error on disposing tcp client connection !, MachineName : {Environment.MachineName}");
            }
        }

        public async Task<bool> CloseAsync()
        {
            try
            {
                _tcpClientBag.Dispose();
                return await Task.FromResult<bool>(true);
            }
            catch (Exception exc)
            {
                _logger.LogError(exc, "{unique} | An error occured while closing the client communicator. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{exc.Message}");
                return false;
            }
        }

        private void Add2Queue(byte[] receiveBuffer, Socket handler)
        {

            InternalMessage incoming = new InternalMessage { InnerMessage = DataConvert.BinaryToHexString(receiveBuffer), DualMessageUniqueChannel = handler.Handle.ToInt64().ToString() };

            IPAddress address = SocketExtensions.GetAddress(handler);
            incoming.RemoteIpAddress = address.ToString();

            _incomingQueue.Enqueue(incoming);

            if ((DateTime.Now - _lastHealthCheck).TotalSeconds > 20)
            {
                _tcpClientBag.ReconnectClients();
                _lastHealthCheck = DateTime.Now;
            }

            _logger.LogDebug("{unique} | Queuing | {additionalMessage}", incoming.Unique, $"Connector Name :{TcpConnector.Name}, Queue size :{_incomingQueue.Count}");
        }

        public async Task<InternalMessage> ReceiveMessage()
        {

            bool dequeued = _incomingQueue.TryDequeue(out InternalMessage message);

            if (dequeued)
            {
                message = await Task.FromResult<InternalMessage>(message);
            }

            return message;
        }
        public async Task<bool> SendAsync(InternalMessage channelMessage)
        {
            _lastSend = DateTime.Now;

            await _tcpClientBag.WriteAsync(channelMessage.BinaryMessage, 0, channelMessage.BinaryMessage.Length);

            return true;
        }

        private async Task<bool> sendByte(byte[] message, NetworkStream stream)
        {
            _lastSend = DateTime.Now;
            
            await stream.WriteAsync(message, 0, message.Length);

            return true;
        }

        public bool Send(InternalMessage channelMessage)
        {
            _tcpClientBag.Write(channelMessage.BinaryMessage, 0, channelMessage.BinaryMessage.Length);

            return true;
        }

        private async Task StartReceiving(TcpStateObject state)
        {
            try
            {
                _logger.LogInformation($"Tcp Client - StartReceiving started ...", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, isConnected : {IsConnected}");

                if (PhsicallyConnected)
                {
                    state.Stream.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
                }
                else
                {
                    _logger.LogDebug("{unique} | Message could not received and queued from connection. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{TcpConnector.Name}, IsConnected = false, LastSend = {_lastSend}");

                    await Task.Delay(2000);
                }

                _logger.LogInformation("{unique} | Tcp Client - StartReceiving finished ... | {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, isConnected : {IsConnected}");
            }
            catch (ObjectDisposedException)
            {
                _logger.LogWarning("{unique} | Socket is disposed. Not connected to server. | {additionalMessage}", LoggerUnique.CorfCore, $"Tcp Connector Name :{TcpConnector.Name}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error while tcp message receiving. | {additionalMessage}", LoggerUnique.CorfCore, $"Tcp Connector Name :{TcpConnector.Name}");
            }
        }
        public void ReadCallback(IAsyncResult ar)
        {
            TcpStateObject state = (TcpStateObject)ar.AsyncState;

            var ns = state.Stream;

            bool disposed = false;

            try
            {
                _logger.LogInformation("{unique} | Tcp Client - readcallback started ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");

                int streamBytes = ns.EndRead(ar);

                if (state.TcpClient.Available == 0)
                {
                    disposed = true;
                    closeHandler(ns, state);
                    _logger.LogDebug("{unique} | Tcp Client - readcallback : Stream available size was zero. Returning ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");
                    return;
                }
                if (state.WaitingEcho)
                {
                    state.ResetEvent.Set();
                }

                if (TcpConnector.HeaderLength > 0)
                {
                    int lenght = DataConvert.HexStringToInt32(DataConvert.BinaryToHexString(state.Header));

                    _logger.LogInformation("{unique} | Tcp Client - length value ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, length {lenght}");

                    int paddingLength = ((BalancedTcpClientConnector)Connector).CheckPadding && ((BalancedTcpClientConnector)Connector).PaddingLength > 0 ? ((BalancedTcpClientConnector)Connector).PaddingLength : 0;

                    lenght += paddingLength;

                    var tryCount = 0;

                    var receivedBytes = new byte[lenght + TcpConnector.HeaderLength];

                    Array.Copy(state.Header, 0, receivedBytes, 0, TcpConnector.HeaderLength);

                    var currentReceiveLength = lenght;

                    int copiedLength = state.Header.Length;

                    while (true)
                    {
                        tryCount++;

                        byte[] currentReceivedBytes = new byte[currentReceiveLength];

                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(1500);

                        int receivedLength = ns.ReadAsync(currentReceivedBytes, 0, currentReceiveLength, cancellationTokenSource.Token).Result;

                        _logger.LogInformation("{unique} | Tcp Client - packet value ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}, value {DataConvert.BinaryToHexString(currentReceivedBytes)}");

                        currentReceiveLength -= receivedLength;

                        if (receivedLength > 0)
                        {
                            Array.Copy(currentReceivedBytes, 0, receivedBytes, copiedLength, receivedLength);

                            copiedLength += receivedLength;

                            if (copiedLength == lenght + state.Header.Length)
                            {
                                state.TcpClientItem.HandleMessageReceived();
                                Add2Queue(receivedBytes, state.TcpClient.Client);
                                break;
                            }
                        }

                        if (tryCount > 3)
                        {
                            disposed = true;
                            closeHandler(ns, state);
                            throw new TimeoutException($"Received message could not be processed, tryCount {tryCount}");
                        }
                    }

                }
                else
                {
                    byte[] receiveBuffer = new byte[streamBytes];

                    Array.Copy(state.Buffer, receiveBuffer, streamBytes);

                    Add2Queue(receiveBuffer, state.TcpClient.Client);
                }

                _logger.LogInformation("{unique} | Tcp Client - readcallback finished ...| {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {state.HandleId}");
            }
            catch (SocketException sex)
            {
                _logger.LogError(sex, "{unique} | Received socket exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], code : {sex.SocketErrorCode}-{sex.NativeErrorCode}, Message : [{sex.Message}] , StackTrace : {sex.StackTrace}.");
            }
            catch (OperationCanceledException ocex)
            {
                _logger.LogError(ocex, "{unique} | Received function time out exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], Message : [{ocex.Message}], StackTrace : {ocex.StackTrace}.");
                disposed = true;
                closeHandler(ns, state);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Received function exception. | {additionalMessage}", LoggerUnique.CorfCore, $"[{ToString()}], Message : [{ex.Message}], StackTrace : {ex.StackTrace}.");
            }
            finally
            {
                if (!disposed && state.TcpClient.Connected && state.TcpClient.Client.Connected)
                    state.Stream.BeginRead(state.Header, 0, TcpConnector.HeaderLength, new AsyncCallback(ReadCallback), state);
            }
            Thread.Sleep(1);
        }
        private void closeHandler(NetworkStream ns, TcpStateObject tcpClientStateObject)
        {
            forceCloseConnection(tcpClientStateObject.TcpClientItem);
            _logger.LogInformation("{unique} | Tcp Client shutdown ... | {additionalMessage}", LoggerUnique.CorfCore, $"Handle Id : {tcpClientStateObject.HandleId}");
        }
     
        public IConnector Connector { get; private set; }

        public bool Initialized { get; private set; }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
            _tcpClientBag = new TcpClientBag(AddressFamily.InterNetwork, _logger, TcpConnector.CheckDeadMessages, TcpConnector.MaxDeadMessagesCount);
        }

    }
}
