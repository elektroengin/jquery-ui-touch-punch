﻿using corf.Configuration;
using corf.Core.Infrastructure;
using System;

namespace corf.Communication.HttpInfra
{
    public interface IPathInfo
    {
        string Uri { get; set; }

        [FlowDesign(Display = false)]
        IServiceProvider ServiceProvider { get; set; }

    }
}