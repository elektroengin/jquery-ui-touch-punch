﻿using corf.Communication.HttpInfra.Authentication;
using corf.Communication.HttpInfra.Authentication.Basic;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Http;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Logging;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
//using Utf8Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Extensions;
using Microsoft.OpenApi.Models;
using OpenTelemetry;
using OpenTelemetry.Exporter;
using OpenTelemetry.Instrumentation.AspNetCore;
using OpenTelemetry.Trace;
using Serilog;
using Steeltoe.Management;
using Steeltoe.Management.Endpoint;
using Steeltoe.Management.Endpoint.Metrics;
using Steeltoe.Management.Endpoint.SpringBootAdminClient;
using Steeltoe.Management.Tracing;
using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Concurrent;
using System.Dynamic;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Prometheus;
using Prometheus.DotNetRuntime;
using Steeltoe.Extensions.Configuration;

namespace corf.Communication.HttpInfra
{
    public abstract class HttpServerCommunicator : IMessageSender
    {
        protected readonly ILogger<HttpServerCommunicator> _logger;

        protected DateTime Incoming = DateTime.Now;

        protected readonly IExternalDependenyProvider _hostContainer;

        public readonly ConcurrentDictionary<string, HttpServerStateObject> _events;

        protected ServerAuthenticatonInfo _serverAuthenticatonInfo = null;

        protected IHost _internalBuilder;

        protected IServiceProvider _globalServiceProvider;

        protected IRequestScopeManager _requestScopeManager;

        public static List<string> ConfigurationFiles { get; set; } = new List<string>();
        public static string ConfigurationPath = string.Empty;
        private IConfiguration Configuration;
        public HttpServerCommunicator(ILogger<HttpServerCommunicator> logger, IExternalDependenyProvider hostContainer, IRequestScopeManager requestScopeManager, IServiceProvider globalServiceProvider)
        {
            _events = new ConcurrentDictionary<string, HttpServerStateObject>();
            _logger = logger;
            _hostContainer = hostContainer;
            _globalServiceProvider = globalServiceProvider;
            _requestScopeManager = requestScopeManager;
        }



        public bool IsConnected
        {
            get { return true; }
        }

        public bool ReadyForRead
        {
            get
            {
                return true;
            }
        }


        public IConnector Connector { get; private set; }

        public bool Initialized { get; protected set; }

        public async Task<bool> CloseAsync()
        {
            await _internalBuilder.StopAsync();

            return true;
        }

        public virtual async Task<bool> ConnectAsync()
        {
            try
            {
                if (Connector.IsActive)
                {
                    _logger.LogInformation("{unique} | Binding to nodes... | {additionalMessage}", LoggerUnique.CorfCore, $"ChannelDescription: {Connector.ChannelDescription}");

                    _internalBuilder = Host.CreateDefaultBuilder()
                           .ConfigureAppConfiguration((hostingContext, config) =>
                           {
                               config.SetBasePath(ConfigurationPath);
                               foreach (string file in ConfigurationFiles)
                               {
                                   config.AddJsonFile(file, optional: false, reloadOnChange: true);
                               }
                               config.AddEnvironmentVariables();
                               Configuration = config.Build();
                           })
                           .ConfigureServices((services) => ConfigureServicesDelegate(services))
                      .ConfigureWebHostDefaults(webBuilder =>
                      {
                          webBuilder
                           .Configure((app) => CofigureDelegate(app))
                           .UseContentRoot(Directory.GetCurrentDirectory())
                           .UseKestrel(options =>
                          {
                              IHttpServerConnector httpServerConnector = Connector as IHttpServerConnector;

                              IPAddress ipAddress = IPAddress.Parse(httpServerConnector.RootAddress.Host);

                              if (httpServerConnector.RootAddress.Http != null)
                              {
                                  options.Listen(ipAddress, httpServerConnector.RootAddress.Http.Port, listenoptions =>
                                  {
                                      ConfigureListenOptions(listenoptions);
                                  });
                              }
                              if (httpServerConnector.RootAddress.Https != null)
                              {
                                  string filePath = httpServerConnector.RootAddress.Https.Certificate.Path;
                                  string password = httpServerConnector.RootAddress.Https.Certificate.Password;

                                  options.Listen(IPAddress.Any, httpServerConnector.RootAddress.Https.Port, listenoptions =>
                                  {
                                      ConfigureListenOptions(listenoptions);

                                      listenoptions.UseHttps(filePath, password);
                                  });
                              }
                          });
                      }).ConfigureServices((context, services) =>
                      {
                          addExternalServices(services);
                      })
                      .ConfigureLogging((hostingContext, logging) =>
                      {
                          logging.AddFilter<ConsoleLoggerProvider>(level => level == LogLevel.None);
                          logging.ClearProviders();
                      }).UseSerilog((context, services, configuration) => configuration
                        .ReadFrom.Configuration(context.Configuration)
                        .ReadFrom.Services(services)
                        .Enrich.FromLogContext()).Build();



                    var internalTask = _internalBuilder.RunAsync();

                    _logger.LogInformation("{unique} | Binding to nodes succeed. | {additionalMessage}", LoggerUnique.CorfCore, $"ChannelDescription: {Connector.ChannelDescription}");

                }
                return true;
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");
                return false;
            }

            finally
            {
                Initialized = true;
            }
        }

        public abstract void ConfigureListenOptions(ListenOptions listenOptions);

        private void addExternalServices(IServiceCollection services)
        {
            foreach (var x in _hostContainer.ExternalDescriptors)
            {
                if (!services.Contains(x))
                {
                    if (x.Lifetime == ServiceLifetime.Singleton)
                    {
                        try
                        {
                            services.AddSingleton(x.ServiceType, _globalServiceProvider.GetService(x.ServiceType));
                        }
                        catch
                        {
                            services.Add(x);
                        }
                    }
                    else
                    {
                        services.Add(x);
                    }
                }
            }

        }
        #region delegations
        public TokenValidationParameters CreateTokenValidationParameters()
        {
            var result = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateTokenReplay = false,
                ValidateIssuerSigningKey = false,
                ValidateActor = false,
                RequireExpirationTime = false,
                ValidateLifetime = false,
                ClockSkew = TimeSpan.Zero,
            };

            result.RequireSignedTokens = false;

            return result;
        }
        public virtual void ConfigureServicesDelegate(IServiceCollection services)
        {
            _serverAuthenticatonInfo = ((IHttpServerConnector)Connector).ServerAuthenticatonInfo;

            //TODO: Şimdilik sadece JWT ve Basic için eklendi. OAuth ve diğerleri için de ihtiyaca göre versiyonlu eklenecek!
            if (_serverAuthenticatonInfo.ServerAuthenticatonType == ServerAuthenticatonType.JwtToken)
            {
                services.AddAuthentication(x =>
                {
                    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(x =>
                {
                    x.RequireHttpsMetadata = false;
                    x.SaveToken = true;
                    x.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(((JwtAuthenticatiton)_serverAuthenticatonInfo.ServerAuthenticaton).EncryptionKey)),
                        ValidateIssuer = false,
                        ValidateAudience = false
                    };
                });
            }
            else if (_serverAuthenticatonInfo.ServerAuthenticatonType == ServerAuthenticatonType.BAuth)
            {
                services
                    .AddAuthentication(x =>
                    {
                        x.DefaultAuthenticateScheme = BasicDefaults.AuthenticationScheme;
                        x.DefaultChallengeScheme = BasicDefaults.AuthenticationScheme;
                    })
                    .AddBasic();

                var basicAuthentication = (BasicAuthentication)_serverAuthenticatonInfo.ServerAuthenticaton;

                if (basicAuthentication is { UseDefaultCredentials: true })
                {
                    services.AddSingleton<IBasicAuthenticationValidator>(new DefaultBasicAuthenticationValidator(basicAuthentication.DefaultUser, basicAuthentication.DefaultPassword));
                }

            }
            if (_serverAuthenticatonInfo.ServerAuthenticatonType == ServerAuthenticatonType.JwtTokenWithoutValidation)
            {
                services
                   .AddAuthentication(x =>
                   {
                       x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                       x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                   }).AddJwtBearer(x =>
                   {
                       x.RequireHttpsMetadata = false;
                       x.SaveToken = false;
                       x.TokenValidationParameters = CreateTokenValidationParameters();
                   });
            }

            if (Configuration.GetSection("Management").GetChildren().Any())
            {

                services.AddAllActuators(Configuration);
                services.AddMetricsActuator(Configuration);
            }

            if (Configuration.GetSection("management:tracing").GetChildren().Any() || Configuration.GetSection("tracing").GetChildren().Any())
            {
                // Add Distributed tracing
                services.AddDistributedTracingAspNetCore(
                    builder =>
                    {
                        var probability = Configuration.GetValue<double>("management:tracing:probability", 0.1);
                        builder.SetSampler(new TraceIdRatioBasedSampler(probability));
                    }
                   );

                services.PostConfigure<AspNetCoreInstrumentationOptions>(options =>
                {
                    options.Enrich = (activity, eventName, rawObject) =>
                    {
                        if (eventName.Equals("OnStartActivity"))
                        {
                            if (rawObject is HttpRequest httpRequest)
                            {
                                activity.SetTag("requestProtocol", httpRequest.Protocol);
                            }
                        }
                    };
                });
                services.PostConfigure<ZipkinExporterOptions>(options =>
                {
                    options.ExportProcessorType = ExportProcessorType.Batch;
                    options.BatchExportProcessorOptions.ExporterTimeoutMilliseconds = 1000;
                });
            }

        }


        public virtual void ConfigureKestrelDelegate(KestrelServerOptions options)
        {

        }

        public virtual void CofigureDelegate(IApplicationBuilder app)
        {
            IHttpServerConnector httpServerConnector = Connector as IHttpServerConnector;

            if (httpServerConnector.AllowAnyCors)
            {
                app.UseCors(policy => policy
                       .AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader());
            }
            ServerAuthenticatonInfo serverAuthenticatonInfo = ((IHttpServerConnector)Connector).ServerAuthenticatonInfo;

            if (serverAuthenticatonInfo.ServerAuthenticatonType == ServerAuthenticatonType.JwtToken)
            {
                app.UseAuthentication();
            }
            app.UseRouting();
            app.UseEndpoints(e =>
            {
                try
                {
                    if (Configuration.GetSection("Management").GetChildren().Any())
                    {
                        e.Map<MetricsEndpoint>();
                        e.MapAllActuators(null);
                    }
                  
                    if (Configuration.GetSection("Spring:boot:admin:client").GetValue<bool>("enabled") && Configuration.GetSection("Spring").GetChildren().Any() && Configuration.GetSection("Management").GetChildren().Any())
                    {
                        app.RegisterWithSpringBootAdmin(Configuration);
                    }

                    e.MapGet("/swagger-resources", async context => {

                        context.Response.StatusCode = 200;
                        context.Response.ContentType = "application/json";
                        await context.Response.WriteAsync(GetSwaggerResources(Assembly.GetEntryAssembly().GetName().Name));
                    });

                    e.MapGet("/v3/api-docs/swagger-config", async context => {

                        context.Response.StatusCode = 200;
                        context.Response.ContentType = "application/json";
                        await context.Response.WriteAsync(System.Text.Json.JsonSerializer.Serialize(GetSwaggerConfig(Assembly.GetEntryAssembly().GetName().Name)));
                    });

                    e.MapGet("/swagger-gateway", async context => {

                        var response = GetSwaggerJsonV3(app.ApplicationServices);

                        context.Response.StatusCode = 200;
                        context.Response.ContentType = "application/json";
                        await context.Response.WriteAsync(response);
                    });

                    e.MapControllers();

                    }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "{unique} | Could not connect to sentinel | {additionalMessage}", LoggerUnique.CorfCore, $"Error Message : {ex.Message}");
                }
            });
            app.UseStaticFiles();
            if (Configuration.GetSection("MetricExporter").GetChildren().Any())
            {
                app.UseMetricServer((!string.IsNullOrEmpty(Configuration.GetSection("MetricExporter")["MetricUrl"]) ? Configuration.GetSection("MetricExporter")["MetricUrl"] : string.Empty));
                app.UseHttpMetrics(options =>
                {
                    options.AddCustomLabel("host", context => context.Request.Host.Host);
                });
                CreateMetricCollector();
            }

            // app.UseSwagger();

            app.UseSwagger();

            app.UseSwaggerUI(x => x.SwaggerEndpoint("/swagger/CorfSwagger/swagger.json", Assembly.GetEntryAssembly().GetName().Name));
            
        }
        private static IDisposable CreateMetricCollector()
        {

            var builder = DotNetRuntimeStatsBuilder.Default();

            builder = DotNetRuntimeStatsBuilder.Customize()
                .WithContentionStats(CaptureLevel.Informational)
                .WithGcStats(CaptureLevel.Verbose)
                .WithThreadPoolStats(CaptureLevel.Informational)
                .WithExceptionStats(CaptureLevel.Errors)
                .WithJitStats(CaptureLevel.Verbose);

            builder.WithDebuggingMetrics(true);

            return builder
                .StartCollecting();
        }
        public static string GetSwaggerJsonV3(IServiceProvider serviceProvider)
        {
            try
            {
                ISwaggerProvider sw = serviceProvider.GetRequiredService<ISwaggerProvider>();
                OpenApiDocument doc = sw.GetSwagger("CorfSwagger", null, "/");
                string swaggerFile = doc.SerializeAsJson(Microsoft.OpenApi.OpenApiSpecVersion.OpenApi3_0);

                var obj = System.Text.Json.JsonSerializer.Deserialize<JsonObject>(swaggerFile);
                var response = System.Text.Json.JsonSerializer.Serialize(obj, new JsonSerializerOptions { Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
                return response.ToString();
            }
            catch (Exception ex)
            {

                throw;
            }
          
           
        }

        public static JsonObject GetSwaggerConfig(string applicationName)
        {
            return new JsonObject
            {
                ["configUrl"] = $"/v3/api-docs/swagger-config",
                ["oauth2RedirectUrl"] = string.Empty,
                ["urls"] = new JsonArray
                {
                    new JsonObject
                    {
                        ["url"] = "/swagger-gateway",
                        ["name"] = applicationName
                    }
                },
                ["validatorUrl"] = string.Empty
            };
        }

        public static string GetSwaggerResources(string applicationName)
        {
            var resource = new dynamic[1];

            resource[0] = new ExpandoObject();
            resource[0].name = applicationName;
            resource[0].url = "/swagger/CorfSwagger/swagger.json";
            resource[0].swaggerVersion = "2.0";
            resource[0].location = "/swagger/CorfSwagger/swagger.json";

            return JsonSerializer.Serialize(resource);
        }

        #endregion

        public async Task<bool> SendAsync(InternalMessage message)
        {
            if (_events.ContainsKey(message.Unique))
            {
                _events[message.Unique].Response = message;

                if (message.AdditionalInfo != null)
                {
                    message.AdditionalInfo.ExtensionData = _events[message.Unique].Request.AdditionalInfo.ExtensionData;
                }
                message.OriginalMessage = _events[message.Unique].Data;

                _events[message.Unique].ResetEvent?.Set();

                return await Task.FromResult(true);
            }
            else
            {
                _logger.LogWarning("{unique} | Message could not send to destination. Message unique was not in the event dictionary. Possible reason is timeout!. | {additionalMessage}", message.Unique, $"Buffer : {message.InnerMessage}");

                return await Task.FromResult(false);
            }
        }

        public bool Send(InternalMessage message)
        {
            return SendAsync(message).Result;
        }

        public void GetReady()
        {
            _logger.LogInformation("{unique} | Http server initialized. | {additionalMessage}", LoggerUnique.CorfCore, $"ChannelDescription : {Connector.ChannelDescription}");
        }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
        }
    }
}

