﻿using corf.Configuration;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public class PathInfo : IPathInfo
    {
        [FlowDesign(Display = false)]
        public IServiceProvider ServiceProvider { get; set; }

        [JsonConstructor]
        public PathInfo()
        {
        }

        [FlowDesign(DefaultValue = "/api/v1/service")]
        public string Uri { get; set; }

        public string Description { get; set; }

        public string Tags { get; set; }

        public string Authorization { get; set; }

        [JsonIgnore]
        public bool AllowGet { get { return Get != null; } }
        [JsonIgnore]
        public bool AllowPost { get { return Post != null; } }
        [JsonIgnore]
        public bool AllowPut { get { return Put != null; } }
        [JsonIgnore]
        public bool AllowDelete { get { return Delete != null; } }

        private PathVerb _get;
        public PathVerb Get
        {
            get
            {
                if (_get != null)
                {
                    _get.PathInfo = this;
                    _get.OperationType = OperationType.Get;
                }
                return _get;
            }
            set
            {
                _get = value;
            }
        }

        private PathVerb _post;
        public PathVerb Post
        {
            get
            {
                if (_post != null)
                {
                    _post.PathInfo = this;
                    _post.OperationType = OperationType.Post;
                }

                return _post;
            }
            set
            {
                _post = value;
            }
        }

        private PathVerb _put;
        public PathVerb Put
        {
            get
            {
                if (_put != null)
                {
                    _put.PathInfo = this;
                    _put.OperationType = OperationType.Put;
                }
                return _put;
            }
            set
            {
                _put = value;
            }
        }

        private PathVerb _delete;
        public PathVerb Delete
        {
            get
            {
                if (_delete != null)
                {
                    _delete.PathInfo = this;
                    _delete.OperationType = OperationType.Delete;
                }
                return _delete;
            }
            set
            {
                _delete = value;
            }
        }

        private List<PathVerb> _verbs;

        [JsonIgnore]
        [FlowDesign(Display = false)]
        public List<PathVerb> Verbs
        {
            get
            {
                if (_verbs == null)
                {
                    _verbs = new List<PathVerb>();

                    if (AllowGet) { _verbs.Add(Get); }
                    if (AllowPost) { _verbs.Add(Post); }
                    if (AllowPut) { _verbs.Add(Put); }
                    if (AllowDelete) { _verbs.Add(Delete); }
                }

                return _verbs;
            }
        }

        public PathInfo Clone()
        {
            return (PathInfo)this.MemberwiseClone();
        }
    }
}