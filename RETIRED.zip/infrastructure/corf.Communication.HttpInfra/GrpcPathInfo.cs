﻿using corf.Configuration;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public class GrpcPathInfo : IPathInfo
    {
        [FlowDesign(Display = false)]
        public IServiceProvider ServiceProvider { get; set; }

        [JsonConstructor]
        public GrpcPathInfo()
        {
        }
        [JsonIgnore]
        public bool AllowPost { get { return Post != null; } }

        [JsonProperty("uri")]
        public string Uri { get; set; }

        private PathVerb _post;
        public PathVerb Post
        {
            get
            {
                if (_post != null)
                {
                    _post.PathInfo = this;
                    _post.OperationType = OperationType.Post;
                }

                return _post;
            }
            set
            {
                _post = value;
            }
        }
        public GrpcPathInfo Clone()
        {
            return (GrpcPathInfo)this.MemberwiseClone();
        }

        public Cacher Cacher { get; set; }
    }
}
