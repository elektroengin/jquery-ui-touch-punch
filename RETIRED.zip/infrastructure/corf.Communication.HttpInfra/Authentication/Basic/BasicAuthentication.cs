﻿using corf.Core.Http;

namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal class BasicAuthentication : ServerAuthenticaton
    {
        public bool UseDefaultCredentials { get; set; }

        public string DefaultUser { get; set; } = string.Empty;

        public string DefaultPassword { get; set; } = string.Empty;
    }
}
