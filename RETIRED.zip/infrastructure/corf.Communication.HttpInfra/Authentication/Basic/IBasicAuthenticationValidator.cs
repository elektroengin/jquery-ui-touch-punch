﻿using System.Threading.Tasks;

namespace corf.Communication.HttpInfra.Authentication.Basic
{
    public interface IBasicAuthenticationValidator
    {
        Task<bool> Validate(string username, string password);
    }
}
