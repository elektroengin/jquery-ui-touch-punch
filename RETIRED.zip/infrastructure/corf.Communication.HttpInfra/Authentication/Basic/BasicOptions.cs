﻿using Microsoft.AspNetCore.Authentication;

namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal class BasicOptions : AuthenticationSchemeOptions
    {
    }
}
