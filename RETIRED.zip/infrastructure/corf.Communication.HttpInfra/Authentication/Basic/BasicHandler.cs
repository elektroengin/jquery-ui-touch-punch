﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text;
using System.Text.Encodings.Web;

namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal class BasicHandler : AuthenticationHandler<BasicOptions>
    {
        private readonly IBasicAuthenticationValidator _basicAuthenticationValidator;

        public BasicHandler(IOptionsMonitor<BasicOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock, IBasicAuthenticationValidator basicAuthenticationValidator) : base(options, logger, encoder, clock)
        {
            _basicAuthenticationValidator = basicAuthenticationValidator;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var header = Request.Headers["Authorization"].ToString();

            if (string.IsNullOrEmpty(header) || !header.StartsWith(BasicDefaults.AuthenticationScheme))
            {
                return AuthenticateResult.Fail("No credentials.");
            }

            var encodedCredentials = header.Replace(BasicDefaults.AuthenticationScheme, string.Empty).Trim();

            if (string.IsNullOrEmpty(encodedCredentials))
            {
                return AuthenticateResult.Fail("No credentials.");
            }

            try
            {
                var decodedCredentials = Encoding.UTF8.GetString(Convert.FromBase64String(encodedCredentials));

                var splitCredentials = decodedCredentials.Split(':');

                if (splitCredentials.Length != 2)
                {
                    return AuthenticateResult.Fail("Wrong format for Basic Auth");
                }

                var username = splitCredentials[0];
                var password = splitCredentials[1];

                var result = await _basicAuthenticationValidator.Validate(username, password);

                return result ?
                    AuthenticateResult.Success(new AuthenticationTicket(Context.User, BasicDefaults.AuthenticationScheme)) :
                    AuthenticateResult.Fail("Username or password is wrong.");
            }
            catch (Exception e)
            {
                return AuthenticateResult.Fail(e);
            }

        }
    }
}
