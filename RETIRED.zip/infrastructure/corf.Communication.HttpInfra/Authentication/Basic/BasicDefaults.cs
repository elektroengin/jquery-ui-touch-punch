﻿namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal class BasicDefaults
    {
        public const string AuthenticationScheme = "Basic";
    }
}
