﻿namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal class DefaultBasicAuthenticationValidator : IBasicAuthenticationValidator
    {
        private readonly string _expectedUsername;
        private readonly string _expectedPassword;

        public DefaultBasicAuthenticationValidator(string expectedUsername, string expectedPassword)
        {
            _expectedUsername = expectedUsername;
            _expectedPassword = expectedPassword;
        }

        public Task<bool> Validate(string username, string password)
        {
            if (string.IsNullOrEmpty(_expectedUsername) || string.IsNullOrEmpty(_expectedPassword))
            {
                return Task.FromResult(false);
            }

            return Task.FromResult(username == _expectedUsername && password == _expectedPassword);
        }
    }
}
