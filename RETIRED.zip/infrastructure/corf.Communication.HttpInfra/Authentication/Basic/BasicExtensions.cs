﻿using Microsoft.AspNetCore.Authentication;

namespace corf.Communication.HttpInfra.Authentication.Basic
{
    internal static class BasicExtensions
    {
        public static AuthenticationBuilder AddBasic(this AuthenticationBuilder builder) =>
            builder.AddScheme<BasicOptions,BasicHandler>(BasicDefaults.AuthenticationScheme, BasicDefaults.AuthenticationScheme, _ => {});

    }
}
