﻿using corf.Core.Http;

namespace corf.Communication.HttpInfra.Authentication
{
    class JwtAuthenticatiton : ServerAuthenticaton
    {
        public string EncryptionKey { get; set; } = string.Empty;
    }
}
