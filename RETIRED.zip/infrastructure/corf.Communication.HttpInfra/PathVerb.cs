﻿using corf.Configuration;
using corf.Core.Commands;
using corf.Core.Http;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public class PathVerb
    {
        [JsonConstructor]
        public PathVerb()
        {
        }

        [JsonIgnore]
        public IBusinessCommand Executer { get { return GetCommand(); } }

        [FlowDesign(IsExecuterDefinition = true)]

        [JsonProperty("executername")]
        public string ExecuterName { get; set; }

        [JsonProperty("executerspecificdestination")]
        public string ExecuterSpecificDestination { get; set; }

        private IBusinessCommand GetCommand()
        {
            return string.IsNullOrWhiteSpace(ExecuterAssembly) == false ? (BusinessCommand)PathInfo.ServiceProvider.GetService(Type.GetType(ExecuterAssembly)) : null;
        }

        public string Description { get; set; }

        public string Summary { get; set; }

        [FlowDesign(Display = false)]
        [JsonIgnore]

        public IPathInfo PathInfo { get; set; }

        [JsonIgnore]
        [FlowDesign(Display = false)]
        public string ExecuterAssembly { get; set; }

        [FlowDesign(Display = false)]
        [JsonIgnore]
        public OperationType OperationType { get; set; }

        [FlowDesign(Display = false)]
        public Dictionary<string, string> Parameters { get; set; }

        [JsonIgnore]
        [FlowDesign(Display = false)]
        public Type RequestPayloadType { get; set; }

        [JsonIgnore]
        [FlowDesign(Display = false)]
        public Type ResponsePayloadType { get; set; }


        public Cacher Cacher { get; set; }

        [JsonIgnore]
        [FlowDesign(Display = false)]
        public IHttpServerConnector Connector { get;  set; }

        public PathVerb Clone()
        {
            return (PathVerb)this.MemberwiseClone();
        }
    }
}