﻿using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Http;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public abstract class HttpClientConnector : DualConnector
    {
        
        private CredentialInfo _credentialsDeserialized;
        public CredentialInfo CredentialsDeserialized
        {
            get
            {
                if (!string.IsNullOrEmpty(Credentials))
                {
                    if (_credentialsDeserialized == null)
                    {
                        _credentialsDeserialized = JsonConvert.DeserializeObject<CredentialInfo>(Credentials);
                    }
                }
                return _credentialsDeserialized;
            }
        }

        public string UrlManagementServiceAssembly { get; set; }
        public string UrlManagementQueueType { get; set; }

        private IUrlManagementService _urlManagementService;
        private bool _urlManagementServiceAssigned;
        public bool UrlManagementAssigned
        {
            get
            {
                return UrlManagementService != null;
            }
        }

        public IUrlManagementService UrlManagementService
        {
            get
            {
                if (_urlManagementService == null && !_urlManagementServiceAssigned && !string.IsNullOrEmpty(UrlManagementServiceAssembly) && !string.IsNullOrEmpty(UrlManagementQueueType))
                {
                    _urlManagementService = (IUrlManagementService)ServiceProvider.GetService(Type.GetType(UrlManagementServiceAssembly));

                    if (_urlManagementService != null)
                        _urlManagementServiceAssigned = true;

                }

                return _urlManagementService;
            }
        }

        [FlowDesign(DefaultValue = "http://localhost", EnvironmentBasedVariable = true, Description = "Base address of service")]
        public string BaseAddress { get; set; }

        private string _path = "/v1/service";

        private ServiceSettings _settings;
        protected HttpClientConnector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, provider, requestScopeManager)
        {
            _settings = settings.Value;
        }

        [FlowDesign(DefaultValue = "/v1/service", Description = "Path of service.")]
        public string Path
        {
            get
            {
                return _path;
            }
            set
            {
                _path = value.Replace("#ModuleId#", _settings != null && _settings.MachineSpecificInfo != null ? _settings.MachineSpecificInfo.AdditionalQueueNumber : "");
            }
        }

        [FlowDesign(Description = "Credentials as json string. ex : \"{'userName':'mqm', 'password':'12345'}\"")]
        public string Credentials { get; set; }

        [FlowDesign(Description = "AuthenticationType : N for No auth, B for Basic", DefaultValue = "N")]
        public string AuthType { get; set; }
    }
}
