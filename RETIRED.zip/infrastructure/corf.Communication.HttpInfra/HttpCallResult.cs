﻿using System.Net.Http;

namespace corf.Communication.HttpInfra
{
    public class HttpCallResult<TResponse>
    {
        public TResponse Response { get; set; }
        public HttpResponseMessage Result { get; set; }
    }
}