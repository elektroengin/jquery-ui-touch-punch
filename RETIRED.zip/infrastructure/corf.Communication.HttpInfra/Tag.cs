﻿using corf.Configuration;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;


namespace corf.Communication.HttpInfra
{
    public class Tag
    {
        public string Name { get; set; }
        public string Description { get; set; }
        [JsonConstructor]
        public Tag()
        {

        }
    }
}
