﻿using corf.Communication.HttpInfra.Authentication;
using corf.Communication.HttpInfra.Authentication.Basic;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Http;
using corf.Core.Infrastructure;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public abstract class HttpServerConnector<TCommunicator, TPath> : DualConnector, IHttpServerConnector where TCommunicator : ICommunicator
    {
        private TCommunicator _communicator;


        public HttpServerConnector(ILogger logger, TCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public TPath[] Paths { get; set; }

        public Tag[] Tags { get; set; }

        public override bool EndlessReceive { get { return false; } }

        public string AuthenticatonInfo { get; set; }

        public HttpRootAddress RootAddress { get; set; }

        public string ResponseHeaders { get; set; }


        [FlowDesign(DefaultValue = true, Description = "If async routing will be used and need to auto time out set 'true' otherwise set 'fase'. Default value is 'true'")]
        public bool UseAsyncRouting { get; set; } = true;

        public override bool AllowAsyncSteps { get; set; } = false;
        public async Task FireAsyncMessageReceived(MessageReceivedEventArgs messageReceivedEventArgs)
        {
            if (Route != null)
            {
               await Route.OperateNextStep(this, messageReceivedEventArgs, AllowAsyncSteps);
            }
        }
        public override string ChannelDescription
        {
            get { return RootAddress.Host; }
        }

        public override ICommunicator CommunicatorInstance
        {
            get
            {

                return _communicator;
            }
        }

        [FlowDesign(Display = false)]
        public ServerAuthenticatonInfo ServerAuthenticatonInfo { get; set; } = new ServerAuthenticatonInfo();

        [FlowDesign(Display = false)]
        public DateTime Incoming { get; set; }
        public bool AllowAnyCors { get; set; }

        public override void Initialize()
        {
            base.Initialize();
                                                                                                                                                        

            if (string.IsNullOrWhiteSpace(AuthenticatonInfo) == false)
            {
                ServerAuthenticatonInfo = JsonConvert.DeserializeObject<ServerAuthenticatonInfo>(AuthenticatonInfo);

                switch (ServerAuthenticatonInfo.ServerAuthenticatonType)
                {
                    case ServerAuthenticatonType.JwtToken:
                        ServerAuthenticatonInfo.ServerAuthenticaton = JsonConvert.DeserializeObject<JwtAuthenticatiton>(ServerAuthenticatonInfo.AuthProperties);
                        break;
                    case ServerAuthenticatonType.BAuth:
                        ServerAuthenticatonInfo.ServerAuthenticaton = JsonConvert.DeserializeObject<BasicAuthentication>(ServerAuthenticatonInfo.AuthProperties);
                        break;
                    case ServerAuthenticatonType.None:
                    case ServerAuthenticatonType.OAuth:
                    default:
                        break;
                }
            }

        }
    }
}
