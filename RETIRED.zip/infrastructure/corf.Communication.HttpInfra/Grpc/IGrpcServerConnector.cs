﻿namespace corf.Communication.HttpInfra.Grpc
{
    public  interface IGrpcServerConnector
    {
         GrpcPathInfo[] Paths { get; set; }
    }
}