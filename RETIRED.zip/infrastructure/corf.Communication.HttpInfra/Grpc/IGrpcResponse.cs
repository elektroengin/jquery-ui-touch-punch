﻿using System.Net;

namespace corf.Communication.HttpInfra.Grpc
{
    public interface IGrpcResponse
    {
        public HttpStatusCode StatusCode { get; set; }
        public string ExceptionMessage { get; set; }
    }
}