﻿using System.Runtime.Serialization;

namespace corf.Communication.HttpInfra
{
    public class ResponseErrorMessage
    {
        public ResponseErrorMessage()
        {
        }

        [DataMember(Name = "MessageCode")]
        public string MessageCode { get; set; }
    }
}