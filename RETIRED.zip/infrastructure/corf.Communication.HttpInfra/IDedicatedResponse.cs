﻿using corf.Core.Routing;

namespace corf.Communication.HttpInfra
{
    public interface IDedicatedResponse<T, Y>
    {
        Task<T> GetDedicatedResponse(Y request);

        IRoute Root { get; set; }
    }
}