﻿namespace corf.Communication
{
    public enum HttpServiceType 
    {
        gRRPC = 1,
        Rest = 2
    }
}