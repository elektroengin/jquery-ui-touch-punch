﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.HttpInfra.Rest
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class PathParametersAttribute : Attribute
    {

        public PathParametersAttribute(Type type)
        {
            Type = type;
        }
        public Type Type { get; private set; }

    }
}
