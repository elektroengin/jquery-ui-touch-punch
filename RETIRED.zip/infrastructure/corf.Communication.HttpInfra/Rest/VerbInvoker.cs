﻿using corf.Configuration;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Text;

namespace corf.Communication.HttpInfra.Rest
{
    public class VerbInvoker<TRequest, TResponse> : IVerbInvoker<TRequest, TResponse>
    {
        internal HttpClient _client = null;
        internal ILogger _logger;
        const string traceheader = "traceparent";
        const string version = "00";
        HttpEndPointInfo _httpEndPointInfo;
        public VerbInvoker(HttpClient client, ILogger logger, HttpEndPointInfo httpEndPointInfo)
        {
            _httpEndPointInfo = httpEndPointInfo;
            _client = client;
            _logger = logger;
        }

        public string Verb { get; set; } = "post";

        public async Task<HttpCallResult<TResponse>> Invoke(TRequest request, string uri, Dictionary<string,object> headers = null, KeyValueCollection requestParameters = null)
        {
            var requestBody = string.Empty;
            var method = new HttpMethod(Verb);

            if (request is string s)
            {
                requestBody = s;
            }
            else if (method == HttpMethod.Get || method == HttpMethod.Delete || method == HttpMethod.Head)
            {
                if (request != null)
                {
                    var queries = request.GetType().GetProperties()
                        .Where(p => p.PropertyType.IsValueType
                            ? !p.GetValue(request).Equals(Activator.CreateInstance(p.PropertyType))
                            : p.GetValue(request) != null)
                        .Select(p =>
                            new KeyValuePair<string, string>(p.Name, p.GetValue(request)?.ToString()));

                    uri = QueryHelpers.AddQueryString(uri, queries);
                }
            }
            else
            {
                requestBody = JsonConvert.SerializeObject(request, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            }

            if (requestParameters != null)
            {
                uri = QueryHelpers.AddQueryString(uri, requestParameters);
            }

            bool isForm = _httpEndPointInfo.Type == "application/x-www-form-urlencoded" ? true : false;

            IDictionary<string, string> formValues = null;

            if (isForm)
            {
                formValues = GetValues(request);
            }
            HttpRequestMessage message = new HttpRequestMessage()
            {
                Content = !isForm ? new StringContent(requestBody, Encoding.UTF8, "application/json") : new FormUrlEncodedContent(formValues),
                RequestUri = new Uri(uri),
                Method = method
            };

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    if (message.Headers.Contains(header.Key) == false)
                    {
                        if (header.Value != null)
                        { 
                            if (header.Value.GetType().Name == "String[]")
                            {
                                message.Headers.Add(header.Key, (IEnumerable<string>)header.Value);
                            }
                            else
                            {
                                message.Headers.Add(header.Key, GetHeaderValue(header.Value));
                            }
                        }
                    }
                }
            }
            if (Activity.Current != null)
                message.Headers.TryAddWithoutValidation(traceheader, $"{version}-{Activity.Current.TraceId.ToHexString()}-{Activity.Current.SpanId.ToHexString()}-0{(int)Activity.Current.ActivityTraceFlags}");

            var result = await CallInternal(message);

            var stream = await result.Content.ReadAsStringAsync();

            _logger.LogDebug("{unique} | Service Response | {additionalMessage}", LoggerUnique.CorfCore, $"Result:{stream}");

            if (typeof(TResponse) == typeof(string))
            {
                return new HttpCallResult<TResponse> { Response = ((TResponse)(object)stream), Result = result };
            }
            else
            {
                return new HttpCallResult<TResponse> { Response = JsonConvert.DeserializeObject<TResponse>(stream), Result = result };
            }
        }
        private string GetHeaderValue(object headerValue)
        {
            if (headerValue != null && headerValue is string[])
                return ((string[])headerValue)[0].ToString();
            return headerValue.ToString();
        }
        public IDictionary<string, string> GetValues(object obj)
        {
            return obj
                    .GetType()
                    .GetProperties()
                    .ToDictionary(p => p.Name, p => p.GetValue(obj).ToString());
        }

        public async Task<HttpResponseMessage> CallInternal(HttpRequestMessage message)
        {
            _logger.LogTrace("{unique} | Message is executing | {additionalMessage}", LoggerUnique.CorfCore, $"{message.Method.Method} invoker. Send started at : {DateTime.Now.ToString("HH.mm.ss.ffffff")}");

            HttpResponseMessage result = await _client.SendAsync(message, HttpCompletionOption.ResponseContentRead);

            _logger.LogTrace("{unique} | Message is executed | {additionalMessage}", LoggerUnique.CorfCore, $"{message.Method.Method} invoker. Send finished at : {DateTime.Now.ToString("HH.mm.ss.ffffff")}");

            return result;
        }
    }
}
