﻿using corf.Core.Messaging;

namespace corf.Communication.HttpInfra.Rest
{
    public interface IVerbInvoker<TRequest, TResponse>
    {
        string Verb { get; set; }
        Task<HttpCallResult<TResponse>> Invoke(TRequest request, string uri, Dictionary<string,object> headers = null, KeyValueCollection requestParameters = null);
    }
}