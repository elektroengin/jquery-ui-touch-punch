﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.HttpInfra.Rest
{
    public class DynamicHeadersConfiguration
    {
        [JsonConstructor]
        public DynamicHeadersConfiguration()
        {

        }
        public bool PassThroughAllHeaders { get; set; }
        public string CustomHeaders { get; set; }
    }

}
