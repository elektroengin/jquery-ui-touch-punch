﻿namespace corf.Communication.HttpInfra.Rest
{
    public interface IRestServerConnector
    {
        PathInfo[] Paths { get; set; }

        Tag[] Tags { get; set; }
    }
}