﻿using System;

namespace corf.Communication.HttpInfra.Rest
{

    /// <summary>
    /// This attribute specifies request model in swagger usage.
    /// </summary>
    public class RequestPayloadAttribute : Attribute
    {
        public RequestPayloadAttribute(Type t)
        {
            Type = t;
        }

        public Type Type { get; private set; }
    }
}