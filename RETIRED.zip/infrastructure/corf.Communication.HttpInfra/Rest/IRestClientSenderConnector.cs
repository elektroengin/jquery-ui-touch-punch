﻿namespace corf.Communication.HttpInfra.Rest
{
    public interface IRestClientSenderConnector
    {
        public DynamicHeadersConfiguration DynamicHeadersConfiguration { get; set; }

        
    }
}
