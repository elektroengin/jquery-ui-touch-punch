﻿using Grpc.Core;
using System.Net;

namespace corf.Communication.HttpInfra.Rest
{
    /// <summary>
    /// This attribute specifies response model in swagger usage.
    /// </summary>
    /// 

    [AttributeUsage(AttributeTargets.Class,
                AllowMultiple = true)]
    public class ResponsePayloadAttribute : Attribute
    {
        public ResponsePayloadAttribute(Type t)
        {
            Type = t;
        }
        public ResponsePayloadAttribute(Type t, HttpStatusCode statusCode, string description)
        {
            Type = t;
            StatusCode = statusCode;
            Description = description;
        }

        public Type Type { get; private set; }

        public HttpStatusCode StatusCode { get; private set; }
        public string Description { get; private set; }
    }
}