﻿namespace corf.Communication.HttpInfra
{
    public interface ICacher
    {
        double AbsoluteExpirationOnMinutes { get; set; }
        double SlidingExpirationOnMinutes { get; set; }
        public string Keys { get; set; }
    }
}