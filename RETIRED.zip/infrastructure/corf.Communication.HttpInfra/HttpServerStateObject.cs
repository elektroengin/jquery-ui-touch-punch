﻿using corf.Core.Messaging;
using Microsoft.VisualStudio.Threading;

namespace corf.Communication.HttpInfra
{
    public class HttpServerStateObject
    {
        public InternalMessage Response { get; set; }
        public AsyncManualResetEvent? ResetEvent { get; set; }

        public InternalMessage Request { get; set; }
        public string Data { get; set; }
    }
}
