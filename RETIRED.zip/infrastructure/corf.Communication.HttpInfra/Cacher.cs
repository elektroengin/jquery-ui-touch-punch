﻿using Newtonsoft.Json;

namespace corf.Communication.HttpInfra
{
    public class Cacher : ICacher
    {
        [JsonConstructor]
        public Cacher()
        {
        }
        public double AbsoluteExpirationOnMinutes { get; set; } = 14;
        public double SlidingExpirationOnMinutes { get; set; } = 14;
        public string Keys { get; set; }

        private string[] _keysArray;
        [JsonIgnore]
        public string[] KeysArray
        {
            get
            {
                if (_keysArray == null)
                {
                    _keysArray = Keys.Split(',');
                }
                return _keysArray;
            }
        }
        public string AppDelimiter { get; set; }
    }
}