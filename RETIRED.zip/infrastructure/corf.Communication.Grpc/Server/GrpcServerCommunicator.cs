﻿using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Threading.Tasks;
using System.IO;
using corf.Communication.HttpInfra;
using corf.Communication.Grpc.Server;

namespace corf.Communication.Grpc.Client
{
    public class GrpcServerCommunicator : HttpServerCommunicator, IGrpcServerCommunicator
    {
        public GrpcServerCommunicator(ILogger<GrpcServerCommunicator> logger, IExternalDependenyProvider hostContainer, IRequestScopeManager requestScopeManager, IServiceProvider globalServiceProvider) : base(logger, hostContainer, requestScopeManager, globalServiceProvider)
        {
        }

        public override void ConfigureServicesDelegate(IServiceCollection services)
        {
            base.ConfigureServicesDelegate(services);
            services.AddGrpc();
            services.AddSingleton<CorfDynamicService>();
        }

        public override void ConfigureListenOptions(ListenOptions listenOptions)
        {
            listenOptions.Protocols = HttpProtocols.Http2;
        }

        public override void CofigureDelegate(IApplicationBuilder app)
        {

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                var dynamicService =  (CorfDynamicService)app.ApplicationServices.GetService(typeof(CorfDynamicService));

                dynamicService.Communicator = this;
                dynamicService.Connector = (GrpcServerConnector)Connector;

                endpoints.MapGrpcService<CorfDynamicService>();

                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Communication with gRPC endpoints must be made through a gRPC client. To learn how to create a client, visit: https://go.microsoft.com/fwlink/?linkid=2086909");
                });
            }).Build();
        }

    }
}
