﻿using corf.Core.Infrastructure;

namespace corf.Communication.Grpc.Client
{
    public interface IGrpcServerCommunicator : IMessageSender
    {
    }
}