﻿using corf.Caching;
using corf.Communication.Grpc.Client;
using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Grpc;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Http;
using corf.Core.Messaging;
using Grpc.Core;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.Threading;
using Newtonsoft.Json;
using System.Net;

namespace corf.Communication.Grpc.Server
{
    public class CorfDynamicService : CorfDynamic.CorfDynamicBase
    {
        private ICacheService _cacheService;
        private readonly ILogger<CorfDynamicService> _logger;
        public Guid Id { get; private set; }
        private IServiceProvider _serviceProvider;
        private IRequestScopeManager _requestScopeManager;
        public CorfDynamicService(ILogger<CorfDynamicService> logger, IServiceProvider serviceProvider, IRequestScopeManager requestScopeManager, ICacheService cacheService)
        {
            Id = Guid.NewGuid();
            _logger = logger;
            _serviceProvider = serviceProvider;
            _requestScopeManager = requestScopeManager;
            _cacheService = cacheService;
        }

        public GrpcServerConnector Connector { get; internal set; }
        public GrpcServerCommunicator Communicator { get; internal set; }

        public override async Task<DynamicPayload> Process(DynamicPayload request, ServerCallContext context)
        {
            var internalMessage = new InternalMessage
            {
                InnerMessage = request.InnerMessage,
                OriginalMessage = request.OriginalMessage,
                ReceiverChannelId = request.ReceiverChannelId,
                ReturnToReceiverChannel = request.ReturnToReceiverChannel,
                Unique = string.IsNullOrWhiteSpace(request.Unique) ? Guid.NewGuid().ToString().Replace("-", "") : request.Unique,
                RemoteIpAddress = request.RemoteIpAddress,
                AdditionalInfo = request.AdditionalInfo != null ? request.AdditionalInfo.ToMessageAdditionalInfo() : null
            };

            request.Path = request.Path.StartsWith('/') ? request.Path.Remove(0, 1) : request.Path;

            if (Connector._pathDictionary.ContainsKey(request.Path))
            {
                string cacheKey = "";

                var contextPathInfo = Connector._pathDictionary[request.Path].Clone();

                contextPathInfo.ServiceProvider = _serviceProvider.CreateScope().ServiceProvider;

                if (((IHttpServerConnector)Connector).ServerAuthenticatonInfo.ServerAuthenticatonType != ServerAuthenticatonType.None && (contextPathInfo.Post.Executer == null || contextPathInfo.Post.Executer.Authorized))
                {
                    var authenticateResult = await context.GetHttpContext().AuthenticateAsync();

                    if (authenticateResult.Succeeded == false)
                    {
                        _logger.LogWarning(authenticateResult.Failure?.Message);
                        const string detail = "You are not authorized. Please contact your system administrator.";

                        context.Status = new Status(StatusCode.Unauthenticated, detail);

                        return new DynamicPayload
                        {
                            Unique = request.Unique,
                            Failed = true,
                            ExceptionMessage = detail,
                            InnerMessage = "",
                            StatusCode = Convert.ToInt32(HttpStatusCode.Unauthorized),
                            AdditionalInfo = request.AdditionalInfo
                        };
                    }
                }


                if (contextPathInfo.Cacher != null && !string.IsNullOrWhiteSpace(internalMessage.InnerMessage))
                {
                    try
                    {
                        _logger.LogDebug("{unique} | Cache check for - gRPC#", internalMessage.Unique);

                        cacheKey = $"{contextPathInfo.Cacher.AppDelimiter}_{internalMessage.InnerMessage.Trim().Replace(" ", "").Replace("\"", "")}";

                        var result = _cacheService.Get<string>(cacheKey);

                        if (!request.Failed && !string.IsNullOrWhiteSpace(result))
                        {

                            var resultMessage = new DynamicPayload
                            {
                                Path = request.Path,
                                InnerMessage = result,
                                OriginalMessage = !string.IsNullOrWhiteSpace(internalMessage.InnerMessage) ? internalMessage.InnerMessage : "",
                                ReceiverChannelId = "",
                                RemoteIpAddress = internalMessage.RemoteIpAddress,
                                ReturnToReceiverChannel = false,
                                Unique = internalMessage.Unique,
                                StatusCode = Convert.ToInt32(HttpStatusCode.OK),
                                AdditionalInfo = null
                            };

                            var jsonString = JsonConvert.SerializeObject(resultMessage);
                            _logger.LogInformation("{unique} | Response received from cache with key. | {additionalMessage}", internalMessage.Unique, $"Cache key :{cacheKey}, Response data {jsonString}");

                            return await Task.FromResult(resultMessage);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "{unique} | Error on cache. | {additionalMessage}", internalMessage.Unique, $"Url :{contextPathInfo.Uri}, AppDelimiter :{contextPathInfo.Cacher.AppDelimiter}, ErrorMessage:{ex.Message}");
                    }
                }

                try
                {

                    HttpServerStateObject stateObject = new HttpServerStateObject { Request = internalMessage, Data = internalMessage.InnerMessage };

                    _requestScopeManager.Add(internalMessage, contextPathInfo.ServiceProvider);

                    bool addedIntoDictionary = Communicator._events.TryAdd(internalMessage.Unique, stateObject);

                    _logger.LogDebug("{unique} | #GRPC# Message inserted into dictionary.", internalMessage.Unique);

                    if (addedIntoDictionary)
                    {
                        if (Connector.UseAsyncRouting == false)
                        {
                            await Connector.FireAsyncMessageReceived(new MessageReceivedEventArgs(internalMessage) { UseSpecificExecuter = true, Executer = contextPathInfo.Post.Executer, Destination = contextPathInfo.Post.ExecuterSpecificDestination });
                        }
                        else
                        {
                            AsyncManualResetEvent completed = new AsyncManualResetEvent(false);

                            stateObject.ResetEvent = completed;

                            Connector.FireAsyncMessageReceived(new MessageReceivedEventArgs(internalMessage) { UseSpecificExecuter = true, Executer = contextPathInfo.Post.Executer, Destination = contextPathInfo.Post.ExecuterSpecificDestination });

                            CancellationTokenSource timeoutCancellation = new CancellationTokenSource(Connector.TimeOut);

                            try
                            {
                                await completed.WaitAsync(timeoutCancellation.Token);
                            }
                            catch (OperationCanceledException)
                            {

                                return new DynamicPayload
                                {
                                    Unique = request.Unique,
                                    Failed = true,
                                    ExceptionMessage = "#GRPC# RequestTimeout !",
                                    InnerMessage = "",
                                    StatusCode = Convert.ToInt32(HttpStatusCode.RequestTimeout)
                                };
                            }
                        }
                        InternalMessage outgoing = Communicator._events[internalMessage.Unique].Response;

                        var resultMessage = new DynamicPayload
                        {
                            Path = request.Path,
                            InnerMessage = outgoing.InnerMessage,
                            OriginalMessage = !string.IsNullOrWhiteSpace(outgoing.OriginalMessage) ? outgoing.OriginalMessage : "",
                            ReceiverChannelId = !string.IsNullOrWhiteSpace(outgoing.ReceiverChannelId) ? outgoing.ReceiverChannelId : "",
                            RemoteIpAddress = request.RemoteIpAddress,
                            ReturnToReceiverChannel = outgoing.ReturnToReceiverChannel,
                            Unique = request.Unique,
                            StatusCode = Convert.ToInt32(HttpStatusCode.OK),
                            AdditionalInfo = outgoing.AdditionalInfo != null && outgoing.AdditionalInfo.ModuleJourney != null ? outgoing.AdditionalInfo.ToAdditionalInfo() : null
                        };


                        if (contextPathInfo.Cacher != null && !string.IsNullOrWhiteSpace(cacheKey) && outgoing.State != MessageState.Failed && outgoing.IsSuccessStatusCode())
                        {
                            try
                            {
                                if (string.IsNullOrWhiteSpace(outgoing.InnerMessage) == false)
                                {
                                    _cacheService.Set(cacheKey, resultMessage.InnerMessage.Replace("\n", "").Replace("\r", ""), contextPathInfo.Cacher.AbsoluteExpirationOnMinutes, contextPathInfo.Cacher.SlidingExpirationOnMinutes);
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, "{unique} | Error on caching key. Transaction flow continues. | {additionalMessage}", outgoing.Unique, $"Cache key : {cacheKey}, ErrorMessage:{ex.Message}");
                            }
                        }

                        return resultMessage;
                    }
                    else
                    {
                        _logger.LogWarning("{unique} | #GRPC# ChannelMessage could not be inserted into dictionary. | {additionalMessage}", internalMessage.Unique, internalMessage.InnerMessage);

                        return new DynamicPayload
                        {
                            Unique = request.Unique,
                            Failed = true,
                            ExceptionMessage = "#GRPC# Same Message !!",
                            InnerMessage = "",
                            StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError),
                            AdditionalInfo = request.AdditionalInfo
                        };
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "{unique} | #GRPC# Channel message could not sent to destination. | {additionalMessage}", request.Unique, $"ErrorMessage:{ex.Message}");
                    return new DynamicPayload
                    {
                        Unique = request.Unique,
                        Failed = true,
                        ExceptionMessage = "#GRPC# Error:Could not parsed json string. Please send a valid json!",
                        InnerMessage = "",
                        StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest),
                        AdditionalInfo = request.AdditionalInfo
                    };
                }
                finally
                {
                    _requestScopeManager.Remove(internalMessage.Unique);
                    Communicator._events.TryRemove(internalMessage.Unique, out HttpServerStateObject stateObject);
                    _logger.LogDebug("{unique} | #GRPC# Message removed from dictionary.", internalMessage.Unique);

                }
            }
            else
            {
                var response = new DynamicPayload
                {
                    Unique = request.Unique,
                    Failed = true,
                    ExceptionMessage = "Path not found or not specified !",
                    InnerMessage = "",
                    StatusCode = Convert.ToInt32(HttpStatusCode.NotFound),
                    AdditionalInfo = request.AdditionalInfo
                };

                _logger.LogWarning("{unique} | #GRPC# Path not found in request. Operation rejected. | {additionalMessage}", request.Unique, $"Path : {request.Path} , Incoming message : {JsonConvert.SerializeObject(request)}");

                return await Task.FromResult(response);
            }
        }
    }
}
