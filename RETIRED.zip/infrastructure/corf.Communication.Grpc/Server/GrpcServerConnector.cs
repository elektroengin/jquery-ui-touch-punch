﻿using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Grpc;
using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Grpc.Client
{
    public class GrpcServerConnector : HttpServerConnector<IGrpcServerCommunicator, GrpcPathInfo>, IGrpcServerConnector
    {
        internal Dictionary<string, GrpcPathInfo> _pathDictionary = new Dictionary<string, GrpcPathInfo>();

        public GrpcServerConnector(ILogger<GrpcServerConnector> logger, IGrpcServerCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, communicator, provider, requestScopeManager)
        {
        }

        public override string ChannelDescription
        {
            get
            {
                return $"{RootAddress.Host} #GRPC";
            }
        }

        public override void Initialize()
        {
            base.Initialize();

            foreach (GrpcPathInfo pathInfo in Paths)
            {
                if (pathInfo.Uri.StartsWith('/'))
                {
                    pathInfo.Uri = pathInfo.Uri.Remove(0, 1);
                }
                _pathDictionary.Add(pathInfo.Uri, pathInfo);
            }
        }
    }
}
