﻿using corf.Communication.HttpInfra.Grpc;
using corf.Core.Messaging;

namespace corf.Communication.Grpc
{
    public static class AdditionalInfoExtensions
    {
        public static AdditionalInfo ToAdditionalInfo(this MessageAdditionalInfo info)
        {
            return new ()
            {
                ModuleJourney =
                {
                    info?.ModuleJourney?.Select(cycle => new ModuleLifeCycle
                    {
                        ModuleName = !string.IsNullOrEmpty(cycle.ModuleName) ? cycle.ModuleName : string.Empty,
                        EntryDate = cycle.EntryDate.ToBinary(),
                        ExitDate = cycle.ExitDate.ToBinary(),
                        DestinationChannelName = !string.IsNullOrEmpty(cycle.DestinationChannelName)
                            ? cycle.DestinationChannelName
                            : string.Empty,
                        SourceChannelName = !string.IsNullOrEmpty(cycle.SourceChannelName)
                            ? cycle.SourceChannelName
                            : string.Empty
                    })
                }
            };
        }

        public static MessageAdditionalInfo ToMessageAdditionalInfo(this AdditionalInfo info)
        {
            return new ()
            {
                ModuleJourney = info?.ModuleJourney?.Select(cycle => new ModuleMessageLifeCycle()
                {
                    ModuleName = cycle.ModuleName,
                    EntryDate = DateTime.FromBinary(cycle.EntryDate),
                    ExitDate = DateTime.FromBinary(cycle.ExitDate),
                    DestinationChannelName = cycle.DestinationChannelName,
                    SourceChannelName = cycle.SourceChannelName
                }).ToList()
            };
        }
    }
}
