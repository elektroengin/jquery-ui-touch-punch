﻿using corf.Communication.HttpInfra;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Grpc.Client
{
    public class GrpcClientConnector : HttpClientConnector
    {
        private IGrpcClientCommunicator _communicator;

        public GrpcClientConnector(ILogger<GrpcClientConnector> logger, IGrpcClientCommunicator communicator,  IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings = null) : base(logger, provider, requestScopeManager, settings)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance { get { return _communicator; } }

        public override string ChannelDescription
        {
            get { return string.Format("{0}{1}", BaseAddress, Path); }
        }

    }
}
