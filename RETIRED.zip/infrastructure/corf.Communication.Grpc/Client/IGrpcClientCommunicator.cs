﻿using corf.Core.Infrastructure;

namespace corf.Communication.Grpc.Client
{
    public interface IGrpcClientCommunicator : IMessageSender
    {
    }
}