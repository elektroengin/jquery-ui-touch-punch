﻿using corf.Communication.HttpInfra.Grpc;
using corf.Configuration;
using corf.Core;
using corf.Core.Messaging;
using Grpc.Core;
using Grpc.Net.Client;
using Grpc.Net.Client.Configuration;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using static corf.Communication.HttpInfra.Grpc.CorfDynamic;

namespace corf.Communication.Grpc.Client
{
    public class GrpcClientCommunicator : IGrpcClientCommunicator
    {
        private ILogger<GrpcClientCommunicator> _logger;

        private CorfDynamicClient _client;

        public GrpcClientCommunicator(ILogger<GrpcClientCommunicator> logger)
        {
            _logger = logger;

        }
        public bool IsConnected { get { return true; } }

        public IConnector Connector { get; private set; }

        public bool Initialized { get; private set; }

        public virtual async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    // The following statement allows you to call insecure services. To be used only in development environments.
                    AppContext.SetSwitch(
                        "System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);

                }

                var channel = GrpcChannel.ForAddress(((GrpcClientConnector)Connector).BaseAddress,
                    new GrpcChannelOptions
                    {
                        Credentials = ChannelCredentials.Insecure,
                        ServiceConfig = new ServiceConfig
                        {
                            LoadBalancingConfigs = { new RoundRobinConfig() }
                        }
                    });
                _client = new CorfDynamicClient(channel);

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");
                return false;
            }

            finally
            {
                Initialized = true;
            }
        }


        public void GetReady()
        {
            //When connection succeed it is already be connected
        }

        public void Initialize(Connector connector)
        {
            this.Connector = connector;
        }

        public bool Send(InternalMessage message)
        {
            return SendAsync(message).Result;
        }

        public async Task<bool> SendAsync(InternalMessage message)
        {
            bool sent = false;

            DynamicPayload dynamicPayload = new DynamicPayload
            {
                Path = ((GrpcClientConnector)Connector).Path,
                InnerMessage = !string.IsNullOrWhiteSpace(message.InnerMessage) ? message.InnerMessage : "",
                OriginalMessage = !string.IsNullOrWhiteSpace(message.OriginalMessage) ? message.OriginalMessage : "",
                ReceiverChannelId = !string.IsNullOrWhiteSpace(message.ReceiverChannelId) ? message.ReceiverChannelId : "",
                RemoteIpAddress = !string.IsNullOrWhiteSpace(message.RemoteIpAddress) ? message.RemoteIpAddress : "",
                ReturnToReceiverChannel = message.ReturnToReceiverChannel,
                Unique = message.Unique,
                AdditionalInfo = message.AdditionalInfo.ToAdditionalInfo()
            };


            InternalMessage returned = null;
            try
            {
                Metadata metadata = null;
                var connector = (GrpcClientConnector)Connector;

                if (connector.Credentials != null)
                {
                    if (connector.AuthType == "B")  //Basic Authentication
                    {
                        var token = Convert.ToBase64String(
                            Encoding.ASCII.GetBytes(
                                string.Format("{0}:{1}", connector.CredentialsDeserialized.UserName,
                                    connector.CredentialsDeserialized.Password)));

                        metadata = new Metadata
                        {
                            { "Authorization", $"Basic {token}" }
                        };
                    }
                }

                var reply = await _client.ProcessAsync(dynamicPayload, metadata);

                if (reply != null)
                {
                    sent = true;

                    if (string.IsNullOrWhiteSpace(reply.InnerMessage))
                    {
                        _logger.LogWarning("{unique} | Receive message is empty. Passing through..", message.Unique);
                    }


                    returned = new InternalMessage
                    {
                        InnerMessage = reply.InnerMessage,
                        OriginalMessage = reply.OriginalMessage,
                        ReceiverChannelId = reply.ReceiverChannelId,
                        RemoteIpAddress = reply.RemoteIpAddress,
                        ReturnToReceiverChannel = reply.ReturnToReceiverChannel,
                        Unique = reply.Unique,
                        StatusCode = (HttpStatusCode)reply.StatusCode,
                        AdditionalInfo = reply.AdditionalInfo.ToMessageAdditionalInfo()
                    };

                    if ((returned.StatusCode != HttpStatusCode.OK && returned.StatusCode != HttpStatusCode.Created &&
                         returned.StatusCode != HttpStatusCode.Accepted))
                    {
                        returned.InnerMessage = "{\"Unique\":\"" + reply.Unique + "\", \"Error\":\"" +
                                                reply.ExceptionMessage + "\"}";
                    }
                }
            }
            catch (RpcException e)
            {
                returned = new InternalMessage
                {
                    InnerMessage = "{\"Unique\":\"" + message.Unique + "\", \"Error\":\"" +
                                   e.Status.Detail + "\"}",
                    OriginalMessage = message.OriginalMessage,
                    Unique = message.Unique,
                    StatusCode = e.StatusCode == StatusCode.Unauthenticated
                        ? HttpStatusCode.Unauthorized
                        : HttpStatusCode.InternalServerError,
                    AdditionalInfo = message.AdditionalInfo
                };

            }
            finally
            {
                if (returned != null)
                {
                    ((GrpcClientConnector)this.Connector).FireMessageReceived(new MessageReceivedEventArgs(returned));
                }

            }
            return sent;

        }
    }
}
