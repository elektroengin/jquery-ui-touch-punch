﻿using corf.Communication.HttpInfra;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;

namespace corf.Communication.ServiceCaller
{
    public interface IHttpServiceCaller<TRequest, TResponse>
    {
        void Initialize(HttpEndPointInfo endPointInfo, ILogger<GenericServiceCaller<TRequest, TResponse>> logger);
        Task<HttpCallResult<TResponse>> Call(TRequest request, Dictionary<string,object> requestHeaders = null, KeyValueCollection requestParameters = null);
    }
}
