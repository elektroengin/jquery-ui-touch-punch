﻿namespace corf.Communication.ServiceCaller
{
    public enum HttpServiceType 
    {
        gRRPC = 1,
        Rest = 2
    }
}