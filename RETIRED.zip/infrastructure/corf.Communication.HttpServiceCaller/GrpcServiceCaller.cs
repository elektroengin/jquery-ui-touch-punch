﻿using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Grpc;
using corf.Configuration;
using corf.Core.Http;
using corf.Core.Messaging;
using Grpc.Core;
using Grpc.Net.Client;
using Grpc.Net.Client.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using static corf.Communication.HttpInfra.Grpc.CorfDynamic;

namespace corf.Communication.ServiceCaller
{
    public class GrpcServiceCaller<TRequest, TResponse> : IHttpServiceCaller<TRequest, TResponse>
    {
        public GrpcServiceEndPointInfo ServiceEndPointInfo { get; private set; }
        private ILogger<GenericServiceCaller<TRequest, TResponse>> _logger;
        private int _lastInvokerIndex = 0;
        private List<CorfDynamicClient> _clientInvokers;

        public void Initialize(HttpEndPointInfo httpEndPointInfo, ILogger<GenericServiceCaller<TRequest, TResponse>> logger)
        {
            var endPointInfo = httpEndPointInfo as GrpcServiceEndPointInfo;
            
            _logger = logger;
            ServiceEndPointInfo = endPointInfo;

            _clientInvokers = new List<CorfDynamicClient>();

            for (int i = 0; i < ServiceEndPointInfo.ConnectionCount; i++)
            {
                var httpHandler = new HttpClientHandler();

                httpHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                var channel = GrpcChannel.ForAddress(ServiceEndPointInfo.BaseAddress,
                    new GrpcChannelOptions
                    {
                        Credentials = ChannelCredentials.Insecure,
                        ServiceConfig = new ServiceConfig
                        {
                            LoadBalancingConfigs = { new RoundRobinConfig() }
                        }
                    });

                CorfDynamicClient client = new CorfDynamicClient(channel);

                _clientInvokers.Add(client);
            }
        }

        public async Task<HttpCallResult<TResponse>> Call(TRequest request, Dictionary<string,object> requestHeaders = null, KeyValueCollection requestParameters = null)
        {
            try
            {
                DynamicPayload dynamicPayload = new DynamicPayload
                {
                    Path = ServiceEndPointInfo.Path,
                    InnerMessage = JsonConvert.SerializeObject(request),
                };

                Metadata metadata = null;

                if (ServiceEndPointInfo.Credentials != null)
                {

                    if (ServiceEndPointInfo.AuthType == "B")  //Basic Authentication
                    {
                        var token = Convert.ToBase64String(
                            Encoding.ASCII.GetBytes(
                                string.Format("{0}:{1}", ServiceEndPointInfo.Credentials.UserName,
                                    ServiceEndPointInfo.Credentials.Password)));

                        metadata = new Metadata
                        {
                            { "Authorization", $"Basic {token}" }
                        };
                    }
                }


                var index = _lastInvokerIndex;

                 _logger.LogInformation("{unique} | Calling gRPC service over invoker | {additionalMessage}", LoggerUnique.CorfCore, $"Using grpc caller[{this.ServiceEndPointInfo.BaseAddress}{this.ServiceEndPointInfo.Path}] with index : [{index}]");

                var reply = await _clientInvokers[index].ProcessAsync(dynamicPayload, headers: metadata);

                Interlocked.Exchange(ref _lastInvokerIndex, (index + 1) % ServiceEndPointInfo.ConnectionCount);

                if (reply != null)
                {
                    return new HttpCallResult<TResponse> { Response = !string.IsNullOrWhiteSpace(reply.InnerMessage) ? JsonConvert.DeserializeObject<TResponse>(reply.InnerMessage) : default, Result = new HttpResponseMessage { StatusCode = HttpStatusCode.OK } };
                }
                else
                {
                    return new HttpCallResult<TResponse> { Response = default, Result = new HttpResponseMessage { StatusCode = HttpStatusCode.InternalServerError } };
                }
            }
            catch (RpcException ex)
            {
                if (ex.StatusCode == StatusCode.Unauthenticated)
                {
                    return new HttpCallResult<TResponse> { Response = default, Result = new HttpResponseMessage { StatusCode = HttpStatusCode.Unauthorized } };
                }
                _logger.LogError(ex, "{unique} | Error on grpc service caller. | {additionalMessage}",  LoggerUnique.CorfCore, $"BaseAddress : {this.ServiceEndPointInfo.BaseAddress} {this.ServiceEndPointInfo.Path}, ErrorMessage:{ex.Message}");
            }

            return null;
        }
    }

}
