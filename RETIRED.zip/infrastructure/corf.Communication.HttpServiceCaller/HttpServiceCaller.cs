﻿using corf.Communication.HttpInfra;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace corf.Communication.ServiceCaller
{
    public class GenericServiceCaller<TRequest, TResponse>
    {
        public HttpServiceType HttpServiceType { get; private set; }
        private ILogger<GenericServiceCaller<TRequest, TResponse>> _logger;
        public IHttpServiceCaller<TRequest, TResponse> EmbeddedServiceCaller { get; private set; }

        public void Initialize(JObject endPointInfo, ILogger<GenericServiceCaller<TRequest, TResponse>> logger)
        {
            _logger = logger;


            if (!endPointInfo.ContainsKey("serviceType"))
            {
                throw new ArgumentException($"serviceType property is required. [Rest/gRPC]");
            }

            string httpServiceType = endPointInfo.GetValue("serviceType").ToString();

            if (httpServiceType.ToLower() == "rest")
            {
                EmbeddedServiceCaller = new RestServiceCaller<TRequest, TResponse>();
                RestServiceEndPointInfo restServiceEndPointInfo = JsonConvert.DeserializeObject<RestServiceEndPointInfo>(JsonConvert.SerializeObject(endPointInfo));
                EmbeddedServiceCaller.Initialize(restServiceEndPointInfo, _logger);
            }
            else if (httpServiceType.ToLower() == "grpc")
            {
                EmbeddedServiceCaller = new GrpcServiceCaller<TRequest, TResponse>();
                GrpcServiceEndPointInfo grpcServiceEndPointInfo = JsonConvert.DeserializeObject<GrpcServiceEndPointInfo>(JsonConvert.SerializeObject(endPointInfo));
                EmbeddedServiceCaller.Initialize(grpcServiceEndPointInfo, _logger);
            }
            else
            {
                throw new ArgumentException($"'{httpServiceType}' service type could not be recognized as a valid service type. Please use Rest or gRPC.");
            }
        }

        public  async Task<HttpCallResult<TResponse>> Call(TRequest request, Dictionary<string,object> requestHeaders = null, KeyValueCollection requestParameters = null)
        {
            return await EmbeddedServiceCaller.Call(request, requestHeaders, requestParameters);
        }
    }
}
