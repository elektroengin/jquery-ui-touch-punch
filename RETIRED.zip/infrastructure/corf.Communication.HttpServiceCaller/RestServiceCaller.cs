﻿using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Rest;
using corf.Configuration;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;

namespace corf.Communication.ServiceCaller
{
    public class RestServiceCaller<TRequest, TResponse> : IHttpServiceCaller<TRequest, TResponse>
    {
        private HttpClient _client;
        public RestServiceEndPointInfo ServiceEndPointInfo { get; private set; }

        private ILogger<GenericServiceCaller<TRequest, TResponse>> _logger;

        private int _lastInvokerIndex = 0;
        private ConcurrentDictionary<int, IVerbInvoker<TRequest, TResponse>> _verbInvokers;

        private HttpEndPointInfo _httpEndPointInfo;

        public void Initialize(HttpEndPointInfo httpEndPointInfo, ILogger<GenericServiceCaller<TRequest, TResponse>> logger)
        {
            _httpEndPointInfo = httpEndPointInfo;
            var endPointInfo = httpEndPointInfo as RestServiceEndPointInfo;
            Random random = new Random();
            _logger = logger;
            _verbInvokers = new ConcurrentDictionary<int, IVerbInvoker<TRequest, TResponse>>();
            ServiceEndPointInfo = endPointInfo;
            ServicePointManager.DefaultConnectionLimit = endPointInfo.ConnectionCount;
            var indexByHosts = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            var socketHttpHandler = new SocketsHttpHandler()
            {
                Credentials = endPointInfo.Credentials != null ? 
                                    new NetworkCredential(endPointInfo.Credentials.UserName, endPointInfo.Credentials.Password) : null,
                MaxConnectionsPerServer = endPointInfo.ConnectionCount,
                ConnectCallback = async (context, cancellationToken) =>
                {
                    var entry = await Dns.GetHostEntryAsync(context.DnsEndPoint.Host);
                    IPAddress[] addresses;
                    if (entry.AddressList.Length == 1) 
                    {
                        addresses = entry.AddressList;
                    }
                    else
                    {
                        var index = indexByHosts.AddOrUpdate(
                            key: entry.HostName,
                            addValue: random.Next(),
                            updateValueFactory: (host, existingValue) => existingValue + 1);

                        index %= entry.AddressList.Length;

                        if (index == 0)
                        {
                            addresses = entry.AddressList;
                        }
                        else
                        {
                            addresses = new IPAddress[entry.AddressList.Length];
                            entry.AddressList.AsSpan(index).CopyTo(addresses);
                            entry.AddressList.AsSpan(0, index).CopyTo(addresses.AsSpan(index));
                        }
                    }

                    var socket = new Socket(SocketType.Stream, ProtocolType.Tcp)
                    {
                        NoDelay = true
                    };

                    try
                    {
                        await socket.ConnectAsync(addresses, context.DnsEndPoint.Port, cancellationToken);
                        return new NetworkStream(socket, ownsSocket: true);
                    }
                    catch
                    {
                        socket.Dispose();
                        throw;
                    }
                }
            };
            socketHttpHandler.SslOptions.RemoteCertificateValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };


            for (int i = 0; i < ServiceEndPointInfo.ConnectionCount; i++)
            {
                _client = new HttpClient(socketHttpHandler, disposeHandler: true);

                if (endPointInfo.Credentials != null && endPointInfo.AuthType == "B")
                {
                    _client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue(
                            "Basic",
                            Convert.ToBase64String(
                                System.Text.ASCIIEncoding.ASCII.GetBytes(
                                    string.Format("{0}:{1}", endPointInfo.Credentials.UserName, endPointInfo.Credentials.Password))));
                }
                

                if (ServiceEndPointInfo.TimeOut > 0)
                {
                    _client.Timeout = TimeSpan.FromMilliseconds(ServiceEndPointInfo.TimeOut);
                }

                _client.BaseAddress = new Uri(endPointInfo.BaseAddress);

                _client.DefaultRequestHeaders.Accept.Clear();

                _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(endPointInfo.Type));

             
                if (string.IsNullOrWhiteSpace(endPointInfo.Headers) == false)
                {
                    foreach (var headerInfo in endPointInfo.Headers.Split('|'))
                    {
                        _client.DefaultRequestHeaders.Add(headerInfo.Split('=')[0], headerInfo.Split('=')[1]);
                    }
                }

                var verbInvoker = new VerbInvoker<TRequest, TResponse>(_client, _logger, _httpEndPointInfo);

                verbInvoker.Verb = endPointInfo.Verb;
                _verbInvokers.TryAdd(i, verbInvoker);
            }
        }
        public async Task<HttpCallResult<TResponse>> Call(TRequest request, Dictionary<string,object> requestHeaders = null, KeyValueCollection requestParameters = null)
        {
            try
            {
                var index = _lastInvokerIndex;

                 _logger.LogInformation("{unique} | Calling service over invoker | {additionalMessage}", LoggerUnique.CorfCore, $"Using rest caller[{this.ServiceEndPointInfo.BaseAddress}{this.ServiceEndPointInfo.Path}] with index : [{index}]");

                var result = await _verbInvokers[index].Invoke(request, $"{ServiceEndPointInfo.BaseAddress}{ServiceEndPointInfo.Path}", requestHeaders, requestParameters);

                if (!result.Result.IsSuccessStatusCode)
                {
                    _logger.LogWarning("{unique} | Status code not successful. | {additionalMessage}", LoggerUnique.CorfCore, $"Result:{JsonConvert.SerializeObject(result.Result)}");
                }

                Interlocked.Exchange(ref _lastInvokerIndex, (index + 1) % ServiceEndPointInfo.ConnectionCount);

                return result;
            }
            catch (ArgumentNullException aex)
            {
                _logger.LogError(aex, "{unique} | Error on rest service caller. | {additionalMessage}", LoggerUnique.CorfCore, $"BaseAddress : {this.ServiceEndPointInfo.BaseAddress} {this.ServiceEndPointInfo.Path}, ErrorMessage:{aex.Message}");
            }
            catch (InvalidOperationException iox)
            {
                _logger.LogError(iox, "{unique} | Error on rest service caller. | {additionalMessage}", LoggerUnique.CorfCore, $"BaseAddress : {this.ServiceEndPointInfo.BaseAddress} {this.ServiceEndPointInfo.Path}, ErrorMessage:{iox.Message}");

            }
            catch (HttpRequestException iox)
            {
                _logger.LogError(iox, "{unique} | Error on rest service caller. | {additionalMessage}", LoggerUnique.CorfCore, $"BaseAddress : {this.ServiceEndPointInfo.BaseAddress} {this.ServiceEndPointInfo.Path}, ErrorMessage:{iox.Message}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error on rest service caller. | {additionalMessage}", LoggerUnique.CorfCore, $"BaseAddress : {this.ServiceEndPointInfo.BaseAddress} {this.ServiceEndPointInfo.Path}, ErrorMessage:{ex.Message}");

            }

            return null;
        }
    }
}
