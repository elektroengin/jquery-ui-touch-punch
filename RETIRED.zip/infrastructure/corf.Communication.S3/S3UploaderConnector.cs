﻿using corf.Communication.S3.Util;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.S3
{
    public class S3UploaderConnector : TransportConnector, IS3UploaderConnector
    {
        private readonly IS3UploaderCommunicator _communicator;

        public S3UploaderConnector(ILogger<S3UploaderConnector> logger, IS3UploaderCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public S3Configuration S3Configuration { get; set; } =new S3Configuration();

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string BucketName { get; set; } = String.Empty;

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string OutputFolderName { get; set; } = String.Empty;

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string SearchPattern{ get; set; } = String.Empty;

        [FlowDesign(EnvironmentBasedVariable = true)]
        public bool DeleteSourceFilesAfterUpload { get; set; }

        [FlowDesign(EnvironmentBasedVariable = true)]
        public string S3FolderName { get; set; } = String.Empty;

        [FlowDesign(EnvironmentBasedVariable = true)]
        public bool AddDateExtensionToBucketName { get; set; } = true;
        public override ICommunicator CommunicatorInstance
        {
            get
            {
                return _communicator;
            }
        }

        [FlowDesign(Display = false)]
        public override string ChannelDescription
        {
            get { return $"ServiceUrl : {S3Configuration.ServiceUrl}, AccessKey : {S3Configuration.AccessKey}, BucketName : {BucketName},  OutputFolderName : {OutputFolderName}, SearchPattern : {SearchPattern}, DeleteSourceFilesAfterUpload {DeleteSourceFilesAfterUpload}"; }
        }
    }
}
