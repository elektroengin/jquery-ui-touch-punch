﻿using corf.Core.Infrastructure;

namespace corf.Communication.S3
{
    public interface IS3UploaderCommunicator : IMessageSender
    {
    }
}