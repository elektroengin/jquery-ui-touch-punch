﻿using Amazon.S3.Model;

namespace corf.Communication.S3.Util
{
    public interface IS3Repository
    {
        void CreateBucket(PutBucketRequest putBucketRequest);
        void CreateFile(string sourcePath, string bucketName, string fileName,string S3FolderName);
    }
}
