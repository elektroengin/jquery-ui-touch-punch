﻿using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Logging;

namespace corf.Communication.S3.Util
{
    public class S3Repository : S3Context, IS3Repository
    {
        private ILogger _logger;
        public S3Repository(S3Configuration configuration, ILogger logger) : base(configuration)
        {
            _logger = logger;
        }
    
        public void CreateBucket(PutBucketRequest putBucketRequest)
        {
            try
            {
                PutBucketResponse putBucketResponse = S3Client.PutBucketAsync(putBucketRequest).Result;
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "{unique} | Bucket could not be created. | {additionalMessage}", this.ToString(), ex.Message);
            }
        }
        public void CreateFile(string sourcePath, string bucketName,string fileName,string S3FolderName)
        {
            TransferUtility utility = new TransferUtility(S3Client);

            utility.Upload(sourcePath, bucketName,String.IsNullOrEmpty(S3FolderName)?fileName: S3FolderName +"/" +fileName);
        }
    }
}
