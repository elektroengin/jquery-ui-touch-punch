﻿using Amazon.S3;

namespace corf.Communication.S3.Util
{
    public class S3Context
    {
        private readonly S3Configuration configuration;
        protected AmazonS3Client S3Client;

        public S3Context(S3Configuration configuration)
        {
            this.configuration = configuration;
            Intialize();
        }

        private void Intialize()
        {
            AmazonS3Config config = new AmazonS3Config();
            config.ServiceURL = configuration.ServiceUrl;
            SSLFactory sSLFactory = new SSLFactory();
            config.HttpClientFactory = sSLFactory;
            S3Client = new AmazonS3Client(
                    configuration.AccessKey,
                    configuration.SecretKey,
                    config
                    );
        }
    }
}
