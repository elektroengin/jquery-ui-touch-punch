﻿using corf.Communication.S3.Util;

namespace corf.Communication.S3
{
    public interface IS3UploaderConnector
    {
        S3Configuration S3Configuration { get; set; }
        string BucketName { get; set; }
        string OutputFolderName { get; set; }
        string SearchPattern { get; set; }
        bool DeleteSourceFilesAfterUpload { get; set; }
    }
}