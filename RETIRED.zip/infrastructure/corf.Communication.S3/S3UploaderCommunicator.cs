﻿using Amazon.S3.Model;
using corf.Communication.S3.Util;
using corf.Core;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using NLog.Filters;

namespace corf.Communication.S3
{
    public class S3UploaderCommunicator : IS3UploaderCommunicator
    {
        public bool IsConnected { get { return true; } }

        private ILogger<S3UploaderCommunicator> _logger;
        public S3UploaderCommunicator(ILogger<S3UploaderCommunicator> logger) 
        {
            _logger = logger;
        }
        public IConnector Connector { get; private set; }

        private static object _lock = new object();

        private int _messagesSize = 0;

        public bool Initialized { get; private set; }
        private S3Repository s3Repository;

        public async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            Initialized = true;
            return true;
        }

        public void GetReady()
        {
        }
        public void Initialize(Connector connector)
        {
            Connector = connector;
            s3Repository = new S3Repository(S3Connector.S3Configuration, _logger);
        }
        protected S3UploaderConnector S3Connector { get { return (S3UploaderConnector)Connector; } }

        public bool Send(InternalMessage message)
        {

            Task<bool> asyncTask = SendAsync(message);
            asyncTask.Wait();
            return asyncTask.Result;
        }

        public async Task<bool> SendAsync(InternalMessage message)
        {
            lock (_lock)
            {
                string dateExtension = S3Connector.AddDateExtensionToBucketName ? "-"+ DateTime.Now.ToString("yyyyMMdd"):"";
                string bucketName = $"{S3Connector.BucketName}{dateExtension}";

                s3Repository.CreateBucket(new PutBucketRequest() { BucketName = bucketName });

                var files = Directory.GetFiles(S3Connector.OutputFolderName, S3Connector.SearchPattern);

                foreach (var filePath in files)
                {

                    var fileName = Path.GetFileName(filePath);
                    var s3Filename = fileName.Replace("_", "-");
                    s3Repository.CreateFile(Path.Combine(S3Connector.OutputFolderName, fileName), bucketName, $"{s3Filename}", S3Connector.S3FolderName);

                    if (S3Connector.DeleteSourceFilesAfterUpload)
                        File.Delete(Path.Combine(S3Connector.OutputFolderName, fileName));
                }
            }

            return await Task.FromResult(true);
        }
    }
}
