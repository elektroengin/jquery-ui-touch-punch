﻿using corf.Communication.HttpInfra;
using corf.Communication.HttpInfra.Rest;
using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Rest.Server
{
    public class RestServerConnector : HttpServerConnector<IRestServerCommunicator, PathInfo>, IRestServerConnector
    {
        public RestServerConnector(ILogger<RestServerConnector> logger, IRestServerCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, communicator, provider, requestScopeManager)
        {
        }
    }   
}
