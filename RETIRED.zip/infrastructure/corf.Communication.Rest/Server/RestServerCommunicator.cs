﻿using Confluent.Kafka;
using corf.Caching;
using corf.Communication.HttpInfra;
using corf.Configuration;
using corf.Core;
using corf.Core.Commands;
using corf.Core.Hosting;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.OpenApi.Models;
using Microsoft.VisualStudio.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using Steeltoe.Management.Endpoint;
using Steeltoe.Management.Endpoint.SpringBootAdminClient;
using System.Linq.Expressions;
using System.Net;
using System.Reflection;
//using Utf8Json;
using System.Text;
using System.Text.Json.Serialization;
using Steeltoe.Management.Endpoint.Trace;

namespace corf.Communication.Rest.Server
{
    public class RestServerCommunicator : HttpServerCommunicator, IRestServerCommunicator
    {
        
        ICacheService _cacheService;
        private IConfigurationRoot Configuration;
        public RestServerCommunicator(ILogger<RestServerCommunicator> logger, ICacheService cacheService, IExternalDependenyProvider hostContainer, IRequestScopeManager requestScopeManager, IServiceProvider globalServiceProvider) : base(logger, hostContainer, requestScopeManager, globalServiceProvider)
        {
            _cacheService = cacheService;
            Configuration = globalServiceProvider.GetRequiredService<IConfigurationRoot>();
        }

        #region delegations

        public override void ConfigureServicesDelegate(IServiceCollection services)
        {
            IHttpServerConnector httpServerConnector = Connector as IHttpServerConnector;

            if (httpServerConnector.AllowAnyCors)
            {
                services.AddCors(options =>
                {
                    options.AddPolicy("AllowAny",
                        builder => builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
                });
            }

            services.AddMvc();
            services.AddControllers().AddJsonOptions(options =>
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

            base.ConfigureServicesDelegate(services);
            services.AddRouting();
            services.AddSingleton<ISwaggerPath>(new SwaggerPath((RestServerConnector)this.Connector));
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("CorfSwagger", new OpenApiInfo
                {
                    Title = ((Connector)httpServerConnector).Title ?? Assembly.GetEntryAssembly().GetName().Name,
                    Description = ((Connector)httpServerConnector).Description ?? string.Empty,
                    Version = Assembly.GetEntryAssembly().GetName().Version.ToString()
                });
                c.CustomSchemaIds((type) => type.FullName?.Replace("+", "."));

                //c.SchemaFilter<EnumSchemaFilter>();
                c.DocumentFilter<SwaggerDocumentFilter>();

                var jwtSecurityScheme = new OpenApiSecurityScheme
                {
                    Description = @"Bearer IAM Token should be filled",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    Reference = new OpenApiReference
                    {
                        Id = JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };
                c.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);

            });
            services.AddSwaggerGenNewtonsoftSupport();

        }

        public override void CofigureDelegate(IApplicationBuilder app)
        {
            base.CofigureDelegate(app);

            var trackPackageRouteHandler = new RouteHandler(context =>
            {
                var routeValues = context.GetRouteData().Values;
                return context.Response.WriteAsync(
                    $"Route values: {string.Join(", ", routeValues)}");
            });

            var routeBuilder = new RouteBuilder(app, trackPackageRouteHandler);

            RestServerConnector connector = (RestServerConnector)Connector;

            app.UseRouting();

            app.UseEndpoints(e =>
            {
                try
                {
                    if (Configuration.GetSection("Spring").GetChildren().Any() && Configuration.GetSection("Management").GetChildren().Any())
                    {
                        e.MapAllActuators(null);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "{unique} | Could not connect to sentinel | {additionalMessage}", LoggerUnique.CorfCore, $"Error Message : {ex.Message}");
                }

                foreach (PathInfo pathInfo in connector.Paths)
                {
                    if (pathInfo.AllowGet)
                    {
                        e.MapGet(pathInfo.Uri, async context =>
                        {
                            var contextPathInfo = ClonePathInfo(pathInfo);
                            contextPathInfo.ServiceProvider = context.RequestServices;
                            await MapVerb(connector, context, contextPathInfo.Get, contextPathInfo.Get.ExecuterSpecificDestination);
                        });
                    }
                    if (pathInfo.AllowPost)
                    {
                        e.MapPost(pathInfo.Uri, async context =>
                        {
                            var contextPathInfo = ClonePathInfo(pathInfo);
                            contextPathInfo.ServiceProvider = context.RequestServices;
                            await MapVerb(connector, context, contextPathInfo.Post, contextPathInfo.Post.ExecuterSpecificDestination);
                        });
                    }
                    if (pathInfo.AllowPut)
                    {
                        e.MapPut(pathInfo.Uri, async context =>
                        {
                            var contextPathInfo = ClonePathInfo(pathInfo);
                            contextPathInfo.ServiceProvider = context.RequestServices;
                            await MapVerb(connector, context, contextPathInfo.Put, contextPathInfo.Put.ExecuterSpecificDestination);
                        });
                    }
                    if (pathInfo.AllowDelete)
                    {
                        e.MapDelete(pathInfo.Uri, async context =>
                        {
                            var contextPathInfo = ClonePathInfo(pathInfo);
                            contextPathInfo.ServiceProvider = context.RequestServices;
                            await MapVerb(connector, context, contextPathInfo.Delete, contextPathInfo.Delete.ExecuterSpecificDestination);
                        });
                    }
                }

            });

           
            app.Build();

        }
        private PathInfo ClonePathInfo(PathInfo pathInfo)
        {
            return new PathInfo()
            {
                Delete = pathInfo.Delete?.Clone(),
                Get = pathInfo.Get?.Clone(),
                Post = pathInfo.Post?.Clone(),
                Put = pathInfo.Put?.Clone(),
                Uri = pathInfo.Uri,
                Description = pathInfo.Description,
                Tags = pathInfo.Tags,
                Authorization = pathInfo.Authorization
            };
        }
        private async Task MapVerb(RestServerConnector connector, HttpContext context, PathVerb pathVerb, string destination)
        {
            pathVerb.Connector = connector;
            string message = "";
            string cacheKey = "";

            DateTime requestStartDateTime = DateTime.Now;

            string traceIdentifier = context.TraceIdentifier;

            _logger.LogDebug("{unique} | New request started. | {additionalMessage}", context.TraceIdentifier, $"Connector Name : {connector.Name} - context trace identifier : {context.TraceIdentifier} - Remote IpAddress : {context.Request.HttpContext.Connection.RemoteIpAddress}");

            IFormFileCollection requestFiles = null;

            if (context.Request.HasFormContentType && context.Request.Form != null)
            {
                requestFiles = context.Request.Form.Files;
            }

            var headers = context.Request.Headers;

            if (_serverAuthenticatonInfo.ServerAuthenticatonType != ServerAuthenticatonType.None && _serverAuthenticatonInfo.ServerAuthenticatonType != ServerAuthenticatonType.JwtTokenWithoutValidation && (pathVerb.Executer == null || pathVerb.Executer.Authorized))
            {
                var result = await context.AuthenticateAsync();

                if (result.Succeeded == false)
                {
                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.Unauthorized);

                    const string unauthorizedMessage =
                        "{'message': 'You are not authorized. Please contact your system administrator.'}";

                    if (connector.InternalPayload)
                    {
                        await context.Response.WriteAsJsonAsync(new HttpMessage
                        {
                            StatusCode = HttpStatusCode.Unauthorized,
                            State = MessageState.ExecutionFailed,
                            InnerMessage = unauthorizedMessage
                        });
                    }
                    else
                    {
                        await context.Response.WriteAsync(unauthorizedMessage);
                    }

                    return;
                }
            }
            try
            {
                if (!string.IsNullOrEmpty(connector.ResponseHeaders))
                {
                    foreach (var headerInfo in connector.ResponseHeaders.Split('|'))
                    {
                        context.Response.Headers.Add(headerInfo.Split('=')[0], headerInfo.Split('=')[1]);
                    }
                }


                HttpMessage channelMessage;

                using (StreamReader reader = new(context.Request.Body, Encoding.UTF8))
                {
                    message = await reader.ReadToEndAsync();
                }

                if (connector.InternalPayload)
                {
                    channelMessage = HttpMessage.ParseFromJson(message);

                    if (string.IsNullOrWhiteSpace(channelMessage.Unique))
                    {
                        channelMessage.Unique = $"{Guid.NewGuid().ToString().Replace("-", "")}";
                    }
                }
                else
                {

                    if (pathVerb.OperationType == OperationType.Get || pathVerb.OperationType == OperationType.Delete || pathVerb.OperationType == OperationType.Head)
                    {
                        JToken messageJson = JToken.Parse("{}");
                        try
                        {
                            messageJson = JToken.Parse(message);
                        }
                        catch (Exception) //If message is not JSON formatted. 
                        {
                            _logger.LogInformation("Payload is not JSON formatted.");
                            messageJson = JToken.Parse("{}");
                        }

                        if (messageJson is not JArray)
                        {
                            foreach (var parameter in context.Request.Query)
                            {
                                if (messageJson[parameter.Key] == null)
                                {
                                    messageJson[parameter.Key] = parameter.Value.FirstOrDefault();
                                }
                            }
                        }

                        channelMessage = new HttpMessage
                        {
                            InnerMessage = messageJson.ToString()
                        };
                    }
                    else
                    {
                        channelMessage = new HttpMessage
                        {
                            InnerMessage = message
                        };
                    }
                    
                }

                var unique = $"{Guid.NewGuid().ToString().Replace("-", "")}";
                string xCorrValue = null;
                if (headers.TryGetValue("x-rly-corr", out var xCorrValues))
                {
                   
                     xCorrValue = xCorrValues.FirstOrDefault();
                    
                }
                else
                {
                    context.Request.Headers.Add("x-rly-corr", unique);
                    xCorrValue = unique;
                }

                channelMessage.Unique = xCorrValue;

                //Caching only for GET operations
                if (pathVerb.Cacher != null && pathVerb.OperationType == OperationType.Get)
                {
                    _logger.LogDebug("{unique} | Cache check. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}");

                    try
                    {
                        if ((context.Request.Query != null && context.Request.Query.Count > 0) || (context.Request.RouteValues != null && context.Request.RouteValues.Count > 0))
                        {
                            List<string> keysList = new List<string>();

                            foreach (var routeValue in context.Request.RouteValues)
                            {
                                keysList.Add($"rtv-{routeValue.Key}#{routeValue.Value}");
                            }

                            if (string.IsNullOrWhiteSpace(pathVerb.Cacher.Keys) == false)
                            {

                                foreach (var key in pathVerb.Cacher.KeysArray)
                                {
                                    if (context.Request.Query.ContainsKey(key))
                                    {
                                        keysList.Add($"{key}#{context.Request.Query[key]}");
                                    }
                                }
                            }
                            else
                            {
                                foreach (var x in context.Request.Query)
                                {
                                    keysList.Add($"{x.Key}#{x.Value}");
                                }
                            }

                            cacheKey = $"{pathVerb.Cacher.AppDelimiter}_{string.Join("_", keysList.ToArray())}";

                            var result = _cacheService.Get<InternalMessage>(cacheKey);

                            if (result != null)
                            {
                                result.Unique = channelMessage.Unique;

                                string jsonString = "";

                                if (connector.InternalPayload)
                                {
                                    jsonString = JsonConvert.SerializeObject(result);
                                    _logger.LogInformation("{unique} | Response received from cache with key. | {additionalMessage}", channelMessage.Unique, $"cacheKey : {cacheKey}, Trace id : {traceIdentifier}, Response data : {jsonString}");
                                }
                                else
                                {
                                    jsonString = JsonConvert.SerializeObject(result.InnerMessage);
                                    _logger.LogInformation("{unique} | Response received from cache with key. | {additionalMessage}", channelMessage.Unique, $"cacheKey : {cacheKey}, Trace id : {traceIdentifier}, Response data : {jsonString}");

                                }

                                if (result.Headers != null)
                                {
                                    
                                    foreach (var header in result.Headers)
                                    {
                                        if (header.Value != null && header.Key != "Transfer-Encoding" && !context.Response.Headers.ContainsKey(header.Key))
                                        {
                                            if (header.Value.GetType().Name == "String[]")
                                            {
                                                context.Response.Headers.Add(header.Key, new StringValues((String[])header.Value));
                                            }
                                            else
                                            {
                                                context.Response.Headers.Add(header.Key, header.Value.ToString());
                                            }
                                        }
                                    }
                                }

                                await context.Response.WriteAsync(jsonString);
                                return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "{unique} | Error on cache. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}, Url:{pathVerb.PathInfo.Uri}, AppDelimiter:{pathVerb.Cacher.AppDelimiter}, ErrorMessage:{ex.Message}");
                    }
                }

                AvailabilityResult availabilityResult = null;

                //TODO: Cache i de kapsayacak bir çözüm gerekir mi? - Selçuk
                if (pathVerb.Executer != null)
                {
                    availabilityResult = pathVerb.Executer.CheckAvailability(channelMessage);
                }

                if (availabilityResult == null || availabilityResult.IsAvailable)
                {
                    channelMessage.Files = requestFiles;

                    channelMessage.HttpHeaders = headers;

                    foreach (var x in context.Request.Query)
                    {
                        channelMessage.ChannelCustomParameters.TryAdd(x.Key, x.Value);
                    }

                    foreach (var x in context.Request.RouteValues)
                    {
                        channelMessage.ChannelCustomParameters.TryAdd(x.Key, (string)x.Value);
                    }

                    try
                    {
                       
                        channelMessage.RemoteIpAddress = context.Connection.RemoteIpAddress.ToString();

                        if (context.Request.Headers.TryGetValue("Authorization", out StringValues basicAuth))
                        {
                            if (connector.ServerAuthenticatonInfo != null)
                                _serverAuthenticatonInfo.ServerAuthenticatonType = connector.ServerAuthenticatonInfo.ServerAuthenticatonType;
                            else _serverAuthenticatonInfo.ServerAuthenticatonType = ServerAuthenticatonType.BAuth;
                            channelMessage.AuthorizationHeader = basicAuth;
                        }

                        HttpServerStateObject stateObject = new HttpServerStateObject { Request = channelMessage, Data = channelMessage.InnerMessage };

                        _requestScopeManager.Add(channelMessage, context.RequestServices);

                        connector.AddMessage();

                        bool addedIntoDictionary = _events.TryAdd(channelMessage.Unique, stateObject);

                        _logger.LogDebug("{unique} | Message inserted into dictionary. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}");

                        if (addedIntoDictionary)
                        {
                            if (connector.UseAsyncRouting == false)
                            {
                                await connector.FireAsyncMessageReceived(new MessageReceivedEventArgs(channelMessage) { UseSpecificExecuter = true, Executer = pathVerb.Executer, Destination = destination });
                            }
                            else
                            {
                                AsyncManualResetEvent completed = new AsyncManualResetEvent(false);

                                stateObject.ResetEvent = completed;

                                connector.FireAsyncMessageReceived(new MessageReceivedEventArgs(channelMessage) { UseSpecificExecuter = true, Executer = pathVerb.Executer, Destination = destination });

                                CancellationTokenSource timeoutCancellation = new CancellationTokenSource(connector.TimeOut);

                                try
                                {
                                    await completed.WaitAsync(timeoutCancellation.Token);
                                }
                                catch(OperationCanceledException)
                                {
                                    _logger.LogError("{unique} | Returning response message. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}");

                                    context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.RequestTimeout);

                                    var responseErrorMessage = new ResponseErrorMessage() { MessageCode = "RequestTimeout" };

                                    await context.Response.WriteAsync(JsonConvert.SerializeObject(responseErrorMessage));

                                    return;
                                }

                            }

                            InternalMessage outgoing = _events[channelMessage.Unique].Response;

                            if (outgoing.Headers != null)
                            {
                                foreach (var header in outgoing.Headers)
                                {
                                    if (header.Value != null && header.Key != "Transfer-Encoding" && !context.Response.Headers.ContainsKey(header.Key))
                                    {
                                        if (header.Value.GetType().Name == "String[]")
                                        {
                                            context.Response.Headers.Add(header.Key, new StringValues((String[])header.Value));
                                        }
                                        else
                                        {
                                            context.Response.Headers.Add(header.Key, header.Value.ToString());
                                        }

                                    }
                                }
                            }

                            context.Response.StatusCode = Convert.ToInt32(outgoing.StatusCode != 0 ? outgoing.StatusCode : HttpStatusCode.Created);

                            if (pathVerb.Cacher != null && !string.IsNullOrWhiteSpace(cacheKey) && pathVerb.OperationType == OperationType.Get && outgoing.State != MessageState.Failed && outgoing.IsSuccessStatusCode())
                            {
                                try
                                {
                                    _cacheService.Set(cacheKey, outgoing, pathVerb.Cacher.AbsoluteExpirationOnMinutes, pathVerb.Cacher.SlidingExpirationOnMinutes);
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, "{unique} | Error on cache key | {additionalMessage}. Transaction flow continues.", channelMessage.Unique, $"Cache key:{cacheKey}, ErrorMessage:{ex.Message}");
                                }
                            }

                            var response = connector.InternalPayload
                                ? JsonConvert.SerializeObject(outgoing,
                                    new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore })
                                : outgoing.InnerMessage;
                            await context.Response.WriteAsync(response);
                            return;

                        }

                        else
                        {
                            _logger.LogWarning("{unique} | ChannelMessage could not be inserted into dictionary. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}. Unique :{channelMessage.Unique} - message :{message}");
                        }

                        if (channelMessage.State == MessageState.Failed)
                        {
                            _logger.LogWarning("{unique} | Channel message could not sent to destination. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}. Fail reason : {channelMessage.FailReason}");
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "{unique} | Channel message could not sent to destination. | {additionalMessage}", channelMessage.Unique, $"Reason : {ex.Message}. Trace id : {traceIdentifier}");
                        context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError);
                        var responseErrorMessage = new ResponseErrorMessage() { MessageCode = $"Error:{ex.Message}!. Trace id : {traceIdentifier}" };
                        await context.Response.WriteAsync(JsonConvert.SerializeObject(responseErrorMessage));
                        return;
                    }
                    finally
                    {
                        _requestScopeManager.Remove(channelMessage.Unique);
                        _events.TryRemove(channelMessage.Unique, out HttpServerStateObject stateObject);
                        _logger.LogDebug("{unique} | Message removed from dictionary. | {additionalMessage}", channelMessage.Unique, $"Trace id : {traceIdentifier}");
                        _logger.LogInformation("{unique} | Overall duration. | {additionalMessage}", channelMessage.Unique, $"{(DateTime.Now - requestStartDateTime).TotalMilliseconds} ms. Trace id : {traceIdentifier}");
                    }
                }
                else
                {
                    if (availabilityResult.Response != null)
                    {
                        await context.Response.WriteAsync(availabilityResult.Response.InnerMessage);
                    }
                    else
                    {
                        var responseErrorMessage = new ResponseErrorMessage() { MessageCode = $"Error:Response could not be retrived!. Trace id : {traceIdentifier}" };
                        await context.Response.WriteAsync(JsonConvert.SerializeObject(responseErrorMessage));
                    }
                    return;
                }

            }
            catch (Exception ex)
            {
                context.Response.StatusCode = Convert.ToInt32(HttpStatusCode.InternalServerError);
                await context.Response.WriteAsync($"An error occured while processing the message. Please contact to administrators. Message unique :  {traceIdentifier}");

                _logger.LogError(ex, "{unique} | Channel message could not sent to destination. | {additionalMessage}", traceIdentifier, $"Trace Id : {traceIdentifier}, ErrorMessage:{ex.Message}");
            }
        }

        public override void ConfigureListenOptions(ListenOptions listenOptions)
        {
            listenOptions.Protocols = HttpProtocols.Http1AndHttp2;
        }

        #endregion

    }
}
