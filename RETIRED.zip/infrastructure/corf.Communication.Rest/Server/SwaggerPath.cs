﻿
namespace corf.Communication.Rest.Server
{
    public class SwaggerPath : ISwaggerPath
    {


        public SwaggerPath(RestServerConnector connector)
        {
            Connector = connector;
        }

        public RestServerConnector Connector { get; private set; }
    }
}