﻿namespace corf.Communication.Rest.Server
{
    public interface ISwaggerPath
    {
        RestServerConnector Connector { get; }
    }
}