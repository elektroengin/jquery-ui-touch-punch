﻿using corf.Core.Infrastructure;

namespace corf.Communication.Rest.Server
{
    public interface IRestServerCommunicator : IMessageSender
    {
    }
}
