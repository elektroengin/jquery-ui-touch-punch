﻿using Microsoft.AspNetCore.Mvc;

namespace corf.Communication.Rest.Server.Controllers
{
    [GenericControllerNameConvention]
    public class GenericController<T> : Controller
    {
        public IActionResult Index()
        {
            return Content($"Hello from a generic {typeof(T).Name} controller.");
        }
    }
}
