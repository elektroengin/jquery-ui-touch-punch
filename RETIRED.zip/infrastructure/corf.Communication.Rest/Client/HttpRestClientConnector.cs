﻿using corf.Communication.HttpInfra;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
//using Utf8Json;
using System.Net;

namespace corf.Communication.Rest.Client
{
    [Serializable]
    public abstract class HttpRestClientConnector : HttpClientConnector
    {
        protected abstract ICommunicator GetCommunicator();

        public HttpRestClientConnector(ILogger logger, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, provider, requestScopeManager, settings)
        {
        }

        public override ICommunicator CommunicatorInstance { get { return GetCommunicator(); } }

        [FlowDesign(DefaultValue = "post", Description = "Http Verb. ex: post,put,delete,get")]
        public string Verb { get; set; } = "post";

        [FlowDesign(DefaultValue = "application/json", Description = "Type of request. ex : application/json")]
        public string Type { get; set; } = "application/json";

        [FlowDesign(Description = "Request headers with | seperator. ex : header1=1|header2=2")]
        public string Headers { get; set; }

        [FlowDesign(Description = "Code for successfull response. ex : OK, Created")]
        public HttpStatusCode SuccessResponseCode { get; set; }
        public override string ChannelDescription
        {
            get { return string.Format("{0}{1} #{2}", BaseAddress, Path, Verb); }
        }
        public int PooledConnectionIdleTimeout { get; set; }
        public int PooledConnectionLifetime { get; set; }
        public int MaxConnectionsPerServer { get; set; }
    }
}