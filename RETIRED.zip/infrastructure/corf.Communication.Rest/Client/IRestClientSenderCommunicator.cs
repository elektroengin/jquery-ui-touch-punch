﻿using corf.Core.Infrastructure;

namespace corf.Communication.Rest.Client
{
    public interface IRestClientSenderCommunicator: IMessageSender
    {
    }
}