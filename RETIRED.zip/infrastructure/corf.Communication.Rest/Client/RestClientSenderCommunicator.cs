﻿using Confluent.Kafka;
using corf.Communication.HttpInfra;
using corf.Communication.Rest.Client.ApplicationIAM;
using corf.Configuration;
using corf.Core;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
//using Utf8Json;
//using Utf8Json.Resolvers;
using Newtonsoft.Json;
using System.Net;

namespace corf.Communication.Rest.Client
{
    public class RestClientSenderCommunicator : RestClientCommunicator, IRestClientSenderCommunicator
    {
        public RestClientSenderCommunicator(ILogger<RestClientSenderCommunicator> logger) : base(logger)
        {
        }
        protected RestClientSenderConnector RestClientSenderConnector
        {
            get { return (RestClientSenderConnector)Connector; }
        }
        public bool Send(InternalMessage message)
        {
            return SendAsync(message).GetAwaiter().GetResult(); 
        }

        private string PrepareCallAddress(string messageReceiverChannelId)
        {
            string path = $"{(((HttpRestClientConnector)Connector).BaseAddress + ((HttpRestClientConnector)Connector).Path)}";
            if (path.IndexOf("#RECEIVER_ID#") > -1)
            {
                string receiverId = string.Empty;
                if (!string.IsNullOrEmpty(messageReceiverChannelId))
                    receiverId = messageReceiverChannelId;
                else if (Connector is ITransportConnector transportConnector && !string.IsNullOrEmpty(transportConnector.ReceiverChannelId))
                    receiverId = transportConnector.ReceiverChannelId;
                path = path.Replace("#RECEIVER_ID#", receiverId);
            }
            return path;
        }

        protected bool _messageHeadersPrepaired = false;
        protected void PrepareMessageHeaders(InternalMessage message)
        {
            if (!_messageHeadersPrepaired || message.Headers.Count == 0)
            {
                if (RestClientSenderConnector.DynamicHeadersConfiguration != null)
                {
                    if (!RestClientSenderConnector.DynamicHeadersConfiguration.PassThroughAllHeaders)
                    {
                        foreach (var header in message.Headers.ToArray())
                        {
                            if (!RestClientSenderConnector.DynamicHeadersConfiguration.CustomHeaders.Contains(header.Key))
                            {
                                message.Headers.Remove(header.Key);
                            }
                        }
                    }
                    if (message is HttpMessage httpMessage)
                    {
                        if (RestClientSenderConnector.DynamicHeadersConfiguration.PassThroughAllHeaders)
                            foreach (var item in httpMessage.HttpHeaders)
                            {
                                message.Headers.Add(item.Key, item.Value);
                            }
                        else
                        {
                            foreach (var item in httpMessage.HttpHeaders)
                            {
                                if (RestClientSenderConnector.DynamicHeadersConfiguration.CustomHeaders.Split('|').Contains(item.Key))
                                    message.Headers.Add(item.Key, item.Value);
                            }
                        }
                    }
                }

                _messageHeadersPrepaired = true;
            }
        }
        public async virtual Task<bool> SendAsync(InternalMessage message)
        {
            InternalMessage responseMessage = new InternalMessage();

            responseMessage.AdditionalInfo = message.AdditionalInfo;
            responseMessage.Unique = message.Unique;
            bool sendResult = false;

            //15.11.2022 : Request parameters pasthrough ve diğer işlemlerde channel custom parametersdan alındı.

            PrepareMessageHeaders(message);

            if (((RestClientSenderConnector)this.Connector).PassThrough)
            {
                HttpCallResult<string> transparentResult = null;
                try
                {
                    transparentResult = await _transparentVerbInvoker.Invoke(message.InnerMessage, PrepareCallAddress(message.ReceiverChannelId), message.Headers, message.ChannelCustomParameters);

                    responseMessage.StatusCode = transparentResult.Result != null ? transparentResult.Result.StatusCode : HttpStatusCode.UnprocessableEntity;
                    responseMessage.InnerMessage = transparentResult.Response;
                    sendResult = checkResult(transparentResult);

                }
                catch (Exception ex)
                {
                    responseMessage.InnerMessage = ex.Message;
                    responseMessage.State = MessageState.Failed;
                    responseMessage.StatusCode = HttpStatusCode.InternalServerError;
                    _logger.LogError(ex, "{unique} | An error occured while sending over rest client sender. | {additionalMessage}", message.Unique, $"ErrorMessage:{ex.Message}");

                    sendResult = false;
                }

                if (transparentResult != null && transparentResult.Result != null)
                {
                    foreach (var header in transparentResult.Result.Headers)
                    {
                        responseMessage.Headers.TryAdd(header.Key, header.Value);
                    }
                }

                ((RestClientSenderConnector)this.Connector).FireMessageReceived(new MessageReceivedEventArgs(responseMessage));

                return sendResult;
            }
            else
            {
                HttpCallResult<InternalMessage> verbResult = null;
                try
                {
                    verbResult = await _verbInvoker.Invoke(message, PrepareCallAddress(message.ReceiverChannelId), message.Headers, message.ChannelCustomParameters);

                    if (verbResult != null)
                    {
                        if (verbResult.Response != null)
                        {
                            verbResult.Response.StatusCode = verbResult.Result.StatusCode;
                            verbResult.Response.Unique = message.Unique;
                            verbResult.Response.AdditionalInfo = message.AdditionalInfo;


                            if (verbResult.Result != null)
                            {
                                foreach (var header in verbResult.Result.Headers)
                                {
                                    verbResult.Response.Headers.TryAdd(header.Key, header.Value);
                                }
                            }
                        }
                        else if (verbResult.Result.IsSuccessStatusCode)
                        {
                            verbResult.Response = message;
                            verbResult.Response.OriginalMessage = verbResult.Response.InnerMessage;
                            verbResult.Response.InnerMessage = "";
                            verbResult.Response.StatusCode = verbResult.Result.StatusCode;
                            verbResult.Response.State = MessageState.Executed;
                        }
                        else
                        {
                            verbResult.Response.State = MessageState.ExecutionFailed;
                            message.FailReason = $"{message.Unique} | Status code not successful. | Status Code: {verbResult.Result.StatusCode.ToString()}";
                            _logger.LogWarning("{unique} | Status code not successful. | {additionalMessage}", message.Unique, $"Result:{JsonConvert.SerializeObject(verbResult.Result)}");

                        }
                    }

                    sendResult = checkResult(verbResult);

                    ((RestClientSenderConnector)this.Connector).FireMessageReceived(new MessageReceivedEventArgs(verbResult.Response));

                }
                catch (Exception ex)
                {
                    responseMessage.InnerMessage = ex.Message;
                    responseMessage.State = MessageState.Failed;
                    responseMessage.StatusCode = HttpStatusCode.InternalServerError;
                    _logger.LogError(ex, "{unique} | An error occured while sending over rest client sender. | {additionalMessage}", message.Unique, $"ErrorMessage:{ex.Message}");

                    if (verbResult != null && verbResult.Result != null)
                    {
                        foreach (var header in verbResult.Result.Headers)
                        {
                            responseMessage.Headers.TryAdd(header.Key, header.Value);
                        }
                    }

                    ((RestClientSenderConnector)this.Connector).FireMessageReceived(new MessageReceivedEventArgs(responseMessage));

                    sendResult = false;
                }

                return sendResult;
            }
        }

        private bool checkResult<T>(HttpCallResult<T> verbResult)
        {
            if (verbResult.Result.StatusCode == ((HttpRestClientConnector)Connector).SuccessResponseCode)
            {
                return true;
            }
            else
            {
                if (verbResult.Result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    IsUnAuthorized = true;
                }

                if (!verbResult.Result.IsSuccessStatusCode)
                {
                    _logger.LogWarning("{unique} | Status code not successful. | {additionalMessage}", LoggerUnique.CorfCore, $"Result:{JsonConvert.SerializeObject(verbResult.Result)}");
                }

            }
            return false;
        }
    }
}
