﻿using corf.Communication.HttpInfra;
using corf.Configuration;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
//using Utf8Json;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Net;

namespace corf.Communication.Rest.Client
{
    public class RestClientReceiverCommunicator : RestClientCommunicator, IRestClientReceiverCommunicator
    {
        private ConcurrentDictionary<HttpStatusCode, HttpMessageResult> _errorMessages = new ConcurrentDictionary<HttpStatusCode, HttpMessageResult>();
        public RestClientReceiverCommunicator(ILogger<RestClientReceiverCommunicator> logger) : base(logger)
        {
        }

        public bool ReadyForRead
        {
            get { return true; }
        }

        public async Task<InternalMessage> ReceiveMessage()
        {
            try
            {
                HttpCallResult<InternalMessage> verbResult = await _verbInvoker.Invoke(null, $"{((HttpRestClientConnector)Connector).BaseAddress}{((HttpRestClientConnector)Connector).Path}");

                if (!verbResult.Result.IsSuccessStatusCode)
                {
                    if (!_errorMessages.ContainsKey(verbResult.Result.StatusCode))
                    {
                        _logger.LogWarning("{unique} | Status code not successful. | {additionalMessage}", LoggerUnique.CorfCore, $"Result:{JsonConvert.SerializeObject(verbResult.Result)}");
                        _errorMessages.TryAdd(verbResult.Result.StatusCode, new HttpMessageResult { Date = DateTime.Now, Message = verbResult.Result, Occured = 1 });
                    }
                    else
                    {
                        _errorMessages[verbResult.Result.StatusCode].Occured++;
                        _logger.LogWarning("{unique} | An error while receiving message. | {additionalMessage}", LoggerUnique.CorfCore, $"Occured {_errorMessages[verbResult.Result.StatusCode].Occured} times and first occured at {_errorMessages[verbResult.Result.StatusCode].Date.ToString("dd.MM.yyyy HH:mm:ss")}");

                        if (_errorMessages[verbResult.Result.StatusCode].Occured > 100)
                        {
                            HttpMessageResult removableResult;
                            _errorMessages.TryRemove(verbResult.Result.StatusCode, out removableResult);

                            _logger.LogWarning("{unique} | Message removed from history. | {additionalMessage}", LoggerUnique.CorfCore,  $"Status code {verbResult.Result.StatusCode} occured 100 times and removed from history.");
                        }
                    }
                }
                else
                {
                    _errorMessages.Clear();
                }

                if (verbResult.Result.StatusCode == ((HttpRestClientConnector)Connector).SuccessResponseCode)
                {
                    return verbResult.Response;
                }

            }
                catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Error on message receiving. | {additionalMessage}", LoggerUnique.CorfCore, $"Connector Name :{this.Connector.Name}, ErrorMessage:{ex.Message}");

            }
            return null;
        }
    }
}
