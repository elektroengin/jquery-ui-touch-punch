﻿using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Rest.Client
{
    public abstract class RestClientConnector<T> : HttpRestClientConnector where T : ICommunicator
    {
        private readonly T _communicator;

        public RestClientConnector(ILogger logger, T communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, provider, requestScopeManager, settings)
        {
            _communicator = communicator;
        }

        protected override ICommunicator GetCommunicator()
        {
            return _communicator;
        }
    }
}
