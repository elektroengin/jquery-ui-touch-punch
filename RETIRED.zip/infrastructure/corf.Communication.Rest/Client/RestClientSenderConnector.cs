﻿using corf.Communication.HttpInfra.Rest;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Rest.Client
{
    public class RestClientSenderConnector : RestClientConnector<IRestClientSenderCommunicator>, IRestClientSenderConnector
    {
        public RestClientSenderConnector(ILogger<RestClientSenderConnector> logger, IRestClientSenderCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, communicator, provider, requestScopeManager, settings)
        {
        }

        [FlowDesign(DefaultValue = false, Description = "True when server side app is external or it only accepts inner message. If you need corf internalmessage headers, set it false")]
        public bool PassThrough { get; set; }

        [FlowDesign(Description = "DynamicHeadersConfiguration(if you want to send customer headers you can set PassThroughAllHeaders false)")]
        public DynamicHeadersConfiguration DynamicHeadersConfiguration { get; set; }

        [FlowDesign(DefaultValue = false, Description = "CarryAuthorizationHeader")]
        public bool CarryAuthorizationHeader { get; set; } = false;
    }
}
