﻿namespace corf.Communication.Rest.Client
{
    public class HttpMessageResult
    {
        public DateTime Date { get; set; }
        public int Occured { get; set; }
        public HttpResponseMessage Message { get; set; }
    }
}