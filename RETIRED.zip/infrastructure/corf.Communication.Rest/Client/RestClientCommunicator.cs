using corf.Communication.HttpInfra.Rest;
using corf.Configuration;
using corf.Core;
using corf.Core.Http;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;

namespace corf.Communication.Rest.Client
{
    public abstract class RestClientCommunicator
    {
        protected ILogger<RestClientCommunicator> _logger;
        protected readonly IServiceProvider ServiceProvider;

        protected HttpClient _client;

        public virtual bool IsUnAuthorized { get; internal set; }

        protected IVerbInvoker<InternalMessage, InternalMessage> _verbInvoker;
        protected IVerbInvoker<string, string> _transparentVerbInvoker;

        public RestClientCommunicator(ILogger<RestClientCommunicator> logger)
        {
            _logger = logger;
        }

        public virtual bool IsConnected { get { return true; } }

        public IConnector Connector { get; private set; }

        public bool Initialized { get; private set; }

        public virtual async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public virtual async Task<bool> ConnectAsync()
        {
            try
            {
                HttpRestClientConnector connector = (HttpRestClientConnector)Connector;
                Random random = new Random();

                ServicePointManager.ServerCertificateValidationCallback +=
                  (sender, cert, chain, sslPolicyErrors) => true;

                 _logger.LogInformation("{unique} | Binding to node... | {additionalMessage}", LoggerUnique.CorfCore, $"BaseAddress:{connector.BaseAddress}, Path:{connector.Path}");

                var indexByHosts = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                ServicePointManager.DefaultConnectionLimit = 2000;//configden okunacak
                var socketHttpHandler = new SocketsHttpHandler()
                {
                    Credentials = connector.CredentialsDeserialized != null ?
                                        new NetworkCredential(connector.CredentialsDeserialized.UserName, connector.CredentialsDeserialized.Password) : null,

                    PooledConnectionIdleTimeout = connector.PooledConnectionIdleTimeout == 0 ? TimeSpan.FromMinutes(2) : TimeSpan.FromMinutes(connector.PooledConnectionIdleTimeout),
                    PooledConnectionLifetime = connector.PooledConnectionLifetime == 0 ? TimeSpan.FromMinutes(2) : TimeSpan.FromMinutes(connector.PooledConnectionLifetime),
                    MaxConnectionsPerServer = connector.MaxConnectionsPerServer == 0 ? int.MaxValue : connector.MaxConnectionsPerServer,


                    ConnectCallback = async (context, cancellationToken) =>
                    {
                        IPAddress[] addresses = null;

                        if (Uri.CheckHostName(context.DnsEndPoint.Host) == UriHostNameType.Dns)
                        {
                           var  entry = await Dns.GetHostEntryAsync(context.DnsEndPoint.Host);

                            if (entry.AddressList.Length == 1)
                            {
                                addresses = entry.AddressList;
                            }
                            else
                            {
                                var index = indexByHosts.AddOrUpdate(
                                    key: entry.HostName,
                                    addValue: random.Next(),
                                    updateValueFactory: (host, existingValue) => existingValue + 1);

                                index %= entry.AddressList.Length;

                                if (index == 0)
                                {
                                    addresses = entry.AddressList;
                                }
                                else
                                {
                                    addresses = new IPAddress[entry.AddressList.Length];
                                    entry.AddressList.AsSpan(index).CopyTo(addresses);
                                    entry.AddressList.AsSpan(0, index).CopyTo(addresses.AsSpan(index));
                                }
                            }
                        }
                        else
                        {
                            addresses = new[] { IPAddress.Parse(context.DnsEndPoint.Host)};
                        }

                        var socket = new Socket(SocketType.Stream, ProtocolType.Tcp)
                        {
                            NoDelay = true
                        };

                        try
                        {
                            await socket.ConnectAsync(addresses, context.DnsEndPoint.Port, cancellationToken);
                            return new NetworkStream(socket, ownsSocket: true);
                        }
                        catch
                        {
                            socket.Dispose();
                            throw;
                        }
                    }
                };
                socketHttpHandler.SslOptions.RemoteCertificateValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                _client = new HttpClient(socketHttpHandler, disposeHandler: true);

                if (connector.CredentialsDeserialized != null && connector.AuthType == "B")
                {
                    _client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue(
                            "Basic",
                            Convert.ToBase64String(
                                System.Text.ASCIIEncoding.ASCII.GetBytes(
                                    string.Format("{0}:{1}", connector.CredentialsDeserialized.UserName, connector.CredentialsDeserialized.Password))));
                }

                if (connector.TimeOut > 0)
                {
                    _client.Timeout = new TimeSpan(connector.TimeOut * 10000);
                }

                _client.BaseAddress = new Uri(connector.BaseAddress);
                _client.DefaultRequestHeaders.Accept.Clear();

                _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(connector.Type) { CharSet = Encoding.UTF8.WebName });

                if (string.IsNullOrWhiteSpace(connector.Headers) == false)
                {
                    foreach (var headerInfo in connector.Headers.Split('|'))
                    {
                        _client.DefaultRequestHeaders.Add(headerInfo.Split('=')[0], headerInfo.Split('=')[1]);
                    }
                }

                var endpointInfo = new RestServiceEndPointInfo()
                {
                  Type = connector.Type,
                };

                _verbInvoker = new VerbInvoker<InternalMessage, InternalMessage>(_client, _logger, endpointInfo);
                _transparentVerbInvoker = new VerbInvoker<string, string>(_client, _logger, endpointInfo);

                _verbInvoker.Verb = ((HttpRestClientConnector)Connector).Verb;
                _transparentVerbInvoker.Verb = ((HttpRestClientConnector)Connector).Verb;

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "{unique} | Start failed with GeneralException. | {additionalMessage}", LoggerUnique.CorfCore, $"ErrorMessage :{ex.Message}");

                return false;
            }

            finally
            {
                Initialized = true;
            }
        }

        public virtual void GetReady()
        {
            //When connection succeed it is already be connected
        }

        public void Initialize(Connector genericConnector)
        {
            Connector = genericConnector;
        }
    }
}
