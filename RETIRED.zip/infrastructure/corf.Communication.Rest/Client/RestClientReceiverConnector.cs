﻿using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Rest.Client
{
    public class RestClientReceiverConnector : RestClientConnector<IRestClientReceiverCommunicator>
    {
        public RestClientReceiverConnector(ILogger<RestClientReceiverConnector> logger, IRestClientReceiverCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, communicator, provider, requestScopeManager, settings)
        {
        }
    }
}
