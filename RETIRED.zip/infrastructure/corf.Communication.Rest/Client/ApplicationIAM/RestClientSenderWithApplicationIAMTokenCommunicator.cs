﻿using Confluent.Kafka;
using corf.Caching;
using corf.Communication.HttpInfra;
using corf.Communication.Rest.Client.ApplicationIAM.ApplicationIAM;
using corf.Communication.Rest.Client.ApplicationIAM.Util;
using corf.Configuration;
using corf.Core;
using corf.Core.Messaging;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.Rest.Client.ApplicationIAM
{
    public class RestClientSenderWithApplicationIAMTokenCommunicator : RestClientSenderCommunicator, IRestClientSenderWithApplicationIAMTokenCommunicator
    {
        private readonly ApplicationIAMTokenServiceCaller _applicationIAMTokenServiceCaller;
        private readonly ICacheManager _cacheManager;
        private readonly ILogger<RestClientSenderWithApplicationIAMTokenCommunicator> logger;
        private ConcurrentDictionary<HttpStatusCode, HttpMessageResult> _errorMessages = new ConcurrentDictionary<HttpStatusCode, HttpMessageResult>();
        public RestClientSenderWithApplicationIAMTokenCommunicator(ILogger<RestClientSenderWithApplicationIAMTokenCommunicator> logger, ICacheManager cacheManager, ApplicationIAMTokenServiceCaller applicationIAMTokenServiceCaller) : base(logger)
        {
            _applicationIAMTokenServiceCaller = applicationIAMTokenServiceCaller;
            _cacheManager = cacheManager;
        }
        protected RestClientSenderWithApplicationIAMTokenConnector RestClientSenderApplicationIAMTokenConnector
        {
            get { return (RestClientSenderWithApplicationIAMTokenConnector)Connector; }
        }

        public override async Task<bool> SendAsync(InternalMessage message)
        {
            if (!RestClientSenderApplicationIAMTokenConnector.CarryAuthorizationHeader)
            {
                IAMTokenCreateResponse? _tokenResponse = _cacheManager.Get<IAMTokenCreateResponse?>(RestClientSenderApplicationIAMTokenConnector.IAMConfiguration.CacheKeyName, CacheType.Both);

                PrepareMessageHeaders(message);

                if (_tokenResponse == null || _tokenResponse.expireDate < DateTime.Now.AddMilliseconds(100))
                {
                    _applicationIAMTokenServiceCaller.Initialize(JObject.FromObject(RestClientSenderApplicationIAMTokenConnector.IAMConfiguration.TokenGeneratorService));
                    var callResult = _applicationIAMTokenServiceCaller.Call(RestClientSenderApplicationIAMTokenConnector.IAMConfiguration.CreateRequest).Result;
                    callResult.Response.expireDate = DateTime.Now.AddMilliseconds(callResult.Response.expires_in);
                    _tokenResponse = callResult.Response;
                    _cacheManager.Set(RestClientSenderApplicationIAMTokenConnector.IAMConfiguration.CacheKeyName, _tokenResponse, _tokenResponse.expires_in, _tokenResponse.expires_in, CacheType.Both);
                }
                message.Headers["Authorization"] = $"Bearer {_tokenResponse.access_token}";
            }
              
            return await base.SendAsync(message);
        }
    }
}
