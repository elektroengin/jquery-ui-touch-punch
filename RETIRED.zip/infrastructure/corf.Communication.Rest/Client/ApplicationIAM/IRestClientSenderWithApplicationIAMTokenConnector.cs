﻿using corf.Communication.HttpInfra.Rest;
using corf.Communication.Rest.Client.ApplicationIAM.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.Rest.Client.ApplicationIAM
{
    public interface IRestClientSenderWithApplicationIAMTokenConnector: IRestClientSenderConnector
    {
        IAMConfiguration IAMConfiguration { get; set; }
        bool PassThrough { get; set; }
    }
}
