﻿using corf.Communication.HttpInfra.Rest;
using corf.Communication.Rest.Client.ApplicationIAM.Util;
using corf.Configuration;
using corf.Core;
using corf.Core.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.Rest.Client.ApplicationIAM
{
    public class RestClientSenderWithApplicationIAMTokenConnector: RestClientSenderConnector, IRestClientSenderWithApplicationIAMTokenConnector 
    {
        public RestClientSenderWithApplicationIAMTokenConnector(ILogger<RestClientSenderWithApplicationIAMTokenConnector> logger, IRestClientSenderWithApplicationIAMTokenCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager, IOptions<ServiceSettings> settings) : base(logger, communicator, provider, requestScopeManager, settings)
        {
        }

        [FlowDesign(DefaultValue = false, Description = "IAMConfiguration")]
        public IAMConfiguration IAMConfiguration { get; set; } = new IAMConfiguration();
    }
}
