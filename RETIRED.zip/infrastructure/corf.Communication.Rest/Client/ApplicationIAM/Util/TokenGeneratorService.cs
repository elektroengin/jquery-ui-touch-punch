﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Communication.Rest.Client.ApplicationIAM.Util
{
 
    public class TokenGeneratorService
    {
        [JsonConstructor]
        public TokenGeneratorService()
        {

        }

        public string baseAddress { get; set; }
        public string path { get; set; }
        public string verb { get; set; }
        public string type { get; set; }
        public int connectionCount { get; set; }
        public string authType { get; set; }
        public string serviceType { get; set; }
        public int timeOut { get; set; }
    }
}
