﻿
using Newtonsoft.Json;

namespace corf.Communication.Rest.Client.ApplicationIAM.Util
{
    public class IAMTokenCreateRequest
    {
        [JsonConstructor]
        public IAMTokenCreateRequest()
        {

        }
        public string grant_type { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
