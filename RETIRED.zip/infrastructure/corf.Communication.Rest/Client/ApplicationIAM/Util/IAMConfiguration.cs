﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace corf.Communication.Rest.Client.ApplicationIAM.Util
{
    public class IAMConfiguration
    {
        [JsonConstructor]
        public IAMConfiguration()
        {

        }
        public TokenGeneratorService TokenGeneratorService { get; set; }
        public IAMTokenCreateRequest CreateRequest { get; set; }

        public string CacheKeyName { get; set; } = "ApplicationIAMTokenService";
    }
}
