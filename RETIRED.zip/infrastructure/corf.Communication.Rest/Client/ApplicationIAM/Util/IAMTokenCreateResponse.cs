﻿using Newtonsoft.Json;

namespace corf.Communication.Rest.Client.ApplicationIAM.Util
{
    public class IAMTokenCreateResponse
    {
        public string access_token { get; set; }
        public int expires_in { get; set; }
        public int refresh_expires_in { get; set; }
        public string refresh_token { get; set; }
        public string token_type { get; set; }

        [JsonProperty("not-before-policy")]
        public string not_before_policy { get; set; }
        public string session_state { get; set; }
        public string scope { get; set; }
        public DateTime expireDate { get; set; } = DateTime.Now;
    }
}
