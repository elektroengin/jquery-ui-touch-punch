﻿using corf.Communication.Rest.Client.ApplicationIAM.Util;
using corf.Communication.ServiceCaller;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Steeltoe.Management.Endpoint.Trace;

namespace corf.Communication.Rest.Client.ApplicationIAM.ApplicationIAM
{
    public class ApplicationIAMTokenServiceCaller : GenericServiceCaller<IAMTokenCreateRequest, IAMTokenCreateResponse>
    {
        private ILogger<ApplicationIAMTokenServiceCaller> logger;

        public void Initialize(JObject endPointInfo)
        {
            this.Initialize(endPointInfo, logger);
        }

        public ApplicationIAMTokenServiceCaller(ILogger<ApplicationIAMTokenServiceCaller> logger)
        {
            this.logger = logger;
              
        }
    }
}
