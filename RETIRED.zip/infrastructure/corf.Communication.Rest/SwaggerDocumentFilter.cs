﻿using corf.Configuration;
using corf.Core.Routing;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using System.Text.RegularExpressions;
using corf.Core.Messaging;
using Microsoft.AspNetCore.Http;
using corf.Communication.Rest.Server;
using System.Reflection;
using System.ComponentModel;
using System.Diagnostics;
using corf.Communication.HttpInfra.Rest;
using corf.Communication.HttpInfra;
using Microsoft.Diagnostics.Tracing.Parsers.Kernel;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.ComponentModel.DataAnnotations;
using System.Numerics;
using corf.Core.Http;
using Microsoft.AspNetCore.Http.Features.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace corf.Communication.Rest
{
    public class SwaggerDocumentFilter : IDocumentFilter
    {
        IConfigurator _configurator;
        ISwaggerPath _swaggerPath;
        private readonly string _swaggerDocHost;
        private bool _runOnLocal;
        private IServiceProvider _serviceProvider;
        private string _entryAssembly;
        public SwaggerDocumentFilter(IHttpContextAccessor httpContextAccessor, IConfigurator configurator, ISwaggerPath swaggerPath, IServiceProvider serviceProvider)
        {
            _runOnLocal = Debugger.IsAttached;
            _configurator = configurator;
            _swaggerPath = swaggerPath;
            var host = _runOnLocal ? httpContextAccessor.HttpContext.Request.Host.Value : httpContextAccessor.HttpContext.Request.Host.Host;
            var scheme = _runOnLocal ? "http" : "https";
            _swaggerDocHost = $"{scheme}://{host}";
            _serviceProvider = serviceProvider;
            _entryAssembly = Assembly.GetEntryAssembly().GetName().Name;
        }

        public void Apply2(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {
            swaggerDoc.Servers.Add(new OpenApiServer { Url = _swaggerDocHost });

            foreach (var path in _swaggerPath.Connector.Paths)
            {
                var operations = new Dictionary<OperationType, OpenApiOperation>();

                path.ServiceProvider = _serviceProvider;

                foreach (var verb in path.Verbs)
                {
                    var acceptAttribute = verb.Executer?.GetType().GetCustomAttribute<RequestPayloadAttribute>();

                    var returnAttribute = verb.Executer?.GetType().GetCustomAttribute<ResponsePayloadAttribute>();

                    verb.RequestPayloadType = acceptAttribute?.Type;

                    verb.ResponsePayloadType = returnAttribute?.Type;

                    var responsePayloadTypeFriendlyName = getTypeFriendlyName(verb.ResponsePayloadType);


                    List<OpenApiParameter> openApiParameters = new List<OpenApiParameter>();


                    if (verb.OperationType != OperationType.Get)
                    {


                        if (verb.RequestPayloadType != null)
                        {
                            var openApiSchema = context.SchemaGenerator.GenerateSchema(verb.RequestPayloadType, context.SchemaRepository);

                            if (!swaggerDoc.Components.Schemas.ContainsKey(verb.RequestPayloadType.Name))
                            {
                                swaggerDoc.Components.Schemas.Add(verb.RequestPayloadType.Name, openApiSchema);
                            }

                        }
                        else if (_swaggerPath.Connector.InternalPayload)
                        {
                            var openApiSchema = context.SchemaGenerator.GenerateSchema(typeof(InternalMessage), context.SchemaRepository);

                            if (!swaggerDoc.Components.Schemas.ContainsKey(typeof(InternalMessage).Name))
                            {
                                swaggerDoc.Components.Schemas.Add(typeof(InternalMessage).Name, openApiSchema);
                            }
                        }
                    }
                    else
                    {

                        foreach (PropertyInfo property in verb.RequestPayloadType?.GetProperties()
                            .Where(x => x.GetCustomAttributes().All(y => y.GetType().Name != "JsonIgnoreAttribute")))
                        {
                            string dscr = property.GetCustomAttribute<DescriptionAttribute>() is not null ? property.GetCustomAttribute<DescriptionAttribute>().Description : "No description";
                            openApiParameters.Add(new OpenApiParameter
                            {
                                Name = property.Name,
                                Description = dscr,
                                In = ParameterLocation.Query,
                                Schema = getParameterSchema(property.PropertyType, swaggerDoc, context)
                            });
                        }
                    }

                    if (verb.ResponsePayloadType != null)
                    {
                        var openApiSchema = context.SchemaGenerator.GenerateSchema(verb.ResponsePayloadType, context.SchemaRepository);

                        if (!swaggerDoc.Components.Schemas.ContainsKey(responsePayloadTypeFriendlyName))
                            swaggerDoc.Components.Schemas.Add(responsePayloadTypeFriendlyName, openApiSchema);

                    }


                    OpenApiRequestBody openApiRequestBody = null;

                    if (verb.RequestPayloadType != null && verb.OperationType != OperationType.Get)
                    {
                        //TODO Kübra content typelar dynamic alınmalı formda,xmlde falan patlar

                        openApiRequestBody = new OpenApiRequestBody
                        {
                            Description = "Required",
                            Required = true,
                            Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id =   verb.RequestPayloadType.Name } } } }
                            }
                        };
                    }
                    else if (_swaggerPath.Connector.InternalPayload)
                    {
                        openApiRequestBody = new OpenApiRequestBody
                        {
                            Description = "Required",
                            Required = true,
                            Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id =   typeof(InternalMessage).Name } } } }
                            }
                        };
                    }

                    OpenApiResponses openApiResponses = new OpenApiResponses
                    {
                        ["200"] = new OpenApiResponse
                        {
                            Description = "OK",
                            Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id = verb.ResponsePayloadType != null ? responsePayloadTypeFriendlyName : "" } } } }
                            }
                        },
                        ["201"] = new OpenApiResponse
                        {
                            Description = "Created",
                            Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id = verb.ResponsePayloadType != null ? responsePayloadTypeFriendlyName : "" } } } }
                            }
                        }
                        //TODO Kübra diğer status kodlar ve response typelar eklenebilir default
                    };

                    operations.Add(verb.OperationType,
                                new OpenApiOperation()
                                {
                                    Summary = verb.Summary,
                                    Description = verb.Description,
                                    RequestBody = openApiRequestBody,
                                    Parameters = openApiParameters,
                                    Responses = openApiResponses,


                                }
                            );
                }

                swaggerDoc.Paths.Add($"/{path.Uri}", new OpenApiPathItem
                {
                    Operations = operations

                });

            }

        }
        public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {

            swaggerDoc.Servers.Add(new OpenApiServer { Url = _swaggerDocHost });

            foreach (var path in _swaggerPath.Connector.Paths)
            {
                var operations = new Dictionary<OperationType, OpenApiOperation>();

                path.ServiceProvider = _serviceProvider;

                foreach (var verb in path.Verbs)
                {
                    OpenApiRequestBody openApiRequestBody = null;
                    OpenApiResponses openApiResponses = null;
                    OpenApiTag tag = null;

                    var requestPayloadAttribute = verb.Executer?.GetType().GetCustomAttribute<RequestPayloadAttribute>();
                    var responsePayloadAttributes = verb.Executer?.GetType().GetCustomAttributes<ResponsePayloadAttribute>();

                    verb.RequestPayloadType = requestPayloadAttribute?.Type;

                    //Generate Schemas
                    GenerateSchemas(verb, swaggerDoc, context, requestPayloadAttribute, responsePayloadAttributes, _entryAssembly);

                    //Generate Get request parameters
                    var openApiParameters = new List<OpenApiParameter>();


                    if (verb.RequestPayloadType != null)
                    {
                        //Generate API Request Body
                        openApiRequestBody = GenerateAPIRequestBody(verb, _swaggerPath);

                    }

                    //Generate Security Scheme
                    OpenApiSecurityRequirement securityScheme = GenerateSecurityScheme(path, verb, swaggerDoc);


                    //Generate API Request Parameters 
                    openApiParameters = GenerateRequestParameters(verb, context);

                    if (responsePayloadAttributes != null && responsePayloadAttributes.Any())
                    {
                        //Generate API Responses
                        openApiResponses = GenerateOpenAPIResponse(responsePayloadAttributes);

                    }

                    tag = GenerateTags(path, _swaggerPath);



                    operations.Add(verb.OperationType,
                                new OpenApiOperation()
                                {
                                    Tags = tag != null ? new List<OpenApiTag> { tag } : null,
                                    Summary = verb.Summary,
                                    Description = verb.Description,
                                    RequestBody = openApiRequestBody,
                                    Parameters = openApiParameters,
                                    Responses = openApiResponses,
                                    OperationId = verb.ExecuterName,
                                    Security = securityScheme != null ? new List<OpenApiSecurityRequirement> { securityScheme } : new List<OpenApiSecurityRequirement>(),

                                }
                            );
                }

                if (_swaggerPath.Connector.Tags != null && _swaggerPath.Connector.Tags.Length > 0)
                    swaggerDoc.Tags = _swaggerPath.Connector.Tags.Select(i => new OpenApiTag { Name = i.Name, Description = i.Description }).ToList();

                swaggerDoc.Paths.Add($"/{path.Uri}", new OpenApiPathItem
                {
                    Operations = operations,

                });


            }

        }

        private OpenApiSecurityRequirement GenerateSecurityScheme(PathInfo pathInfo, PathVerb verb, OpenApiDocument swaggerDoc)
        {
            if (pathInfo.Authorization?.ToLowerInvariant() == "bearer" || pathInfo.Authorization?.ToLowerInvariant() == "basic")
            {
                return new OpenApiSecurityRequirement
                {
                    {
                      new OpenApiSecurityScheme
                        {
                            Description = @"Bearer IAM Token should be filled",
                            Name = "Authorization",
                            In = ParameterLocation.Header,
                            Type = SecuritySchemeType.ApiKey,
                            Scheme = "Bearer",
                            Reference = new OpenApiReference
                            {
                                Id = JwtBearerDefaults.AuthenticationScheme,
                                Type = ReferenceType.SecurityScheme
                            }
                        },
                        new List<string>()
                    }
                };
            }

            return null;
        }

        private OpenApiTag GenerateTags(PathInfo path, ISwaggerPath swaggerPath)
        {
            OpenApiTag openApiTag = null;
            if (!string.IsNullOrWhiteSpace(path.Tags) && _swaggerPath.Connector.Tags != null && _swaggerPath.Connector.Tags.Any(i => i.Name == path.Tags))
            {
                openApiTag = new OpenApiTag()
                {
                    Name = _swaggerPath.Connector.Tags.First(i => i.Name == path.Tags).Name,
                    Description = _swaggerPath.Connector.Tags.First(i => i.Name == path.Tags).Description
                };
            }
            return openApiTag;
        }

        private OpenApiResponses GenerateOpenAPIResponse(IEnumerable<ResponsePayloadAttribute>? responsePayloadAttributes)
        {
            OpenApiResponses openApiResponses = new OpenApiResponses();

            foreach (var responsePayloadAttribute in responsePayloadAttributes)
            {

                openApiResponses.Add(((int)responsePayloadAttribute.StatusCode).ToString(), new OpenApiResponse
                {
                    Description = !string.IsNullOrWhiteSpace(responsePayloadAttribute.Description) ? responsePayloadAttribute.Description : responsePayloadAttribute.StatusCode.ToString(),
                    Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema,  Id =  responsePayloadAttribute.Type.FullName?.Replace("+", ".")} } } }
                            },

                });

            }

            return openApiResponses;
        }

        private OpenApiRequestBody GenerateAPIRequestBody(PathVerb verb, ISwaggerPath swaggerPath)
        {
            OpenApiRequestBody openApiRequestBody = null;

            if (verb.RequestPayloadType != null)
            {
                if (_swaggerPath.Connector.InternalPayload)
                {
                    openApiRequestBody = new OpenApiRequestBody
                    {
                        Description = "Required",
                        Required = true,
                        Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id = $"{_entryAssembly}.{typeof(InternalMessage).Name}"} } } }
                            }
                    };
                }
                else
                {
                    if (verb.OperationType != OperationType.Get)
                    {
                        openApiRequestBody = new OpenApiRequestBody
                        {
                            Description = "Required",
                            Required = true,
                            Content = new Dictionary<string, OpenApiMediaType>
                            {
                                { "application/json", new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id =  $"{_entryAssembly}.{verb.RequestPayloadType.Name }"} } } }
                            }
                        };
                    }
                }

            }

            return openApiRequestBody;
        }

        private void GenerateSchemas(PathVerb verb, OpenApiDocument swaggerDoc, DocumentFilterContext context, RequestPayloadAttribute? requestPayloadAttribute, IEnumerable<ResponsePayloadAttribute>? responsePayloadAttributes, string? entryAssembly)
        {
            // Generate Request Schemas
            if (verb.RequestPayloadType != null)
            {
                SchemaGenerationForRequestPayload(verb, swaggerDoc, context, entryAssembly);
            }

            //Generate Response Schemas
            if (responsePayloadAttributes != null && responsePayloadAttributes.Any())
            {
                foreach (var responsePayloadAttribute in responsePayloadAttributes)
                {
                    SchemaGenerationForResponsePayload(verb, responsePayloadAttribute.Type, swaggerDoc, context, entryAssembly);
                }
            }

        }

        private static void SchemaGenerationForResponsePayload(PathVerb verb, Type responsePayloadType, OpenApiDocument swaggerDoc, DocumentFilterContext context, string entryAssembly)
        {

            var openApiSchema = context.SchemaGenerator.GenerateSchema(responsePayloadType, context.SchemaRepository);

            if (!swaggerDoc.Components.Schemas.ContainsKey(entryAssembly + "." + responsePayloadType.Name))
                swaggerDoc.Components.Schemas.Add(entryAssembly + "." + responsePayloadType.Name, openApiSchema);

        }

        private void SchemaGenerationForRequestPayload(PathVerb verb, OpenApiDocument swaggerDoc, DocumentFilterContext context, string entryAssembly)
        {

            if (verb.OperationType != OperationType.Get)
            {
                if (verb.RequestPayloadType != null)
                {

                    var openApiSchema = context.SchemaGenerator.GenerateSchema(verb.RequestPayloadType, context.SchemaRepository);

                    if (!swaggerDoc.Components.Schemas.ContainsKey($"{entryAssembly}.{verb.RequestPayloadType.Name}"))
                    {
                        swaggerDoc.Components.Schemas.Add($"{entryAssembly}.{verb.RequestPayloadType.Name}", openApiSchema);
                    }
                }
                else if (_swaggerPath.Connector.InternalPayload)
                {
                    var openApiSchema = context.SchemaGenerator.GenerateSchema(typeof(InternalMessage), context.SchemaRepository);

                    if (!swaggerDoc.Components.Schemas.ContainsKey($"{entryAssembly}.{typeof(InternalMessage).Name}"))
                    {
                        swaggerDoc.Components.Schemas.Add($"{entryAssembly}.{typeof(InternalMessage).Name}", openApiSchema);
                    }
                }
            }

        }


        private static OpenApiParameter GenerateOpenApiParameter(DocumentFilterContext context, PropertyInfo property, ParameterLocation parameterLocation)
        {
            var openApiParameter = new OpenApiParameter() { Name = property.Name, Description = "No description", In = parameterLocation };
            var apiParameterSchema = context.SchemaGenerator.GenerateSchema(property.PropertyType, context.SchemaRepository);
            var propertyAtributes = property.GetCustomAttributes();



            if (propertyAtributes.Any())
            {
                foreach (var attribute in propertyAtributes)
                {
                    if (attribute is JsonPropertyAttribute)
                    {
                        openApiParameter.Name = ((JsonPropertyAttribute)attribute).PropertyName;
                    }
                    else if (attribute is JsonPropertyNameAttribute)
                    {
                        openApiParameter.Name = ((JsonPropertyNameAttribute)attribute).Name;
                    }

                    else if (attribute is DescriptionAttribute)
                    {
                        apiParameterSchema.Description = ((DescriptionAttribute)attribute).Description;
                    }
                    else if (attribute is RequiredAttribute)
                    {
                        openApiParameter.Required = true;
                        apiParameterSchema.Required = new HashSet<string> { "true" };
                    }
                    else if (attribute is MaxLengthAttribute)
                    {
                        apiParameterSchema.MaxLength = ((MaxLengthAttribute)attribute).Length; ;
                    }
                    else if (attribute is MinLengthAttribute)
                    {
                        apiParameterSchema.MinLength = ((MinLengthAttribute)attribute).Length; ;
                    }
                    else if (attribute is RangeAttribute)
                    {
                        apiParameterSchema.Minimum = Convert.ToDecimal(((RangeAttribute)attribute).Minimum);
                        apiParameterSchema.Maximum = Convert.ToDecimal(((RangeAttribute)attribute).Maximum);
                    }
                    else if (attribute is RangeAttribute)
                    {
                        apiParameterSchema.Minimum = Convert.ToDecimal(((RangeAttribute)attribute).Minimum);
                        apiParameterSchema.Maximum = Convert.ToDecimal(((RangeAttribute)attribute).Maximum);
                    }
                    else if (attribute is StringLengthAttribute)
                    {
                        apiParameterSchema.MinLength = ((StringLengthAttribute)attribute).MinimumLength;
                        apiParameterSchema.MaxLength = ((StringLengthAttribute)attribute).MaximumLength;
                    }
                    else if (attribute is MinLengthAttribute)
                    {
                        apiParameterSchema.MinLength = ((MinLengthAttribute)attribute).Length;

                    }
                    else if (attribute is MaxLengthAttribute)
                    {
                        apiParameterSchema.MaxLength = ((MaxLengthAttribute)attribute).Length;

                    }
                    else if (attribute is RegularExpressionAttribute)
                    {
                        apiParameterSchema.Pattern = ((RegularExpressionAttribute)attribute).Pattern;

                    }
                }

                openApiParameter.Schema = apiParameterSchema;

            }
            return openApiParameter;
        }

        private static List<OpenApiParameter> GenerateRequestParameters(PathVerb verb, DocumentFilterContext context)
        {
            List<OpenApiParameter> openApiParameters = null;


            var queryParametersAttribute = verb.Executer?.GetType().GetCustomAttribute<QueryParametersAttribute>();
            var pathParametersAttribute = verb.Executer?.GetType().GetCustomAttribute<PathParametersAttribute>();
            var headerParametersAttribute = verb.Executer?.GetType().GetCustomAttribute<HeaderParametersAttribute>();

            if (queryParametersAttribute != null || pathParametersAttribute != null)
            {
                openApiParameters = new List<OpenApiParameter>();

                headerParametersAttribute?.Type.GetProperties().ToList().ForEach(p =>
                {

                    openApiParameters.Add(GenerateOpenApiParameter(context, p, ParameterLocation.Header));
                });

                queryParametersAttribute?.Type.GetProperties().ToList().ForEach(p =>
                {

                    openApiParameters.Add(GenerateOpenApiParameter(context, p, ParameterLocation.Query));
                });

                pathParametersAttribute?.Type.GetProperties().ToList().ForEach(p =>
                {

                    openApiParameters.Add(GenerateOpenApiParameter(context, p, ParameterLocation.Path));
                });



            }
            return openApiParameters;
        }


        private string getTypeFriendlyName(Type type)
        {
            if (type == null)
                return null;

            string friendlyName = type.Name;
            if (type.IsGenericType)
            {
                int iBacktick = friendlyName.IndexOf('`');
                if (iBacktick > 0)
                {
                    friendlyName = friendlyName.Remove(iBacktick);
                }
                friendlyName += "_";
                Type[] typeParameters = type.GetGenericArguments();
                for (int i = 0; i < typeParameters.Length; ++i)
                {
                    string typeParamName = getTypeFriendlyName(typeParameters[i]);
                    friendlyName += (i == 0 ? typeParamName : "_" + typeParamName);
                }
                friendlyName += "_";
            }

            return friendlyName;
        }

        private OpenApiSchema getParameterSchema(Type parameterType, OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {
            var schema = new OpenApiSchema();
            if (parameterType == typeof(int))
            {
                schema.Type = "integer";
                schema.Format = "int32";
            }
            else if (parameterType == typeof(long))
            {
                schema.Type = "integer";
                schema.Format = "int64";
            }
            else if (parameterType == typeof(double) || parameterType == typeof(decimal))
            {
                schema.Type = "number";
                schema.Format = "double";
            }
            else if (parameterType == typeof(bool))
            {
                schema.Type = "boolean";
            }
            else if (parameterType == typeof(DateTime))
            {
                schema.Type = "string";
                schema.Format = "date-time";
            }
            else if (parameterType == typeof(string))
            {
                schema.Type = "string";
            }
            else if (parameterType.IsEnum)
            {
                var openApiSchema = context.SchemaGenerator.GenerateSchema(parameterType, context.SchemaRepository);

                if (!swaggerDoc.Components.Schemas.ContainsKey(openApiSchema.Reference.Id))
                    swaggerDoc.Components.Schemas.Add(openApiSchema.Reference.Id, openApiSchema);


                schema.Reference = new OpenApiReference()
                {
                    Id = openApiSchema.Reference.Id,
                    Type = ReferenceType.Schema
                };
            }
            else if (parameterType.IsArray)
            {
                schema.Type = "array";
                schema.Items = getParameterSchema(parameterType.GetElementType(), swaggerDoc, context);
            }
            else if (parameterType.IsGenericType && parameterType.GetGenericTypeDefinition() == typeof(List<>))
            {
                schema.Type = "array";
                schema.Items = getParameterSchema(parameterType.GetGenericArguments().First(), swaggerDoc, context);
            }
            else if (parameterType.IsGenericType && parameterType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                schema = getParameterSchema(parameterType.GetGenericArguments().First(), swaggerDoc, context);
                schema.Nullable = true;
            }
            else if (!parameterType.IsValueType && parameterType.IsClass && !parameterType.IsPrimitive)
            {
                var openApiSchema = context.SchemaGenerator.GenerateSchema(parameterType, context.SchemaRepository);

                if (!swaggerDoc.Components.Schemas.ContainsKey(openApiSchema.Reference.Id))
                    swaggerDoc.Components.Schemas.Add(openApiSchema.Reference.Id, openApiSchema);

                schema.Reference = new OpenApiReference()
                {
                    Id = openApiSchema.Reference.Id,
                    Type = ReferenceType.Schema
                };
            }
            else
            {
                return null;
            }

            return schema;
        }


    }
}