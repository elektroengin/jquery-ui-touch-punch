﻿using corf.Core;
using corf.Core.Hosting;
using corf.Core.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace corf.Communication.Pipe
{
    public class PipeConnector : TransportConnector, IPipeConnector
    {
        private readonly IPipeCommunicator _communicator;

        public PipeConnector(ILogger<PipeConnector> logger, IPipeCommunicator communicator, IServiceProvider provider, IRequestScopeManager requestScopeManager) : base(logger, provider, requestScopeManager)
        {
            _communicator = communicator;
        }

        public override ICommunicator CommunicatorInstance { get { return _communicator; } }

        public override string ChannelDescription { get { return "PipeConnector"; } }
    }
}
