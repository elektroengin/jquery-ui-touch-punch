﻿namespace corf.Communication.Pipe
{
    internal interface IPipeConnector
    {
    }
}