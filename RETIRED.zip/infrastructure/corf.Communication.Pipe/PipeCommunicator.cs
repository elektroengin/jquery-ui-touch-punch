﻿using corf.Core;
using corf.Core.Messaging;

namespace corf.Communication.Pipe
{
    public class PipeCommunicator : IPipeCommunicator
    {
        public bool IsConnected { get { return true; } }

        public IConnector Connector { get; private set; }

        public bool Initialized { get { return true; } }

        public async Task<bool> CloseAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> ConnectAsync()
        {
            return await Task.FromResult(true);
        }

        public void GetReady()
        {
        }

        public void Initialize(Connector connector)
        {
            this.Connector = connector;
        }

        public bool Send(InternalMessage message)
        {
            return true;
        }

        public async Task<bool> SendAsync(InternalMessage message)
        {
            return await Task.FromResult(true);
        }
    }
}
