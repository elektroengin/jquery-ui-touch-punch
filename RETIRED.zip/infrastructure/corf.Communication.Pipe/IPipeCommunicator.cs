﻿using corf.Core.Infrastructure;

namespace corf.Communication.Pipe
{
    public interface IPipeCommunicator : IMessageSender
    {
    }
}