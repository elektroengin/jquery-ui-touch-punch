﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using corf.Caching.InMemory;

namespace corf.Caching
{
    public class CacheManager : ICacheManager
    {
        private readonly IMemoryCacheService memoryCacheService;
        private readonly ICacheService cacheService;

        public CacheManager(
            IMemoryCacheService memoryCacheService,
            ICacheService cacheService)
        {
            this.memoryCacheService = memoryCacheService;
            this.cacheService = cacheService;
        }

        public T? Get<T>(string key, CacheType cacheType = CacheType.Redis)
        {
            try
            {
                switch (cacheType)
                {
                    case CacheType.Redis:
                        return cacheService.Get<T>(key);

                    case CacheType.InMemory:
                        return memoryCacheService.Get<T>(key);

                    case CacheType.Both:
                        return memoryCacheService.Get<T>(key) ?? cacheService.Get<T>(key);

                    default:
                        return default;
                }
            }
            catch (Exception)
            {
                return default;
            }
        }

        public T? Set<T>(string key, T value, double absoluteExpiration, double slidingExpiration, CacheType cacheType = CacheType.Redis)
        {
            try
            {
                switch (cacheType)
                {
                    case CacheType.Redis:
                        return cacheService.Set(key, value, absoluteExpiration, slidingExpiration);

                    case CacheType.InMemory:
                        return memoryCacheService.Set(key, value, absoluteExpiration);

                    case CacheType.Both:
                        cacheService.Set(key, value, absoluteExpiration, slidingExpiration);
                        memoryCacheService.Set(key, value, absoluteExpiration);

                        return value;

                    default:
                        return value;
                }
            }
            catch (Exception)
            {
                return value;
            }
        }

        public bool Remove(string key, CacheType cacheType = CacheType.Redis)
        {
            try
            {
                switch (cacheType)
                {
                    case CacheType.Redis:
                        return cacheService.Remove(key);

                    case CacheType.InMemory:
                        return memoryCacheService.Remove(key);

                    case CacheType.Both:
                        return memoryCacheService.Remove(key) && cacheService.Remove(key);

                    default:
                        return default;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool RemoveAll(CacheType cacheType = CacheType.Redis) 
        {
            try
            {
                switch (cacheType)
                {
                    case CacheType.Redis:
                        return cacheService.RemoveAll();

                    case CacheType.InMemory:
                        return memoryCacheService.RemoveAll();

                    case CacheType.Both:
                        return memoryCacheService.RemoveAll() && cacheService.RemoveAll();

                    default:
                        return default;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
