﻿namespace corf.Caching
{
    public interface ICacheService
    {
        T? Get<T>(string key);
        T? Set<T>(string key, T value);
        T? Set<T>(string key, T value, double absoluteExpiration, double slidingExpiration);
        bool IsActive { get; }
        bool Remove(string key);
        bool RemoveAll();
    }
}