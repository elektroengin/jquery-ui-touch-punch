﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Caching.InMemory
{
    public interface IMemoryCacheService
    {
        T? Get<T>(string key);

        T? Set<T>(string key, T value, double absoluteExpiration);

        bool Remove(string key);
        bool RemoveAll();
    }
}
