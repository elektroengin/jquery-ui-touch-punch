﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using Microsoft.Extensions.Primitives;
using Microsoft.VisualBasic;

namespace corf.Caching.InMemory
{
    public class MemoryCacheService : IMemoryCacheService
    {
        private IMemoryCache _memoryCache;
        private CancellationTokenSource _resetCacheToken = new();

        public MemoryCacheService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public T? Get<T>(string key)
        {
            T item = (T)_memoryCache.Get(key);

            return item ?? default;
        }

        public T? Set<T>(string key, T value, double absoluteExpiration)
        {
            if (!string.IsNullOrEmpty(key))
            {
                using var entry = _memoryCache.CreateEntry(key);
                entry.Value = value;
                if (absoluteExpiration > 0)
                { var options = new MemoryCacheEntryOptions()
                                    .SetAbsoluteExpiration(relative: TimeSpan.FromMinutes(absoluteExpiration));
                    entry.SetOptions(options);
                }
                entry.AddExpirationToken(new CancellationChangeToken(_resetCacheToken.Token));
                
            }

            return value;
        }

        public bool Remove(string key)
        {
            if (!string.IsNullOrEmpty(key))
            {
                _memoryCache.Remove(key);
                return true;
            }

            return false;
        }

        public bool RemoveAll()
        {
            try 
            {
                _resetCacheToken.Cancel(); 
                _resetCacheToken.Dispose(); 
                _resetCacheToken = new CancellationTokenSource();
                return true;
            } 
            catch (Exception ex)
            {
                return false;
            }
            
        }
    }
}
