﻿using corf.Configuration;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace corf.Caching.Redis
{
    public class TemporaryRedisCacheService : ICacheService
    {
        private IConnectorConfiguration _connectorConfiguration;

        public TemporaryRedisCacheService(IConnectorConfiguration connectorConfiguration)
        {
            _connectorConfiguration = connectorConfiguration;
        }

        public bool IsActive { get { return false; } }

        public T? Get<T>(string key)
        {
            return default(T);
        }

        public bool Remove(string key)
        {
            return true;
        }

        public bool RemoveAll()
        {
            return true;
        }

        public T? Set<T>(string key, T value)
        {
            return default(T);
        }

        public T? Set<T>(string key, T value, double absoluteExpiration, double slidingExpiration)
        {
            return default(T);
        }
    }
}