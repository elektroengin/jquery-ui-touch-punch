﻿using corf.Configuration;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;
using System.Reflection;

namespace corf.Caching.Redis
{
    public class RedisCacheService : ICacheService
    {
        private readonly IDistributedCache _cache;
        private IConnectorConfiguration _connectorConfiguration;
        private ConcurrentDictionary<string, bool> _keys = new ConcurrentDictionary<string, bool>();
        private string _applicationName;

        public RedisCacheService(IDistributedCache cache, IConnectorConfiguration connectorConfiguration)
        {
            _cache = cache;
            _connectorConfiguration = connectorConfiguration;
            _applicationName = Assembly.GetEntryAssembly()?.GetName().Name ?? Guid.NewGuid().ToString();
        }

        public bool IsActive { get { return true; } }

        public T? Get<T>(string key)
        {
            try 
            {
                var value = _cache.GetString(key);
                if (value != null && !_keys.ContainsKey(key))
                {
                    SetMachine(key);
                }                
                if (value != null)
                {
                    return JsonConvert.DeserializeObject<T>(value);
                }
            }
            catch (Exception ex) 
            {
                var message = ex.Message;
            }
            return default;

        }

        public T? Set<T>(string key, T value)
        {
            return Set(key, value, _connectorConfiguration.Redis.AbsoluteExpirationOnMinutes, _connectorConfiguration.Redis.SlidingExpirationOnMinutes);
        }

        public T? Set<T>(string key, T value, double absoluteExpiration, double slidingExpiration)
        {
            
            var options = new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = absoluteExpiration > 0 ? TimeSpan.FromMinutes(absoluteExpiration) : null,
                SlidingExpiration = slidingExpiration > 0 ? TimeSpan.FromMinutes(slidingExpiration) : null
            };

            _cache.SetString(key, JsonConvert.SerializeObject(value), options);
            return value;
        }

        public bool Remove(string key)
        {
            if (!string.IsNullOrEmpty(key))
            {
                _cache.Remove(key);
                RemoveKeyInMachineCache(key);
                return true;
            }

            return false;
        }

        public bool RemoveAll()
        {
            try
            {
                var machineCache = _cache.GetString(_applicationName);

                if (string.IsNullOrEmpty(machineCache))
                    return false;

                List<string> keysToRemove = JsonConvert.DeserializeObject<List<string>>(machineCache);

                foreach (var key in keysToRemove)
                {
                    _cache.Remove(key);
                    _keys.TryRemove(key, out _);
                }
                foreach (var item in _keys)
                {
                    _cache.Remove(item.Key);
                }

                _cache.Remove(_applicationName);
                _keys.Clear();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private void SetMachine(string key)
        {
            if (_keys == null || _keys.Count < 0)
            {
                _keys ??= new ConcurrentDictionary<string, bool> ();
            }

            _keys.TryAdd(key, true);

            string cacheList = _cache.GetString(_applicationName);

            List<string> keyList = string.IsNullOrEmpty(cacheList) ? new List<string>() : JsonConvert.DeserializeObject<List<string>>(cacheList);
            keyList ??= new List<string>();

            if (!keyList.Contains(key))
            {
                keyList.Add(key);
                cacheList = JsonConvert.SerializeObject(keyList);
                _cache.SetString(_applicationName, cacheList);
            }


        }

        private void RemoveKeyInMachineCache(string key)
        {
            _keys.TryRemove(key, out _);

            string machineCache = _cache.GetString(_applicationName);

            if (!string.IsNullOrEmpty(machineCache))
            {
                List<string> keyList = JsonConvert.DeserializeObject<List<string>>(machineCache);
                keyList?.Remove(key);

                machineCache = JsonConvert.SerializeObject(keyList);
                _cache.SetString(_applicationName, machineCache);
            }
            
            
        }
    }
}

    
