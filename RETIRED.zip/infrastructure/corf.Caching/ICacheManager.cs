﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace corf.Caching
{
    public interface ICacheManager
    {
        T? Get<T>(string key, CacheType cacheType = CacheType.Redis);

        T? Set<T>(string key, T value, double absoluteExpiration, double slidingExpiration, CacheType cacheType = CacheType.Redis);

        bool Remove(string key, CacheType cacheType = CacheType.Redis);
        bool RemoveAll(CacheType cacheType = CacheType.Redis);
    }
}
