﻿using Microsoft.Extensions.Options;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using NLog.Config;
using NLog.Extensions.Logging;

namespace Logging
{
    public class NLogAdapter : ILogAdapter
    {
        LogConfiguration _config;

        LoggerBase _internalLogger;


        public NLogAdapter(IOptions<LogConfiguration> logconfig, IConfigurationRoot root)
        {
            LoggingConfiguration nLogConfig = new NLogLoggingConfiguration(root.GetSection(string.IsNullOrEmpty(logconfig.Value.NLogSection)
                ? "NLog"
                : logconfig.Value.NLogSection));

            if (logconfig.Value != null && string.IsNullOrWhiteSpace(logconfig.Value.LoggerName) == false)
            {
                _config = logconfig.Value;

                _internalLogger = LoggerFactory.GetLogger(_config.LoggerName, _config.FlushPerRequest, nLogConfig);
            }
            else
            {
                _internalLogger = LoggerFactory.GetLogger("corf", false, nLogConfig);
            }

        }

        public void LogError(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Error(message, ex, unique, additionalMessage);
        }
        public void LogError(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Error(message, ex, unique, additionalMessage, formatParams);
        }

        public void LogCritical(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Fatal(message, ex, unique, additionalMessage);
        }

        public void LogCritical(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Fatal(message, ex, unique, additionalMessage, formatParams);
        }

        public void LogInformation(string message, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Info(message, unique, additionalMessage);
        }
        public void LogInformation(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Info(message, unique, additionalMessage, formatParams);
        }

        public void LogTrace(string message, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Trace(message, unique, additionalMessage);
        }
        public void LogTrace(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Trace(message, unique, additionalMessage, formatParams);
        }

        public void LogDebug(string message, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Debug(message, unique, additionalMessage);
        }

        public void LogDebug(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Debug(message, unique, additionalMessage, formatParams);
        }

        public void LogWarning(string message, string? unique = null, string? additionalMessage = null)
        {
           _internalLogger.Warn(message, unique, additionalMessage);
        }
        public void LogWarning(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           _internalLogger.Warn(message, unique, additionalMessage, formatParams);
        }

        public void Flush()
        {
            LogManager.Flush();
        }
    }
}
