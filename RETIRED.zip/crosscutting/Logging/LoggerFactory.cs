﻿using NLog;
using System;
using System.Collections.Generic;
using System.Text;
using NLog.Config;

namespace Logging
{
    internal static class LoggerFactory
    {
        internal static LoggerBase GetLogger(string loggerName, bool isFlusher, LoggingConfiguration configuration)
        {
            if (!isFlusher)
            {
                return new DefaultLogger(loggerName, configuration);
            }
            else
            {
                return new FlusherLogger(loggerName, configuration);
            }
        }
    }
}
