﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Logging
{
    public enum Result
    {
        Successful,
        BusinessFault,
        SystemFault
    }

    public enum State
    {
        Started,
        Running,
        Finished
    }
    public abstract class MetricMonitoringMessage
    {
        public bool InitialRecord { get; set; }
        public string ApplicationId { get; set; } = string.Empty;
        public string ApplicationName { get; set; } = string.Empty;
        public string ServerName { get; set; } = string.Empty;
        public string Acquirer { get; set; } = string.Empty;
        public string Tuid { get; set; } = string.Empty;//Var ise o işleme özel unique bir değer. 
        public bool IsReversal { get; set; } //Reversal mesaj mı?


        public MetricMonitoringDashboardDetails DashboardDetails { get; set; }
        public MetricMonitoringMessageDetails? Details { get; set; }
        public JObject BusinessSpesific { get; set; }
        public string timestamp { get; set; } = DateTimeOffset.Now.ToString("o");
    }

    public class MetricMonitoringDashboardDetails
    {
        public bool DashboardLogActive { get; set; }
        [JsonProperty(PropertyName = "log_source")]
        public string LogSource { get; set; }
        [JsonProperty(PropertyName = "channel")]
        public string Channel { get; set; }
        [JsonProperty(PropertyName = "category")]
        public string Category { get; set; }
        [JsonProperty(PropertyName = "service_name")]
        public string ServiceName { get; set; }
        [JsonProperty(PropertyName = "operation_name")]
        public string OperationName { get; set; }
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
        [JsonProperty(PropertyName = "host")]
        public string Host { get; set; }
        [JsonProperty(PropertyName = "message_text")]
        public string MessageText { get; set; }
        [JsonProperty(PropertyName = "owner_team")]
        public string OwnerTeam { get; set; }
        [JsonProperty(PropertyName = "owner_email")]
        public string OwnerEmail { get; set; }
        [JsonProperty(PropertyName = "response_time")]
        public long ResponseTime { get; set; }
        [JsonProperty(PropertyName = "error_code")]
        public string ErrorCode { get; set; }
        [JsonProperty(PropertyName = "consumer_code")]
        public string ConsumerCode { get; set; }
    }

    public class MetricMonitoringJourneyMessage : MetricMonitoringMessage
    {
        public IEnumerable<ApplicationTiming>? ApplicationTimings { get; set; }
    }

    public class MetricMonitoringSingleMessage : MetricMonitoringMessage
    {
        public DateTime EntryDate { get; set; }
        public DateTime ExitDate { get; set; }
        public long Duration { get; set; }
        public long InternalDuration { get; set; }

    }

    public class MetricMonitoringLongRunningMessage : MetricMonitoringSingleMessage
    {
        public State State { get; set; }
    }

    public class ApplicationTiming
    {
        public string ApplicationId { get; set; } = string.Empty;
        public DateTime EntryDate { get; set; }
        public DateTime ExitDate { get; set; }
        public long Duration { get; set; }
    }

    public class MetricMonitoringMessageDetails
    {
        public Result Result { get; set; }
        public string Destination { get; set; } = string.Empty;
        public string TransactionType { get; set; } = string.Empty;
        public string Latitude { get; set; } = string.Empty; //merchant geocode
        public string Longitude { get; set; } = string.Empty; //merchant geocode
        public string UserIdentifier { get; set; } = string.Empty; //Merchant Id
        public string UserDescription { get; set; } = string.Empty; //Doldurulabiliyor ise (ekstra bir yerden çekmeye gerek yok. O anda elimizde var ise doldurabiliriz)
        public string ResponseCode { get; set; } = string.Empty; //Dönüş kodu. (Banka hosttan dönen response kod da o aşamada yazdırılabilir)
        public string InternalResponseCode { get; set; } = string.Empty; //Safir Dönüş kodu. 
        public string ErrorMessage { get; set; } = string.Empty; //Exception durumunda hata mesajı   
        public bool IsOnlineTransaction { get; set; }

    }
}
