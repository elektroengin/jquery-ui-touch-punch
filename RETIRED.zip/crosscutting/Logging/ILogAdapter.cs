﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logging
{
    public interface ILogAdapter
    {
        void LogError(string message, Exception ex, string? unique = null, string? additionalMessage = null);
        void LogError(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void LogInformation(string message, string? unique = null, string? additionalMessage = null);
        void LogInformation(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void LogWarning(string message, string? unique = null, string? additionalMessage = null);
        void LogWarning(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void LogCritical(string message, Exception ex, string? unique = null, string? additionalMessage = null);
        void LogCritical(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void LogTrace(string message, string? unique = null, string? additionalMessage = null);
        void LogTrace(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void LogDebug(string message, string? unique = null, string? additionalMessage = null);
        void LogDebug(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        void Flush();
    }
}
