﻿using NLog;
using NLog.Config;
using NLog.Targets;
using System.Net.Http.Headers;
using System.Text;

namespace Logging.Nlog.Extensions.Targets
{
    [Target("RestTarget")]
    public class RestTarget : AsyncTaskTarget
    {
        [RequiredParameter]
        public string? BaseAddress { get; set; }

        [RequiredParameter]
        public string? Path { get; set; }

        [RequiredParameter]
        public string? Verb { get; set; }

        [RequiredParameter]
        public string? ContentType { get; set; }

        [RequiredParameter]
        public int TimeOut { get; set; }

        [DefaultParameter]
        public string? AuthType { get; set; }

        [DefaultParameter]
        public string? Username { get; set; }

        [DefaultParameter]
        public string? Password { get; set; }

        [ArrayParameter(typeof(MethodCallParameter), "header")]
        public IList<MethodCallParameter>? Headers { get; set; }

        private HttpClient? _client;

        public RestTarget()
        {
        }
        protected override async Task WriteAsyncTask(LogEventInfo logEvent, CancellationToken cancellationToken)
        {
            if (_client == null)
            {
                _client = new HttpClient { BaseAddress = new Uri(BaseAddress) };

                if (TimeOut > 0)
                {
                    _client.Timeout = new TimeSpan(TimeOut * 10000);
                }
                if (Headers != null)
                {
                    foreach (var headerInfo in Headers)
                    {
                        _client.DefaultRequestHeaders.Add(headerInfo.Name, headerInfo.Layout.ToString());
                    }
                }

                if (AuthType == "B")
                {
                    _client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue(
                            "Basic",
                            Convert.ToBase64String(
                                Encoding.ASCII.GetBytes(
                                    string.Format("{0}:{1}", Username, Password))));
                }
            }


            var logMessage = this.Layout.Render(logEvent);

            

            var message = new HttpRequestMessage()
            {
                Content = new StringContent(logMessage, Encoding.UTF8, "application/json"),
                RequestUri = new Uri($"{BaseAddress}{Path}"),
                Method = new HttpMethod(Verb)
            };

            await _client.SendAsync(message, cancellationToken);

        }

    }
}
