﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logging
{
    public class LogConfiguration
    {
        public string LoggerName { get; set; } = string.Empty;
        public bool FlushPerRequest { get; set; }
        public string ApplicationName { get; set; } = string.Empty;
        public string ApplicationId { get; set; } = string.Empty;
        public string Acquirer { get; set; } = string.Empty;
        public string NLogSection { get; set; } = string.Empty;
    }
}
