﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Logging
{
    public class MetricMonitoringLogAdapter : IMetricMonitoringLogAdapter
    {
        private readonly LogConfiguration _logConfiguration;
        private ILogger<MetricMonitoringLogAdapter> _logger;
        public MetricMonitoringLogAdapter(ILogger<MetricMonitoringLogAdapter> logger, IOptions<LogConfiguration> options)
        {
            _logConfiguration = options.Value;
            _logger = logger;
        }
        public void Send(MetricMonitoringMessage monitoringMessage)
        {
            monitoringMessage.ApplicationName = string.IsNullOrEmpty(monitoringMessage.ApplicationName) ? _logConfiguration.ApplicationName : monitoringMessage.ApplicationName;
            monitoringMessage.ApplicationId = string.IsNullOrEmpty(monitoringMessage.ApplicationId) ? _logConfiguration.ApplicationId : monitoringMessage.ApplicationId;
            monitoringMessage.Acquirer = string.IsNullOrEmpty(monitoringMessage.Acquirer) ? _logConfiguration.Acquirer : monitoringMessage.Acquirer;
            monitoringMessage.ServerName = string.IsNullOrEmpty(monitoringMessage.ServerName) ? Environment.MachineName : monitoringMessage.ServerName;
            _logger.LogInformation(JsonConvert.SerializeObject(monitoringMessage, Formatting.Indented, new StringEnumConverter()));
        }

        public void Send<T> (T message)
        {
            _logger.LogInformation(JsonConvert.SerializeObject(message, Formatting.Indented, new StringEnumConverter()));
        }
    }
}
