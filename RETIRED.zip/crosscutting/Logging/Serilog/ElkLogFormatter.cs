﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog.Sinks.Http;
using System.Globalization;

namespace Logging.Serilog
{
    public class ElkLogFormatter : IBatchFormatter
    {
        public void Format(IEnumerable<string> logEvents, TextWriter output)
        {
            if (logEvents == null) throw new ArgumentNullException(nameof(logEvents));
            if (output == null) throw new ArgumentNullException(nameof(output));

            // Abort if sequence of log events is empty
            if (!logEvents.Any())
            {
                return;
            }

            output.Write("[");

            var delimStart = string.Empty;

            foreach (var logEvent in logEvents)
            {
                if (string.IsNullOrWhiteSpace(logEvent))
                {
                    continue;
                }

                JObject logJson = JObject.Parse(logEvent);

                var exception = logJson.GetValue("Exception");


                if (exception != null && exception is JToken)
                {
                    logJson.Remove("Exception");

                    logJson.Add("Exception", JToken.FromObject(new Exception(exception.Value<string>())));
                }

                var properties = logJson.GetValue("Properties");

                logJson.Remove("Properties");
                string level = logJson["Level"]?.ToString();
                string logLevel = "trace";

                if (level.ToLower() == "fatal")
                    logLevel = "alert";

                logJson.TryAdd("logLevel", logLevel);

                logJson.Remove("datetime");
                logJson.TryAdd("datetime", DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffff", CultureInfo.InvariantCulture));

                logJson.TryAdd("machineName", System.Environment.MachineName);

                logJson.TryAdd("message", logJson["RenderedMessage"].ToString());
                logJson.TryAdd("level", logJson["Level"].ToString());

                logJson.Remove("RenderedMessage");
                logJson.Remove("MessageTemplate");

                logJson.Remove("Timestamp");
                logJson.Remove("timestamp");
                logJson.TryAdd("timestamp", DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fff", CultureInfo.InvariantCulture));

                logJson.Remove("Level");

                foreach (var x in properties)
                {
                    if (((JProperty)x).Name == "MachineName")
                        continue;
                    logJson.Add(x);
                }
                output.Write(delimStart);
                output.Write(logJson);
                delimStart = ",";
            }

            output.Write("]");
        }

        private object GetPropertyValue(JProperty property)
        {
            object value = null;
            JToken valueToken;
            try
            {
                if (property.Value is JObject)
                    valueToken = property.Value.SelectToken("Value");
                else if (property.Value is JToken)
                    valueToken = property.Value;
                else
                    return value;

                if (valueToken != null)
                {
                    switch (valueToken.Type)
                    {
                        case JTokenType.String:
                            value = valueToken.Value<string>();
                            break;
                        case JTokenType.Integer:
                            value = valueToken.Value<long>();
                            break;
                        case JTokenType.Array:
                            if (valueToken.Values().Any())
                                value = valueToken.Values().First().Value<string>();
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetPropertyValue Exception: {JsonConvert.SerializeObject(property)} {ex.Message} {ex.StackTrace}");
            }
            return value;
        }
    }
}
