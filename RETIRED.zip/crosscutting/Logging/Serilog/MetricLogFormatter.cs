﻿using Newtonsoft.Json.Linq;
using Serilog.Events;
using Serilog.Formatting;
using Serilog.Sinks.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logging.Serilog
{
    public class MetricLogFormatter : IBatchFormatter
    {

        public void Format(IEnumerable<string> logEvents, TextWriter output)
        {
            if (logEvents == null) throw new ArgumentNullException(nameof(logEvents));
            if (output == null) throw new ArgumentNullException(nameof(output));

            // Abort if sequence of log events is empty
            if (!logEvents.Any())
            {
                return;
            }

            output.Write("[");

            var delimStart = string.Empty;

            foreach (var logEvent in logEvents)
            {
                if (string.IsNullOrWhiteSpace(logEvent))
                {
                    continue;
                }

                JObject logJson = JObject.Parse(logEvent);

                var properties = logJson.GetValue("Properties");

                JObject messageJson = JObject.Parse(logJson["RenderedMessage"].ToString());

                JToken dashboardDetails = messageJson.GetValue("DashboardDetails");

                logJson.TryAdd("machineName", System.Environment.MachineName);

                logJson.Remove("timestamp");
                logJson.Remove("@timestamp");

                logJson.TryAdd("level", logJson["Level"].ToString());

                string dateTime;
                if (logJson["Timestamp"] != null)
                    dateTime = ((DateTimeOffset)(((JValue)logJson["Timestamp"]).Value)).ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz");
                else
                    dateTime = DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz", CultureInfo.InvariantCulture);

                logJson.TryAdd("datetime", dateTime);
                logJson.TryAdd("timestamp", dateTime);

                logJson.TryAdd("class", "metric");

                foreach (var x in properties)
                {
                    if (((JProperty)x).Name == "MachineName" || ((JProperty)x).Name == "class")
                        continue;
                    logJson.Add(x);
                }

                foreach (var x in dashboardDetails)
                {
                    logJson.Add(x);
                }

                messageJson.Remove("DashboardDetails");
                logJson.TryAdd("message", messageJson);

                logJson.Remove("Properties");
                logJson.Remove("RenderedMessage");
                logJson.Remove("Level");
                logJson.Remove("MessageTemplate");

                output.Write(delimStart);
                output.Write(logJson);
                delimStart = ",";
            }

            output.Write("]");
        }
    }
}
