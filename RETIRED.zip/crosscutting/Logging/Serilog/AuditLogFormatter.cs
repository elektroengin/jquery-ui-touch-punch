﻿using Newtonsoft.Json.Linq;
using Serilog.Sinks.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logging.Serilog
{
    public class AuditLogFormatter : IBatchFormatter
    {
        public void Format(IEnumerable<string> logEvents, TextWriter output)
        {
            if (logEvents == null) throw new ArgumentNullException(nameof(logEvents));
            if (output == null) throw new ArgumentNullException(nameof(output));

            // Abort if sequence of log events is empty
            if (!logEvents.Any())
            {
                return;
            }

            output.Write("[");

            var delimStart = string.Empty;

            foreach (var logEvent in logEvents)
            {
                if (string.IsNullOrWhiteSpace(logEvent))
                {
                    continue;
                }

                JObject logJson = JObject.Parse(logEvent);

                var properties = logJson.GetValue("Properties");

                logJson.Remove("Properties");
                string level = logJson["Level"]?.ToString();
                string logLevel = "trace";

                if (level.ToLower() == "fatal")
                    logLevel = "alert";

                logJson.TryAdd("logLevel", logLevel);

                logJson.TryAdd("datetime", DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffff", CultureInfo.InvariantCulture));

                logJson.TryAdd("machineName", System.Environment.MachineName);

                logJson.TryAdd("auditMessage", logJson["RenderedMessage"].ToString());
                logJson.TryAdd("level", logJson["Level"].ToString());

                logJson.Remove("RenderedMessage");
                logJson.Remove("MessageTemplate");

                logJson.Remove("Timestamp");
                logJson.TryAdd("timestamp", DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fff", CultureInfo.InvariantCulture));

                logJson.Remove("Level");

                foreach (var x in properties)
                {
                    if (((JProperty)x).Name == "MachineName")
                        continue;
                    logJson.Add(x);
                }
                output.Write(delimStart);
                output.Write(logJson);
                delimStart = ",";
            }

            output.Write("]");
        }
    }
}
