﻿using Newtonsoft.Json.Linq;
using Serilog.Events;
using Serilog.Formatting;
using Serilog.Formatting.Elasticsearch;
using Serilog.Sinks.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Confluent.Kafka;
using Newtonsoft.Json;

namespace Logging.Serilog
{
    public class MetricLogTextFormatter : ITextFormatter
    {
        public void Format(LogEvent logEvent, TextWriter output)
        {
            if (logEvent == null) throw new ArgumentNullException(nameof(logEvent));
            if (output == null) throw new ArgumentNullException(nameof(output));

            JObject logJson = JObject.FromObject(logEvent);

            var properties = logJson.GetValue("Properties");

            JObject messageJson = JObject.Parse(logEvent.RenderMessage());

            JToken dashboardDetails = messageJson.GetValue("DashboardDetails");

            logJson.TryAdd("machineName", System.Environment.MachineName);

            logJson.Remove("timestamp");
            logJson.Remove("@timestamp");

            logJson.TryAdd("level", logJson["Level"].ToString());

            string dateTime;
            if (logJson["Timestamp"] != null)
                dateTime = ((DateTimeOffset)(((JValue)logJson["Timestamp"]).Value)).ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz");
            else
                dateTime = DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz", CultureInfo.InvariantCulture);

            logJson.TryAdd("datetime", dateTime);
            logJson.TryAdd("timestamp", dateTime);

            logJson.TryAdd("class", "metric");

            foreach (var x in properties)
            {
                var property = ((JProperty)x);

                if (((JProperty)x).Name == "MachineName" || ((JProperty)x).Name == "class")
                    continue;
                if (((property.Value).SelectToken("Value")).Type != JTokenType.Array)
                    logJson.Add(property.Name, ((JToken)(property.Value).SelectToken("Value").Value<string>()));
                else
                {
                    IEnumerable<JToken> tokenList = (property.Value).SelectToken("Value").Values();
                    if (tokenList.Any())
                        logJson.Add(property.Name, (tokenList.First().Value<string>()));
                }
            }

            foreach (var x in dashboardDetails)
            {
                var property = ((JProperty)x);

                if (logJson.ContainsKey(property.Name))
                    continue;

                if (property.Value.Type != JTokenType.Array)
                    logJson.Add(property.Name, property.Value.ToString());
                else
                {
                    IEnumerable<JToken> tokenList = property.Values();
                    if (tokenList.Any())
                        logJson.Add(property.Name, (tokenList.First().Value<string>()));
                }
            }

            messageJson.Remove("DashboardDetails");
            logJson.TryAdd("message", messageJson);

            logJson.Remove("Properties");
            logJson.Remove("DashboardDetails");

            logJson.Remove("RenderedMessage");
            logJson.Remove("Timestamp");
            logJson.Remove("Level");
            logJson.Remove("MessageTemplate");

            output.Write(logJson);


        }
    }
}
