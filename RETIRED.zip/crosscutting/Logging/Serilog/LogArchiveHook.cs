﻿using Serilog.Sinks.File.Archive;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logging.Serilog
{
    public class SerilogHooks
    {
        public static ArchiveHooks CustomArchiveHook => new LogArchiveHook();
    }
    public class LogArchiveHook : ArchiveHooks
    {
        private readonly string archiveFolderName = "archive";
        private readonly string archiveFileExtention = ".gz";
        public LogArchiveHook()
        {

        }

        public override void OnFileDeleting(string path)
        {
            try
            {
                string archiveFolderPath = Path.Combine(Path.GetDirectoryName(path), archiveFolderName);
                if (!Directory.Exists(archiveFolderPath))
                    Directory.CreateDirectory(archiveFolderPath);

                base.OnFileDeleting(path);
                File.Move(path + archiveFileExtention, Path.Combine(archiveFolderPath, Path.GetFileName(path) + Path.GetRandomFileName() + archiveFileExtention));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
