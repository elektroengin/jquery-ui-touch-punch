﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog.Events;
using Serilog.Formatting;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logging.Serilog
{
    public class ElkLogTextFormatter : ITextFormatter
    {
        public void Format(LogEvent logEvent, TextWriter output)
        {
            if (logEvent == null) throw new ArgumentNullException(nameof(logEvent));
            if (output == null) throw new ArgumentNullException(nameof(output));

            JObject logJson = JObject.FromObject(logEvent);

            var properties = logJson.GetValue("Properties");

            logJson.Remove("Properties");
            string level = logJson["Level"]?.ToString();
            string logLevel = "trace";

            if (level.ToLower() == "fatal")
                logLevel = "alert";

            logJson.TryAdd("logLevel", logLevel);

            logJson.Remove("datetime");
            logJson.Remove("timestamp");
            logJson.Remove("@timestamp");

            string dateTime;
            if (logJson["Timestamp"] != null)
                dateTime = ((DateTimeOffset)(((JValue)logJson["Timestamp"]).Value)).ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz");
            else
                dateTime = DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffffzzz", CultureInfo.InvariantCulture);

            logJson.TryAdd("datetime", dateTime);
            logJson.TryAdd("timestamp", dateTime);

            logJson.TryAdd("machineName", System.Environment.MachineName);

            logJson.TryAdd("message", logEvent.RenderMessage());

            LogEventLevel enumValue = LogEventLevel.Information;

            if (Enum.TryParse<LogEventLevel>(logJson["Level"].ToString(), out enumValue))
                logJson.TryAdd("level", enumValue.ToString());
            else
                logJson.TryAdd("level", LogEventLevel.Information.ToString());


            logJson.Remove("RenderedMessage");
            logJson.Remove("MessageTemplate");

            logJson.Remove("Timestamp");

            logJson.Remove("Level");

            foreach (var x in properties)
            {
                var property = ((JProperty)x);

                if (logJson.ContainsKey(property.Name))
                    continue;

                if (property.Name == "MachineName" || (property.Value).SelectToken("Value") == null)
                    continue;

                object propertyValue = GetPropertyValue(property);
                if (propertyValue != null)
                    logJson.Add(property.Name, JToken.FromObject(propertyValue));
            }
            output.Write(logJson);


        }

        private object GetPropertyValue(JProperty property)
        {
            object value = null;
            JToken valueToken;
            try
            {

                if (property.Value is JObject)
                    valueToken = property.Value.SelectToken("Value");
                else if (property.Value is JToken)
                    valueToken = property.Value;
                else
                    return value;

                if (valueToken != null)
                {
                    switch (valueToken.Type)
                    {
                        case JTokenType.String:
                            value = valueToken.Value<string>();
                            break;
                        case JTokenType.Integer:
                            value = valueToken.Value<long>();
                            break;
                        case JTokenType.Array:
                            if (valueToken.Values().Any())
                                value = valueToken.Values().First().Value<string>();
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetPropertyValue Exception: {JsonConvert.SerializeObject(property)} {ex.Message} {ex.StackTrace}");
            }
            return value;
        }
    }
}
