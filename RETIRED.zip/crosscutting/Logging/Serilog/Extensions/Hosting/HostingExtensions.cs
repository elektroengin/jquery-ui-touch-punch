﻿using Microsoft.Extensions.Hosting;

namespace Logging.Serilog.Extensions.Hosting
{
    public static class HostingExtension
    {
        public static void AddSerilogExtension(this IHostBuilder builder)
        {
        }
    }
}
