﻿using NLog;
using System;
using System.IO;
using NLog.Config;

namespace Logging
{
    public abstract class LoggerBase
    {
        internal NLog.Logger _logger;
        internal LoggerBase(string loggerName, LoggingConfiguration configuration)
        {
            _logger = LogManager.GetLogger(loggerName);

            LogManager.Configuration = configuration;
        }

        public abstract void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null);
        public abstract void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        public abstract void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null);
        public abstract void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        public abstract void Info(string message, string? unique = null, string? additionalMessage = null);
        public abstract void Info(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        public abstract void Trace(string message, string? unique = null, string? additionalMessage = null);
        public abstract void Trace(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        public abstract void Debug(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
        public abstract void Warn(string message, string? unique = null, string? additionalMessage = null);
        public abstract void Debug(string message, string? unique = null, string? additionalMessage = null);
        public abstract void Warn(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams);
  
    }
}