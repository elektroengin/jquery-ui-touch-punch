﻿using NLog;
using System;
using System.Collections.Generic;
using System.Text;
using NLog.Config;
using NLog.Extensions.Logging;

namespace Logging
{
    public class FlusherLogger : LoggerBase
    {
        public FlusherLogger(string loggerName, LoggingConfiguration configuration) : base(loggerName, configuration)
        {
        }

        public override void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique)
                .WithProperty("additionalMessage", additionalMessage)
                .Error(ex, message);
            LogManager.Flush();
        }
        public override void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Error(ex, message, formatParams);
            LogManager.Flush();
        }

        public override void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Fatal(ex, message);
            LogManager.Flush();
        }

        public override void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Fatal(ex, message, formatParams);
            LogManager.Flush();
        }

        public override void Info(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Info(message);
            LogManager.Flush();
        }
        public override void Info(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Info(message, formatParams);
            LogManager.Flush();
        }

        public override void Trace(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Trace(message);
            LogManager.Flush();
        }
        public override void Trace(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Trace(message, formatParams);
            LogManager.Flush();
        }

        public override void Debug(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Debug(message);
            LogManager.Flush();
        }

        public override void Debug(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Debug(message, formatParams);
            LogManager.Flush();
        }

        public override void Warn(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Warn(message);
            LogManager.Flush();
        }
        public override void Warn(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Warn(message, formatParams);
            LogManager.Flush();
        }
    }
}
