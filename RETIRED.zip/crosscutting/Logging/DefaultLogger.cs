﻿using System;
using System.Collections.Generic;
using System.Text;
using NLog;
using NLog.Config;
using NLog.Extensions.Logging;

namespace Logging
{
    public class DefaultLogger : LoggerBase
    {
        public DefaultLogger(string loggerName, LoggingConfiguration configuration) : base(loggerName, configuration)
        {
        }

        public override void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage",additionalMessage).Error(ex, message);
        }
        public override void Error(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
           
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Error(ex, message, formatParams);
        }

        public override void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Fatal(ex, message);

        }

        public override void Fatal(string message, Exception ex, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Fatal(ex, message, formatParams);
        }

        public override void Info(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Info(message);
        }
        public override void Info(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Info(message, formatParams);
        }

        public override void Trace(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Trace(message);
        }
        public override void Trace(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Trace(message, formatParams);
        }

        public override void Debug(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Debug(message);
        }

        public override void Debug(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Debug(message, formatParams);
        }

        public override void Warn(string message, string? unique = null, string? additionalMessage = null)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Warn(message);
        }
        public override void Warn(string message, string? unique = null, string? additionalMessage = null, params object[] formatParams)
        {
            _logger.WithProperty("unique", unique).WithProperty("additionalMessage", additionalMessage).Warn(message, formatParams);
        }
    }
}
