using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using System.Diagnostics;

namespace corf.BinaryConverter
{
    public partial class DataConvert
    {
        private readonly static Dictionary<string, string> BinartToHexArray = new Dictionary<string, string>
            {
                {"0000","0"},
                {"0001","1"},
                {"0010","2"},
                {"0011","3"},
                {"0100","4"},
                {"0101","5"},
                {"0110","6"},
                {"0111","7"},
                {"1000","8"},
                {"1001","9"},
                {"1010","A"},
                {"1011","B"},
                {"1100","C"},
                {"1101","D"},
                {"1110","E"},
                {"1111","F"},
            };

        private static int Ishexadecimal(char value)
        {
            switch (value)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    return value - '0';

                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'F':
                    return value - 'A' + 10;

                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                    return value - 'a' + 10;
                default:
                    return -1;
            }
        }

        public static bool[] GetBitsArray(byte[] data, int lenghtCounter, int maxLength)
        {
            return data.Skip(lenghtCounter).Take(maxLength).ToArray().SelectMany(GetBits).ToArray();
        }

        public static IEnumerable<bool> GetBits(byte b)
        {
            for (int i = 0; i < 8; i++)
            {
                yield return (b & 0x80) != 0;
                b *= 2;
            }
        }

        private static List<string[]> createBitMapIndexes(string initial)
        {
            List<string[]> bitmapResult = new List<string[]>();

            for (int i = 0; i < 16; i++)
            {
                bitmapResult.Add(new string[] { "0", "0", "0", "0" });
            }

            return bitmapResult;
        }

        public static byte[] BitIndexes2BitMapHex(int[] indexes)
        {
            BitArray bits = new BitArray(64);

            int maxValue = indexes.Max();

            string hexResult = string.Empty;

            int extensionCount = maxValue <= 64 ? 0 : maxValue <= 128 ? 1 : 2;

            for (int i = 0; i < extensionCount + 1; i++)
            {
                var bitMapIndexs = createBitMapIndexes("0");

                var bitMapPart = indexes.Where(x => x > (64 * i) && x <= 64 * (i + 1)).ToList();

                if ((bitMapPart.Count <= 0 && maxValue > 0) || bitMapPart.Max() < maxValue)
                {
                    bitMapIndexs[0][0] = "1";
                }

                foreach (int index in bitMapPart)
                {
                    bitMapIndexs[(index - (i * 64) - 1) / 4][(index - (i * 64) - 1) % 4] = "1";
                }

                foreach (string[] val in bitMapIndexs)
                {
                    hexResult += BinartToHexArray[string.Join("", val)];
                }
            }

            return HexStringToBinary(hexResult);
        }

        private static int Isnumeric(char value)
        {
            return _numericChars.Contains(value) ? value - '0' : -1;
        }

        private static readonly char[] _numericChars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        private bool IsNumericChar(char value)
        {
            return _numericChars.Contains(value);
        }
        private static bool Isalpha(Char value)
        {
            if (
                (value >= 'a' && value <= 'z') ||
                (value >= 'A' && value <= 'Z') ||
                (value == '�' || value == '�') ||
                (value == '�' || value == '�') ||
                (value == '�' || value == '�') ||
                (value == '�' || value == '�')
                )
                return true;

            {
                return false;
            }
        }
        public static bool IsNumeric(string value)
        {
            if (value == null)
            {
                return false;
            }

            if (String.IsNullOrEmpty(value))
            {
                return false;
            }

            for (int iLoop = 0; iLoop < value.Length; iLoop++)
            {
                if (Isnumeric(value[iLoop]) == -1)
                {
                    return false;
                }
            }
            return true;
        }
        public static bool IsBcd(string piValue)
        {
            if (piValue == null)
            {
                return false;
            }

            if (String.IsNullOrEmpty(piValue))
            {
                return false;
            }

            for (int iLoop = 0; iLoop < piValue.Length; iLoop++)
            {
                if (Isnumeric(piValue[iLoop]) == -1)
                {
                    return false;
                }
            }
            return true;
        }
        public static bool IsHexadecimal(string value)
        {
            if (value == null)
            {
                return false;
            }

            if (value == string.Empty)
            {
                return false;
            }

            for (int iLoop = 0; iLoop < value.Length; iLoop++)
            {
                if (Ishexadecimal(value[iLoop]) == -1)
                {
                    return false;
                }
            }
            return true;
        }
        public static bool IsAlpha(string value)
        {
            if (value == null)
            {
                return false;
            }

            if (String.IsNullOrEmpty(value))
            {
                return false;
            }

            for (int iLoop = 0; iLoop < value.Length; iLoop++)
            {
                if (!Isalpha(value[iLoop]))
                {
                    return false;
                }
            }
            return true;
        }
        public static bool IsAlphaNumeric(string value)
        {
            if (value == null)
            {
                return false;
            }

            if (String.IsNullOrEmpty(value))
            {
                return false;
            }

            for (int iLoop = 0; iLoop < value.Length; iLoop++)
            {
                if (!Isalpha(value[iLoop]) && Isnumeric(value[iLoop]) == -1)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Converts "1624" into { 0x16, 0x24 }
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[]? StringToBcd(string value)
        {
            int loop = 0;
            if (value != null)
            {
                if (!String.IsNullOrEmpty(value))
                {
                    if ((value.Length % 2) == 1)
                    {
                        value = $"0{value}";
                    }
                    byte[] result = new byte[value.Length / 2];

                    for (loop = 0; loop < result.Length; loop++)
                    {
                        result[loop] = (byte)(((Isnumeric(value[loop * 2]) & 0x0F) << 4) +
                                               (Isnumeric(value[(loop * 2) + 1]) & 0x0F));
                    }
                    return result;
                }
            }

            // string de�eri bcd'ye �evirirken hata olu�tu.
            System.Diagnostics.Trace.TraceError("Safir.Framework.Core.DataConvert:StringToBcd failure.[{0}]", value);
            return null;
        }

        /// <summary>
        /// Converts { 0x16, 0x24 } into "1624".
        /// Won't convert { 0x0E } beause it's not BCD.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string? BcdToString(byte[] value)
        {
            int loop = 0;
            if (value != null)
            {
                if (value.Length > 0)
                {
                    byte[] result = new byte[value.Length * 2];
                    for (loop = 0; loop < value.Length; loop++)
                    {
                        result[loop * 2] = _HexChars[(value[loop] >> 4) & 0x0F];
                        result[(loop * 2) + 1] = _HexChars[value[loop] & 0x0F];
                    }
                    if (result[result.Length - 1] == 'F')
                    {
                        return Encoding.Default.GetString(result).Substring(0, result.Length - 1);
                    }
                    else
                    {
                        return Encoding.Default.GetString(result);
                    }
                }
              Trace.TraceError("Safir.Framework.Core.DataConvert:BcdToString failure.[{0}]", BinaryToHexString(value));
            }
            // bcd de�eri string'e �evirirken hata olu�tu.
            return null;
        }
        public static byte[]? HexStringToBinary(string value)
        {
            int loop = 0;
            if (value != null)
            {
                if (!String.IsNullOrEmpty(value))
                {
                    if ((value.Length % 2) == 1)
                    {
                        value = value + "F";
                    }

                    byte[] result = new byte[value.Length / 2];
                    for (loop = 0; loop < result.Length; loop++)
                    {
                        result[loop] = (byte)(((Ishexadecimal(value[loop * 2]) & 0x0F) << 4) +
                                               (Ishexadecimal(value[(loop * 2) + 1]) & 0x0F));
                    }
                    return result;
                }
            }
            // hex string'i binary'e �evirirken hata olu�tu.
            System.Diagnostics.Trace.TraceError("DataConvert::HexStringToBinary returns error[{0}]", value);
            return null;
        }
        public static Int32 HexStringToInt32(string value)
        {
            Int32 result = 0;
            if (value != null)
            {
                if (!String.IsNullOrEmpty(value))
                {
                    result = System.Int32.Parse(value, System.Globalization.NumberStyles.AllowHexSpecifier);
                }
            }
            return result;
        }

        public static string BinaryToHexString(byte[] value)
        {
            int loop = 0;
            if (value != null)
            {
                if (value.Length > 0)
                {
                    byte[] result = new byte[value.Length * 2];
                    for (loop = 0; loop < value.Length; loop++)
                    {
                        result[loop * 2] = _HexChars[(value[loop] >> 4) & 0x0F];
                        result[(loop * 2) + 1] = _HexChars[value[loop] & 0x0F];
                    }

                    return Encoding.Default.GetString(result);
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Converts "AB14" into { 0x41, 0x42, 0x31, 0x34 }
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[]? StringToByte(string value)
        {
            if (value != null)
            {
                return Encoding.Default.GetBytes(value);
            }
            // String'i byte'e �eviriken hata olu�tu
            System.Diagnostics.Trace.TraceError("DataConvert::StringToByte returns error[{0}]", value);
            return null;
        }
        /// <summary>
        /// Converts { 0x41, 0x42, 0x31, 0x34 } into "AB14"
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string? ByteToString(byte[] value)
        {
            if (value != null)
            {
                return Encoding.Default.GetString(value);
            }
            // Byte de�eri string'e �eviriken hata olu�tu
            System.Diagnostics.Trace.TraceError("DataConvert::ByteToString returns error");
            return null;
        }

        /// <summary>
        /// Converts 1624 into { 0x16, 0x24 }
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[]? NumberToBcd(int value)
        {
            if (value < 0)
            {
                // negatif de�eri bcd'ye �eviriken hata olu�tu
                System.Diagnostics.Trace.TraceError("DataConvert::NumberToBcd value is negative");
                return null;
            }

            return StringToBcd(value.ToString());
        }
        /// <summary>
        /// Converts { 0x16, 0x24 } into 1624.
        /// Won't convert { 0x0E } beause it's not BCD.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int BcdToNumber(byte[] value)
        {
            string sTemp = BcdToString(value);

            if (sTemp != null)
            {
                return int.Parse(sTemp);
            }

            // Bcd de�eri say�ya �evirirken hata olu�tu
            System.Diagnostics.Trace.TraceError("DataConvert::BcdToNumber has error.");
            return -1;
        }

        /// <summary>
        /// Sets 0x00 to all bytes of "value" array.
        /// </summary>
        /// <param name="value"></param>
        public static void ZERO(byte[] value)
        {
            if (value != null)
            {
                ZERO(value, 0);
            }
        }
        /// <summary>
        /// Sets 0x00 to all bytes of "value" array starting from "offset" index.
        /// </summary>
        /// <param name="value">Array to use</param>
        /// <param name="offset">Starting index</param>
        public static void ZERO(byte[] value, int offset)
        {
            if (value != null)
            {
                for (int iLoop = offset; iLoop < value.Length; iLoop++)
                {
                    value[iLoop] = 0x00;
                }
            }
        }

        public static byte[] Ebcdic500ToAscii(byte[] buffer, int offSet, int length)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            if (buffer.Length > offSet + length)
            {
                return new byte[] { };
            }

            int max = offSet + length;

            for (position = offSet; position < max; position++)
            {
                buffer[position] = ConversionTableEbcdic500ToAscii437[buffer[position]];
            }
            return buffer;
        }
        public static byte[] Ebcdic500ToAscii(byte[] buffer)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            byte[] outBuffer = new byte[buffer.Length];

            for (position = 0; position < buffer.Length; position++)
                outBuffer[position] = ConversionTableEbcdic500ToAscii437[buffer[position]];

            return outBuffer;
        }

        public static byte[] AsciiToEbcdic500(byte[] buffer, int offSet, int length)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            if (buffer.Length > offSet + length)
            {
                return new byte[] { };
            }
            int max = offSet + length;

            for (position = offSet; position < max; position++)
            {
                buffer[position] = ConversionTableAscii437ToEbcdic500[buffer[position]];
            }
            return buffer;
        }

        public static int Bcd2Int(byte[] value, int len)
        {
            short i;
            byte tb;
            int top = 0;

            for (i = 0; i < len; i++)
            {
                top *= 10;

                if ((i % 2) == 0)
                {
                    tb = value[i / 2];
                    tb >>= 4;
                }
                else
                {
                    tb = value[i / 2];
                    tb &= 15;
                }

                top += tb;
            }

            return top;
        }
        public static byte[] AsciiToEbcdic500(byte[] buffer)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            byte[] outBuffer = new byte[buffer.Length];

            for (position = 0; position < buffer.Length; position++)
                outBuffer[position] = ConversionTableAscii437ToEbcdic500[buffer[position]];

            return outBuffer;
        }

        public static byte[] Ebcdic37ToAscii(byte[] buffer, int offSet, int length)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }
            if (buffer.Length > offSet + length)
            {
                return new byte[] { };
            }

            int max = offSet + length;

            for (position = offSet; position < max; position++)
            {
                buffer[position] = ConversionTableEbcdic037ToAscii437[buffer[position]];
            }
            return buffer;
        }
        public static byte[] Ebcdic37ToAscii(byte[] buffer)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            byte[] outBuffer = new byte[buffer.Length];

            for (position = 0; position < buffer.Length; position++)
                outBuffer[position] = ConversionTableEbcdic037ToAscii437[buffer[position]];

            return outBuffer;
        }

        public static byte[] AsciiToEbcdic37(byte[] buffer, int offSet, int length)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }
            if (buffer.Length > offSet + length)
            {
                return new byte[] { };
            }
            int max = offSet + length;

            for (position = offSet; position < max; position++)
            {
                buffer[position] = ConversionTableAscii437ToEbcdic037[buffer[position]];
            }
            return buffer;
        }
        public static byte[] AsciiToEbcdic37(byte[] buffer)
        {
            int position = 0;

            if (buffer == null)
            {
                return new byte[] { };
            }

            byte[] outBuffer = new byte[buffer.Length];

            for (position = 0; position < buffer.Length; position++)
                outBuffer[position] = ConversionTableAscii437ToEbcdic037[buffer[position]];

            return outBuffer;
        }

        /// <summary>
        /// Returns the Int16 value of "b" calculated from 2 bytes from "start" index.
        /// </summary>
        /// <param name="b"></param>
        /// <param name="start"></param>
        /// <returns></returns>
        public static Int32 ConvertToInt16(byte[] b, int start)
        {
            if (null == b)
            {
                return 0;
            }
            if (start < 0)
            {
                return 0;
            }
            if (b.Length < start + 2)
            {
                return 0;
            }
            return (b[start + 1] << 8) | (b[start]);
        }
        /// <summary>
        /// Returns the Int32 value of "b" calculated from 4 bytes from "start" index
        /// </summary>
        /// <param name="b"></param>
        /// <param name="start"></param>
        /// <returns></returns>
        public static Int32 ConvertToInt32(byte[] b, int start)
        {
            if (null == b)
                return 0;
            if (start < 0) return 0;
            if (b.Length < start + 4)
                return 0;
            return (b[start + 3] << 24) | (b[start + 2] << 16) | (b[start + 1] << 8) | (b[start]);
        }
        /// <summary>
        /// Returns the Int64 value of "b" calculated from 8 bytes from "start" index
        /// </summary>
        /// <param name="b"></param>
        /// <param name="start"></param>
        /// <returns></returns>
        public static Int32 ConvertToInt64(byte[] b, int start)
        {
            if (null == b)
                return 0;
            if (start < 0) return 0;
            if (b.Length < start + 8)
                return 0;
            return
                (b[start + 7] << 56) |
                (b[start + 6] << 48) |
                (b[start + 5] << 40) |
                (b[start + 4] << 32) |
                (b[start + 3] << 24) |
                (b[start + 2] << 16) |
                (b[start + 1] << 8) |
                (b[start]);
        }

        public static byte[] HexToBinary(string hexValue)
        {
            ulong number = UInt64.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);

            byte[] bytes = BitConverter.GetBytes(number);

            return bytes;
        }


        public static Int32 Ebcdic500ToInt(byte[] buffer)
        {
            if (buffer == null)
            {
                return 0;
            }

            byte[] normalizedLength = Ebcdic500ToAscii(buffer);
            string s = Encoding.ASCII.GetString(normalizedLength);

            if (!IsNumeric(s))
                return 0;

            return Convert.ToInt32(s);
        }
        public static string ConvertHexToAscii(String hexStr)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hexStr.Length; i += 2)
            {
                sb.Append(System.Convert.ToChar(System.Convert.ToUInt32(hexStr.Substring(i, 2), 16)));
            }

            return sb.ToString();
        }

        public static string ConvertAsciiToHex(String asciiString)
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in asciiString)
            {
                sb.AppendFormat("{0:X2}", (int)c);
            }

            return sb.ToString().Trim();
        }

        /// <summary>
        /// Converts "509" into {"0x01",  "0xFD"}
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] ConvertIntToByteArray(int value, int len)
        {
            //var len = (value.ToString().Length / 2) + (value.ToString().Length % 2);
            byte[] returnValue = new byte[len];
            returnValue[1] = (byte)(value % 0x100);
            returnValue[0] = (byte)((value - (int)returnValue[1]) / 0x100);
            return returnValue;
        }

        /// <summary>
        /// Converts "509" into {"0x01",  "0xFD"}
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] ConvertIntToAsciiByteArray(int value, int len)
        {
            //var len = (value.ToString().Length / 2) + (value.ToString().Length % 2);
            byte[] byteArray = StringToByte(value.ToString().PadLeft(len, '0')); ;

            return byteArray;
        }

        public static string FillTheBlankAndConvertString(List<string> val, int valLength, bool isErrorMessage)
        {
            List<string> filledData = new List<string>();
            foreach (var item in val)
            {
                if (isErrorMessage)
                filledData.Add(ASCII2HEX(item.PadRight(valLength), true));
                else
                filledData.Add("01" + ASCII2HEX(item.PadRight(valLength), true));
            }
            string valStr = string.Join("", filledData);
            return valStr;
        }
        public static string FillLengthAndGenericConvertString(List<KeyValuePair<int, string>> val)
        {
            List<string> filledData = new List<string>();
            foreach (var item in val)
            {
                filledData.Add(ConvertBcdToHex(item.Key) + ASCII2HEX(item.Value.PadRight(item.Key)));
            }
            string valStr = string.Join("", filledData);
            return valStr;
        }
        public static string FillLengthAndConvertString(List<string> val)
        {
            List<string> filledData = new List<string>();
            filledData.Add(val.FirstOrDefault().PadRight(50));
            filledData.Add(FillZeroToValue(val.Skip(1).First(), 50));
            filledData.Add(val.Last());
            string valStr = string.Join("", filledData);
            return valStr;
        }
        public static string FillZeroToValue(string val, int len)
        {
            string result = string.Empty;
            for (int i = val.Length; i < len; i++)
            {
                result += "0";
            }
            result += val;

            return result;
        }
        public static string ConvertBcdToHex(int length)
        {
            byte[] valLengthBytes = StringToBcd(length.ToString("0000"));
            StringBuilder valLengthBytesStr = new StringBuilder();
            for (int i = 0; i < valLengthBytes.Length; i++)
            {
                valLengthBytesStr.Append(valLengthBytes[i].ToString("x2"));
            }
            return valLengthBytesStr.ToString();
        }
        public static string ConvertBcdToHex2(int length)
        {
            byte[] valLengthBytes = StringToBcd(length.ToString("00"));
            StringBuilder valLengthBytesStr = new StringBuilder();
            for (int i = 0; i < valLengthBytes.Length; i++)
            {
                valLengthBytesStr.Append(valLengthBytes[i].ToString("x2"));
            }
            return valLengthBytesStr.ToString();
        }
        public static string? ConvertListDataToIsoMultiTlv(int valLength, int valCount, List<string> val, bool isErrorMessage = true)
        {
            string data = string.Empty;
            if (valCount != val.Count())
            {
                Trace.TraceError("CreateMultiTLVIsoMessage failure.[{0},{1}]", valCount, val.Count());
                return null;
            }

            string valHexStr = FillTheBlankAndConvertString(val, valLength, isErrorMessage);
            if (!isErrorMessage)
                valLength += 1;
            string valLengthStr = ConvertBcdToHex(valLength);
            string valCountStr = ConvertBcdToHex(valCount);
            data += valCountStr + valLengthStr + valHexStr;
            return data;
        }
        public static List<string>? ConvertIsoMultiTLVToListData(string data)
        {
            byte[] dataBytes = Encoding.ASCII.GetBytes(data);

            var hexTotalValCountLen = Encoding.ASCII.GetString(dataBytes.Take(4).ToArray());
            int totalValCountLen = int.Parse(hexTotalValCountLen);

            var hexValCountLen = Encoding.ASCII.GetString(dataBytes.Skip(4).Take(4).ToArray());
            int valCountLen = int.Parse(hexValCountLen);

            var hexValLen = Encoding.ASCII.GetString(dataBytes.Skip(8).Take(4).ToArray());
            int valLen = int.Parse(hexValLen);

            var hexData = Encoding.ASCII.GetString(dataBytes.Skip(12).ToArray());
            string convertedData = HEX2ASCII(hexData);

            List<string> dataList = SplitByLength(convertedData, valLen).ToList();
            if (dataList.Count != valCountLen)
            {
                System.Diagnostics.Trace.TraceError("ConvertDataTLVToDataList failure.[{0},{1}]", valCountLen, dataList.Count());
                return null;
            }

            return dataList;
        }
        public static List<string> ConvertAsciiTLVToListData(string data)
        {
            byte[] dataBytes = Encoding.ASCII.GetBytes(data);
            List<string> returnObj = new List<string>();
            var uid = System.Text.Encoding.ASCII.GetString(dataBytes.Take(100).ToArray());
            returnObj.Add(HEX2ASCII(uid).Trim());

            var trnxid = System.Text.Encoding.ASCII.GetString(dataBytes.Skip(100).Take(100).ToArray());
            returnObj.Add(HEX2ASCII(trnxid).Trim());

            var stage = System.Text.Encoding.ASCII.GetString(dataBytes.Skip(200).Take(2).ToArray());
            returnObj.Add(stage.Trim());

            return returnObj;
        }

        public static List<KeyValuePair<int, string>> ConvertAsciiTLVToGenericListData(string data)
        {
            List<KeyValuePair<int, string>> returnObj = new List<KeyValuePair<int, string>>();
            byte[] dataBytes = Encoding.ASCII.GetBytes(data);
            var hexValLength = System.Text.Encoding.ASCII.GetString(dataBytes.Skip(4).Take(4).ToArray());
            int valLength = int.Parse(hexValLength);
            int firstValLen = 0;
            int index = 2;
            while (dataBytes.Length >= ((4 * index) + firstValLen) + (valLength * 2))
            {
                var obj = System.Text.Encoding.ASCII.GetString(dataBytes.Skip((4 * index) + firstValLen).Take(valLength * 2).ToArray());
                returnObj.Add(new KeyValuePair<int, string>(valLength, HEX2ASCII(obj).Trim()));
                if (dataBytes.Length != ((4 * index) + firstValLen) + (valLength * 2))
                {
                    firstValLen += valLength * 2;

                    hexValLength = System.Text.Encoding.ASCII.GetString(dataBytes.Skip((4 * index) + firstValLen).Take(4).ToArray());
                    valLength = int.Parse(hexValLength);

                    index++;
                }
                else
                    firstValLen++;
            }
            return returnObj;
        }
        public static string ConvertTLVToListGenericDataToAscii(List<KeyValuePair<int, string>> dataList)
        {
            string data = string.Empty;

            string valHexStr = FillLengthAndGenericConvertString(dataList);
            data = ConvertBcdToHex((dataList.Count)) + valHexStr;
            return data.ToUpper();
        }
        public static List<T> ParseMultiTlvToGenericStruct<T>(List<KeyValuePair<int, string>> dataList, T strct)
        {
            List<T> returnObj = new List<T>();
            int index = 1;
            while (index < dataList.Count())
            {
                dynamic exo = new System.Dynamic.ExpandoObject();
                foreach (var field in GetProperties(strct))
                {
                    ((IDictionary<String, Object>)exo).Add(field.Name, dataList.Skip(index - 1).Take(index).FirstOrDefault().Value);
                    index++;
                }
                T obj = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(exo));
                returnObj.Add(obj);
            }
            return returnObj;
        }

        public static List<string> ParseMultiTlvToGenericStruct(List<KeyValuePair<int, string>> dataList)
        {
            List<string> returnObj = new List<string>();
            foreach (var item in dataList)
            {
                returnObj.Add(item.Value);
            }
            return returnObj;
        }




        public static string ConvertTLVToListDataToAscii(List<string> dataList)
        {
            string data = string.Empty;

            string valHexStr = FillLengthAndConvertString(dataList);

            string totalLenStr = ConvertBcdToHex((valHexStr.Length / 2));
            data = totalLenStr + valHexStr;

            return data.ToUpper();
        }
        public static string HEX2ASCII(string hex)
        {
            string res = String.Empty;
            for (int a = 0; a < hex.Length; a = a + 2)
            {
                string Char2Convert = hex.Substring(a, 2);
                int n = Convert.ToInt32(Char2Convert, 16);
                char c = (char)n;
                res += c.ToString();
            }
            return res;
        }
        public static string ASCII2HEX(string ascii)
        {
            byte[] valBytes = Encoding.Default.GetBytes(ascii);
            StringBuilder valBytesStr = new StringBuilder();
            for (int i = 0; i < valBytes.Length; i++)
            {
                valBytesStr.Append(valBytes[i].ToString("x2"));
            }
            return valBytesStr.ToString();
        }
        public static string ASCII2HEX(string ascii, Encoding encoding)
        {
            byte[] valBytes = encoding.GetBytes(ascii);
            StringBuilder valBytesStr = new StringBuilder();
            for (int i = 0; i < valBytes.Length; i++)
            {
                valBytesStr.Append(valBytes[i].ToString("x2"));
            }
            return valBytesStr.ToString();
        }
        public static string ASCII2HEX(string ascii, bool turkishSupport)
        {
            if (!turkishSupport)
            {
                return ASCII2HEX(ascii);
            }

            Dictionary<char, byte> turkishMapper = new Dictionary<char, byte>
            {
                {'�', 0xFD}, {'�', 0xF0}, {'�', 0xFC}, {'�', 0xFE}, {'�', 0xF6}, {'�', 0xE7},
                {'�', 0xDD}, {'�', 0xD0}, {'�', 0xDC}, {'�', 0xDE}, {'�', 0xD6}, {'�', 0xC7}
            };

            StringBuilder valBytesStr = new StringBuilder();

            for (int i = 0; i < ascii.Length; i++)
            {
                valBytesStr.Append((turkishMapper.ContainsKey(ascii[i]) ? 
                    turkishMapper[ascii[i]] : 
                    Encoding.Latin1.GetBytes(ascii, i, 1)[0]).ToString("X2"));
            }
            return valBytesStr.ToString();
        }

        public static IEnumerable<string> SplitByLength(string str, int maxLength)
        {
            for (int index = 0; index < str.Length; index += maxLength / 2)
            {
                yield return str.Substring(index, Math.Min(maxLength / 2, str.Length - index));
            }
        }
        public static IEnumerable<string> SplitMessage(string str, int maxLength)
        {
            for (int index = 0; index < str.Length; index += maxLength)
            {
                yield return str.Substring(index, Math.Min(maxLength, str.Length - index));
            }
        }
        public static List<KeyValuePair<int, string>> ParseObjList<T>(List<T> dataList)
        {
            List<KeyValuePair<int, string>> returnObj = new List<KeyValuePair<int, string>>();
            foreach (var item in dataList)
            {
                if (typeof(T) == typeof(String))
                {
                    returnObj.Add(new KeyValuePair<int, string>(item.ToString().Length, item.ToString()));
                }
                else
                {

                    foreach (var field in GetProperties(item))
                    {
                        if (field.GetValue(item) != null)
                            returnObj.Add(new KeyValuePair<int, string>(field.GetValue(item).ToString().Length, field.GetValue(item).ToString()));
                    }

                }
            }
            return returnObj;
        }

        public static List<string> ParseObjList<T>(List<T> dataList, int len)
        {
            List<string> returnObj = new List<string>();
            foreach (var item in dataList)
            {
                string oneStringVal = string.Empty;
                foreach (var field in GetProperties(item))
                {
                    oneStringVal += field.GetValue(item).ToString().PadRight(len);
                }
                returnObj.Add(oneStringVal);
            }
            return returnObj;
        }
        public static List<T> ParseMultiTlvToStruct<T>(List<string> dataList, T strct, int propLen)
        {
            List<T> returnObj = new List<T>();
            foreach (var item in dataList)
            {
                IEnumerable<string> itemData = SplitByLength(item, propLen);
                dynamic exo = new System.Dynamic.ExpandoObject();
                int index = 0;
                foreach (var field in GetProperties(strct))
                {
                    ((IDictionary<String, Object>)exo).Add(field.Name, itemData.ToList().Skip(index).Take(1).FirstOrDefault());
                    index++;
                }
                T obj = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(exo));
                returnObj.Add(obj);
            }
            return returnObj;
        }

        public static List<string> ParseMultiTlvToStruct<T>(List<T> dataList)
        {
            List<string> returnObj = new List<string>();
            foreach (var item in dataList)
            {
                string oneStringVal = string.Empty;
                foreach (var field in GetProperties(item))
                {
                    oneStringVal += field.GetValue(item);
                }
                returnObj.Add(oneStringVal);
            }
            return returnObj;
        }
        private static PropertyInfo[] GetProperties(object obj)
        {
            return obj.GetType().GetProperties();
        }
        private static byte[] _HexChars = new byte[]
                                              {
                                                  0x30, 0x31, 0x32, 0x33,
                                                  0x34, 0x35, 0x36, 0x37,
                                                  0x38, 0x39, 0x41, 0x42,
                                                  0x43, 0x44, 0x45, 0x46
                                              };

        public static byte[] ConversionTableAscii437ToEbcdic500 = {
                                                                      0x00, 0x01, 0x02, 0x03, 0x37, 0x2D, 0x2E, 0x2F,
                                                                      0x16, 0x05, 0x25, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                                                                      0x10, 0x11, 0x12, 0x13, 0x3C, 0x3D, 0x32, 0x26,
                                                                      0x18, 0x19, 0x3F, 0x27, 0x1C, 0x1D, 0x1E, 0x1F,
                                                                      0x40, 0x5A, 0x7F, 0x7B, 0x5B, 0x6C, 0x50, 0x7D,
                                                                      0x4D, 0x5D, 0x5C, 0x4E, 0x6B, 0x60, 0x4B, 0x61,
                                                                      0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
                                                                      0xF8, 0xF9, 0x7A, 0x5E, 0x4C, 0x7E, 0x6E, 0x6F,
                                                                      0x7C, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
                                                                      0xC8, 0xC9, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
                                                                      0xD7, 0xD8, 0xD9, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6,
                                                                      0xE7, 0xE8, 0xE9, 0x4A, 0xE0, 0x4F, 0x5F, 0x6D,
                                                                      0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
                                                                      0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
                                                                      0x97, 0x98, 0x99, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
                                                                      0xA7, 0xA8, 0xA9, 0xC0, 0x6A, 0xD0, 0xA1, 0x07,
                                                                      0x20, 0x21, 0x22, 0x23, 0x24, 0x15, 0x06, 0x17,
                                                                      0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x09, 0x0A, 0x1B,
                                                                      0x30, 0x31, 0x1A, 0x33, 0x34, 0x35, 0x36, 0x08,
                                                                      0x38, 0x39, 0x3A, 0x3B, 0x04, 0x14, 0x3E, 0xE1,
                                                                      0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
                                                                      0x49, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
                                                                      0x58, 0x59, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
                                                                      0x68, 0x69, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75,
                                                                      0x76, 0x77, 0x78, 0x80, 0x8A, 0x8B, 0x8C, 0x8D,
                                                                      0x8E, 0x8F, 0x90, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E,
                                                                      0x9F, 0xA0, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
                                                                      0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
                                                                      0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF,
                                                                      0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xDA, 0xDB,
                                                                      0xDC, 0xDD, 0xDE, 0xDF, 0xEA, 0xEB, 0xEC, 0xED,
                                                                      0xEE, 0xEF, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF
                                                                  };

        public static byte[] ConversionTableEbcdic500ToAscii437 = {
                                                                      0x00, 0x01, 0x02, 0x03, 0x9C, 0x09, 0x86, 0x7F,
                                                                      0x97, 0x8D, 0x8E, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                                                                      0x10, 0x11, 0x12, 0x13, 0x9D, 0x85, 0x08, 0x87,
                                                                      0x18, 0x19, 0x92, 0x8F, 0x1C, 0x1D, 0x1E, 0x1F,
                                                                      0x80, 0x81, 0x82, 0x83, 0x84, 0x0A, 0x17, 0x1B,
                                                                      0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x05, 0x06, 0x07,
                                                                      0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,
                                                                      0x98, 0x99, 0x9A, 0x9B, 0x14, 0x15, 0x9E, 0x1A,
                                                                      0x20, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
                                                                      0xA7, 0xA8, 0x5B, 0x2E, 0x3C, 0x28, 0x2B, 0x5D,
                                                                      0x26, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
                                                                      0xB0, 0xB1, 0x21, 0x24, 0x2A, 0x29, 0x3B, 0x5E,
                                                                      0x2D, 0x2F, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
                                                                      0xB8, 0xB9, 0x7C, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
                                                                      0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1,
                                                                      0xC2, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
                                                                      0xC3, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
                                                                      0x68, 0x69, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
                                                                      0xCA, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
                                                                      0x71, 0x72, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0,
                                                                      0xD1, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
                                                                      0x79, 0x7A, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
                                                                      0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
                                                                      0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
                                                                      0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
                                                                      0x48, 0x49, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED,
                                                                      0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
                                                                      0x51, 0x52, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3,
                                                                      0x5C, 0x9F, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
                                                                      0x59, 0x5A, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9,
                                                                      0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
                                                                      0x38, 0x39, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF
                                                                  };

        public static byte[] ConversionTableEbcdic037ToAscii437 = {
                                                                      0x00, 0x01, 0x02, 0x03, 0x07, 0x09, 0x07, 0x7F,
                                                                      0x07, 0x07, 0x07, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                                                                      0x10, 0x11, 0x12, 0x13, 0x07, 0x0A, 0x08, 0x07,
                                                                      0x18, 0x19, 0x07, 0x07, 0x07, 0x07, 0x07, 0x07,
                                                                      0x07, 0x07, 0x1C, 0x07, 0x07, 0x0A, 0x17, 0x1B,
                                                                      0x07, 0x07, 0x07, 0x07, 0x07, 0x05, 0x06, 0x07,
                                                                      0x07, 0x07, 0x16, 0x07, 0x07, 0x07, 0x07, 0x04,
                                                                      0x07, 0x07, 0x07, 0x07, 0x14, 0x15, 0x07, 0x1A,
                                                                      0x20, 0xFF, 0x83, 0x84, 0x85, 0xA0, 0x07, 0x86,
                                                                      0x87, 0xA4, 0x9B, 0x2E, 0x3C, 0x28, 0x2B, 0x7C,
                                                                      0x26, 0x82, 0x88, 0x89, 0x8A, 0xA1, 0x8C, 0x07,
                                                                      0x8D, 0xE1, 0x21, 0x24, 0x2A, 0x29, 0x3B, 0xAA,
                                                                      0x2D, 0x2F, 0x07, 0x8E, 0x07, 0x07, 0x07, 0x8F,
                                                                      0x80, 0xA5, 0x07, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
                                                                      0x07, 0x90, 0x07, 0x07, 0x07, 0x07, 0x07, 0x07,
                                                                      0x70, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
                                                                      0x07, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
                                                                      0x68, 0x69, 0xAE, 0xAF, 0x07, 0x07, 0x07, 0xF1,
                                                                      0xF8, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
                                                                      0x71, 0x72, 0xA6, 0xA7, 0x91, 0x07, 0x92, 0x07,
                                                                      0xE6, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
                                                                      0x79, 0x7A, 0xAD, 0xAB, 0x07, 0x07, 0x07, 0x07,
                                                                      0x5E, 0x9C, 0x9D, 0xFA, 0x07, 0x07, 0x07, 0xAC,
                                                                      0xAB, 0x07, 0x5B, 0x5D, 0x07, 0x07, 0x07, 0x07,
                                                                      0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
                                                                      0x48, 0x49, 0x07, 0x93, 0x94, 0x95, 0xA2, 0x07,
                                                                      0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
                                                                      0x51, 0x52, 0x07, 0x96, 0x81, 0x97, 0xA3, 0x98,
                                                                      0x5C, 0xF6, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
                                                                      0x59, 0x5A, 0xFD, 0x07, 0x99, 0x07, 0x07, 0x07,
                                                                      0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
                                                                      0x38, 0x39, 0x07, 0x07, 0x9A, 0x07, 0x07, 0x07
                                                                  };

        public static byte[] ConversionTableAscii437ToEbcdic037 = {
                                                                      0x00, 0x01, 0x02, 0x03, 0x37, 0x2D, 0x2E, 0x2F,
                                                                      0x16, 0x05, 0x15, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                                                                      0x10, 0x11, 0x12, 0x13, 0x3C, 0x3D, 0x32, 0x26,
                                                                      0x18, 0x19, 0x3F, 0x27, 0x22, 0x1D, 0x1E, 0x1F,
                                                                      0x40, 0x5A, 0x7F, 0x7B, 0x5B, 0x6C, 0x50, 0x7D,
                                                                      0x4D, 0x5D, 0x5C, 0x4E, 0x6B, 0x60, 0x4B, 0x61,
                                                                      0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
                                                                      0xF8, 0xF9, 0x7A, 0x5E, 0x4C, 0x7E, 0x6E, 0x6F,
                                                                      0x7C, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
                                                                      0xC8, 0xC9, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
                                                                      0xD7, 0xD8, 0xD9, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6,
                                                                      0xE7, 0xE8, 0xE9, 0xBA, 0xE0, 0xBB, 0xB0, 0x6D,
                                                                      0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
                                                                      0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
                                                                      0x97, 0x98, 0x99, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
                                                                      0xA7, 0xA8, 0xA9, 0xC0, 0x4F, 0xD0, 0xA1, 0x07,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x59, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F, 0x3F,
                                                                      0x90, 0x3F, 0x3F, 0x3F, 0x3F, 0xEA, 0x3F, 0xFF
                                                                  };
    }
}
